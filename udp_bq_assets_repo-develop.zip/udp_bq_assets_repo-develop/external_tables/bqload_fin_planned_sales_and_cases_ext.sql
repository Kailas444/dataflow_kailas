CREATE OR REPLACE EXTERNAL TABLE `raw_layer.fin_planned_sales_and_cases_ext`
(
  plan_type STRING OPTIONS(DESCRIPTION='Plan Type'),
  plan_account_desc STRING OPTIONS(DESCRIPTION='Account Description'),
  fiscal_week_end_date STRING OPTIONS(DESCRIPTION='Fiscal Week End Date in Format MM/DD/YY'),
  business_unit STRING OPTIONS(DESCRIPTION='Plan Business Unit'),
  department STRING OPTIONS(DESCRIPTION='Department'),
  product STRING OPTIONS(DESCRIPTION='Product'),
  location STRING OPTIONS(DESCRIPTION='Plan Location Number'),
  plan_cust_group_num STRING OPTIONS(DESCRIPTION='Plan Customer Group Number'),
  sales_amt_or_cases STRING OPTIONS(DESCRIPTION='Total Planned Sales Amount and Cases')
)
OPTIONS (
  DESCRIPTION='Finance Planned Sales and Cases for Fiscal Year',
  format = 'CSV',
  uris = ['gs://${{BUCKET_URI}}/MFT/finance/hyperion/budget/weekly_daily05_*.txt'],
  field_delimiter = '\t',
  max_bad_records = 0,
  skip_leading_rows = 1
);
