CREATE OR REPLACE EXTERNAL TABLE `raw_layer.retail_intel_weekly_sales_spins_ext`
(
  retailer STRING OPTIONS(description='Retailer Name'),
  units STRING OPTIONS(description='Sales Units'),
  store STRING OPTIONS(description='Store Name'),
  storeid STRING OPTIONS(description='SPINS Store ID'),
  department STRING OPTIONS(description='SPINS Department Name'),
  enddate STRING OPTIONS(description='Week End Date - Sunday'),
  brand STRING OPTIONS(description='SPINS Product Brand Name'),
  category STRING OPTIONS(description='SPINS Product Category Name'),
  subcategory STRING OPTIONS(description='SPINS Product Sub Category Name'),
  upc STRING OPTIONS(description='Product UPC Code'),
  reportinglevel STRING OPTIONS(description='Weekly SPINS Aggregation by UPC'),
  numberofweeks STRING OPTIONS(description='Number of Weeks to Aggregate'),
  dollars STRING OPTIONS(description='Sales Dollars'),
  dollarsnonpromotion STRING OPTIONS(description='Sales Dollars with No Promotions'),
  dollarspromotion STRING OPTIONS(description='Sales Dollars with Promotions'),
  unitsnonpromotion STRING OPTIONS(description='Sales Units with No Promotions'),
  unitspromotion STRING OPTIONS(description='Sales Units with Promotions'),
  isfilldata STRING OPTIONS(description='Boolean Is Fill Data'),
)
OPTIONS(
  description="SPINS Weekly Raw Sales data ",
  allow_quoted_newlines=true,
  skip_leading_rows=1,
  format="CSV",
  quote ='"',  
  uris=["gs://${BUCKET_URI}/retail/spins/spins_weekly_store_*.csv"]
);
