DROP SCHEMA IF EXISTS retail_silver;
DROP SCHEMA IF EXISTS  gu_silver;

CREATE TABLE `retail_sales_silver.fact_weekly_store_sales_by_item`
LIKE `retail_intel_silver.fact_weekly_store_sales_by_item`
AS SELECT * FROM `retail_intel_silver.fact_weekly_store_sales_by_item`;

DROP SCHEMA IF EXISTS retail_intel_silver;
