DROP TABLE `raw_layer.retail_sales_pos_gu`;
DROP TABLE `raw_layer.retail_sales_pos_pwsc`;
