DELETE 
FROM   `gc-proj-udp-prd-c082.finance_silver.fact_sales_by_account`
WHERE   sales_entry_date > '2025-05-10';