insert into `gc-proj-udp-prd-c082.lake_layer.retail_intel_weekly_sales_spins`
select * from `gc-proj-udp-dev-54a3.lake_layer.retail_intel_weekly_sales_spins`;