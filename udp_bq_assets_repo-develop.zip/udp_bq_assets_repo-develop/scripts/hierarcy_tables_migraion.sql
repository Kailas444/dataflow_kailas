insert into `gc-proj-udp-prd-c082.master_silver.dim_location_hierarchy`
select * from `gc-proj-udp-dev-54a3.master_silver.dim_location_hierarchy`;
 --291 Rows Inserted

insert into `gc-proj-udp-prd-c082.master_silver.dim_product_hierarchy`
select * from `gc-proj-udp-dev-54a3.master_silver.dim_product_hierarchy`;
--3650410 Rows Inserted

insert into `gc-proj-udp-prd-c082.master_silver.dim_customer_hierarchy`
select * from `gc-proj-udp-dev-54a3.master_silver.dim_customer_hierarchy`;
--47226 Rows Inserted