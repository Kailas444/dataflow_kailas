TRUNCATE TABLE `gc-proj-udp-prd-c082.retail_sales_silver.fact_pos_header`;
-----truncating the silver table of header

TRUNCATE TABLE `gc-proj-udp-prd-c082.retail_sales_silver.fact_pos_line`;
-----truncating the silver table of line

TRUNCATE TABLE `gc-proj-udp-prd-c082.retail_sales_silver.fact_pos_tender`;
-----truncating the silver table of tender

TRUNCATE TABLE `gc-proj-udp-prd-c082.lake_layer.retail_sales_pos_gu`;
-----truncating the lake table for GU

TRUNCATE TABLE `gc-proj-udp-prd-c082.lake_layer.retail_sales_pos_pwsc`;
-----truncating the lake table for PWSC
