truncate table `gc-proj-udp-prd-c082.master_silver.dim_customer_hierarchy`;

insert into `gc-proj-udp-prd-c082.master_silver.dim_customer_hierarchy`
select * from `gc-proj-udp-dev-54a3.master_silver.dim_customer_hierarchy`;
--47226 Rows Inserted