INSERT INTO `gc-proj-udp-prd-c082.lake_layer.wholesale_slot_inventory_exabi`
select * from `gc-proj-udp-dev-54a3.lake_layer.wholesale_slot_inventory_exabi`
