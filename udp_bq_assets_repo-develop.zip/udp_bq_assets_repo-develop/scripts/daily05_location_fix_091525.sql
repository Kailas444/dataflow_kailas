DROP TABLE `master_silver.dim_location`;

CREATE OR REPLACE TABLE `master_silver.dim_location`
(
    whse_id INT64 OPTIONS(description="Warehouse ID"),
    warehouse_name STRING OPTIONS(description="Warehouse or EBS Organization Name"),
    organization_id INT64 OPTIONS(description="Organization Identifier"),
    organization_cde STRING OPTIONS(description="Organization Code"),
    organization_name STRING OPTIONS(description="Organization Name"),
    gl_location_name STRING OPTIONS(description="GL Location Name"),
    division_id INT64 OPTIONS(description="Division ID"),
    gl_location_cde STRING OPTIONS(description="GL Location Code"),
    hyperion_warehouse_num STRING OPTIONS(description="Hyperion Warehouse num"),
    ebs_warehouse_id INT64 OPTIONS(description="EBS Warehouse Number"),
    wms_warehouse_num INT64 OPTIONS(description="WMS Warehouse Number"),
    hr_location_num STRING OPTIONS(description="HR location"),
    hr_location_heirarchy STRING OPTIONS(description="HR hierarchy"),
    company_name STRING OPTIONS(description="Company name"),
    warehouse_type STRING OPTIONS(description="Warehouse type"),
    warehouse_status STRING OPTIONS(description="Warehouse status"),
    gl_site_id INT64 OPTIONS(description="GL Location Site"),
    campus_id INT64 OPTIONS(description="Campus ID"),    
    campus_name STRING OPTIONS(description="Campus name"),
    warehouse_address_1 STRING OPTIONS(description="Address line 1"),
    warehouse_address_2 STRING OPTIONS(description="Address line 2"),
    warehouse_address_3 STRING OPTIONS(description="Address line 3"),
    warehouse_city STRING OPTIONS(description="City"),
    warehouse_state STRING OPTIONS(description="State"),
    warehouse_zipcode STRING OPTIONS(description="Zipcode"),
    warehouse_latitude STRING OPTIONS(description="Latitude"),
    warehouse_longitude STRING OPTIONS(description="Longitude"),
    capacity_in_cases NUMERIC OPTIONS(description="Case capacity"),
    min_open_holes_target NUMERIC OPTIONS(description="Open holes target"),
    sq_footage NUMERIC OPTIONS(description="Square footage"),
    receiving_docks_num NUMERIC OPTIONS(description="Receiving docks"),
    shipping_docks_num NUMERIC OPTIONS(description="Shipping docks"),
    first_dispatch_time STRING OPTIONS(description="First dispatch"),
    last_dispatch_time STRING OPTIONS(description="Last dispatch"),
    trans_provider_name STRING OPTIONS(description="Transport provider"),
    fac_union_or_no_flag STRING OPTIONS(description="Union flag"),
    fac_wms_system STRING OPTIONS(description="WMS system"),
    fac_lift_system STRING OPTIONS(description="Lift system"),
    fac_lift_standards STRING OPTIONS(description="Lift standards"),
    fac_selection_type STRING OPTIONS(description="Selection type"),
    wp_yms_system STRING OPTIONS(description="YMS system"),
    wp_time_n_atendnc_sys STRING OPTIONS(description="Time attendance"),
    wp_whs_in_box STRING OPTIONS(description="WHS in box"),
    number_of_selectors NUMERIC OPTIONS(description="Selectors count"),
    number_of_buildings NUMERIC OPTIONS(description="Building count"),
    number_of_aisles NUMERIC OPTIONS(description="Aisle count"),
    number_of_server_roomsmdfs NUMERIC OPTIONS(description="Server rooms"),
    number_of_shipping_offices NUMERIC OPTIONS(description="Shipping offices"),
    number_of_receiving_offices NUMERIC OPTIONS(description="Receiving offices"),
    number_of_main_entry_areas NUMERIC OPTIONS(description="Main entries"),
    lease_end_dt DATETIME OPTIONS(description="Lease end date"),
    wms_invoice_site STRING OPTIONS(description="Invoice site"),
    total_reserve_slots NUMERIC OPTIONS(description="Reserve slots"),
    total_pick_slots NUMERIC OPTIONS(description="Pick slots"),
    total_pallet_locations NUMERIC OPTIONS(description="Pallet locations"),
    avg_cases_per_pallet NUMERIC OPTIONS(description="Avg cases/pallet"),
    total_capacity_in_cases NUMERIC OPTIONS(description="Total capacity"),
    total_rcti NUMERIC OPTIONS(description="Total RCTI"),
    sun_ship_day_start_end STRING OPTIONS(description="Sun ship day"),
    sun_ship_night_start_end STRING OPTIONS(description="Sun ship night"),
    sun_rec_day_start_end STRING OPTIONS(description="Sun receive day"),
    sun_rec_night_start_end STRING OPTIONS(description="Sun receive night"),
    mon_ship_day_start_end STRING OPTIONS(description="Mon ship day"),
    mon_ship_night_start_end STRING OPTIONS(description="Mon ship night"),
    mon_rec_day_start_end STRING OPTIONS(description="Mon receive day"),
    mon_rec_night_start_end STRING OPTIONS(description="Mon receive night"),
    tues_ship_day_start_end STRING OPTIONS(description="Tue ship day"),
    tues_ship_night_start_end STRING OPTIONS(description="Tue ship night"),
    tues_rec_day_start_end STRING OPTIONS(description="Tue receive day"),
    tues_rec_night_start_end STRING OPTIONS(description="Tue receive night"),
    wed_ship_day_start_end STRING OPTIONS(description="Wed ship day"),
    wed_ship_night_start_end STRING OPTIONS(description="Wed ship night"),
    wed_rec_day_start_end STRING OPTIONS(description="Wed receive day"),
    wed_rec_night_start_end STRING OPTIONS(description="Wed receive night"),
    thur_ship_day_start_end STRING OPTIONS(description="Thu ship day"),
    thur_ship_night_start_end STRING OPTIONS(description="Thu ship night"),
    thur_rec_day_start_end STRING OPTIONS(description="Thu receive day"),
    thur_rec_night_start_end STRING OPTIONS(description="Thu receive night"),
    fri_ship_day_start_end STRING OPTIONS(description="Fri ship day"),
    fri_ship_night_start_end STRING OPTIONS(description="Fri ship night"),
    fri_rec_day_start_end STRING OPTIONS(description="Fri receive day"),
    fri_rec_night_start_end STRING OPTIONS(description="Fri receive night"),
    sat_ship_day_start_end STRING OPTIONS(description="Sat ship day"),
    sat_ship_night_start_end STRING OPTIONS(description="Sat ship night"),
    sat_rec_day_start_end STRING OPTIONS(description="Sat receive day"),
    sat_rec_night_start_end STRING OPTIONS(description="Sat receive night"),
    audit_created_ts DATETIME DEFAULT CURRENT_DATETIME(),
    audit_updated_ts DATETIME DEFAULT CURRENT_DATETIME(),
    PRIMARY KEY (whse_id) NOT ENFORCED
)
OPTIONS(
  description="C&S Warehouse Location Dimension"
);

insert into `lake_layer.wholesale_mf_gl_site_mapping`
select * from `gc-proj-udp-dev-54a3.lake_layer.wholesale_mf_gl_site_mapping`;

insert into `lake_layer.fin_ebs_daily05_sales`
select * from `lake_layer.fin_daily05_sales`;

drop table IF EXISTS `lake_layer.fin_daily05_sales`;

insert into `lake_layer.fin_mf_daily05_sales`
select * from `lake_layer.fin_daily05_mf_sales`;

drop table IF EXISTS `lake_layer.fin_daily05_mf_sales`;
