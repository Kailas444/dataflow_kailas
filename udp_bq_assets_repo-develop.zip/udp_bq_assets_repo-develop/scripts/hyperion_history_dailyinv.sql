INSERT INTO `gc-proj-udp-prd-c082.finance_silver.fact_inventory_by_department`
SELECT * FROM `gc-proj-udp-dev-54a3.finance_silver.fact_inventory_by_department`
WHERE inventory_date <= '2025-06-07';
