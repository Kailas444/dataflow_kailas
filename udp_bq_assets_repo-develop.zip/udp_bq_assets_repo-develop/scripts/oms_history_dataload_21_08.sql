INSERT INTO `gc-proj-udp-prd-c082.lake_layer.wholesale_sales_invoice_header_oms`
SELECT * FROM `gc-proj-udp-dev-54a3.lake_layer.wholesale_sales_invoice_header_oms`;
--2027909 Rows

INSERT INTO `gc-proj-udp-prd-c082.lake_layer.wholesale_sales_invoice_line_oms`
SELECT * FROM `gc-proj-udp-dev-54a3.lake_layer.wholesale_sales_invoice_line_oms`;
--107288629 Rows

INSERT INTO `gc-proj-udp-prd-c082.lake_layer.wholesale_sales_order_header_oms`
SELECT * FROM `gc-proj-udp-dev-54a3.lake_layer.wholesale_sales_order_header_oms`;
--4350678 Rows

INSERT INTO `gc-proj-udp-prd-c082.lake_layer.wholesale_sales_order_lines_oms`
SELECT * FROM `gc-proj-udp-dev-54a3.lake_layer.wholesale_sales_order_lines_oms`;
--Rows 74591087

INSERT INTO `gc-proj-udp-prd-c082.lake_layer.wholesale_sales_return_header_oms`
SELECT * FROM `gc-proj-udp-dev-54a3.lake_layer.wholesale_sales_return_header_oms`;

INSERT INTO `gc-proj-udp-prd-c082.lake_layer.wholesale_sales_return_line_oms`
SELECT * FROM `gc-proj-udp-dev-54a3.lake_layer.wholesale_sales_return_line_oms`;
--Rows 105991

INSERT INTO `gc-proj-udp-prd-c082.lake_layer.wholesale_sales_order_markouts_oms`
SELECT * FROM `gc-proj-udp-dev-54a3.lake_layer.wholesale_sales_order_markouts_oms`;
--11019885
