DELETE FROM `gc-proj-udp-prd-c082.raw_layer.retail_sales_pos_gu`
WHERE trans_date <= '09/17/2025';

DELETE FROM `gc-proj-udp-prd-c082.raw_layer.retail_sales_pos_pwsc`
WHERE trans_date <= '09/18/2025';

insert into `gc-proj-udp-prd-c082.raw_layer.retail_sales_pos_gu`
select * from `gc-proj-udp-dev-54a3.raw_layer.retail_sales_pos_gu`
where trans_date <='09/17/2025'

insert into `gc-proj-udp-prd-c082.raw_layer.retail_sales_pos_pwsc`
select * from `gc-proj-udp-dev-54a3.raw_layer.retail_sales_pos_pwsc`
where trans_date <='09/18/2025'
