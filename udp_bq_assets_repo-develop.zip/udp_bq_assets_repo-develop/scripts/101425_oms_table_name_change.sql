ALTER TABLE `gc-proj-udp-dev-54a3.sales_silver.fact_invoice_headers` RENAME TO `fact_invoice_header`;
ALTER TABLE `gc-proj-udp-dev-54a3.sales_silver.fact_invoice_lines` RENAME TO `fact_invoice_line`;
ALTER TABLE `gc-proj-udp-dev-54a3.raw_layer.wholesale_sales_invoice_header_oms` RENAME TO `wholesale_sales_invoice_header_csoms`;
ALTER TABLE `gc-proj-udp-dev-54a3.lake_layer.wholesale_sales_invoice_header_oms` RENAME TO `wholesale_sales_invoice_header_csoms`;
ALTER TABLE `gc-proj-udp-dev-54a3.raw_layer.wholesale_sales_invoice_line_oms` RENAME TO `wholesale_sales_invoice_line_csoms`;
ALTER TABLE `gc-proj-udp-dev-54a3.lake_layer.wholesale_sales_invoice_line_oms` RENAME TO `wholesale_sales_invoice_line_csoms`;

ALTER TABLE `gc-proj-udp-dev-54a3.lake_layer.wholesale_sales_order_markouts_oms` RENAME TO `wholesale_sales_order_markouts_csoms`;
ALTER TABLE `gc-proj-udp-dev-54a3.raw_layer.wholesale_sales_order_markouts_oms` RENAME TO `wholesale_sales_order_markouts_csoms`;
ALTER TABLE `gc-proj-udp-dev-54a3.sales_silver.fact_order_markouts` RENAME TO `fact_order_markout`;

ALTER TABLE `gc-proj-udp-dev-54a3.raw_layer.wholesale_sales_return_header_oms` RENAME TO `wholesale_sales_return_header_csoms`;
ALTER TABLE `gc-proj-udp-dev-54a3.raw_layer.wholesale_sales_return_line_oms` RENAME TO `wholesale_sales_return_line_csoms`;
ALTER TABLE `gc-proj-udp-dev-54a3.lake_layer.wholesale_sales_return_header_oms` RENAME TO `wholesale_sales_return_header_csoms`;
ALTER TABLE `gc-proj-udp-dev-54a3.lake_layer.wholesale_sales_return_line_oms` RENAME TO `wholesale_sales_return_line_csoms`;
ALTER TABLE `gc-proj-udp-dev-54a3.sales_silver.fact_return_headers` RENAME TO `fact_return_header`;
ALTER TABLE `gc-proj-udp-dev-54a3.sales_silver.fact_return_lines` RENAME TO `fact_return_line`;

ALTER TABLE `gc-proj-udp-dev-54a3.raw_layer.wholesale_sales_order_header_oms` RENAME TO `wholesale_sales_order_header_csoms`;
ALTER TABLE `gc-proj-udp-dev-54a3.raw_layer.wholesale_sales_order_lines_oms` RENAME TO `wholesale_sales_order_lines_csoms`;
ALTER TABLE `gc-proj-udp-dev-54a3.lake_layer.wholesale_sales_order_header_oms` RENAME TO `wholesale_sales_order_header_csoms`;
ALTER TABLE `gc-proj-udp-dev-54a3.lake_layer.wholesale_sales_order_lines_oms` RENAME TO `wholesale_sales_order_lines_csoms`;
ALTER TABLE `gc-proj-udp-dev-54a3.sales_silver.fact_order_headers` RENAME TO `fact_order_header`;
ALTER TABLE `gc-proj-udp-dev-54a3.sales_silver.fact_order_lines` RENAME TO `fact_order_line`;


