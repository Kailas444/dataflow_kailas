INSERT INTO `gc-proj-udp-prd-c082.udp_audit.warehouse_lookup`
SELECT * FROM `gc-proj-udp-dev-54a3.udp_audit.warehouse_lookup`
