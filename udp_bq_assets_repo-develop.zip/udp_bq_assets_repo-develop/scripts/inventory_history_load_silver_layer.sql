INSERT INTO `gc-proj-udp-prd-c082.warehouse_silver.fact_slot_inventory`
SELECT * from `gc-proj-udp-dev-54a3.warehouse_silver.fact_slot_inventory`
