insert into `gc-proj-udp-prd-c082.retail_intel_silver.fact_weekly_store_sales_by_item`
select * from `gc-proj-udp-dev-54a3.retail_intel_silver.fact_weekly_store_sales_by_item`;

insert into `gc-proj-udp-prd-c082.master_silver.spins_customer_lkp`
select * from `gc-proj-udp-dev-54a3.master_silver.spins_customer_lkp`;