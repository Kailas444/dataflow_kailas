truncate table `gc-proj-udp-prd-c082.master_silver.epm_to_hyperion_location_lkp`;
--78 Rows Truncate

insert into `gc-proj-udp-prd-c082.master_silver.epm_to_hyperion_location_lkp`
select * from `gc-proj-udp-dev-54a3.master_silver.epm_to_hyperion_location_lkp`;
--92 Rows Insert

delete
from   `gc-proj-udp-prd-c082.finance_silver.fact_sales_by_account`
where  sales_entry_date <= '2025-07-23';
--79533034 Rows Delete 

insert into `gc-proj-udp-prd-c082.finance_silver.fact_sales_by_account`
select * from `gc-proj-udp-dev-54a3.finance_silver.fact_sales_by_account`;
--99484969 Rows Insert

