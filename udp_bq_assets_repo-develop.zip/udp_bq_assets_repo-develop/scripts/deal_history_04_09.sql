INSERT INTO `gc-proj-udp-prd-c082.lake_layer.master_deal_types_ebs`
SELECT * FROM `gc-proj-udp-dev-54a3.lake_layer.master_deal_types_ebs`;
--2986587 Rows

INSERT INTO `gc-proj-udp-prd-c082.lake_layer.master_deals_ebs`
SELECT * FROM `gc-proj-udp-dev-54a3.lake_layer.master_deals_ebs`;
--91 Rows

INSERT INTO `gc-proj-udp-prd-c082.lake_layer.master_link_group_stores_ebs`
SELECT * FROM `gc-proj-udp-dev-54a3.lake_layer.master_link_group_stores_ebs`;
--159 Rows

INSERT INTO `gc-proj-udp-prd-c082.lake_layer.master_link_groups_ebs`
SELECT * FROM `gc-proj-udp-dev-54a3.lake_layer.master_link_groups_ebs`;
--Rows 10783

INSERT INTO `gc-proj-udp-prd-c082.lake_layer.master_plan_data_versions_ebs`
SELECT * FROM `gc-proj-udp-dev-54a3.lake_layer.master_plan_data_versions_ebs`;
--5561788 Rows 

INSERT INTO `gc-proj-udp-prd-c082.lake_layer.master_plan_store_versions_ebs`
SELECT * FROM `gc-proj-udp-dev-54a3.lake_layer.master_plan_store_versions_ebs`;
--Rows 12420601
