insert into `finance_silver.fact_planned_sales_by_cust_group`
select * from `gc-proj-udp-dev-54a3.finance_silver.fact_planned_sales_by_cust_group`