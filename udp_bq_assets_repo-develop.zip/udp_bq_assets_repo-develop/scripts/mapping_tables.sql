INSERT INTO `gc-proj-udp-prd-c082.master_silver.dim_calendar`
SELECT * FROM `gc-proj-udp-dev-54a3.master_silver.dim_calendar`;

INSERT INTO `gc-proj-udp-prd-c082.master_silver.dim_department`
SELECT * FROM `gc-proj-udp-dev-54a3.master_silver.dim_department`;

INSERT INTO `gc-proj-udp-prd-c082.master_silver.epm_to_hyperion_cust_group_lkp`
SELECT * FROM `gc-proj-udp-dev-54a3.master_silver.epm_to_hyperion_cust_group_lkp`;

INSERT INTO `gc-proj-udp-prd-c082.master_silver.epm_to_hyperion_location_lkp`
SELECT * FROM `gc-proj-udp-dev-54a3.master_silver.epm_to_hyperion_location_lkp`;
