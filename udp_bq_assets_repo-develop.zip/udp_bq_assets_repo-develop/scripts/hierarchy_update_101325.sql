UPDATE `master_silver.dim_customer_hierarchy`
SET    l2_chain_name = 'EAST COAST INDEPENDENTS'
WHERE  l2_chain_num IN ('51','98','27','2');

UPDATE `master_silver.dim_product_hierarchy` 
SET   l1_product_class = 'TOTAL PERISHABLE'
WHERE l1_product_class = 'TOTAL PERISH';

UPDATE `master_silver.dim_product_hierarchy` 
SET   l1_product_class = 'TOTAL FROZEN'
WHERE l1_product_class = 'Total Frozen';

INSERT INTO `master_silver.epm_to_hyperion_cust_group_lkp`
SELECT 'C1502_Input','C1502','1502'
UNION ALL 
SELECT 'C0066_Input','C1218','1218';
