CREATE SCHEMA `raw_layer`
OPTIONS(
  location="us",
  is_case_insensitive=false,
  max_time_travel_hours=168,
  description="Bronze Raw Layer - Schema Free Tables"
);