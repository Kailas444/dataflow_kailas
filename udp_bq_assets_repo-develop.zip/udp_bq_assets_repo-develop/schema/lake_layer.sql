CREATE SCHEMA `lake_layer`
OPTIONS(
  location="us",
  is_case_insensitive=false,
  max_time_travel_hours=168,
  description="Bronze Lake Layer - Tables are Schema Enforced same as Source System"
);