CREATE SCHEMA `warehouse_silver`
OPTIONS(
  location="us",
  is_case_insensitive=false,
  max_time_travel_hours=168,
  description=""Warehouse Silver Fact Dataset"
);
