CREATE SCHEMA `temp_layer`
OPTIONS(
  location="us",
  is_case_insensitive=false,
  max_time_travel_hours=168,
  description="Temporary Dataset to stage the Temporary Tables or Temporary Data"
);