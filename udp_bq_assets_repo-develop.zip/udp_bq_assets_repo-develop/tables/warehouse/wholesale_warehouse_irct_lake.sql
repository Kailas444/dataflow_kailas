CREATE TABLE `lake_layer.wholesale_warehouse_irct`
(
  dc_id INT64 OPTIONS(description="Distribution center ID number"),
  rcpt_id INT64 OPTIONS(description="Receipt identification code/number"),
  user_id STRING OPTIONS(description="User login ID number"),
  rsta_id STRING OPTIONS(description="Receipt status ID"),
  rcpt_dtim DATETIME OPTIONS(description="Date/Time stamp when work unit was received"),
  whse_id INT64 OPTIONS(description="Warehouse identification number"),
  appt_id INT64 OPTIONS(description="Appointment ID number"),
  po_id INT64 OPTIONS(description="Purchase order ID number"),
  verify_user STRING OPTIONS(description="Verification user ID"),
  verify_dtim DATETIME OPTIONS(description="Verification date/time"),
  flow_auto_ship_flg STRING OPTIONS(description="Flag indicating whether shipment should be automatically generated"),
  key INT64 OPTIONS(description="Receipt record unique ID"),
  queue_id INT64 OPTIONS(description="Queue identifier"),
  warehouse STRING OPTIONS(description="Warehouse name"),
  audit_created_ts DATETIME NOT NULL OPTIONS(description="System audit creation timestamp"),
  audit_updated_ts DATETIME NOT NULL OPTIONS(description="System audit update timestamp")
)PARTITION BY DATE(audit_created_ts)
OPTIONS (
  description = "Source table for warehouse data from exabi. Contains metadata , classifications, visibility, applicability, and audit tracking fields."
);