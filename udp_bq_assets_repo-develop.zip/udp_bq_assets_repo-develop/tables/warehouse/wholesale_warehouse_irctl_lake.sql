CREATE TABLE `lake_layer.wholesale_warehouse_irctl`
(
  rctl_id INT64 OPTIONS(description="Receipt log ID"),
  dc_id INT64 OPTIONS(description="Distribution center ID number"),
  whse_id INT64 OPTIONS(description="Warehouse identification number"),
  lic_plt_id INT64 OPTIONS(description="License plate ID number. Unique for each pallet."),
  prod_id INT64 OPTIONS(description="Product ID"),
  prdd_id INT64 OPTIONS(description="Product detail ID number"),
  code_date DATETIME OPTIONS(description="Code date of product"),
  rct_qty NUMERIC OPTIONS(description="Receipt quantity"),
  catch_wgt NUMERIC OPTIONS(description="Product catch weight"),
  lot_no STRING OPTIONS(description="Lot number to identify specific product lots"),
  po_id INT64 OPTIONS(description="Purchase order ID number"),
  pod_id INT64 OPTIONS(description="Purchase order detail ID number"),
  create_dtim DATETIME OPTIONS(description="Creation date and time"),
  extr_flag STRING OPTIONS(description="Extracted flag. (Yes=Extracted, No=Not extracted)"),
  roll_flag STRING OPTIONS(description="Roll flag - Log record has been rolled to history"),
  rct_type STRING OPTIONS(description="Receipt type"),
  flow_dtl_flg STRING OPTIONS(description="Flowthru detail flag"),
  whse_gnrt_flow_flg STRING OPTIONS(description="Warehouse generated flowthru flag (Yes/No)"),
  rctt_id STRING OPTIONS(description="Receipt type ID"),
  extr_dtim DATETIME OPTIONS(description="Extraction date and time"),
  bkord_rcpt STRING OPTIONS(description="Backorder receipt flag"),
  warehouse STRING OPTIONS(description="Warehouse name"),
  audit_created_ts DATETIME NOT NULL OPTIONS(description="System audit creation timestamp"),
  audit_updated_ts DATETIME NOT NULL OPTIONS(description="System audit update timestamp")
)PARTITION BY DATE(audit_created_ts)
OPTIONS (
  description = "Source table for warehouse data from exabi. Contains metadata , classifications, visibility, applicability, and audit tracking fields."
);