CREATE TABLE `raw_layer.wholesale_warehouse_iapt`
(
  dc_id STRING OPTIONS(description="Distribution center ID number"),
  whse_id STRING OPTIONS(description="Warehouse identification number"),
  appt_id STRING OPTIONS(description="Appointment ID number"),
  appt_dtim STRING OPTIONS(description="Appointment date/time"),
  appt_door STRING OPTIONS(description="Appointment door"),
  arrv_dtim STRING OPTIONS(description="Arrival date and time"),
  depdtim STRING OPTIONS(description="Departure date and time"),
  create_user STRING OPTIONS(description="Creation user ID"),
  create_dtim STRING OPTIONS(description="Creation date and time"),
  change_user STRING OPTIONS(description="Last change user ID"),
  change_dtim STRING OPTIONS(description="Record of the last changed date/time stamp"),
  carrier STRING OPTIONS(description="Carrier code"),
  arrv_door STRING OPTIONS(description="Arrival door"),
  closed_flg STRING OPTIONS(description="Specifies whether the appointment is closed"),
  bill_of_lading STRING OPTIONS(description="Bill of Lading"),
  yard_flag STRING OPTIONS(description="Specifies whether the appointment is on the yard"),
  key STRING OPTIONS(description="Appointment record unique ID"),
  warehouse STRING OPTIONS(description="twarehouse name"),
  audit_created_ts DATETIME NOT NULL OPTIONS(description="System audit creation timestamp")
)OPTIONS (
  description = "Source table for warehouse data from exabi. Contains metadata , classifications, visibility, applicability, and audit tracking fields."
);