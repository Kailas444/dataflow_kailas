CREATE TABLE `raw_layer.wholesale_warehouse_iercd`
(
  ercd_id STRING OPTIONS(description="Error code ID"),
  iercd_user_val STRING OPTIONS(description="Exception reason code ID user value"),
  iercd_sdesc STRING OPTIONS(description="Exception reason code ID short description"),
  iercd_desc STRING OPTIONS(description="Exception reason code ID description"),
  create_dtim STRING OPTIONS(description="Creation date and time"),
  create_user STRING OPTIONS(description="Creation User ID"),
  change_dtim STRING OPTIONS(description="Record of the last changed date/time stamp"),
  change_user STRING OPTIONS(description="Last change user ID"),
  lang_id STRING OPTIONS(description="Language identifier (ex. U=USA, E=English)"),
  warehouse STRING OPTIONS(description="Warehouse name"),
  audit_created_ts DATETIME NOT NULL OPTIONS(description="System audit creation timestamp")
)OPTIONS (
  description = "Source table for warehouse data from exabi. Contains metadata , classifications, visibility, applicability, and audit tracking fields."
);