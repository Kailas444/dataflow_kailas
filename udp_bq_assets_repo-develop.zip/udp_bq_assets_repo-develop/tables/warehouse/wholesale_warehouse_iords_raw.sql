CREATE TABLE `raw_layer.wholesale_warehouse_iords`
(
  ords_id STRING OPTIONS(description="Order status table ID"),
  dc_id STRING OPTIONS(description="Distribution center ID number"),
  whse_id STRING OPTIONS(description="Warehouse identification number"),
  ord_id STRING OPTIONS(description="Order ID number"),
  sgmt_id STRING OPTIONS(description="Order segment ID number"),
  osta_id STRING OPTIONS(description="Order status ID"),
  create_dtim STRING OPTIONS(description="Creation date and time"),
  create_user STRING OPTIONS(description="Creation user ID"),
  warehouse STRING OPTIONS(description="twarehouse name"),
  audit_created_ts DATETIME NOT NULL OPTIONS(description="System audit creation timestamp")
)OPTIONS (
  description = "Source table for warehouse data from exabi. Contains metadata , classifications, visibility, applicability, and audit tracking fields."
);