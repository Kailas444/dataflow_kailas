CREATE TABLE `lake_layer.wholesale_warehouse_iords`
(
  ords_id INT64 OPTIONS(description="Order status table ID"),
  dc_id INT64 OPTIONS(description="Distribution center ID number"),
  whse_id INT64 OPTIONS(description="Warehouse identification number"),
  ord_id INT64 OPTIONS(description="Order ID number"),
  sgmt_id INT64 OPTIONS(description="Order segment ID number"),
  osta_id STRING OPTIONS(description="Order status ID"),
  create_dtim DATETIME OPTIONS(description="Creation date and time"),
  create_user STRING OPTIONS(description="Creation user ID"),
  warehouse STRING OPTIONS(description="Warehouse name"),
  audit_created_ts DATETIME NOT NULL OPTIONS(description="System audit creation timestamp"),
  audit_updated_ts DATETIME NOT NULL OPTIONS(description="System audit update timestamp")
)PARTITION BY DATE(audit_created_ts)
OPTIONS (
  description = "Source table for warehouse data from exabi. Contains metadata , classifications, visibility, applicability, and audit tracking fields."
);