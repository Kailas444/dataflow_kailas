CREATE TABLE `lake_layer.wholesale_warehouse_iordd`
(
  dc_id INT64 OPTIONS(description="Distribution center ID number"),
  whse_id INT64 OPTIONS(description="Warehouse identification number"),
  ord_id INT64 OPTIONS(description="Order ID number"),
  sgmt_id INT64 OPTIONS(description="Order segment ID number"),
  ordd_id INT64 OPTIONS(description="Order detail ID number"),
  prod_id INT64 OPTIONS(description="Product ID"),
  ord_qty NUMERIC OPTIONS(description="Order quantity"),
  ecr_flg STRING OPTIONS(description="Efficient customer response flag"),
  comt_rsv_flg STRING OPTIONS(description="Buyer reserve flag"),
  pkty_id STRING OPTIONS(description="Pick type ID"),
  whse_cost STRING OPTIONS(description="Warehouse cost"),
  rtl_price STRING OPTIONS(description="Retail price per unit of product"),
  rtl_cost STRING OPTIONS(description="Retail cost per unit"),
  lot_no STRING OPTIONS(description="Lot number to identify specific product lots"),
  change_dtim DATETIME OPTIONS(description="Record of the last changed date/time stamp"),
  change_user STRING OPTIONS(description="Last change user ID"),
  create_user STRING OPTIONS(description="Creation user ID"),
  create_dtim DATETIME OPTIONS(description="Creation date and time"),
  price_adj_flg STRING OPTIONS(description="Price adjustment flag"),
  unit_ship_cse NUMERIC OPTIONS(description="Individual product units per shipping case"),
  pkgp_id_seq INT64 OPTIONS(description="Pick group ID category"),
  commodity_type STRING OPTIONS(description="Commodity type"),
  sub_type STRING OPTIONS(description="Flag to indicate type of substitution"),
  key INT64 OPTIONS(description="Record unique ID"),
  ord_det_ref_id INT64 OPTIONS(description="Order detail reference ID"),
  prod_seq NUMERIC OPTIONS(description="Product sequence within the order"),
  invoice_class STRING OPTIONS(description="Invoice classification code"),
  cust_prod_id INT64 OPTIONS(description="Customer-specific product ID"),
  cust_lcost NUMERIC OPTIONS(description="Customer-specific landed cost"),
  rtl_cse_cost NUMERIC OPTIONS(description="Retail case cost"),
  taxable_flag STRING OPTIONS(description="Taxable flag for the product"),
  comm_class STRING OPTIONS(description="Commodity classification code"),
  warehouse STRING OPTIONS(description="Warehouse name"),
  audit_created_ts DATETIME NOT NULL OPTIONS(description="System audit creation timestamp"),
  audit_updated_ts DATETIME NOT NULL OPTIONS(description="System audit update timestamp")
)PARTITION BY DATE(audit_created_ts)
OPTIONS (
  description = "Source table for warehouse data from exabi. Contains metadata , classifications, visibility, applicability, and audit tracking fields."

);
