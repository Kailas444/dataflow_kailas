CREATE TABLE `udp_audit.table_run_status`
(
  source_system STRING,
  schema_name STRING,
  warehouse STRING,
  table_name STRING,
  status INT64,
  run_sequence INT64,
  run_date DATETIME,
  audit_created_ts DATETIME
);
