CREATE TABLE `raw_layer.wholesale_warehouse_irct`
(
  dc_id STRING OPTIONS(description="Distribution center ID number"),
  rcpt_id STRING OPTIONS(description="Receipt identification code/number"),
  user_id STRING OPTIONS(description="User login ID number"),
  rsta_id STRING OPTIONS(description="Receipt status ID"),
  rcpt_dtim STRING OPTIONS(description="Date/Time stamp when work unit was received"),
  whse_id STRING OPTIONS(description="Warehouse identification number"),
  appt_id STRING OPTIONS(description="Appointment ID number"),
  po_id STRING OPTIONS(description="Purchase order ID number"),
  verify_user STRING OPTIONS(description="Verification user ID"),
  verify_dtim STRING OPTIONS(description="Verification date/time"),
  flow_auto_ship_flg STRING OPTIONS(description="Flag indicating whether shipment should be automatically generated"),
  key STRING OPTIONS(description="Receipt record unique ID"),
  queue_id STRING OPTIONS(description="Queue identifier"),
  warehouse STRING OPTIONS(description="Warehouse"),
  audit_created_ts DATETIME NOT NULL OPTIONS(description="System audit creation timestamp")
)OPTIONS (
  description = "Source table for warehouse data from exabi. Contains metadata , classifications, visibility, applicability, and audit tracking fields."
);