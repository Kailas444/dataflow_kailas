CREATE TABLE `udp_audit.warehouse_lookup`
(
  table_name STRING OPTIONS(description="Name of the warehouse-related table"),
  warehouse STRING OPTIONS(description="Warehouse code or identifier")
)
OPTIONS(
  description="Lookup table containing mapping of warehouse tables to their corresponding warehouses"
);
