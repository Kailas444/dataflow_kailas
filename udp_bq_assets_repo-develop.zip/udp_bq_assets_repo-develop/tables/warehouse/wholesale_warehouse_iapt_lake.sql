CREATE TABLE `lake_layer.wholesale_warehouse_iapt`
(
  dc_id INT64 OPTIONS(description="Distribution center ID number"),
  whse_id INT64 OPTIONS(description="Warehouse identification number"),
  appt_id INT64 OPTIONS(description="Appointment ID number"),
  appt_dtim DATETIME OPTIONS(description="Appointment date/time"),
  appt_door STRING OPTIONS(description="Appointment door"),
  arrv_dtim DATETIME OPTIONS(description="Arrival date and time"),
  depdtim DATETIME OPTIONS(description="Departure date and time"),
  create_user STRING OPTIONS(description="Creation user ID"),
  create_dtim DATETIME OPTIONS(description="Creation date and time"),
  change_user STRING OPTIONS(description="Last change user ID"),
  change_dtim DATETIME OPTIONS(description="Record of the last changed date/time stamp"),
  carrier STRING OPTIONS(description="Carrier code"),
  arrv_door STRING OPTIONS(description="Arrival door"),
  closed_flg STRING OPTIONS(description="Specifies whether the appointment is closed"),
  bill_of_lading STRING OPTIONS(description="Bill of Lading"),
  yard_flag STRING OPTIONS(description="Specifies whether the appointment is on the yard"),
  key INT64 OPTIONS(description="Appointment record unique ID"),
  warehouse STRING OPTIONS(description="Warehouse name"),
  audit_created_ts DATETIME NOT NULL OPTIONS(description="System audit creation timestamp"),
  audit_updated_ts DATETIME NOT NULL OPTIONS(description="System audit update timestamp")
)PARTITION BY DATE(audit_created_ts)
OPTIONS (
  description = "Source table for warehouse data from exabi. Contains metadata , classifications, visibility, applicability, and audit tracking fields."
);