CREATE TABLE `raw_layer.master_iaptd_exabi`
(
  dc_id STRING OPTIONS(description="Distribution center ID number"),
  whse_id STRING OPTIONS(description="Warehouse identification number"),
  appt_id STRING OPTIONS(description="Appointment ID number"),
  po_id STRING OPTIONS(description="Purchase order ID number"),
  po_closed_flg STRING OPTIONS(description="Flag indicating if the purchase order is closed"),
  warehouse STRING OPTIONS(description="warehouse name"),
  audit_created_ts DATETIME NOT NULL OPTIONS(description="System audit creation timestamp")
)OPTIONS (
  description = "Source table for warehouse data from exabi. Contains metadata , classifications, visibility, applicability, and audit tracking fields."
);