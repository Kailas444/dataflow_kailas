CREATE TABLE `lake_layer.wholesale_warehouse_irctd`
(
  dc_id INT64 OPTIONS(description="Distribution center ID number"),
  whse_id INT64 OPTIONS(description="Warehouse identification number"),
  lic_plt_id INT64 OPTIONS(description="License plate ID number. Unique for each pallet."),
  prod_id INT64 OPTIONS(description="Product ID"),
  prdd_id INT64 OPTIONS(description="Product detail ID number"),
  rcpt_id INT64 OPTIONS(description="Receipt identification code/number"),
  mpp_id INT64 OPTIONS(description="Multi-pallet platform ID"),
  code_date DATETIME OPTIONS(description="Code date of product"),
  rct_qty NUMERIC OPTIONS(description="Receipt quantity"),
  catch_wgt NUMERIC OPTIONS(description="Product catch weight"),
  lot_no STRING OPTIONS(description="Lot number to identify specific product lots"),
  po_id INT64 OPTIONS(description="Purchase order ID number"),
  pod_id INT64 OPTIONS(description="Purchase order detail ID number"),
  rdst_id STRING OPTIONS(description="Receipt detail status ID"),
  stor_ti NUMERIC OPTIONS(description="Storage TI (units per layer on a pallet)"),
  stor_hi NUMERIC OPTIONS(description="Storage high"),
  receipt_user STRING OPTIONS(description="Receipt user ID"),
  receipt_dtim DATETIME OPTIONS(description="Receipt date/time"),
  rctt_id STRING OPTIONS(description="Receipt type ID"),
  flow_dtl_flg STRING OPTIONS(description="Flowthru detail flag"),
  whse_gnrt_flow_flg STRING OPTIONS(description="Warehouse generated flowthru flag (Yes/No)"),
  qlty_id INT64 OPTIONS(description="Quality ID"),
  temperature NUMERIC OPTIONS(description="Storage or handling temperature"),
  urcp_id STRING OPTIONS(description="Unit receiving process ID"),
  key INT64 OPTIONS(description="Unique receipt detail key."),
  coo_id INT64 OPTIONS(description="Country of origin ID"),
  ips_id INT64 OPTIONS(description="Inbound processing status ID"),
  product_identifier INT64 OPTIONS(description="Unique product code"),
  cod_dt_incr STRING OPTIONS(description="Code date increment"),
  calc_cde_dt_flg STRING OPTIONS(description="Flag to indicate if code date is system-calculated"),
  warehouse STRING OPTIONS(description="Warehouse name"),
  audit_created_ts DATETIME NOT NULL OPTIONS(description="System audit creation timestamp"),
  audit_updated_ts DATETIME NOT NULL OPTIONS(description="System audit update timestamp")
)PARTITION BY DATE(audit_created_ts)
OPTIONS (
  description = "Source table for warehouse data from exabi. Contains metadata , classifications, visibility, applicability, and audit tracking fields."
);