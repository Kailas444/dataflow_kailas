CREATE TABLE `raw_layer.wholesale_warehouse_irctl`
(
  rctl_id STRING OPTIONS(description="tReceipt log ID"),
  dc_id STRING OPTIONS(description="tDistribution center ID number"),
  whse_id STRING OPTIONS(description="tWarehouse identification number"),
  lic_plt_id STRING OPTIONS(description="tLicense plate ID number. Unique for each pallet."),
  prod_id STRING OPTIONS(description="tProduct ID"),
  prdd_id STRING OPTIONS(description="tProduct detail ID number"),
  code_date STRING OPTIONS(description="tCode date of product"),
  rct_qty STRING OPTIONS(description="tReceipt quantity"),
  catch_wgt STRING OPTIONS(description="tProduct catch weight"),
  lot_no STRING OPTIONS(description="tLot number to identify specific product lots"),
  po_id STRING OPTIONS(description="tPurchase order ID number"),
  pod_id STRING OPTIONS(description="tPurchase order detail ID number"),
  create_dtim STRING OPTIONS(description="tCreation date and time"),
  extr_flag STRING OPTIONS(description="tExtracted flag. (Yes=Extracted, No=Not extracted)"),
  roll_flag STRING OPTIONS(description="tRoll flag - Log record has been rolled to history"),
  rct_type STRING OPTIONS(description="tReceipt type"),
  flow_dtl_flg STRING OPTIONS(description="tFlowthru detail flag"),
  whse_gnrt_flow_flg STRING OPTIONS(description="tWarehouse generated flowthru flag (Yes/No)"),
  rctt_id STRING OPTIONS(description="tReceipt type ID"),
  extr_dtim STRING OPTIONS(description="tExtraction date and time"),
  bkord_rcpt STRING OPTIONS(description="tBackorder receipt flag"),
  warehouse STRING OPTIONS(description="Warehouse"),
  audit_created_ts DATETIME NOT NULL OPTIONS(description="System audit creation timestamp")
)OPTIONS (
  description = "Source table for warehouse data from exabi. Contains metadata , classifications, visibility, applicability, and audit tracking fields."
);