CREATE TABLE `lake_layer.master_iaptd_exabi`
(
  dc_id INT64 OPTIONS(description="Distribution center ID number"),
  whse_id INT64 OPTIONS(description="Warehouse identification number"),
  appt_id INT64 OPTIONS(description="Appointment ID number"),
  po_id INT64 OPTIONS(description="Purchase order ID number"),
  po_closed_flg STRING OPTIONS(description="Flag indicating if the purchase order is closed"),
  warehouse STRING OPTIONS(description="Warehouse name"),
  audit_created_ts DATETIME NOT NULL OPTIONS(description="System audit creation timestamp"),
  audit_updated_ts DATETIME NOT NULL OPTIONS(description="System audit update timestamp")
)PARTITION BY DATE(audit_created_ts)
OPTIONS (
  description = "Source table for warehouse data from exabi. Contains metadata , classifications, visibility, applicability, and audit tracking fields."
);