CREATE TABLE `retail_sales_silver.fact_pos_header`
(
  pos_transaction_id INT64 OPTIONS(description="Surrogate key for indentifying a unique transaction"),
  terminal_id INT64 OPTIONS(description="POS terminal identifier"),
  cashier_id INT64 OPTIONS(description="Cashier staff code"),
  frequent_shopper_id NUMERIC OPTIONS(description="Loyalty card number"),
  store_id INT64 OPTIONS(description="Store location number"),
  shopper_id NUMERIC OPTIONS(description="Unique shopper ID to Shopper"),
  transaction_cde STRING OPTIONS(description="Transaction unique code"),
  transaction_dttm DATETIME OPTIONS(description="Date and Time of transaction"),
  sales_amt NUMERIC OPTIONS(description="Total sales value"),
  tax_amt NUMERIC OPTIONS(description="Total tax amount"),
  discount_amt NUMERIC OPTIONS(description="Total discount applied"),
  transaction_amt NUMERIC OPTIONS(description="Full transaction amount"),
  cost_amt NUMERIC OPTIONS(description="Item cost price"),
  loyalty_points INT64 OPTIONS(description="Available loyalty points"),
  store_type_cde STRING OPTIONS(description="Type of Store (Grand Union/Piggly Wiggly)"),
  audit_created_ts DATETIME NOT NULL OPTIONS(description="System audit creation timestamp"),
  audit_updated_ts DATETIME NOT NULL OPTIONS(description="System audit update timestamp"),
  PRIMARY KEY (pos_transaction_id) NOT ENFORCED
)
PARTITION BY DATE(transaction_dttm)
CLUSTER BY store_type_cde
OPTIONS (
  description = "Fact table capturing summary-level POS sales transaction data across retail stores. Includes transactional metrics such as total sales, tax, discounts, cost, and loyalty activity, along with store and shopper metadata. Designed for analytical and reporting use cases including sales performance, shopper behavior, and financial reconciliation",
  labels = [("domain", "gu"),("layer", "silver"),("source", "kafka_gu_pw"),("frequency", "daily"), ("grain1", "transaction_cde"),("grain2", "store_id"),("grain3", "transaction_dttm"),("grain4", "store_type_cde")]
);


