CREATE TABLE `retail_sales_silver.fact_pos_line`
(
  pos_transaction_id INT64 NOT NULL OPTIONS(description="Surrogate key for indentifying a unique transaction"),
  transaction_line_id INT64 OPTIONS(description="Transaction order number"),
  transaction_cde STRING OPTIONS(description="Transaction unique code"),
  transaction_indicator STRING OPTIONS(description="Type of transaction"),
  store_id INT64 OPTIONS(description="Store location number"),
  department_id INT64 OPTIONS(description="Product department code"),
  category_id INT64 OPTIONS(description="Product category ID"),
  sub_category_id INT64 OPTIONS(description="Product sub-category ID"),
  product_id INT64 OPTIONS(description="product id from dim_product table"),
  gtin_retail STRING OPTIONS(description="Gtin id for each product"),
  unit_of_measure STRING OPTIONS(description="unit of measure"),
  price_multiple INT64 OPTIONS(description="Pricing rule code"),
  price NUMERIC OPTIONS(description="Item unit price"),
  transaction_dttm DATETIME OPTIONS(description="Date and Time of transaction"),
  sales_qty INT64 OPTIONS(description="Quantity purchased"),
  sales_weight NUMERIC OPTIONS(description="Product weight sold"),
  sales_amt NUMERIC OPTIONS(description="Total sales value"),
  discount_amt NUMERIC OPTIONS(description="Total discount applied"),
  frequent_shopper_discount_amt NUMERIC OPTIONS(description="Frequent shopper discount"),
  premium_amt NUMERIC OPTIONS(description="Loyalty premium earned"),
  total_points INT64 OPTIONS(description="Loyalty points earned"),
  cashback_amt NUMERIC OPTIONS(description="Cashback amount given"),
  cost_amt NUMERIC OPTIONS(description="Item cost price"),
  receipt_flag STRING OPTIONS(description="Receipt issued flag"),
  price_type STRING OPTIONS(description="Type of price"),
  store_type_cde STRING OPTIONS(description="Type of Store (Grand Union/Piggly Wiggly)"),
  audit_created_ts DATETIME NOT NULL OPTIONS(description="System audit creation timestamp"),
  audit_updated_ts DATETIME NOT NULL OPTIONS(description="System audit update timestamp"),
  PRIMARY KEY (pos_transaction_id,transaction_line_id) NOT ENFORCED
)
PARTITION BY DATE(transaction_dttm)
CLUSTER BY department_id,store_type_cde
OPTIONS (
    description = "Fact table containing transactional-level POS sales line data for all retail stores. Includes item-level details such as pricing, discounting, loyalty metrics, and store identifiers, used for reporting and analytical workloads.",
labels = [("domain", "gu"),("layer", "silver"),("source", "kafka_gu_pw"),("frequency", "daily"), ("grain1", "store_id"),("grain2", "transaction_cde"),("grain3", "transaction_line_id"),("grain4", "transaction_dttm"),("grain5", "store_type_cde")]
);


