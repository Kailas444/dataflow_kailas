CREATE TABLE `raw_layer.retail_sales_pos_gu`
(
  trans_date STRING OPTIONS(description="Transaction date in YYYYMMDD format"),
  trans_time STRING OPTIONS(description="Transaction time in HHMMSS format"),
  terminal_code STRING OPTIONS(description="POS terminal identifier"),
  cashier_code STRING OPTIONS(description="Cashier or operator code"),
  sequence STRING OPTIONS(description="Transaction sequence number on the register"),
  key_function STRING OPTIONS(description="Key function name used in transaction"),
  key_function_id STRING OPTIONS(description="Identifier of the key function used"),
  department_code STRING OPTIONS(description="Sales department code"),
  price_multiple STRING OPTIONS(description="Price multiplier (e.g. for bulk sales)"),
  price STRING OPTIONS(description="Unit price of the item"),
  quantity STRING OPTIONS(description="Quantity of items sold"),
  weight STRING OPTIONS(description="Weight of item, if applicable"),
  ext_sales STRING OPTIONS(description="Extended sales value (quantity × price)"),
  tendered_amount STRING OPTIONS(description="Amount tendered by customer"),
  receipt_flags STRING OPTIONS(description="Flags indicating receipt properties"),
  account STRING OPTIONS(description="Account or store code for transaction"),
  category STRING OPTIONS(description="Product category"),
  sub_category STRING OPTIONS(description="Product sub-category"),
  sub_department STRING OPTIONS(description="Sub-department for finer classification"),
  price_type STRING OPTIONS(description="Type of pricing applied (e.g. sale, promo)"),
  fs_discount STRING OPTIONS(description="Frequent shopper discount amount"),
  premium STRING OPTIONS(description="Premium or loyalty-based amount"),
  frequent_shopper_id STRING OPTIONS(description="Frequent shopper or loyalty ID"),
  sales_total STRING OPTIONS(description="Total sales amount for transaction"),
  tax_total STRING OPTIONS(description="Total tax amount for transaction"),
  transaction_total STRING OPTIONS(description="Total transaction value"),
  total_discounts STRING OPTIONS(description="Total discounts applied"),
  total_points STRING OPTIONS(description="Loyalty points awarded"),
  cash_back STRING OPTIONS(description="Cash back given to customer"),
  transaction_code STRING OPTIONS(description="Code identifying type of transaction"),
  cost STRING OPTIONS(description="Cost of goods sold"),
  customer_id STRING OPTIONS(description="Customer identifier"),
  store_number STRING OPTIONS(description="Store or location number"),
  alternate_id STRING OPTIONS(description="Alternate product or customer ID"),
  loyalty_points STRING OPTIONS(description="Loyalty points balance"),
  extra_filler STRING OPTIONS(description="Additional filler field (for padding or future use)"),
  source_file STRING OPTIONS(description="Original source file name"),
  sourcefile_ts STRING OPTIONS(description="Timestamp from the source file name"),
  file_record_count STRING OPTIONS(description="Record count in the source file"),
  filesize_bytes STRING OPTIONS(description="Size of the file in bytes"),
  audit_created_ts DATETIME DEFAULT CURRENT_DATETIME() OPTIONS(description="System audit creation timestamp")
)
PARTITION BY DATE(audit_created_ts)
OPTIONS (
  description="Raw POS history data from GU stores, containing transactional-level details used for analysis and ETL processing"
);

