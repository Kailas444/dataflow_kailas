CREATE TABLE `lake_layer.retail_sales_pos_pwsc`
(
  trans_date DATE OPTIONS(description="Date of transaction"),
  trans_time TIME OPTIONS(description="time of transaction"),
  terminal_code INT64 OPTIONS(description="POS terminal identifier"),
  cashier_code INT64 OPTIONS(description="Cashier staff code"),
  sequence INT64 OPTIONS(description="Transaction order number"),
  key_function STRING OPTIONS(description="Type of transaction"),
  key_function_id STRING OPTIONS(description="Transaction function ID"),
  department_code INT64 OPTIONS(description="Product department code"),
  price_multiple INT64 OPTIONS(description="Pricing rule code"),
  price NUMERIC OPTIONS(description="Item unit price"),
  quantity INT64 OPTIONS(description="Quantity purchased"),
  weight NUMERIC OPTIONS(description="Product weight sold"),
  ext_sales NUMERIC OPTIONS(description="Total item amount"),
  tendered_amount NUMERIC OPTIONS(description="Amount customer paid"),
  receipt_flags STRING OPTIONS(description="Receipt issued flag"),
  account STRING OPTIONS(description="Customer account number"),
  category INT64 OPTIONS(description="Product category ID"),
  sub_category INT64 OPTIONS(description="Product sub-category ID"),
  sub_department INT64 OPTIONS(description="Sub-department identifier"),
  price_type STRING OPTIONS(description="Type of price"),
  fs_discount NUMERIC OPTIONS(description="Frequent shopper discount"),
  premium NUMERIC OPTIONS(description="Loyalty premium earned"),
  frequent_shopper_id NUMERIC OPTIONS(description="Loyalty card number"),
  sales_total NUMERIC OPTIONS(description="Total sales value"),
  tax_total NUMERIC OPTIONS(description="Total tax amount"),
  transaction_total NUMERIC OPTIONS(description="Full transaction amount"),
  total_discounts NUMERIC OPTIONS(description="Total discount applied"),
  total_points INT64 OPTIONS(description="Loyalty points earned"),
  cash_back NUMERIC OPTIONS(description="Cashback amount given"),
  transaction_code STRING OPTIONS(description="Transaction unique code"),
  cost NUMERIC OPTIONS(description="Item cost price"),
  customer_id NUMERIC OPTIONS(description="Unique customer ID"),
  store_number STRING OPTIONS(description="Store location number"),
  alternate_id STRING OPTIONS(description="Alternate customer ID"),
  loyalty_points INT64 OPTIONS(description="Available loyalty points"),
  extra_filler STRING OPTIONS(description="Placeholder or unused column; may be reserved for future data or ignored fields."),
  source_file STRING OPTIONS(description="Name of the file from which the sales data was ingested (e.g., CSV, TXT, etc.)."),
  sourcefile_ts STRING OPTIONS(description="Timestamp (as string) indicating when the source file was created or extracted."),
  file_record_count STRING OPTIONS(description="Number of records/rows present in the source file at the time of ingestion."),
  filesize_bytes STRING OPTIONS(description="Size of the source file in bytes, stored as string (may need conversion)."),
  audit_created_ts DATETIME NOT NULL OPTIONS(description="System audit creation timestamp"),
  audit_updated_ts DATETIME NOT NULL OPTIONS(description="System audit update timestamp")
)
PARTITION BY DATE(audit_created_ts)
OPTIONS (
  description = "Retail POS sales data for PW stores, capturing transaction details including pricing, discounts, customer info, and audit timestamps for ETL and analytics purposes."
);


