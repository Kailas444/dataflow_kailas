CREATE TABLE `retail_sales_silver.fact_pos_tender`
(
  pos_transaction_id INT64 OPTIONS(description="Surrogate key for indentifying a unique transaction"),
  transaction_cde STRING OPTIONS(description="Transaction unique code"),
  tender_line_id INT64 OPTIONS(description="Transaction order number - sequence number in an order"),
  transaction_indicator STRING OPTIONS(description="Type of transaction"),
  store_id INT64 OPTIONS(description="Store location number"),
  payment_type STRING OPTIONS(description="Transaction function ID"),
  tender_amt NUMERIC OPTIONS(description="Amount customer paid"),
  cashback_amt NUMERIC OPTIONS(description="Cashback amount given"),
  transaction_dttm DATETIME OPTIONS(description="Date and Time of transaction"),
  store_type_cde STRING OPTIONS(description="Type of Store (Grand Union/Piggly Wiggly)"),
  audit_created_ts DATETIME NOT NULL OPTIONS(description="System audit creation timestamp"),
  audit_updated_ts DATETIME NOT NULL OPTIONS(description="System audit update timestamp"),
  PRIMARY KEY (pos_transaction_id,tender_line_id) NOT ENFORCED
)
PARTITION BY DATE(transaction_dttm)
CLUSTER BY store_type_cde
OPTIONS (
  description = "Fact table capturing tender (payment) details for each POS transaction across retail stores. Contains information on payment types, amounts, cashback, and associated store metadata. Supports analytical and reporting workloads related to sales and payment behaviors",
  labels = [("domain", "gu"),("layer", "silver"),("source", "kafka_gu_pw"),("frequency", "daily"), ("grain1", "transaction_cde"),("grain2", "store_id"),("grain3", "transaction_dttm"),("grain4", "tender_line_id"),("grain5", "store_type_cde")]);

