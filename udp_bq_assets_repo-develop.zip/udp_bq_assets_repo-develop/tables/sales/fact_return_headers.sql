CREATE TABLE `sales_silver.fact_return_headers`
(
  return_id INT64 OPTIONS(description="Unique identifier for each return record."),
  invoice_id INT64 OPTIONS(description="Reference to the original invoice ID."),
  return_auth_id STRING OPTIONS(description="Return authorization identifier."),
  credit_id INT64 OPTIONS(description="Credit note identifier issued for the return."),
  request_id INT64 OPTIONS(description="Request ID associated with the return process."),
  company_id INT64 OPTIONS(description="Identifier for the company processing the return."),
  division_id INT64 OPTIONS(description="Division within the company handling the return."),
  organization_cde STRING OPTIONS(description="Organizational code for grouping or filtering."),
  retailer_num STRING OPTIONS(description="Retailer number associated with the return."),
  invoice_num STRING OPTIONS(description="Original invoice number linked to the return."),
  return_status STRING OPTIONS(description="Current status of the return (e.g., Approved, Pending)."),
  department STRING OPTIONS(description="Department associated with the return."),
  creation_date DATETIME OPTIONS(description="Timestamp when the return record was created."),
  return_date DATETIME OPTIONS(description="Date the return was initiated."),
  approved_by STRING OPTIONS(description="User who approved the return."),
  approved_date DATETIME OPTIONS(description="Date when the return was approved."),
  total_amount NUMERIC OPTIONS(description="Total monetary value of the return."),
  wait_for_delivery STRING OPTIONS(description="Indicates if the return is waiting for delivery."),
  reference_data STRING OPTIONS(description="Additional reference information related to the return."),
  process_status STRING OPTIONS(description="Processing status of the return record."),
  source STRING OPTIONS(description="Source system that created the return."),
  last_updated_by NUMERIC OPTIONS(description="User or process ID that last updated the return."),
  last_update_date DATETIME OPTIONS(description="Timestamp of the last update."),
  created_by NUMERIC OPTIONS(description="User or process ID that created the record."),
  print_on_invoice STRING OPTIONS(description="Flag indicating if return info should be printed on invoice."),
  sent_to_exabi STRING OPTIONS(description="Indicates if return was sent to EXABI system."),
  restock_fee NUMERIC OPTIONS(description="Fee charged for restocking the returned item(s)."),
  estimated_amount NUMERIC OPTIONS(description="Estimated return amount before processing."),
  customer_details JSON OPTIONS(description="Structured customer information related to the return."),
  return_details JSON OPTIONS(description="Structured return line item details."),
  dash_account STRING OPTIONS(description="DASH account associated with the return."),
  print_required STRING OPTIONS(description="Indicates if printing is required."),
  send_to_exe STRING OPTIONS(description="Flag indicating if return should be sent to EXE system."),
  audit_created_ts DATETIME NOT NULL OPTIONS(description="Timestamp when the audit record was created."),
  audit_updated_ts DATETIME NOT NULL OPTIONS(description="Timestamp when the audit record was last updated.")
)
PARTITION BY DATE(return_date)
OPTIONS(
  description="This table captures return transactions related to wholesale sales, including invoice linkage, return status, amounts, authorization, and source system tracking"
);