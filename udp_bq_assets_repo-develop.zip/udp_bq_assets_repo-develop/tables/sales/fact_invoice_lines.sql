CREATE OR REPLACE TABLE `sales_silver.fact_invoice_lines`
(
  invoice_id INT64 NOT NULL OPTIONS(description="Sales Order Invoice unique ID (Foreign Key)"),
  invoice_line_id INT64 NOT NULL OPTIONS(description="Sales Order Invoice Line ID (Primary Key)"),
  invoice_num STRING OPTIONS(description="Invoice number"),
  invoice_date DATE OPTIONS(description="Invoice date"),
  order_header_id INT64 NOT NULL OPTIONS(description="Sales Order ID (Foreign Key)"),
  order_line_id INT64 NOT NULL OPTIONS(description="Sales Order Line ID (Foreign Key)"),
  product_id INT64 OPTIONS(description="Product ID"),
  delivery_line_id INT64 OPTIONS(description="Delivery line ID"),
  division_id INT64 OPTIONS(description="Division ID"),
  variable_weight_indicator STRING OPTIONS(description="Variable weight indicator"),
  original_order_quantity NUMERIC OPTIONS(description="Original order quantity"),
  ordered_quantity NUMERIC OPTIONS(description="Ordered quantity"),
  shipped_quantity NUMERIC OPTIONS(description="Shipped quantity"),
  shipped_weight NUMERIC OPTIONS(description="Shipped weight"),
  scratched_quantity NUMERIC OPTIONS(description="Scratched quantity"),
  retail_price_quantity NUMERIC OPTIONS(description="Retail price quantity"),
  retail_price NUMERIC OPTIONS(description="Retail price"),
  percentage_profit NUMERIC OPTIONS(description="Percentage profit"),
  extended_cost NUMERIC OPTIONS(description="Extended cost"),
  base_price NUMERIC OPTIONS(description="Base price"),
  net_price NUMERIC OPTIONS(description="Net price"),
  uniform_weight_flag STRING OPTIONS(description="Uniform weight flag"),
  vendor_cost NUMERIC OPTIONS(description="Vendor cost"),
  tax_components JSON OPTIONS(description="Tax components (JSON)"),
  price_components JSON OPTIONS(description="price_component details (JSON)"),
  markout_details JSON OPTIONS(description="Markout details (JSON)"),
  item_details JSON OPTIONS(description="Item details (JSON)"),
  shipped_weight_details JSON OPTIONS(description="Shipped weight info (JSON)"),
  cool_details JSON OPTIONS(description="COOL details (JSON)"),
  wms_details JSON OPTIONS(description="WMS metadata (JSON)"),
  order_details JSON OPTIONS(description="Order metadata (JSON)"),
  order_line_details JSON OPTIONS(description="Order line info (JSON)"),
  full_pallet_discount NUMERIC OPTIONS(description="Full pallet discount"),
  audit_created_ts DATETIME NOT NULL OPTIONS(description="Record creation timestamp"),
  audit_updated_ts DATETIME NOT NULL OPTIONS(description="Last update timestamp")
)
PARTITION BY invoice_date
CLUSTER BY division_id
OPTIONS(
  description="This table contains line-level details for wholesale sales invoices, including product, pricing, shipping, quantity, and discount data"
);