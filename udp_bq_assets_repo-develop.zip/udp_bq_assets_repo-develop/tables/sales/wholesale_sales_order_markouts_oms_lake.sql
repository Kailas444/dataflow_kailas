CREATE TABLE `lake_layer.wholesale_sales_order_markouts_oms`
(
  markout_id NUMERIC OPTIONS(description="Unique Markout Identifier"),
  order_header_id NUMERIC OPTIONS(description="Order Header Identifier"),
  order_line_id NUMERIC OPTIONS(description="Order Line Identifier"),
  quantity NUMERIC OPTIONS(description="Quantity of Items"),
  line_order_qty NUMERIC OPTIONS(description="Quantity Per Order Line"),
  reason_id NUMERIC OPTIONS(description="Reason for Action"),
  reason_code STRING OPTIONS(description="Code for the Reason"),
  created_by NUMERIC OPTIONS(description="Creator of the Record"),
  creation_date DATETIME OPTIONS(description="Record Creation Date"),
  last_updated_by NUMERIC OPTIONS(description="Last Updated by User"),
  last_update_date DATETIME OPTIONS(description="Date of Last Update"),
  entry_source STRING OPTIONS(description="Source of Data Entry"),
  audit_created_ts DATETIME NOT NULL OPTIONS(description="Record creation timestamp"),
  audit_updated_ts DATETIME NOT NULL OPTIONS(description="Last update timestamp")
)
PARTITION BY DATE(audit_created_ts)
OPTIONS(
  description="This table tracks item-level markouts on wholesale sales orders, including reason codes, quantities affected, and associated order references"
);