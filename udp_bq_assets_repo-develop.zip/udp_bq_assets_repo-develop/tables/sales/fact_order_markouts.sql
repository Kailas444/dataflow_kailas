CREATE OR REPLACE TABLE `sales_silver.fact_order_markouts`
(
  markout_id INT64 OPTIONS(description="Unique identifier for each markout event."),
  order_header_id INT64 OPTIONS(description="ID referencing the order header associated with the markout."),
  order_line_id INT64 OPTIONS(description="ID referencing the specific order line that was marked out."),
  reason_id INT64 OPTIONS(description="ID representing the reason for the markout."),
  reason_cde STRING OPTIONS(description="Code description or short name for the markout reason."),
  quantity INT64 OPTIONS(description="Quantity of product marked out from the order."),
  line_order_qty INT64 OPTIONS(description="Total quantity originally ordered on the affected order line."),
  created_by INT64 OPTIONS(description="ID of the user or system that created the markout record."),
  creation_date DATETIME OPTIONS(description="Timestamp when the markout record was created."),
  last_updated_by INT64 OPTIONS(description="ID of the user or process that last updated the record."),
  last_update_date DATETIME OPTIONS(description="Timestamp of the most recent update to the record."),
  entry_source STRING OPTIONS(description="Source system or process that recorded the markout."),
  audit_created_ts DATETIME NOT NULL OPTIONS(description="Audit timestamp for when the record was first created."),
  audit_updated_ts DATETIME NOT NULL OPTIONS(description="Audit timestamp for when the record was last updated.")
)
PARTITION BY DATE(creation_date)
OPTIONS(
  description="This table tracks item-level markouts on wholesale sales orders, including reason codes, quantities affected, and associated order references"
);