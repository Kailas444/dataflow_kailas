CREATE TABLE `lake_layer.wholesale_sales_return_header_oms`
(
  return_id NUMERIC OPTIONS(description="Unique return transaction identifier"),
  invoice_id NUMERIC OPTIONS(description="Linked invoice identifier"),
  retailer_number STRING OPTIONS(description="Identifier for retailer account"),
  invoice_number STRING OPTIONS(description="Unique sales invoice number"),
  status STRING OPTIONS(description="Current return process status"),
  department STRING OPTIONS(description="Department handling the return"),
  return_auth_number STRING OPTIONS(description="Authorization number for return"),
  creation_date DATETIME OPTIONS(description="Date when return created"),
  return_date DATETIME OPTIONS(description="Date goods were returned"),
  approved_by STRING OPTIONS(description="Person approving the return"),
  approved_date DATETIME OPTIONS(description="Date return was approved"),
  total_amount NUMERIC OPTIONS(description="Total value of returned items"),
  wait_for_delivery STRING OPTIONS(description="Flag indicating pending delivery"),
  reference_data STRING OPTIONS(description="Additional reference information"),
  credit_id NUMERIC OPTIONS(description="Linked credit note identifier"),
  process_status STRING OPTIONS(description="Current processing stage status"),
  source STRING OPTIONS(description="Origin of the return request"),
  last_updated_by NUMERIC OPTIONS(description="User who last modified record"),
  last_update_date DATETIME OPTIONS(description="Date of last record update"),
  created_by NUMERIC OPTIONS(description="User who created record"),
  notes STRING OPTIONS(description="Additional remarks or comments"),
  print_on_invoice STRING OPTIONS(description="Flag to print on invoice"),
  sent_to_exabi STRING OPTIONS(description="Flag if sent to Exabi system"),
  request_id NUMERIC OPTIONS(description="Identifier for return request"),
  division_code STRING OPTIONS(description="Code of responsible division"),
  division_id NUMERIC OPTIONS(description="Division identifier number"),
  restock_fee NUMERIC OPTIONS(description="Fee charged for restocking"),
  org_code STRING OPTIONS(description="Organization code identifier"),
  estimated_amount NUMERIC OPTIONS(description="Estimated return value amount"),
  customer_details JSON OPTIONS(description="Information about the customer"),
  return_details JSON OPTIONS(description="Detailed items return information"),
  company_code STRING OPTIONS(description="Company code identifier"),
  dash_account STRING OPTIONS(description="DASH system account reference"),
  print_required STRING OPTIONS(description="Flag for printing requirement"),
  send_to_exe STRING OPTIONS(description="Flag to send to EXE system"),
  audit_created_ts DATETIME NOT NULL OPTIONS(description="Record creation timestamp"),
  audit_updated_ts DATETIME NOT NULL OPTIONS(description="Last update timestamp")
)
PARTITION BY DATE(audit_created_ts)
OPTIONS(
  description="This table captures return transactions related to wholesale sales, including invoice linkage, return status, amounts, authorization, and source system tracking"
);