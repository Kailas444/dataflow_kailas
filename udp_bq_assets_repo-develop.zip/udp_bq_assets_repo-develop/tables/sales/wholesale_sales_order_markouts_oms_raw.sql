CREATE TABLE `raw_layer.wholesale_sales_order_markouts_oms`
(
  markout_id STRING,
  order_header_id STRING,
  order_line_id STRING,
  reason_id STRING,
  reason_code STRING,
  quantity STRING,
  line_order_qty STRING,
  created_by STRING,
  creation_date STRING,
  last_updated_by STRING,
  last_update_date STRING,
  entry_source STRING
)
OPTIONS(
  description="This table tracks item-level markouts on wholesale sales orders, including reason codes, quantities affected, and associated order references."
);