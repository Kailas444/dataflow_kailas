CREATE TABLE `raw_layer.master_link_group_stores_ebs`
(
  link_store_id STRING OPTIONS(description="Unique identifier for the store-link relationship"),
  link_group_id STRING OPTIONS(description="Identifier referencing the associated link group"),
  chain_number STRING OPTIONS(description="Identifier for the store’s retail chain"),
  store_number STRING OPTIONS(description="Unique store number within the chain"),
  store_desc STRING OPTIONS(description="Textual description or name of the store"),
  created_by STRING OPTIONS(description="User who created the record"),
  creation_date STRING OPTIONS(description="Date when the record was created"),
  last_updated_by STRING OPTIONS(description="User who last updated the record"),
  last_update_date STRING OPTIONS(description="Timestamp of the last update"),
  batch_id STRING OPTIONS(description="Batch identifier for data load tracking"),
  source_system STRING OPTIONS(description="System from which the record originated"),
  is_active STRING OPTIONS(description="Flag indicating whether the store-link record is active")
)
OPTIONS (
  description = "Mapping table linking stores to link groups in EBS. Tracks store metadata, origin system, audit fields, and active status."
);
