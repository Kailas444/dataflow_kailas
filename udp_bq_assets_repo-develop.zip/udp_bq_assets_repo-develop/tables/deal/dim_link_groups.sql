CREATE TABLE `master_silver.dim_link_groups`
(
  link_group_id INT64 NOT NULL OPTIONS(description="Unique identifier for the link group"),
  division_id INT64 OPTIONS(description="ID representing the business division"),
  link_num STRING OPTIONS(description="Numeric reference for the link"),
  link_group STRING OPTIONS(description="Label assigned to the group of links"),
  is_active STRING OPTIONS(description="Indicates whether the link group is currently active (Y/N)"),
  comments STRING OPTIONS(description="Additional notes or comments about the link group"),
  created_by STRING OPTIONS(description="User who created the record"),
  creation_date DATETIME OPTIONS(description="Date and time when the link group was created"),
  last_updated_by STRING OPTIONS(description="User who last updated the record"),
  last_update_date DATETIME OPTIONS(description="Date and time when the record was last modified"),
  audit_created_ts DATETIME NOT NULL OPTIONS(description="System audit record creation timestamp"),
  audit_updated_ts DATETIME NOT NULL OPTIONS(description="System audit last update timestamp"),
  PRIMARY KEY (link_group_id) NOT ENFORCED
)
CLUSTER BY division_id
OPTIONS(
  description="Master Silver table storing link group information from Oracle EBS (dim_link_groups)",
  labels = [
    ("domain", "deals"),
    ("layer", "silver"),
    ("source", "oracle_ebs"),
    ("frequency", "daily"),
    ("grain", "link_group_id")
  ]
);
