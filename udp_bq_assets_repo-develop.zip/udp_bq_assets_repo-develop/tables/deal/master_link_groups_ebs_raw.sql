CREATE TABLE `raw_layer.master_link_groups_ebs`
(
  link_group_id STRING OPTIONS(description="Unique identifier for the link group"),
  division_id STRING OPTIONS(description="ID representing the business division"),
  facility STRING OPTIONS(description="Code of the physical facility"),
  link_group STRING OPTIONS(description="Label assigned to the group of links"),
  description STRING OPTIONS(description="Textual description of the link group"),
  link_number STRING OPTIONS(description="Coded reference for the link"),
  comments STRING OPTIONS(description="Context related to the link group"),
  created_by STRING OPTIONS(description="User who created the record"),
  creation_date STRING OPTIONS(description="Timestamp of when the link group was created"),
  last_updated_by STRING OPTIONS(description="User who last updated the record"),
  last_update_date STRING OPTIONS(description="Time the record was last modified"),
  link_identifier STRING OPTIONS(description="Key used to identify the link"),
  is_active STRING OPTIONS(description="Indicates whether the link group is currently active"),
  awi_retailergroupidentifier STRING OPTIONS(description="Identifier used by AWI for grouping retailers")
)
OPTIONS (
  description = "Master table storing link group details from EBS. It captures identifiers, organizational mapping, facility and retailer group information, along with audit and activity status."
);
