CREATE TABLE `raw_layer.master_deal_types_ebs`
(
  division_id STRING OPTIONS(description="Unique ID for a business division"),
  deal_type_id STRING OPTIONS(description="Primary key for the deal type"),
  deal_type_name STRING OPTIONS(description="Name of the deal type"),
  type_of_deal STRING OPTIONS(description="General classification"),
  po_or_so STRING OPTIONS(description="Indicates whether the deal applies to POs or SOs"),
  deduction_type STRING OPTIONS(description="Method of cost deduction applied"),
  chrm_deal_type STRING OPTIONS(description="Custom categorization of deal type"),
  deals_ui_deal_type STRING OPTIONS(description="How deal type is labeled/shown in the UI"),
  allow_multiple STRING OPTIONS(description="Flag to allow multiple deals of this type"),
  created_by STRING OPTIONS(description="User who created the record"),
  creation_date STRING OPTIONS(description="Date when the deal type was created"),
  last_updated_by STRING OPTIONS(description="User who last modified the record"),
  last_update_date STRING OPTIONS(description="Timestamp of the last update"),
  vendor_deal_type STRING OPTIONS(description="Deal classification specific to vendors"),
  chrm_deal_type_id STRING OPTIONS(description="ID corresponding to the CHRM-specific deal type"),
  responsibility_id STRING OPTIONS(description="Associated role or access responsibility ID"),
  deal_types_visible STRING OPTIONS(description="Indicates if this deal type is visible to users"),
  target_customers STRING OPTIONS(description="Intended customer groups for the deal"),
  cost_visibility STRING OPTIONS(description="Flag to control if cost info is exposed"),
  sell_application STRING OPTIONS(description="Where the deal type is applied in the selling process"),
  funding_source STRING OPTIONS(description="Origin of funds for the deal"),
  deal_type_category STRING OPTIONS(description="Grouping of the deal type"),
  add_to_cost_side STRING OPTIONS(description="Indicates if deal value affects costing"),
  add_to_sell_side STRING OPTIONS(description="Indicates if deal value affects selling price."),
  display_sequence STRING OPTIONS(description="Ordering preference in UI/display"),
  retail_price_type STRING OPTIONS(description="Type of retail pricing impacted")
)
OPTIONS (
  description = "Stores all deal types defined in the system, including categorization, visibility, and configuration details used across divisions, vendors, and customer groups."
);
