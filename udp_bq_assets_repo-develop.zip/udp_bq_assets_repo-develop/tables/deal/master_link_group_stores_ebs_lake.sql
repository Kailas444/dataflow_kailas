CREATE TABLE `lake_layer.master_link_group_stores_ebs`
(
  link_store_id INT64 NOT NULL OPTIONS(description="Unique ID for the store entry within a link group"),
  link_group_id INT64 OPTIONS(description="Reference to the associated link group"),
  chain_number STRING OPTIONS(description="Identifier for the retailer chain the store belongs to"),
  store_number STRING OPTIONS(description="Unique number assigned to the individual store"),
  store_desc STRING OPTIONS(description="Textual description or name of the store"),
  created_by NUMERIC OPTIONS(description="User who initially created the record"),
  creation_date DATETIME OPTIONS(description="Timestamp when the record was created"),
  last_updated_by NUMERIC OPTIONS(description="User who last modified the record"),
  last_update_date DATETIME OPTIONS(description="Date and time of the last update to the record"),
  batch_id INT64 OPTIONS(description="ID of the batch process that loaded or updated the data"),
  source_system STRING OPTIONS(description="Source system from which this record originated"),
  is_active STRING OPTIONS(description="Indicates if the store record is currently active"),
  audit_created_ts DATETIME NOT NULL OPTIONS(description="System audit creation timestamp"),
  audit_updated_ts DATETIME NOT NULL OPTIONS(description="System audit update timestamp")
)
PARTITION BY DATE(audit_created_ts)
OPTIONS (
  description = "Source table for link group store reference data from EBS. Stores metadata about stores within link groups, including identifiers, descriptions, creation/update details, batch lineage, source system, and audit tracking fields."
);
