CREATE TABLE `lake_layer.master_link_groups_ebs`
(
  link_group_id INT64 NOT NULL OPTIONS(description="Unique identifier for the link group"),
  division_id INT64 OPTIONS(description="ID representing the business division"),
  facility STRING OPTIONS(description="Code of the physical facility"),
  link_group STRING OPTIONS(description="Label assigned to the group of links"),
  description STRING OPTIONS(description="Textual description of the link group"),
  link_number STRING OPTIONS(description="Coded reference for the link"),
  comments STRING OPTIONS(description="Context related to the link group"),
  created_by NUMERIC OPTIONS(description="User who created the record"),
  creation_date DATETIME OPTIONS(description="Timestamp of when the link group was created"),
  last_updated_by NUMERIC OPTIONS(description="User who last updated the record"),
  last_update_date DATETIME OPTIONS(description="Time the record was last modified"),
  link_identifier STRING OPTIONS(description="Key used to identify the link"),
  is_active STRING OPTIONS(description="Indicates whether the link group is currently active"),
  awi_retailergroupidentifier NUMERIC OPTIONS(description="Identifier used by AWI for grouping retailers"),
  audit_created_ts DATETIME NOT NULL OPTIONS(description="System audit creation timestamp"),
  audit_updated_ts DATETIME NOT NULL OPTIONS(description="System audit update timestamp")
)
PARTITION BY DATE(audit_created_ts)
OPTIONS (
  description = "Source table for link group reference data from EBS. Captures metadata about link groups including division, facility, identifiers, descriptions, lifecycle status, AWI retailer group mapping, and audit timestamps."
);
