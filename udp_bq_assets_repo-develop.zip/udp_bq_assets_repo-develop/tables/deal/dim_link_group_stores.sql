CREATE TABLE `master_silver.dim_link_group_stores`
(
  link_store_id INT64 NOT NULL OPTIONS(description = "Unique ID for the store entry within a link group"),
  link_group_id INT64 NOT NULL OPTIONS(description = "Reference to the associated link group"),
  batch_id INT64 OPTIONS(description = "ID of the batch process that loaded or updated the data"),
  customer_id INT64 OPTIONS(description = "Customer ID"),
  chain_num INT64 OPTIONS(description = "Identifier for the retailer chain the store belongs to"),
  store_num STRING OPTIONS(description = "Unique number assigned to the individual store"),
  store_desc STRING OPTIONS(description = "Textual description or name of the store"),
  source_system STRING OPTIONS(description = "Code of the system from which the data originated"),
  is_active STRING OPTIONS(description = "Indicates if the store record is currently active (Y/N)"),
  created_by STRING OPTIONS(description = "User who initially created the record"),
  creation_date DATETIME OPTIONS(description = "Date and time when the record was created"),
  last_updated_by STRING OPTIONS(description = "User who last modified the record"),
  last_update_date DATETIME OPTIONS(description = "Date and time of the last update to the record"),
  audit_created_ts DATETIME NOT NULL OPTIONS(description = "System audit record creation timestamp"),
  audit_updated_ts DATETIME NOT NULL OPTIONS(description = "System audit last update timestamp"),
  PRIMARY KEY (link_store_id) NOT ENFORCED
)
CLUSTER BY customer_id
OPTIONS (
  description = "Master Silver table storing group stores information from Oracle EBS (dim_link_group_stores)",
  labels = [
    ("domain", "deals"),
    ("layer", "silver"),
    ("source", "oracle_ebs"),
    ("frequency", "daily"),
    ("grain", "link_store_id")
  ]
);
