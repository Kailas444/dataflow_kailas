CREATE TABLE `master_silver.dim_deal_types`
(
  deal_type_id INT64 NOT NULL OPTIONS(description = "Primary key for the deal type"),
  division_id INT64 OPTIONS(description = "Unique ID for a business division"),
  chrm_deal_type_id INT64 OPTIONS(description = "ID corresponding to the CHRM-specific deal type"),
  responsibility_id INT64 OPTIONS(description = "Associated role or access responsibility ID"),
  deal_type_category STRING OPTIONS(description = "Grouping of the deal type"),
  deal_type_name STRING OPTIONS(description = "Name of the deal type"),
  type_of_deal STRING OPTIONS(description = "General classification"),
  po_or_so STRING OPTIONS(description = "Indicates whether the deal applies to POs or SOs"),
  deduction_type STRING OPTIONS(description = "Method of cost deduction applied"),
  chrm_deal_type STRING OPTIONS(description = "Custom categorization of deal type"),
  deals_ui_deal_type STRING OPTIONS(description = "How deal type is labeled/shown in the UI"),
  vendor_deal_type STRING OPTIONS(description = "Deal classification specific to vendors"),
  target_customers STRING OPTIONS(description = "Intended customer groups for the deal"),
  display_sequence NUMERIC OPTIONS(description = "Ordering preference in UI/display"),
  cost_visibility STRING OPTIONS(description = "Flag to control if cost info is exposed"),
  sell_application STRING OPTIONS(description = "Where the deal type is applied in the selling process"),
  funding_source STRING OPTIONS(description = "Origin of funds for the deal"),
  add_to_cost_side STRING OPTIONS(description = "Indicates if deal value affects costing"),
  add_to_sell_side STRING OPTIONS(description = "Indicates if deal value affects selling price"),
  retail_price_type NUMERIC OPTIONS(description = "Type of retail pricing impacted"),
  created_by STRING OPTIONS(description = "User who created the record"),
  creation_date DATETIME OPTIONS(description = "DateTime when the deal type was created"),
  last_updated_by STRING OPTIONS(description = "User who last modified the record"),
  last_update_date DATETIME OPTIONS(description = "DateTime of the last update"),
  audit_created_ts DATETIME NOT NULL OPTIONS(description = "Record creation timestamp"),
  audit_updated_ts DATETIME NOT NULL OPTIONS(description = "Last update timestamp"),
  PRIMARY KEY (deal_type_id) NOT ENFORCED
)
CLUSTER BY division_id
OPTIONS (
  description = "Master Silver table storing all deal types information from Oracle EBS (promo_cs_deals_deal_type)",
  labels = [
    ("domain", "deals"),
    ("layer", "silver"),
    ("source", "oracle_ebs"),
    ("frequency", "daily"),
    ("grain", "deal_type_id")
  ]
);
