CREATE TABLE IF NOT EXISTS `udp_audit.udp_audit_metadata`
(
  pipeline_date DATE OPTIONS(description="Pipeline Execution Date"),
  dag_name STRING OPTIONS(description="Pipeline Name"),
  dataset_name  STRING OPTIONS(description="Dataset Name"),
  table_name STRING OPTIONS(description="Table Name"),
  impacted_rows BIGINT OPTIONS(description="Rows Impacted"),
  source_system STRING OPTIONS(description="Source System"),
  source_entity_name STRING OPTIONS(description="Source Entity Name"),
  entity_type STRING OPTIONS(description="Source System- Table, File, Kafka Topic"),
  data_type STRING OPTIONS(description="Type of Data"),
  user_id STRING OPTIONS(description="User ID"),
  audit_created_ts DATETIME DEFAULT CURRENT_DATETIME() OPTIONS(description="Insert Audit Datetime in EST"),
  audit_updated_ts DATETIME DEFAULT CURRENT_DATETIME() OPTIONS(description="Update Audit Datetime in EST")
)
PARTITION BY pipeline_date
CLUSTER BY dag_name,dataset_name, table_name
OPTIONS(
  description="UDP Audit Metadata"
);
