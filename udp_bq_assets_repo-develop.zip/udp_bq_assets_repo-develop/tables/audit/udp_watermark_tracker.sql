CREATE TABLE `udp_audit.udp_watermark_tracker`
(
  pipeline_run_date DATE OPTIONS(description="Pipeline DAG Execution Date"),  
  dag_name STRING OPTIONS(description="Pipeline Dag Name"),  
  dag_execution_ts DATETIME OPTIONS(description="Pipeline DAG Execution Timestamp"),
  dataset_name STRING OPTIONS(description="Dataset Name"), 
  table_name STRING OPTIONS(description="Table Name"),  
  min_partition_key STRING OPTIONS(description="Source Data Partition Key"),
  max_partition_key STRING OPTIONS(description="Source Data Partition Key"),
  row_identifiers JSON OPTIONS(description="Source Data Identifier"),  
  status_cde STRING OPTIONS(description="Source to Target Ingestion Watermark Status"),  
  audit_created_ts DATETIME DEFAULT CURRENT_DATETIME() OPTIONS(description="Insert Audit Datetime in EST"),
  audit_updated_ts DATETIME DEFAULT CURRENT_DATETIME() OPTIONS(description="Update Audit Datetime in EST")
)
CLUSTER BY dag_name
OPTIONS(
  description="UDP Watermark Tracker"
);