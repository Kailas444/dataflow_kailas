CREATE TABLE `master_silver.dim_department`
(
  item_dept_id INT64 NOT NULL OPTIONS(description="Item Department ID"),
  item_dept_desc STRING OPTIONS(description="Item Department Description"),
  ebs_item_dept_num STRING OPTIONS(description="EBS Item Department Number")
)
OPTIONS(
  description="C&S Item Department Dimension"
);