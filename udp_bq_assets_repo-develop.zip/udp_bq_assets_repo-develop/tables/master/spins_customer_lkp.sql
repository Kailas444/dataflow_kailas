CREATE TABLE `master_silver.spins_customer_lkp`
(
  spin_store_id INT64 OPTIONS(description="SPINS Store ID managed by SPINS"),
  spins_store_name STRING OPTIONS(description="SPINS Store Name"),
  parent_name STRING OPTIONS(description="Parent Store or Headquarters"),  
  customer_id INT64 OPTIONS(description="C&S Customer ID"),
  address STRING OPTIONS(description="Store Address"),
  city STRING OPTIONS(description="Store City"),
  state STRING OPTIONS(description="Store State"),
  region STRING OPTIONS(description="Store Region"),
  PRIMARY KEY (spin_store_id, customer_id) NOT ENFORCED 
)
options(description='SPINS Store ID to UDP Customer ID Lookup Table');