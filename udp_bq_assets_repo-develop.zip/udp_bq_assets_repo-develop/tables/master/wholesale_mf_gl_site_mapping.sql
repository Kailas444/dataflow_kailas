CREATE TABLE `lake_layer.wholesale_mf_gl_site_mapping`
(
  mf_gl_site_id INT64 OPTIONS(description="Mainframe GL Site ID."),
  organization_cde STRING OPTIONS(description="Organization Code."),
  warehouse_type STRING OPTIONS(description="Warehouse Type."),
  hyperion_warehouse_num STRING OPTIONS(description="Hyperion Warehouse Num"),
  audit_created_ts DATETIME OPTIONS(description="Audit created timestamp."),
  audit_updated_ts DATETIME OPTIONS(description="Audit updated timestamp.")
);