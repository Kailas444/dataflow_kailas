CREATE TABLE `master_silver.dim_calendar`
(
  calendar_id INT64 OPTIONS(description="Unique ID for the Calendar."),
  calendar_desc STRING OPTIONS(description="Calendar Identifier Descrition."),
  fiscal_date DATE OPTIONS(description="Fiscal Date."),
  day_num INT64 OPTIONS(description="Day Number Indicator."),
  week_day_ind INT64 OPTIONS(description="Week Day Indicator."),
  week_day_short_desc STRING OPTIONS(description="Week Day Short Description"),
  week_day_long_desc STRING OPTIONS(description="Week Day Long Description."),
  week_begin_date DATE OPTIONS(description="Week Begin Date."),
  week_end_date DATE OPTIONS(description="Week End Date"),
  week_num INT64 OPTIONS(description="Week Number."),
  month_begin_date DATE OPTIONS(description="Month Begin Date."),
  month_end_date DATE OPTIONS(description="Month End Date."),
  month_num INT64 OPTIONS(description="Month Number."),
  quarter_begin_date DATE OPTIONS(description="Quarter Begin Date."),
  quarter_end_date DATE OPTIONS(description="Quarter End Date."),
  quarter_num INT64 OPTIONS(description="Quarter Number."),
  year_begin_date DATE OPTIONS(description="Year Begin Date."),
  year_end_date DATE OPTIONS(description="Year End Date."),
  holiday_ind DATE OPTIONS(description="Holiday Indicator."),
  fiscal_year INT64 OPTIONS(description="Fiscal Year."),
  last_fiscal_year INT64 OPTIONS(description="Last Fiscal Year."),
  ly_date DATE OPTIONS(description="Last Fiscal Year Date."),
  ly_week_begin_date DATE OPTIONS(description="Last Year Week Begin Date"),
  ly_week_end_date DATE OPTIONS(description="Last Year Week End Date"),
  ly_month_begin_date DATE OPTIONS(description="Last Year Month Begin Date."),
  ly_month_end_date DATE OPTIONS(description="Last Year Month End Date."),
  ly_quarter_begin_date DATE OPTIONS(description="Last Year Quarter Begin Date."),
  ly_quarter_end_date DATE OPTIONS(description="Last Year Quarter End Date."),
  ly_year_begin_date DATE OPTIONS(description="Last Year Begin Date."),
  ly_year_end_date DATE OPTIONS(description="Last Year End Date."),
  audit_created_ts DATETIME OPTIONS(description="Audit created timestamp."),
  audit_updated_ts DATETIME OPTIONS(description="Audit updated timestamp."),
  PRIMARY KEY (calendar_id,fiscal_date) NOT ENFORCED
)
OPTIONS(
  description="C&S Fiscal Calendar"
);