CREATE TABLE `lake_layer.master_divisions_exabi`
(
  division_id INT64,
  division_code STRING,
  division_name STRING,
  default_warehouse STRING,
  start_date DATE,
  end_date DATE,
  parent_division STRING,
  dp_flag STRING,
  dp_org STRING,
  active_flag STRING,
  created_by NUMERIC,
  creation_date DATE,
  last_update_date DATE,
  last_updated_by NUMERIC,
  item_length NUMERIC,
  dp_oms STRING,
  company_code STRING,
  ship_mode STRING,
  audit_created_ts DATETIME DEFAULT current_datetime(),
  audit_updated_ts DATETIME DEFAULT current_datetime()
)
PARTITION BY DATE(audit_created_ts)
OPTIONS(
  description="Lake Layer Division Table Sourced from OMS OMS_DIVISION"
);