CREATE TABLE `master_silver.dim_product_hierarchy`
(
  hierarchy_id INT64 OPTIONS(description="Unique ID for the product hierarchy."),
  hierarchy_name STRING OPTIONS(description="Name of the product hierarchy."),
  l0_product_family STRING OPTIONS(description="Broadest product group (e.g., Food, Non-Food)."),
  l1_product_class STRING OPTIONS(description="High-level classification within the product family."),
  l2_ebs_gl_product_code INT64 OPTIONS(description="ERP/GL product code (e.g., from Oracle EBS)."),
  l2_ebs_gl_product_desc STRING OPTIONS(description="Description of the GL product code."),
  l3_item_department_num INT64 OPTIONS(description="Department number for mid-level grouping."),
  l3_item_department_name STRING OPTIONS(description="Department name."),
  l4_item_category INT64 OPTIONS(description="Item category code (lowest level)."),
  l4_item_category_desc STRING OPTIONS(description="Description of the item category."),
  l5_sub_category_cde STRING OPTIONS(description="sub category code"),
  l5_sub_category_desc STRING OPTIONS(description="sub category desc"),
  l6_brand_name STRING OPTIONS(description="brand Name"),
  l7_product_id INT64 OPTIONS(description="product id"),
  l7_product_description STRING OPTIONS(description="product description"),
  creation_date DATETIME OPTIONS(description="Record creation date."),
  created_by STRING OPTIONS(description="Creator of the record."),
  last_update_date DATETIME OPTIONS(description="Last update date of the record."),
  last_updated_by STRING OPTIONS(description="Last user/system who updated the record."),
  audit_created_ts DATETIME OPTIONS(description="Audit created timestamp"),
  audit_updated_ts DATETIME OPTIONS(description="Audit updated timestamp")
);