CREATE TABLE `master_silver.dim_customer_hierarchy`
(
  hierarchy_id INT64 OPTIONS(description="Unique ID for the Customer Hierarchy."),
  hierarchy_name STRING OPTIONS(description="Name of the Customer Hierarchy."),
  l0_customer_class STRING OPTIONS(description="Customer Class."),
  l1_customer_ar_segment STRING OPTIONS(description="Customer AR Segment"),
  l2_chain_num STRING OPTIONS(description="Chain Number."),
  l2_chain_name STRING OPTIONS(description="Chain Name."),
  l3_customer_division_num INT64 OPTIONS(description="Customer Division Number."),
  l3_customer_division_name STRING OPTIONS(description="Customer Division Name."),
  l4_ebs_gl_cust_group_num STRING OPTIONS(description="EBS/GL Customer Group Number."),
  l4_ebs_gl_cust_group_name STRING OPTIONS(description="EBS/GL Customer Group Name."),
  l6_store_num STRING OPTIONS(description="Store Number."),
  l6_store_name STRING OPTIONS(description="Store Name."),
  l5_customer_id INT64 OPTIONS(description="Customer ID."),
  audit_created_ts DATETIME OPTIONS(description="Audit created timestamp."),
  audit_updated_ts DATETIME OPTIONS(description="Audit updated timestamp."),
  PRIMARY KEY (hierarchy_id,l5_customer_id) NOT ENFORCED
)
CLUSTER BY hierarchy_id
OPTIONS(
  description="Customer Hierachy Table",
  labels=[("layer", "master"), ("source", "dim_customer"), ("frequency", "daily")]
);
