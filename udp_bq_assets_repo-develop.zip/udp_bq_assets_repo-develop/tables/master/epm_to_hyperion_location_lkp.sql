CREATE OR REPLACE TABLE `master_silver.epm_to_hyperion_location_lkp`
(
  hyperion_warehouse_num STRING NOT NULL OPTIONS(description="Warehouse Hyperion Warehouse Number"),
  hyperion_location_num STRING NOT NULL OPTIONS(description="Hyperion Location number receives in Mainframe File ")
)
OPTIONS(
  description="Mainframe Location Lookup "
);
