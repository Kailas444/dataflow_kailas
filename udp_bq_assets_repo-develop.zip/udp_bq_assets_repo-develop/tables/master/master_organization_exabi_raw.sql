CREATE TABLE `raw_layer.master_organization_exabi`
(
  organization_code STRING,
  organization_name STRING,
  source STRING,
  address_line_1 STRING,
  address_line_2 STRING,
  address_line_3 STRING,
  city STRING,
  state STRING,
  zipcode STRING,
  buyer_vendor_nbr STRING
)
OPTIONS(
  description="Raw Layer Organization Table Sourced from EXABI MF_LOCATION"
);