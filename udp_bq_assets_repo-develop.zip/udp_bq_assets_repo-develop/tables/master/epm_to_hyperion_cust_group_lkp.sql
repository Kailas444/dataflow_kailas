CREATE TABLE `master_silver.epm_to_hyperion_cust_group_lkp`
(
  epm_customer_num STRING NOT NULL OPTIONS(description="EPM Source Customer Number"),
  hyperion_customer_num STRING NOT NULL OPTIONS(description="Hyperion Source Customer Number"),
  ebs_gl_cust_group_id INT64 OPTIONS(description="EBS Customer Group Number")
)
OPTIONS(
  description="EPM to Hyperion Customer Group Lookup "
);