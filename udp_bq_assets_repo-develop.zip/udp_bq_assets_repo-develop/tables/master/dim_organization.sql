CREATE TABLE `master_silver.dim_organization`
(
  organization_id INT64 OPTIONS(description="Organization ID"),
  organization_cde STRING OPTIONS(description="Organization code"),
  city STRING OPTIONS(description="City"),
  state STRING OPTIONS(description="State"),
  zipcode STRING OPTIONS(description="Zipcode"),
  organization_name STRING OPTIONS(description="Organization name"),
  source STRING OPTIONS(description="Source system"),
  address_line_1 STRING OPTIONS(description="Address line 1"),
  address_line_2 STRING OPTIONS(description="Address line 2"),
  address_line_3 STRING OPTIONS(description="Address line 3"),
  division_id INT64 OPTIONS(description="Division ID"),
  audit_created_ts DATETIME DEFAULT CURRENT_DATETIME(),
  audit_updated_ts DATETIME DEFAULT CURRENT_DATETIME(),
  PRIMARY KEY (organization_id) NOT ENFORCED
)
OPTIONS(
  description="C&S Warehouse Organization Dimension"
);