CREATE TABLE `master_silver.dim_divisions`
(
  division_id INT64 OPTIONS(description="Division ID"),
  dp_organization_num STRING OPTIONS(description="Org number"),
  legacy_company_cde STRING OPTIONS(description="Legacy company"),
  division_cde STRING OPTIONS(description="Division code"),
  division_name STRING OPTIONS(description="Division name"),
  parent_division STRING OPTIONS(description="Parent division"),
  dp_oms STRING OPTIONS(description="OMS reference"),
  default_warehouse STRING OPTIONS(description="Default warehouse"),
  start_date DATETIME OPTIONS(description="Start date"),
  end_date DATETIME OPTIONS(description="End date"),
  dp_flag STRING OPTIONS(description="DP flag"),
  active_flag STRING OPTIONS(description="Active flag"),
  created_by NUMERIC OPTIONS(description="Created by"),
  creation_date DATETIME OPTIONS(description="Creation date"),
  last_update_date DATETIME OPTIONS(description="Last updated"),
  last_updated_by NUMERIC OPTIONS(description="Updated by"),
  ship_mode STRING OPTIONS(description="Ship mode"),
  audit_created_ts DATETIME DEFAULT CURRENT_DATETIME(),
  audit_updated_ts DATETIME DEFAULT CURRENT_DATETIME(),
  PRIMARY KEY (division_id) NOT ENFORCED
)
OPTIONS(
  description="C&S Division Dimension"
);