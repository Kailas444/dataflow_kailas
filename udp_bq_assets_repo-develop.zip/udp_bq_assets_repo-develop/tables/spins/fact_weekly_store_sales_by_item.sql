CREATE TABLE `retail_intel_silver.fact_weekly_store_sales_by_item`
(
  week_end_date DATE OPTIONS(description="Week End Date - Sunday"),
  store_id NUMERIC OPTIONS(description="Unique identifier for each store"),
  spins_store_id INT64 OPTIONS(description="Unique identifier for each store in spins api"),
  department_id NUMERIC OPTIONS(description=" Unique identifier for each department"),
  category_id NUMERIC OPTIONS(description=" Unique identifier for each category"),
  product_id NUMERIC OPTIONS(description=" Unique identifier for each product"),
  upc STRING OPTIONS(description="Universal product code of the item"),
  sales_qty NUMERIC OPTIONS(description="Number of product units sold"),
  sales_amt NUMERIC OPTIONS(description="Total sales amount in currency"),
  sales_qty_non_promotion NUMERIC OPTIONS(description="Units sold without promotion"),
  sales_amt_non_promotion NUMERIC OPTIONS(description="Revenue without promotional offers"),
  sales_qty_with_promotion NUMERIC OPTIONS(description="Units sold during promotion period"),
  sales_amt_with_promotion NUMERIC OPTIONS(description="Sales amount with promotions applied"),
  audit_created_ts DATETIME DEFAULT CURRENT_DATETIME() OPTIONS(description="Insert Audit Datetime in EST"),
  audit_updated_ts DATETIME DEFAULT CURRENT_DATETIME() OPTIONS(description="Update Audit Datetime in EST")
)
PARTITION BY week_end_date
CLUSTER BY store_id, product_id, upc
OPTIONS(
  description="SPINS Weekly aggregated Sales by Store and UPC "
);