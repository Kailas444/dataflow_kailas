CREATE TABLE `lake_layer.retail_intel_weekly_sales_spins`
(
  reportinglevel STRING OPTIONS(description='Weekly SPINS Aggregation by UPC'),
  enddate DATE OPTIONS(description='Week End Date - Sunday'),
  numberofweeks INT64 OPTIONS(description='Number of Weeks to Aggregate'),
  retailer STRING OPTIONS(description='Retailer Name'),
  store STRING OPTIONS(description='Store Name'),
  storeid INT64 OPTIONS(description='SPINS Store ID'),
  department STRING OPTIONS(description='SPINS Department Name'),
  brand STRING OPTIONS(description='SPINS Product Brand Name'),
  category STRING OPTIONS(description='SPINS Product Category Name'),
  subcategory STRING OPTIONS(description='SPINS Product Sub Category Name'),
  upc STRING OPTIONS(description='Product UPC Code')  ,
  dollars NUMERIC OPTIONS(description='Sales Dollars'),
  units NUMERIC OPTIONS(description='Sales Units'),
  dollarsnonpromotion NUMERIC OPTIONS(description='Sales Dollars with No Promotions'),
  dollarspromotion NUMERIC OPTIONS(description='Sales Dollars with Promotions'),
  unitsnonpromotion NUMERIC OPTIONS(description='Sales Units with No Promotions'),
  unitspromotion NUMERIC OPTIONS(description='Sales Units with Promotions'),
  isfilldata BOOL OPTIONS(description='Boolean Is Fill Data'),
  file_source STRING OPTIONS(description='File Source'),
  file_name STRING OPTIONS(description='Source File Name'),
  audit_created_ts DATETIME OPTIONS(description='Insert Audit Datetime in EST'),
  audit_updated_ts DATETIME OPTIONS(description='Update Audit Datetime in EST')    
)
PARTITION BY date(audit_created_ts)
CLUSTER BY enddate,storeid,upc
OPTIONS (
  DESCRIPTION='SPINS Weekly Lake Sales data ');