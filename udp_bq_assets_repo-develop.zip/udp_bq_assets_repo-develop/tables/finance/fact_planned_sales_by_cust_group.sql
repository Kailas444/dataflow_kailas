CREATE OR REPLACE TABLE `finance_silver.fact_planned_sales_by_cust_group`
(
  fiscal_date DATE NOT NULL OPTIONS(DESCRIPTION='Fiscal Date'),
  plan_cycle_cde STRING NOT NULL OPTIONS(DESCRIPTION='Budget Plan Type - BUD, Q2 & Q4 are the values'),
  location_id INT64 OPTIONS(DESCRIPTION='Warehouse Location ID'), 
  item_dept_id INT64 OPTIONS(DESCRIPTION='Item Department ID'), 
  ebs_gl_cust_group_num STRING OPTIONS(DESCRIPTION='Customer Group ID'), 
  planned_cases_qty NUMERIC OPTIONS(DESCRIPTION='Planned Cases'), 
  planned_sales_amount NUMERIC OPTIONS(DESCRIPTION='Planned Sales Amount'),
  audit_created_ts DATETIME NOT NULL OPTIONS(DESCRIPTION='Insert Audit Timestamp'),
  audit_updated_ts DATETIME NOT NULL OPTIONS(DESCRIPTION='Update Audit Timestamp'),
  PRIMARY KEY (fiscal_date, plan_cycle_cde,location_id,item_dept_id,ebs_gl_cust_group_num) NOT ENFORCED  
)
PARTITION BY DATE(audit_created_ts)
CLUSTER BY fiscal_date,ebs_gl_cust_group_num,location_id,item_dept_id
OPTIONS(DESCRIPTION='Finance Planned Sales and Cases for Fiscal Year')  ;