CREATE TABLE `finance_silver.fact_planned_inventory_by_location`
(
  fiscal_date DATE NOT NULL OPTIONS(description="Fiscal Date"),
  plan_cycle_cde STRING NOT NULL OPTIONS(description="Budget Plan Type - BUD, Q2 & Q4 are the values"),
  location_id INT64 OPTIONS(description="Warehouse Location ID"),
  item_dept_id INT64 OPTIONS(description="Item Department ID"),
  inv_account_name STRING OPTIONS(description="Inventory Account Name"),
  inventory_amount NUMERIC OPTIONS(description="Planned Inventory Amount"),
  audit_created_ts DATETIME NOT NULL OPTIONS(description="Insert Audit Timestamp"),
  audit_updated_ts DATETIME NOT NULL OPTIONS(description="Update Audit Timestamp"),
  PRIMARY KEY (fiscal_date, plan_cycle_cde, location_id, item_dept_id) NOT ENFORCED
)
PARTITION BY DATE(audit_created_ts)
CLUSTER BY fiscal_date, location_id, item_dept_id
OPTIONS(
  description="Finance Planned Inventory Dollars for Fiscal Year"
);