CREATE TABLE `lake_layer.fin_planned_sales_and_cases`
(
  plan_type STRING OPTIONS(description="Plan Type"),
  plan_account_desc STRING OPTIONS(description="Account Description"),
  fiscal_week_end_date DATE OPTIONS(description="Fiscal Week End Date in Format MM/DD/YY"),
  business_unit STRING OPTIONS(description="Plan Business Unit"),
  department STRING OPTIONS(description="Department"),
  product STRING OPTIONS(description="Product"),
  location STRING OPTIONS(description="Plan Location Number"),
  plan_cust_group_num STRING OPTIONS(description="Plan Customer Group Number"),
  planned_cases NUMERIC OPTIONS(description="Total Planned Sales"),
  planned_sales_amt NUMERIC OPTIONS(description="Planned Sales Amount"),
  file_source STRING OPTIONS(description="File Source"),
  file_name STRING OPTIONS(description="Source File Name"),
  audit_created_ts DATETIME OPTIONS(description="Insert Audit Timestamp"),
  audit_updated_ts DATETIME OPTIONS(description="Update Audit Timestamp")
)
PARTITION BY DATE(audit_created_ts)
CLUSTER BY plan_type
OPTIONS(
  description="Finance Planned Sales and Cases for Fiscal Year"
);