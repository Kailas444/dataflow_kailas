
CREATE TABLE `lake_layer.fin_dailyinv_po_dlvry`
(

  item_code INT64 options(description='Item Code'),
  warehouse_number INT64 options(description='Warehouse Number'),
  gl_site STRING options(description='Facilitiy Number'),
  gl_number INT64 options(description='GL Product Number'),
  on_order_type STRING options(description='Order Type'),
  delivery_date INT64 options(description='PO Delivery in Days'),
  on_order_qty INT64 options(description='PO Order quantity'),
  audit_created_ts datetime options(description='Record creation timestamp'),
  audit_updated_ts datetime options(description='Last update timestamp')
)
partition by date(audit_created_ts)
options(description='Open Purchase Orders in Dollars');