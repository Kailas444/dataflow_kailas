CREATE OR REPLACE VIEW `slotting.sslot_item_v` AS
SELECT
	Z_ITEM_SSlot.SSIC,
	Z_ITEM_SSlot.CODE,
	Z_ITEM_SSlot.DESTINATION,
	Z_ITEM_SSlot.DEPT_ID,
	Z_ITEM_SSlot.Zone,
	Z_ITEM_SSlot.AISLE,
	Z_ITEM_SSlot.BAY,
	Z_ITEM_SSlot.PICK,
	Z_ITEM_SSlot.Location,
	Z_ITEM_SSlot.PSIZE,
	Z_ITEM_SSlot.SLOT_DESCRIPTION,
	Z_ITEM_SSlot.DESCRIPTION,
	Z_ITEM_SSlot.NLSN_CTGRY_DESC,
	Z_ITEM_SSlot.VENDOR_TI,
	Z_ITEM_SSlot.VENDOR_HI,
	Z_ITEM_SSlot.STOR_TI,
	Z_ITEM_SSlot.STOR_HI,
	Z_ITEM_SSlot.BOH,
	Z_ITEM_SSlot.BOO,
	Z_ITEM_SSlot.CSE_WGT,
	Z_ITEM_SSlot.CSE_CUBE,
	Z_ITEM_SSlot.CSE_HGT,
	Z_ITEM_SSlot.CASEPACK,
	Z_ITEM_SSlot.SHIPPER,
	Z_ITEM_SSlot.13WK_Sum,
	Z_ITEM_SSlot.13WkAvg,
	Z_ITEM_SSlot.5WkAvg,
	Z_ITEM_SSlot.Week_1,
	Z_ITEM_SSlot.Week_2,
	Z_ITEM_SSlot.Week_3,
	Z_ITEM_SSlot.Week_4,
	Z_ITEM_SSlot.Week_5,
	Z_ITEM_SSlot.CUST_SETUP,
	Z_ITEM_SSlot.CUSTOMER,
	Z_ITEM_SSlot.CSlot,
	Z_ITEM_SSlot.SSlot,
	FORMAT( '%.6f',
	CASE
		WHEN Z_ITEM_SSlot.5WkAvg = 0 THEN 0
		WHEN Z_ITEM_SSlot.CSlot IN ('Re-Pack', 'HS/RR') THEN (CAST(Z_ITEM_SSlot.5WkAvg AS FLOAT64) / CAST(Z_ITEM_SSlot.Mastercase AS FLOAT64)) * CAST(Z_ITEM_SSlot.CSE_CUBE AS FLOAT64) / CASE
			WHEN (CAST(Calibrations.HS_Height AS FLOAT64) = 0
			OR CAST(Calibrations.HS_Width AS FLOAT64) = 0
			OR CAST(Calibrations.HS_Depth AS FLOAT64) = 0) THEN NULL
			ELSE (CAST(Calibrations.HS_Height AS FLOAT64) * CAST(Calibrations.HS_Width AS FLOAT64) * CAST(Calibrations.HS_Depth AS FLOAT64)) / (12 * 12 * 12)
		END
		WHEN Z_ITEM_SSlot.CSlot = 'SHORT' THEN Z_ITEM_SSlot.5WkAvg / ( CASE
			WHEN CAST(Z_ITEM_SSlot.STOR_TI AS FLOAT64) = 0 THEN NULL
			ELSE CAST(Z_ITEM_SSlot.STOR_TI AS FLOAT64) * CASE
				WHEN ((Calibrations.Short_Opening - Calibrations.Lift_Clear - Calibrations.Pallet_Height) / CAST(Z_ITEM_SSlot.CSE_HGT AS FLOAT64)) < 1 THEN 1
				ELSE ((Calibrations.Short_Opening - Calibrations.Lift_Clear - Calibrations.Pallet_Height) / CAST(Z_ITEM_SSlot.CSE_HGT AS FLOAT64))
			END
		END )
		WHEN Z_ITEM_SSlot.CSlot = 'TALL' THEN Z_ITEM_SSlot.5WkAvg / ( CASE
			WHEN CAST(Z_ITEM_SSlot.STOR_TI AS FLOAT64) = 0 THEN NULL
			ELSE CAST(Z_ITEM_SSlot.STOR_TI AS FLOAT64) * CASE
				WHEN ((Calibrations.Tall_Opening - Calibrations.Lift_Clear - Calibrations.Pallet_Height) / CAST(Z_ITEM_SSlot.CSE_HGT AS FLOAT64)) < 1 THEN 1
				ELSE ((Calibrations.Tall_Opening - Calibrations.Lift_Clear - Calibrations.Pallet_Height) / CAST(Z_ITEM_SSlot.CSE_HGT AS FLOAT64))
			END
		END )
		ELSE NULL
	END ) AS C_Replens,
	FORMAT( CASE
		WHEN Z_ITEM_SSlot.5WkAvg = 0 THEN '0'
		WHEN Z_ITEM_SSlot.SSlot IN ('Re-Pack', 'HS/RR') THEN CAST( (CAST(Z_ITEM_SSlot.5WkAvg AS FLOAT64) / CAST(Z_ITEM_SSlot.Mastercase AS FLOAT64)) * CAST(Z_ITEM_SSlot.CSE_CUBE AS FLOAT64) / CASE
			WHEN (CAST(Calibrations.HS_Height AS FLOAT64) = 0
			OR CAST(Calibrations.HS_Width AS FLOAT64) = 0
			OR CAST(Calibrations.HS_Depth AS FLOAT64) = 0) THEN NULL
			ELSE (CAST(Calibrations.HS_Height AS FLOAT64) * CAST(Calibrations.HS_Width AS FLOAT64) * CAST(Calibrations.HS_Depth AS FLOAT64)) / (12 * 12 * 12)
		END AS STRING)
		WHEN Z_ITEM_SSlot.SSlot = 'SHORT' THEN CAST( Z_ITEM_SSlot.5WkAvg / ( CASE
			WHEN CAST(Z_ITEM_SSlot.STOR_TI AS FLOAT64) = 0 THEN NULL
			ELSE CAST(Z_ITEM_SSlot.STOR_TI AS FLOAT64) * CASE
				WHEN CAST(((Calibrations.Short_Opening - Calibrations.Lift_Clear - Calibrations.Pallet_Height) / CAST(Z_ITEM_SSlot.CSE_HGT AS FLOAT64)) AS FLOAT64) < 1 THEN 1
				ELSE CAST(((Calibrations.Short_Opening - Calibrations.Lift_Clear - Calibrations.Pallet_Height) / CAST(Z_ITEM_SSlot.CSE_HGT AS FLOAT64)) AS FLOAT64)
			END
		END ) AS STRING )
		WHEN Z_ITEM_SSlot.SSlot = 'TALL' THEN CAST( Z_ITEM_SSlot.5WkAvg / ( CASE
			WHEN CAST(Z_ITEM_SSlot.STOR_TI AS FLOAT64) = 0 THEN NULL
			ELSE CAST(Z_ITEM_SSlot.STOR_TI AS FLOAT64) * CASE
				WHEN CAST(((Calibrations.Tall_Opening - Calibrations.Lift_Clear - Calibrations.Pallet_Height) / CAST(Z_ITEM_SSlot.CSE_HGT AS FLOAT64)) AS FLOAT64) < 1 THEN 1
				ELSE CAST(((Calibrations.Tall_Opening - Calibrations.Lift_Clear - Calibrations.Pallet_Height) / CAST(Z_ITEM_SSlot.CSE_HGT AS FLOAT64)) AS FLOAT64)
			END
		END ) AS STRING )
		ELSE 'NULL'
	END ) AS S_Replens,
	( CASE
		WHEN Z_ITEM_SSlot.5WkAvg = 0 THEN 0
		WHEN Z_ITEM_SSlot.SSlot IN ('Re-Pack', 'HS/RR') THEN CAST( (CAST(Z_ITEM_SSlot.5WkAvg AS FLOAT64) / CAST(Z_ITEM_SSlot.Mastercase AS FLOAT64)) * CAST(Z_ITEM_SSlot.CSE_CUBE AS FLOAT64) / CASE
			WHEN (CAST(Calibrations.HS_Height AS FLOAT64) = 0
			OR CAST(Calibrations.HS_Width AS FLOAT64) = 0
			OR CAST(Calibrations.HS_Depth AS FLOAT64) = 0) THEN NULL
			ELSE (CAST(Calibrations.HS_Height AS FLOAT64) * CAST(Calibrations.HS_Width AS FLOAT64) * CAST(Calibrations.HS_Depth AS FLOAT64)) / (12 * 12 * 12)
		END AS FLOAT64)
		WHEN Z_ITEM_SSlot.SSlot = 'SHORT' THEN CAST( Z_ITEM_SSlot.5WkAvg / ( CASE
			WHEN CAST(Z_ITEM_SSlot.STOR_TI AS FLOAT64) = 0 THEN NULL
			ELSE CAST(Z_ITEM_SSlot.STOR_TI AS FLOAT64) * CASE
				WHEN CAST(((Calibrations.Short_Opening - Calibrations.Lift_Clear - Calibrations.Pallet_Height) / CAST(Z_ITEM_SSlot.CSE_HGT AS FLOAT64)) AS FLOAT64) < 1 THEN 1
				ELSE CAST(((Calibrations.Short_Opening - Calibrations.Lift_Clear - Calibrations.Pallet_Height) / CAST(Z_ITEM_SSlot.CSE_HGT AS FLOAT64)) AS FLOAT64)
			END
		END ) AS FLOAT64 )
		WHEN Z_ITEM_SSlot.SSlot = 'TALL' THEN CAST( Z_ITEM_SSlot.5WkAvg / ( CASE
			WHEN CAST(Z_ITEM_SSlot.STOR_TI AS FLOAT64) = 0 THEN NULL
			ELSE CAST(Z_ITEM_SSlot.STOR_TI AS FLOAT64) * CASE
				WHEN CAST(((Calibrations.Tall_Opening - Calibrations.Lift_Clear - Calibrations.Pallet_Height) / CAST(Z_ITEM_SSlot.CSE_HGT AS FLOAT64)) AS FLOAT64) < 1 THEN 1
				ELSE CAST(((Calibrations.Tall_Opening - Calibrations.Lift_Clear - Calibrations.Pallet_Height) / CAST(Z_ITEM_SSlot.CSE_HGT AS FLOAT64)) AS FLOAT64)
			END
		END ) AS FLOAT64 )
		ELSE CAST(NULL AS FLOAT64)
	END ) - ( CASE
		WHEN Z_ITEM_SSlot.5WkAvg = 0 THEN 0
		WHEN Z_ITEM_SSlot.SSlot IN ('Re-Pack', 'HS/RR') THEN CAST( (CAST(Z_ITEM_SSlot.5WkAvg AS FLOAT64) / CAST(Z_ITEM_SSlot.Mastercase AS FLOAT64)) * CAST(Z_ITEM_SSlot.CSE_CUBE AS FLOAT64) / CASE
			WHEN (CAST(Calibrations.HS_Height AS FLOAT64) = 0
			OR CAST(Calibrations.HS_Width AS FLOAT64) = 0
			OR CAST(Calibrations.HS_Depth AS FLOAT64) = 0) THEN NULL
			ELSE (CAST(Calibrations.HS_Height AS FLOAT64) * CAST(Calibrations.HS_Width AS FLOAT64) * CAST(Calibrations.HS_Depth AS FLOAT64)) / (12 * 12 * 12)
		END AS FLOAT64)
		WHEN Z_ITEM_SSlot.SSlot = 'SHORT' THEN CAST( Z_ITEM_SSlot.5WkAvg / ( CASE
			WHEN CAST(Z_ITEM_SSlot.STOR_TI AS FLOAT64) = 0 THEN NULL
			ELSE CAST(Z_ITEM_SSlot.STOR_TI AS FLOAT64) * CASE
				WHEN CAST(((Calibrations.Short_Opening - Calibrations.Lift_Clear - Calibrations.Pallet_Height) / CAST(Z_ITEM_SSlot.CSE_HGT AS FLOAT64)) AS FLOAT64) < 1 THEN 1
				ELSE CAST(((Calibrations.Short_Opening - Calibrations.Lift_Clear - Calibrations.Pallet_Height) / CAST(Z_ITEM_SSlot.CSE_HGT AS FLOAT64)) AS FLOAT64)
			END
		END ) AS FLOAT64 )
		WHEN Z_ITEM_SSlot.SSlot = 'TALL' THEN CAST( Z_ITEM_SSlot.5WkAvg / ( CASE
			WHEN CAST(Z_ITEM_SSlot.STOR_TI AS FLOAT64) = 0 THEN NULL
			ELSE CAST(Z_ITEM_SSlot.STOR_TI AS FLOAT64) * CASE
				WHEN CAST(((Calibrations.Tall_Opening - Calibrations.Lift_Clear - Calibrations.Pallet_Height) / CAST(Z_ITEM_SSlot.CSE_HGT AS FLOAT64)) AS FLOAT64) < 1 THEN 1
				ELSE CAST(((Calibrations.Tall_Opening - Calibrations.Lift_Clear - Calibrations.Pallet_Height) / CAST(Z_ITEM_SSlot.CSE_HGT AS FLOAT64)) AS FLOAT64)
			END
		END ) AS FLOAT64 )
		ELSE CAST(NULL AS FLOAT64)
	END ) AS `Replen Diff`
FROM
	`slotting.calibrations` AS Calibrations
RIGHT JOIN `slotting.z-item-sslot` AS Z_ITEM_SSlot ON
	Calibrations.Zone = Z_ITEM_SSlot.Zone
	AND Calibrations.Building = CAST(Z_ITEM_SSlot.DESTINATION AS INT64)
ORDER BY
	Z_ITEM_SSlot.Location;
