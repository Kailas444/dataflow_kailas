CREATE OR REPLACE  VIEW `shared_dimensions.dim_calendar_vw`
AS select * from `master_silver.dim_calendar`;