CREATE OR REPLACE  VIEW `shared_dimensions.dim_vendor_vw`
AS select * from `master_silver.dim_vendor`;