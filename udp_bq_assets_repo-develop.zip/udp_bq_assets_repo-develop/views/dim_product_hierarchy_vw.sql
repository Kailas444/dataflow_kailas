CREATE OR REPLACE VIEW `shared_dimensions.dim_product_hierarchy_vw`
AS
(
  SELECT * FROM `master_silver.dim_product_hierarchy`
);
