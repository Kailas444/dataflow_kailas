CREATE OR REPLACE  VIEW `shared_dimensions.dim_department_vw`
AS select * from `master_silver.dim_department`;