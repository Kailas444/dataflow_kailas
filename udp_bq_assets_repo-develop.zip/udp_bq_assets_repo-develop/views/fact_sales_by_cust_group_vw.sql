CREATE OR REPLACE VIEW `finance_silver.fact_sales_by_cust_group_vw`
AS (
    select s.*,c.customer_group_id customer_group_id
    from  `finance_silver.fact_sales_by_account` s
    left join
        `shared_dimensions.dim_customer_vw` c
    on s.customer_id = c.customer_id
)