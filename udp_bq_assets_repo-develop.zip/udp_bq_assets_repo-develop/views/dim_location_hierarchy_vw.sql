CREATE OR REPLACE VIEW `shared_dimensions.dim_location_hierarchy_vw`
AS
(
  SELECT * FROM `master_silver.dim_location_hierarchy`
);
