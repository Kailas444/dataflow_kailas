CREATE OR REPLACE  VIEW `shared_dimensions.dim_location_vw`
AS select * from `master_silver.dim_location`;