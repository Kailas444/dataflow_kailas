CREATE OR REPLACE VIEW `shared_dimensions.dim_customer_vw`
AS select * from `master_silver.dim_customer`;