CREATE OR REPLACE  VIEW `shared_dimensions.dim_division_vw`
AS select * from `master_silver.dim_divisions`;