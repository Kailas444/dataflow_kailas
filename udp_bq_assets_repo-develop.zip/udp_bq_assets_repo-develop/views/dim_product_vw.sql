CREATE OR REPLACE  VIEW `shared_dimensions.dim_product_vw`
AS select * from `master_silver.dim_product`;