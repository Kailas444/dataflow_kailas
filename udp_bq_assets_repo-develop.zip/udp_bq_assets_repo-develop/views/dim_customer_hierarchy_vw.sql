CREATE OR REPLACE VIEW `shared_dimensions.dim_customer_hierarchy_vw`
AS
(
  SELECT * FROM `master_silver.dim_customer_hierarchy`
);