"""
    File Name: config_parser.py
    Description: 
        This file contains the ConfigParser Class which helps 
        to read configuration files for the framework.
    Created By: sprithiv
    Revision History:
        | Date      | Author    | Changes Made
        | 2025-03-27| sprithiv   | Initial Framework
"""
import os
import yaml
import logging
from typing import List
from jinja2 import Environment, FileSystemLoader, select_autoescape, Undefined
from pathlib import Path
from cs_orchestration_fw.utils.get_environment import get_env_details

logger = logging.getLogger(__name__)

class KeepUndefined(Undefined):
    """
    Custom Undefined for Jinja2 that keeps undefined values untouched
    and prints them back as template expressions.
    """

    def __getattr__(self, name):
        # For attribute access: {{ ti.xcom_pull }}
        return KeepUndefined(name=f"{self._undefined_name}.{name}")

    def __getitem__(self, key):
        # For dictionary-like access: {{ ti['key'] }}
        return KeepUndefined(name=f"{self._undefined_name}[{repr(key)}]")

    def __call__(self, *args, **kwargs):
        # For function calls: {{ ti.xcom_pull('task') }}
        args_repr = ", ".join(map(repr, args))
        kwargs_repr = ", ".join(f"{k}={v!r}" for k, v in kwargs.items())
        all_args = ", ".join(filter(None, [args_repr, kwargs_repr]))
        return KeepUndefined(name=f"{self._undefined_name}({all_args})")

    def __str__(self):
        # How it will appear in the final rendered template
        return f"{{{{ {self._undefined_name} }}}}"

    __repr__ = __str__

    # Boolean conversion (used in if conditions)
    def __bool__(self):
        return False

    # Length handling (if someone does {{ var|length }})
    def __len__(self):
        return 0

    # Iteration handling (just empty iterator)
    def __iter__(self):
        return iter([])

    # Arithmetic operations (leave unchanged)
    def __add__(self, other):
        return KeepUndefined(name=f"{self._undefined_name}+{other}")

    def __radd__(self, other):
        return KeepUndefined(name=f"{other}+{self._undefined_name}")

    def __sub__(self, other):
        return KeepUndefined(name=f"{self._undefined_name}-{other}")

    def __rsub__(self, other):
        return KeepUndefined(name=f"{other}-{self._undefined_name}")

    def __mul__(self, other):
        return KeepUndefined(name=f"{self._undefined_name}*{other}")

    def __truediv__(self, other):
        return KeepUndefined(name=f"{self._undefined_name}/{other}")

    def __eq__(self, other):
        return False

    def __ne__(self, other):
        return True


class ConfigParser:
    """
        This class is used to parse the configuration file.
        Methods:
        __init__: Initializes the ConfigParser object.
        read_and_update_jinja_template: Reads and updates the Jinja template.
        read_yaml_file: Reads a YAML file and returns its content as a dictionary.
        read_yaml_data: Reads the YAML data from a string and returns it as a dictionary.
        get_base_folder_path: Returns the base folder path for the composer.
        get_config_details: Gets the configuration details from files.
        read_main_config_file: Fetches environment specific configuration file path from common configuration file.
        get_pipeline_specific_config_details: Gets the configuration of the pipeline.
        validate_pipeline_config: Validate the pipeline config.
    """
    def __init__(self,base_folder=None) -> None:
        """
        Initializes the config parser.

        Raises:
            Exception: If an unexpected error occurs while initializing the config parser.
        """
        try:
            self.environment = get_env_details()

            if not self.environment:
                raise EnvironmentVariableNotSetInAirflow(self.environment)
            
            self.base_folder_path = self.get_base_folder_path(base_folder)
            self.pipeline_config_path = self.base_folder_path / "dag_config" 
            
            if self.environment == "prod":
                self.env_config_file_path = self.base_folder_path / "env_config" / "env_config.yaml"
            else:
                self.env_config_file_path = self.base_folder_path / "env_config" / f"env_config_{self.environment}.yaml"        

        except Exception as exp:
            logger.error(f"An unexpected error occurred while initializing the config parser: {exp}")
            raise exp
        
    def get_config_details(self, config_path: str) -> List:
        """This function gets the configuration details from files.

        Returns:
            List of the DAG configuration
        """

        self.dag_config_path = self.pipeline_config_path / config_path

        # Read main configuration file
        # and get common config path and pipeline config path.
        try:
            if self.dag_config_path:
                env_config_details = self.get_environment_dict()
                pipeline_config_data = self.read_and_update_jinja_template(self.dag_config_path,env_config_details)    
                dag_config_dict= self.read_yaml_data(pipeline_config_data)
                self.validate_pipeline_config(dag_config_dict)

            else:
                logger.error("pipeline_file_path cannot be blank")
                raise ValueError("pipeline_file_path cannot be blank")
            return dag_config_dict
        except Exception as exp:
            logger.error(f"An unexpected error occurred in the get_config_details method: {exp}")
            raise exp        

    def read_and_update_jinja_template(
        self, template_path: str, jinja_dict: dict
    ) -> str:
        """Reads and updates the Jinja template.
        Args:
            template_path: The template file path which needs to be read 
            jinja_dict: Values that are required to be replaced.
        Returns:
            Template with jinja specific values replaced.
        """
        try:
            # Check if template_path and jinja_dict are not empty
            if not template_path:
                logger.error("template_path cannot be empty.")
                raise ValueError("template_path cannot be empty.")
            
            if not os.path.exists(template_path):
                logger.error(f"Template file '{template_path}' does not exist.")
                raise FileNotFoundError(f"Template file '{template_path}' does not exist.")
            
            if not jinja_dict:
                logger.error("jinja_dict cannot be empty.")
                raise ValueError("jinja_dict cannot be empty.")
            
            # Extract the folder of the file path
            jinja_template_folder = os.path.dirname(template_path)
            # Extact the file from the file path
            jinja_file = os.path.basename(template_path)  
            # load the jinja file and substitute the values.
          
            environment = Environment(
                autoescape=select_autoescape(['xml']),
                loader=FileSystemLoader(
                    jinja_template_folder
                ),
                undefined=KeepUndefined
            )
            template = environment.get_template(jinja_file)
            read_data = template.render(jinja_dict)
            return read_data
        except Exception as exp:
            logger.error(f"An unexpected error occurred: {exp}")  
            raise exp

    def read_yaml_file(self, file_path: str) -> dict:
        """
        Reads a YAML file and returns its content as a dictionary.
        Args:
            file_path (str): Path to the YAML file.
        Returns:
            dict: The content of the YAML file.
        """
        try:
            yaml_content_dict = {}
            if not os.path.exists(file_path):
                logger.error(f"File '{file_path}' does not exist.")
                raise FileNotFoundError(f"File '{file_path}' does not exist.")
            
            with open(file_path, 'r') as file_obj:  # pylint: disable=unspecified-encoding
                yaml_content_dict = yaml.safe_load(file_obj)
            return yaml_content_dict
        except Exception as exp:
            logger.error(f"An unexpected error occurred in the read_yaml_file method: {exp}")  
            raise exp

    def read_yaml_data(self, yaml_data: str) -> dict:
        """
        Reads the YAML data from a string and returns it as a dictionary.
        Args:
            yaml_data (str): YAML data in string format.
        Returns:
            dict: The content of the YAML data.
        """
        try:
            if not yaml_data:
                logger.error("yaml_data cannot be empty.")
                raise ValueError("yaml_data cannot be empty.")
            
            yaml_content_dict = yaml.safe_load(yaml_data)
            return yaml_content_dict
        except Exception as exp:
            logger.error(f"An unexpected error occurred in the read_yaml_data method: {exp}")
            raise exp

    def get_environment_dict(self) -> dict:
        """
        Reads the YAML data from a string and returns it as a dictionary.
        Args:
            yaml_data (str): YAML data in string format.
        Returns:
            dict: The content of the YAML data.
        """
        try:
            env_name = self.environment
            env_config_dict = self.read_yaml_file(self.env_config_file_path)['environments'][env_name]                
            return env_config_dict
        except Exception as exp:
            logger.error(f"An unexpected error occurred in the Environment read_yaml_data method: {exp}")
            raise exp                 

    def get_base_folder_path(self,base_folder=None) -> str:
        """Gets the base folder path for the composer
        Args:
            None
        Returns:
            Base folder path for composer
        """
        try:
            # setting default in case DAG_FOLDER is not configured.
            if base_folder:
                base_folder_path = Path(base_folder)
            else:
                base_folder_path = Path("/home/airflow/gcs/dags")
            logger.info("DAG Config is not set in the environment. Setting default path. %s",base_folder_path)
                
            return base_folder_path
        except Exception as exp:
            logger.error(f"An unexpected error occurred while setting the base_folder_path: {exp}")
            raise exp
        

    def validate_pipeline_config(
        self, 
        pipeline_config_details: dict
    ) -> None:
        """Validate the pipeline config
        Args:
            pipeline_config_details: Pipeline configuration details.
            pipeline_config_path: Pipeline specific configuration file path.
        Returns:
            None
        """
        try:
            # Check if pipeline_config_details and pipeline_config_path are present and not empty
            if not pipeline_config_details:
                logger.error("pipeline_config_details cannot be empty.")
                raise ValueError("pipeline_config_details cannot be empty.")
            
            # Validation of 'tasks_spec' tag in the pipeline config file.
            if 'pipeline' not in pipeline_config_details:
                logger.error(f"Tag pipeline is not present the config file \
                file {self.dag_config_path}")
                raise KeyError(f"Tag pipeline is not present the main config \
                file {self.dag_config_path}")
            if 'tasks' not in pipeline_config_details:
                logger.error(f"Tag tasks is not present the main config \
                file {self.dag_config_path}")
                raise KeyError(f"Tag tasks is not present the main config \
                file {self.dag_config_path}")
            if not isinstance(pipeline_config_details['tasks'], list):
                logger.error("The list of DAG's specification is required to be present \
                in dag_spec")
                raise KeyError("The list of DAG's specification is required to be present \
                in dag_spec")
        except Exception as exp:
            logger.error(f"An unexpected error occurred in the validate_pipeline_config method: {exp}")
            raise exp

class EnvironmentVariableNotSetInAirflow(Exception):
    """Custom exception raised when environment variable is not set."""

    def __init__(self, env_variable):
        super().__init__(
            f"Environment variable '{env_variable}' is not set in Airflow."
        )

