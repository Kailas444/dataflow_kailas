from cs_orchestration_fw.utils.base_logger import get_logger
from cs_orchestration_fw.task.task_creator import TaskCreator
from cs_orchestration_fw.task.task_sequencer import TaskSequencer
from airflow import DAG
from cs_orchestration_fw.config_parser.config_parser import ConfigParser
from datetime import datetime
from airflow.exceptions import AirflowException


logger = get_logger(__name__)

class DagCreator:
    """
        This class is used to create the airflow dag
    """
    def __init__(self, config_file: str,custom_function_registry: dict = None):
        self.config_file = config_file
        config_obj = ConfigParser()
        pipeline_config_dict = config_obj.get_config_details(self.config_file)
        self.pipeline_config_dict = pipeline_config_dict
        self.dag_args = self.pipeline_config_dict.get('pipeline', {})
        self.tasks_config_list = self.pipeline_config_dict.get('tasks', [])
        self.custom_function_registry = custom_function_registry
        self.dag_id =  self.dag_args['dag_id']

    def create_dag_from_config(self):
        
        try:
            print(f"dag args={self.dag_args}")    
            if 'dag_id' not in self.dag_args:
                logger.error(f"DAG name not present in the config file")
                raise ValueError("Unable to Create the Dag as dag_id key not found in the Config File")

            dag_attributes = self.dag_args.copy()
            dag_attributes.pop("dag_id")
            tasks_list = self.tasks_config_list.copy()

            if "start_date" not in dag_attributes:
                raise AirflowException("Missing required parameter 'start_date' in DAG YAML config.")

            # Convert string into datetime at midnight
            dag_attributes["start_date"] = datetime.strptime(dag_attributes["start_date"], "%Y-%m-%d")

            dag_obj = DAG(
                            dag_id=self.dag_id,
                            **dag_attributes
                        ) 
            
            task_creator_obj = TaskCreator(dag_obj, tasks_list)
            task_operators,task_dependencies = task_creator_obj.create_tasks(self.custom_function_registry)

            task_sequence_obj = TaskSequencer(task_operators,task_dependencies)
            task_sequence_obj.set_task_sequence()

            return dag_obj

        except Exception as exp:
            logger.error(f"An error occurred while creating airflow DAG: {exp}")
            raise exp