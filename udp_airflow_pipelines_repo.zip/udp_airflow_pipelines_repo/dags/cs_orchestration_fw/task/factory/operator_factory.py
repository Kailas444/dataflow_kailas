"""
    File Name: operator_factory.py
    Description: This file contains operator factory class
        used to provide the operators for the dag.
    Created By: abpatre
    Revision History:
        | Date      | Author    | Changes Made
        | 2025-03-27| sprithiv   | Initial Framework
"""
from inspect import getmembers, isfunction

import json
from airflow import DAG
from airflow.models import BaseOperator

from airflow.operators.empty import EmptyOperator as DummyOperator
from airflow.operators.python import PythonOperator
from airflow.operators.bash import BashOperator
from airflow.operators.python import BranchPythonOperator
from airflow.operators.python import ShortCircuitOperator
from airflow.operators.trigger_dagrun import TriggerDagRunOperator
from airflow.providers.common.sql.operators.sql import SQLExecuteQueryOperator
from airflow.providers.google.cloud.transfers.gcs_to_gcs import GCSToGCSOperator  # noqa
from airflow.providers.google.cloud.operators.gcs import GCSDeleteObjectsOperator
from airflow.providers.google.cloud.operators.bigquery import BigQueryInsertJobOperator
from airflow.providers.google.cloud.operators.bigquery import BigQueryCheckOperator
from airflow.providers.google.cloud.operators.bigquery import BigQueryValueCheckOperator
from airflow.providers.google.cloud.operators.bigquery import BigQueryUpdateTableOperator
from airflow.providers.google.cloud.operators.bigquery import BigQueryCreateTableOperator
from airflow.providers.google.cloud.operators.bigquery import BigQueryGetDataOperator
from airflow.providers.google.cloud.operators.bigquery import BigQueryUpsertTableOperator
from airflow.providers.google.cloud.operators.bigquery import BigQueryDeleteTableOperator
from airflow.providers.google.cloud.operators.bigquery import BigQueryIntervalCheckOperator
from airflow.providers.google.cloud.operators.bigquery import BigQueryColumnCheckOperator
from airflow.providers.google.cloud.operators.bigquery import BigQueryTableCheckOperator
from airflow.providers.google.cloud.sensors.bigquery import BigQueryTableExistenceSensor
from airflow.providers.google.cloud.sensors.bigquery import BigQueryTablePartitionExistenceSensor
from airflow.providers.google.cloud.operators.dataflow import DataflowTemplatedJobStartOperator
from airflow.providers.google.cloud.operators.dataflow import DataflowStartFlexTemplateOperator
from airflow.providers.google.cloud.operators.dataproc import DataprocSubmitJobOperator
from airflow.providers.google.cloud.operators.dataproc import DataprocCreateClusterOperator
from airflow.providers.google.cloud.operators.dataproc import DataprocDeleteClusterOperator
from airflow.providers.google.cloud.sensors.dataproc import DataprocJobSensor
from airflow.providers.google.cloud.transfers.postgres_to_gcs import PostgresToGCSOperator
from airflow.providers.google.cloud.operators.dataflow import DataflowStartFlexTemplateOperator
from airflow.providers.google.cloud.sensors.dataflow import DataflowJobStatusSensor
from airflow.providers.google.cloud.operators.dataform import DataformCreateCompilationResultOperator
from airflow.providers.google.cloud.operators.dataform import DataformCreateWorkflowInvocationOperator
from airflow.providers.google.cloud.operators.cloud_run import CloudRunExecuteJobOperator
from airflow.providers.google.cloud.operators.cloud_run import CloudRunDeleteJobOperator
from airflow.providers.google.cloud.operators.cloud_run import CloudRunCreateJobOperator
from airflow.providers.google.cloud.operators.cloud_run import CloudRunUpdateJobOperator

from cs_orchestration_fw.utils.base_logger import get_logger
from typing import Callable
# from cs_orchestration_fw.task.task_operator.constant import Constant
# from cs_orchestration_fw.task.task_operator.audit_helper import AuditHelper
# from cs_orchestration_fw.task.task_operator.db_ingestion_helper import DbIngestionHelper
# from cs_orchestration_fw.task.task_operator.ingestion_helper import IngestionHelper
# from cs_orchestration_fw.task.task_operator.metadata_refresh_helper import MetadataRefreshHelper
# from cs_orchestration_fw.task.task_operator.alert_and_notification_helper import AlertNotificationHelper


logger = get_logger(__name__)


class OperatorFactory:
    """
        This class is used to get the operators.
    """

    def __init__(self) -> None:
        """
        Initializes the OperatorFactory object.
        This method initializes the OperatorFactory object by setting up the operator factory map and helper functions map.
        It also registers operators and python helper functions.
        Parameters:
            None
        Returns:
            None
        """
        self._operator_factory_map = {}
        self._helper_functions_map = {}

        try:
            self._register_operators()
            # self._register_python_helper_functions()
        except Exception as e:
            logger.error("Error occurred during initialization of OperatorFactory: %s", str(e))
            raise e

    def _register_operators(self) -> None:
        """Registers the operators that can be supplied through the operator Factory Class.

            Args:
                None
            Returns:
                None
            Background: 
                This function helps us resolve the problem statement: "How to resolve the Airflow Operators by the Framework". The airflow operators are the classes which is being used to create the airflow tasks. In this function, we are using 'self._operator_factory_map' to store the airflow operators, and the method 'get_operator_task' leverages this variable to get the airflow operator classes for consumption.
            Usage Guide:
                This function helps in adding the Airflow operator's support to the framework.
                When someone plans to use any new operator, following steps are required to be followed:
                    1. Add import statement into this class 
                        ex. from airflow.operators.python import PythonOperator
                    2. Set the Operator Factory map variable with the class name. 
                        ex. self._operator_factory_map['PythonOperator'] = PythonOperator
                    3. Add operator name in the constant.py file for the variable TASK_TYPE_MAPPING
        """
        try:
            self._operator_factory_map['BashOperator'] = BashOperator
            self._operator_factory_map['DummyOperator'] = DummyOperator
            self._operator_factory_map['PythonOperator'] = PythonOperator
            self._operator_factory_map['GCSToGCSOperator'] = GCSToGCSOperator
            self._operator_factory_map['ShortCircuitOperator'] = ShortCircuitOperator
            self._operator_factory_map['BranchPythonOperator'] = BranchPythonOperator
            self._operator_factory_map['TriggerDagRunOperator'] = TriggerDagRunOperator
            self._operator_factory_map['SQLExecuteQueryOperator'] = SQLExecuteQueryOperator
            self._operator_factory_map['GCSDeleteObjectsOperator'] = GCSDeleteObjectsOperator
            self._operator_factory_map['BigQueryInsertJobOperator'] = BigQueryInsertJobOperator
            self._operator_factory_map['DataflowTemplatedJobStartOperator'] = DataflowTemplatedJobStartOperator
            self._operator_factory_map['DataflowStartFlexTemplateOperator'] = DataflowStartFlexTemplateOperator
            self._operator_factory_map['DataprocSubmitJobOperator'] = DataprocSubmitJobOperator
            self._operator_factory_map['DataprocCreateClusterOperator'] = DataprocCreateClusterOperator
            self._operator_factory_map['DataprocDeleteClusterOperator'] = DataprocDeleteClusterOperator
            self._operator_factory_map['DataprocJobSensor'] = DataprocJobSensor
            self._operator_factory_map['PostgresToGCSOperator'] = PostgresToGCSOperator
            self._operator_factory_map['DataflowStartFlexTemplateOperator'] = DataflowStartFlexTemplateOperator
            self._operator_factory_map['DataflowJobStatusSensor'] = DataflowJobStatusSensor
            self._operator_factory_map['DataformCreateCompilationResultOperator'] = DataformCreateCompilationResultOperator
            self._operator_factory_map['DataformCreateWorkflowInvocationOperator'] = DataformCreateWorkflowInvocationOperator
            self._operator_factory_map['CloudRunExecuteJobOperator'] = CloudRunExecuteJobOperator
            self._operator_factory_map['BigQueryCheckOperator'] = BigQueryCheckOperator
            self._operator_factory_map['BigQueryValueCheckOperator'] = BigQueryValueCheckOperator
            self._operator_factory_map['BigQueryUpdateTableOperator'] = BigQueryUpdateTableOperator
            self._operator_factory_map['BigQueryCreateTableOperator'] = BigQueryCreateTableOperator
            self._operator_factory_map['BigQueryGetDataOperator'] = BigQueryGetDataOperator
            self._operator_factory_map['BigQueryUpsertTableOperator'] = BigQueryUpsertTableOperator
            self._operator_factory_map['BigQueryDeleteTableOperator'] = BigQueryDeleteTableOperator
            self._operator_factory_map['BigQueryIntervalCheckOperator'] = BigQueryIntervalCheckOperator
            self._operator_factory_map['BigQueryColumnCheckOperator'] = BigQueryColumnCheckOperator
            self._operator_factory_map['BigQueryTableCheckOperator'] = BigQueryTableCheckOperator
            self._operator_factory_map['BigQueryTableExistenceSensor'] = BigQueryTableExistenceSensor
            self._operator_factory_map['BigQueryTablePartitionExistenceSensor'] = BigQueryTablePartitionExistenceSensor
            self._operator_factory_map['CloudRunDeleteJobOperator'] = CloudRunDeleteJobOperator
            self._operator_factory_map['CloudRunCreateJobOperator'] = CloudRunCreateJobOperator
            self._operator_factory_map['CloudRunUpdateJobOperator'] = CloudRunUpdateJobOperator


            logger.info(
                "Following Operators are registered and are ready to use (%s)",
                self._operator_factory_map
            )
        except Exception as e:
            logger.error("Error occurred during operator registration: %s", str(e))
            raise e

    def register_python_custom_callables(self,custome_callable_registry: dict) -> None:
        """Registers the cusotmer callable functions that can be supplied through the Main Py.

            Args:
                custome_callable_registry: cusomte callable dict
            Returns:
                None
        """
        try:
            if custome_callable_registry:
                for function_name in custome_callable_registry:
                    self._add_python_custom_callable(function_name,custome_callable_registry[function_name])

                logger.info(
                    "Following python Helpers are registered and are ready to use (%s)",
                    self._helper_functions_map
                )
        except Exception as e:
            logger.error("Error occurred during python helper function registration: %s", str(e))
            raise e
        
    def _add_python_custom_callable(self, key: str, function_name: Callable) -> None:
        """
        Adds a Python helper function to the helper functions map.

        Args:
            class_name (str): The name of the class containing the helper function.
            function_name (str): The name of the helper function.

        Raises:
            DuplicatePythonHelperFunctionFound: If a duplicate helper function is found in the class.

        Raises:
            ValueError: If invalid parameters are passed to the function.

        Returns:
            None
        """
        if callable(function_name):
            if key not in self._helper_functions_map:
                self._helper_functions_map[key] = function_name
            else:
                logger.error(f"Duplicate function{key} Found")
                raise DuplicatePythonHelperFunctionFound(None, key)
            
        else:
            logger.error(f"Invalid parameter passed to function _add_python_helper_function. {class_name=} and {function_name=}")
            raise ValueError(f"Invalid parameter passed to function _add_python_helper_function. {class_name=} and {function_name=}")


    def _add_python_helper_function(self, class_name: str, function_name: str) -> None:
        """
        Adds a Python helper function to the helper functions map.

        Args:
            class_name (str): The name of the class containing the helper function.
            function_name (str): The name of the helper function.

        Raises:
            DuplicatePythonHelperFunctionFound: If a duplicate helper function is found in the class.

        Raises:
            ValueError: If invalid parameters are passed to the function.

        Returns:
            None
        """
        if class_name and function_name:
            if function_name not in self._helper_functions_map:
                self._helper_functions_map[function_name] = eval(f"{class_name}.{function_name}")
            else:
                logger.error(f"Duplicate function{function_name} Found in class{class_name}")
                raise DuplicatePythonHelperFunctionFound(class_name, function_name)
            
        else:
            logger.error(f"Invalid parameter passed to function _add_python_helper_function. {class_name=} and {function_name=}")
            raise ValueError(f"Invalid parameter passed to function _add_python_helper_function. {class_name=} and {function_name=}")


    def _register_python_helper_functions(self) -> None:
        """Registers the callable functions that can be supplied through the operator Factory Class.

            Args:
                None
            Returns:
                None
            Background:
                This function helps us resolve the problem statement: "How to resolve the callable functions by the Framework". The functionalities are divided into seperate classes in the framework. All these classes needs to have all the staticmethods. In this function, we are using 'self._helper_functions_map' to store python callable functions, and the method 'get_operator_task' leverages this variable to get the helper function's callable functions
            Usage Guide:
                This function helps in adding the helper function's callable functions to the framework.
                When someone plans to use any new custom classes, following steps are required to be followed:
                    1. Add import statement into this class.
                        ex. from cs_orchestration_fw.task.task_operator.audit_helper import AuditHelper
                    2. Set the function map variable with the class name. 
                        ex. for function_name in dict(getmembers(AuditHelper, isfunction)):
                                self._add_python_helper_function('AuditHelper', function_name)
        """
        try:
            # for function_name in dict(getmembers(IngestionHelper, isfunction)):
            #     self._add_python_helper_function('IngestionHelper', function_name)
            # for function_name in dict(getmembers(AlertNotificationHelper, isfunction)):
            #     self._add_python_helper_function('AlertNotificationHelper', function_name)
            # for function_name in dict(getmembers(AuditHelper, isfunction)):
            #     self._add_python_helper_function('AuditHelper', function_name)
            # for function_name in dict(getmembers(MetadataRefreshHelper, isfunction)):
            #     self._add_python_helper_function('MetadataRefreshHelper', function_name)
            # for function_name in dict(getmembers(DbIngestionHelper, isfunction)):
            #     self._add_python_helper_function('DbIngestionHelper', function_name)

            logger.info(
                "Following python Helpers are registered and are ready to use (%s)",
                self._helper_functions_map
            )
        except Exception as e:
            logger.error("Error occurred during python helper function registration: %s", str(e))
            raise e

    def _get_operator_class(self, operator_name: str) -> BaseOperator:
        """Returns the Airflow operator based on the operator name

            Args:
                operator_name: Airflow operator name
            Returns:
                Airflow operator Class.
        """
        operator_class: BaseOperator = None
        try:
            if operator_name and isinstance(operator_name, str):
                if operator_name in self._operator_factory_map:
                    operator_class = self._operator_factory_map.get(operator_name)
                else:
                    raise OperatorNotRegisteredException(operator_name)
            else:
                logger.error(f"Invalid parameter passed to function _get_operator_class. {operator_name=}")
                raise ValueError(f"Invalid parameter passed to function _get_operator_class. {operator_name=}")
        except Exception as e:
            logger.error("Error occurred while getting operator class: %s", str(e))
            raise e

        return operator_class

    def _get_python_helper_function(self, function_name: str) -> callable:
        """Returns the Python helper functions based on the function name

            Args:
                function_name: Custom python function name
            Returns:
                Callable python function
        """
        helper_function: callable = None

        try:
            if function_name and isinstance(function_name, str):
                if function_name in self._helper_functions_map:
                    logger.info(f"Python Helper Exists: {function_name}")
                    helper_function = self._helper_functions_map[function_name]
                else:
                    logger.info(f"Python Helper Doesn't Exist: {function_name}")
                    raise FunctionNotRegisteredException(function_name)
            else:
                logger.error(f"Invalid parameter passed to function _get_python_helper_function. {function_name=}")
                raise ValueError(f"Invalid parameter passed to function _get_python_helper_function. {function_name=}")
        except Exception as e:
            logger.error("Error occurred while getting python helper function: %s", str(e))
            raise e

        return helper_function

    def does_operator_exists(self, operator_name: str) -> bool:
        """Checks if the operator exists in the registed operator list.

            Args:
                operator_name: Airflow Operator name
            Returns:
                Boolean value depending on if the value is present.
        """
        try:
            if operator_name and isinstance(operator_name, str):
                logger.info(f"Operator Exists: {operator_name}")
                return operator_name in self._operator_factory_map
            else:
                logger.info(f"Operator doesn't Exist: {operator_name}")
                logger.error(f"Invalid parameter passed to function does_operator_exists. {operator_name=}")
                raise ValueError(f"Invalid parameter passed to function does_operator_exists. {operator_name=}")

        except Exception as e:
            logger.error("Error occurred while checking if operator exists: %s", str(e))
            raise e
        
    def get_operator_task(
            self, dag_obj: DAG, task_spec: dict
    ) -> BaseOperator:
        """Gets the operator task.

            Args:
                dag_obj: Dag object
                task_spec: task Specification
            Returns:
                the task operator object, ready to use.
        """
        operator_task: object = None
    
        try:
            if(
                dag_obj and task_spec and isinstance(task_spec, dict)
            ):
                # (task_id, task_spec) = self.set_dag_defaults(task_id, task_spec, dag_config_file_path)
                _task_spec = task_spec.copy()
                task_id = _task_spec['id']
                operator = _task_spec.pop('operator')

                if operator == "PythonOperator":
                    if _task_spec['python_callable'] in self._helper_functions_map:
                        _task_spec['python_callable'] = self._helper_functions_map[_task_spec['python_callable']]                

                _task_spec.pop('id')
                _task_spec.pop('dependencies',None)
                _task_spec['task_id'] = task_id
                _task_spec['dag'] = dag_obj
                operator_class = self._get_operator_class(operator)
                operator_task = operator_class(**_task_spec)
                logger.info(f"Task {task_id} - {operator}:Operator is created.")
            else:
                logger.error(f"Invalid parameter passed to function get_operator_task. {task_id=} and {dag_obj=} and {_task_spec=}")
                raise ValueError(f"Invalid parameter passed to function get_operator_task. {task_id=} and {dag_obj=} and {_task_spec=}")

        except Exception as e:
            logger.error("Error occurred while getting operator task: %s", str(e))
            raise e

        return operator_task

    def set_dag_defaults(#NOSONAR
        self, task_id: str, task_spec: dict,
        dag_config_file_path: str
    ) -> tuple:
        """
        Sets default values for the task specification in a DAG.

        Args:
            task_id (str): The ID of the task.
            task_spec (dict): The specification of the task.

        Returns:
            tuple: A tuple containing the task ID and the updated task specification.
        """
        try:
            if (
                task_id and task_spec and dag_config_file_path
                and isinstance(task_spec, dict)
            ):
                # In case there is any python callable function required while
                # preparing the operator, resolve the string value with python
                # callable function
                # Skipping 'on_execute_callback', 'on_failure_callback', 'on_success_callback' detection.
                # In case DAG tries to implement these callbacks, they will be ignored.
                for callable_key in [
                    'python_callable', 'on_retry_callback'
                ]:
                    if callable_key in task_spec:
                        task_spec[callable_key] = self._get_python_helper_function(
                            task_spec[callable_key])

                task_spec = self.set_doc_json_defaults(task_spec)

                # By Default, all the DAGs shall have common callbacks
                task_spec['on_success_callback'] = \
                    AuditHelper.generic_on_success_callback  # noqa
                task_spec['on_failure_callback'] = \
                    AuditHelper.generic_on_failure_callback  # noqa
                task_spec['on_execute_callback'] = \
                    AuditHelper.generic_on_execute_callback  # noqa
                logger.info(f"The DAG related defaults are set. {task_spec}")

                return task_id, task_spec
            else:
                logger.error(f"Invalid parameter passed to function set_dag_defaults. {task_id=} and {task_spec=} and {dag_config_file_path=}")
                raise ValueError(f"Invalid parameter passed to function set_dag_defaults. {task_id=} and {task_spec=} and {dag_config_file_path=}")

        except Exception as e:
            logger.error("Error occurred while setting DAG defaults: %s", str(e))
            raise e

    def set_doc_json_defaults(self, task_spec: dict) -> dict:
        """
        Sets default values for the 'doc_json' field in the task specification dictionary.
        This method ensures that the 'doc_json' field in the task_spec dictionary contains
        default alert delivery settings for task failure and data quality (DQ) failure alerts.
        Args:
            task_spec (dict): The task specification dictionary which may contain the 'doc_json' field.
        Returns:
            dict: The updated task specification dictionary with default 'doc_json' values set.
        """

        if 'doc_json' in task_spec:
            # Logic for ALERT_CODE_TASK_FAILURE
            # -----------------------------------------------
            doc_dict = task_spec['doc_json']

            if 'alert_delivery' in doc_dict:
                doc_dict['alert_delivery'].update(
                    {
                        Constant.ALERT_CODE_TASK_FAILURE:  {
                        "is_email_notification_enabled": True,
                        "is_service_now_notification_enabled": False,
                        "is_team_notification_enabled": False
                        }
                    }
                )
            else:
                doc_dict["alert_delivery"] = {
                    Constant.ALERT_CODE_TASK_FAILURE: {
                        "is_email_notification_enabled": True,
                        "is_service_now_notification_enabled": False,
                        "is_team_notification_enabled": False
                    }
                }
            # Logic for ALERT_CODE_DQ_FAILURE
            # -----------------------------------------------
            if 'dq_enabled_ind' in doc_dict and doc_dict['dq_enabled_ind']:
                doc_dict['alert_delivery'][Constant.ALERT_CODE_DQ_FAILURE] =  {
                    "is_email_notification_enabled": True,
                    "is_service_now_notification_enabled": False,
                    "is_team_notification_enabled": False
                }

            task_spec['doc_json'] = json.dumps(doc_dict)
        else:
            task_spec['doc_json'] =  json.dumps(
                {
                    "alert_delivery": {
                        Constant.ALERT_CODE_TASK_FAILURE: {
                            "is_email_notification_enabled": True,
                            "is_service_now_notification_enabled": False,
                            "is_team_notification_enabled": False
                        }
                    }
                }
            )

        return task_spec


# -------------------------------------------------------------------------------------
# Custom Exception class to resolve pylint error
# -------------------------------------------------------------------------------------
class OperatorNotRegisteredException(Exception):
    """
        Custom Exception for case when operator is not registered with Operator Factory class.
    """

    def __init__(self, operator_name):
        super().__init__(
            f"The operator {operator_name} is not registered with OperatorFactory. Register the Operator in OperatorFactory Class."
        )


class FunctionNotRegisteredException(Exception):
    """
        Custom Exception for case when callable function is not registered
        with Operator Factory class.
    """

    def __init__(self, function_name):
        super().__init__(
            f"The function {function_name} is not registered with OperatorFactory. Callable functions are auto-registered from select helper classes. Please check and try again."
        )

class DuplicatePythonHelperFunctionFound(Exception):
    """
        Custom Exception for case when Duplicate function is found in the custom Python Classes.
    """

    def __init__(self, class_name, function_name):
        super().__init__(
            f"The function {function_name} is already registered with OperatorFactory.  Duplicate function definition found in the class_name({class_name}). Please rename the function and try again."
        )
