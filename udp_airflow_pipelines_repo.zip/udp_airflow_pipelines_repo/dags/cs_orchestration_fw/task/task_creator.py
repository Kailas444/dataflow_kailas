"""
    File Name: task_creator.py
    Description: This file is used to create the Airflow tasks
    Created By: abpatre
    Revision History:
        | Date      | Author    | Changes Made
        | 2025-03-27| sprithiv   | Initial Framework
"""
from cs_orchestration_fw.utils.base_logger import get_logger
from typing import List, Union
from cs_orchestration_fw.task.factory.operator_factory \
    import OperatorFactory, OperatorNotRegisteredException


logger = get_logger(__name__)

class TaskCreator:  # pylint: disable=too-few-public-methods
    """
        This class is used to create the Airflow task.
    """
    def __init__(self, dag_obj: object, tasks_list: List) -> None:
        """
        Initializes the TaskCreator object.

        Args:
            dag_obj (object): The DAG object.
            dag_config_file_path (str): The file path of the DAG configuration file.

        Returns:
            None

        """
        try:
            self._dag_obj = dag_obj
            self._tasks_list = tasks_list
            self._operator_factory = OperatorFactory()
        except Exception as exp:
            logger.error(f"Error occurred while initializing TaskCreator: {exp}")
            raise exp

    def _validate_task_spec(self, task_spec: dict) -> None:
        """Validates if the task spec follows proper convention as required by the framework.

            Args:
                task_spec (dict): Task specification for creating the airflow task.
            Returns:
                None
        """
        try:
            if 'operator' not in task_spec:
                logger.error(f'Keyword "operator" is required in task spec {task_spec}')
                raise KeyError(
                    f'Keyword "operator" is required in task spec{task_spec}'
                )

            if(
                not self._operator_factory.does_operator_exists(
                    task_spec['operator']
                )
            ):
                logger.error(f'Operator "{task_spec["operator"]}" is not registered')
                raise OperatorNotRegisteredException(task_spec["operator"])
        except Exception as exp:
            logger.error(f"Error occurred while validating task spec: {exp}")
            raise exp

    def create_tasks(self,custom_function_registry)-> dict:
        """
        Create the Airflow Tasks .

        Args:
            None

        Returns:
            dict

        """   
        task_operators = {}
        task_dependcies = {}

        try:
            self._operator_factory.register_python_custom_callables(custom_function_registry)            

            for task_spec in self._tasks_list:
                self._validate_task_spec(task_spec)

                task_operator = self._operator_factory.get_operator_task(
                    self._dag_obj, task_spec
                )
                task_operators[task_spec["id"]] = task_operator

                if "dependencies" in task_spec:
                    task_dependcies[task_spec["id"]] = task_spec["dependencies"]

            return task_operators,task_dependcies
        except Exception as exp:
            logger.error(f"Error occurred while creating task: {exp}")
            raise exp        

