"""
    File Name: task_sequencer.py
    Description: This file is used to create the task sequence of the airflow dag.
    Created By: sprithiv
    Revision History:
        | Date      | Author    | Changes Made
        | 2025-03-27| sprithiv   | Initial Framework
"""
from typing import List, Union
from cs_orchestration_fw.utils.base_logger import get_logger


logger = get_logger("__name__")


class TaskSequencer:
    """
        This class is used to create the task sequence of a given dag.
    """
    def __init__(self,task_operators: dict, task_dependencies: dict ) -> None:
        """
        Initializes a TaskSequencer object.

        Args:
            created_task_map (dict): A dictionary containing the created tasks
        Returns:
            None
        """
        self._task_dependencies = task_dependencies
        self._task_operators = task_operators

    def _validate_task_dependecies(self,upstream_task_list: List):
        """Validates if the task Dependies task are exists as Task Operators.

            Args:
                None
            Returns:
                None
        """
        try:
            missing_operators = [key for key in upstream_task_list if key not in self._task_operators]

            if missing_operators:
                missing_task_operators = ", ".join(missing_operators)
                logger.error(f'Operator "{missing_task_operators=}" is not registered')
                raise UpStreamOrDownstreamTaskNotCreated(f'Operator "{missing_task_operators=}" is not registered')
        except Exception as exp:
            logger.error(f"Error occurred while validating task spec: {exp}")
            raise exp        
        
    def set_task_sequence(self):
        """
        Initializes a task sequence to create dependencies.

        Args:
            task_operators (dict): List of Tasks Operators created as per Config File
            task_dependencies (dict): List of Tasks Dependencies for each tasks as per Config File
        Returns:
            None
        """

        try:
            for downstream_task_id in self._task_dependencies:

                upstream_task_list = self._task_dependencies[downstream_task_id]
                self._validate_task_dependecies(upstream_task_list)
                self._validate_task_dependecies([downstream_task_id])

                if len(upstream_task_list) == 1:
                    self.set_one_upstream(upstream_task_list[0],downstream_task_id)
                    pass

                if len(upstream_task_list) > 1:  
                    self.set_multiple_upstream(upstream_task_list,downstream_task_id)      
                    pass

        except Exception as exp:
            logger.error(f"Error occurred while creating task: {exp}")
            raise exp      

    def set_one_upstream(
        self, upstream_task_id: str, downstream_task_id: str
    ) -> None:
        """Sets one downstream task depending on the upstream task

            Args:
                upstream_task_id: Upstream task id.
                downstream_task_id: Downstream tasks id
            Returns:
                None
        """
        try:
            self._task_operators[upstream_task_id]  >> self._task_operators[downstream_task_id]
            logger.info(f"Task sequence: {upstream_task_id} >> {downstream_task_id} has been set")

        except Exception as exp:
            logger.error(f"Error occurred while setting one upstream task: {exp}")
            raise exp
        
    def set_multiple_upstream(
        self, upstream_task_id_list: List, downstream_task_id: str
    ) -> None:
        """Sets multiple downstream task depending on the upstream task

            Args:
                upstream_task_id: Upstream task id.
                downstream_task_id_list: Downstream tasks id
            Returns:
                None
        """
        try:
            upstream_task_opr_list = []

            for upstream_task_id in upstream_task_id_list:
                upstream_task_opr_list.append(self._task_operators[upstream_task_id])

            upstream_task_opr_list  >> self._task_operators[downstream_task_id]    
            logger.info(f"Task Sequence {upstream_task_id_list} >> {downstream_task_id} has been set")

        except Exception as exp:
            logger.error(f"Error occurred while setting multiple upstream tasks: {exp}")
            raise exp        

# -------------------------------------------------------------------------------------
# Custom Exception class to resolve pylint error
# -------------------------------------------------------------------------------------
class UpStreamOrDownstreamTaskNotCreated(Exception):
    """
        Custom Exception when downstream task is not created.
    """
    def __init__(self, text):
        super().__init__(text)
