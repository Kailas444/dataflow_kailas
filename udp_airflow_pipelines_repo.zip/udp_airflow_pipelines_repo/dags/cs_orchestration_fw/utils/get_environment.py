"""
    File Name: base_logger.py
    Description: This file is to get the logger object to be used in the framework.
    Created By: abpatre
    Revision History:
        | Date      | Author    | Changes Made
        | 2025-04-27| sprithiv   | Initial Framework
"""
import os

def get_env_details() -> str:
    """Gets the environment name.
    Args:
        None
    Returns:
        Environment name.
    """
    env_name: str = os.environ.get('ENVIRONMENT', 'dev')

    if env_name and isinstance(env_name, str):
        env_name = env_name.lower()

    if env_name not in ["dev", "prod", "uat"]:
        env_name = None

    return env_name
    
