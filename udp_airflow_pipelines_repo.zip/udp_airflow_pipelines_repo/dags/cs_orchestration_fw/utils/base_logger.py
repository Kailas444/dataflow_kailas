"""
    File Name: base_logger.py
    Description: This file is to get the logger object to be used in the framework.
    Created By: sprithiv
    Revision History:
        | Date      | Author    | Changes Made
        | 2025-04-27| sprithiv   | Initial Framework
"""

import logging
from cs_orchestration_fw.utils.get_environment import get_env_details

def get_logger(namespace: str) -> object:
    """Creates the logger object to be used by entire framework.

        Args:
            namespace: The file namespace is passed here.
        Returns:
           logger object.
    """
    try:
        logger = logging.getLogger(namespace)
        env_name: str = get_env_details()
        env_name = env_name.lower()
        
        if env_name != 'prod':
            logger.setLevel(logging.INFO)
        else:
            logger.setLevel(logging.DEBUG)

        return logger
    except Exception as exp:
        logger = None
        print(f"Error creating logger: {exp}")
        raise exp

class EnvironmentVariableNotSetInAirflow(Exception):
    """Custom exception raised when environment variable is not set."""

    def __init__(self, env_variable):
        super().__init__(
            f"Environment variable '{env_variable}' is not set in Airflow."
        )
    
