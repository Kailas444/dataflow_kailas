"""
File Name: finance_inventory_budget_src_to_silver_udp.py
Description: DAG for inventory movement to archive or error based on Dataform success
Created By: Kailas
"""

from airflow import DAG
from airflow.models import TaskInstance
from airflow.operators.dummy import DummyOperator
from airflow.operators.python import PythonOperator, BranchPythonOperator
from airflow.utils.dates import days_ago
from airflow.utils.trigger_rule import TriggerRule
from airflow.utils.state import State
from airflow.utils.db import provide_session 
from airflow.utils.log.logging_mixin import LoggingMixin

from google.cloud import storage
from datetime import datetime, timedelta
import pendulum
import os
import yaml

from airflow.providers.google.cloud.operators.dataform import (
    DataformCreateCompilationResultOperator,
    DataformCreateWorkflowInvocationOperator,
)

logger = LoggingMixin().log
# -----------------------
# Load Config
# -----------------------
# dag_folder = os.path.dirname(os.path.realpath(__file__))
# config_path = os.path.join(dag_folder, "config_files/finance_inventory_budget_src_to_silver_udp.yaml")

# def load_config_local(path: str) -> dict:
#     with open(path, "r") as f:
#         return yaml.safe_load(f)

# CONFIG = load_config_local(config_path)

# GCS_BUCKET = DAG_CONFIG["gcs_bucket"]
# PROJECT_ID = DAG_CONFIG["dataform_project_id"]
# REGION = DAG_CONFIG["dataform_region"]
# REPOSITORY_ID = DAG_CONFIG["dataform_repository_id"]
# WORKSPACE = DAG_CONFIG["dataform_workspace"]
# SERVICE_ACCOUNT = DAG_CONFIG["dataform_service_account"]
# RELEASECONFIGS = DAG_CONFIG["dataform_releaseconfigs"]
# INCLUDED_TAGS = DAG_CONFIG["dataform_included_tags"]
# INVENTORY_PREFIXES = DAG_CONFIG["inventory_prefixes"]
# MOVE_TASKS = DAG_CONFIG["move_tasks"]
# ERROR_TASKS = DAG_CONFIG["error_tasks"]
# SOURCES = DAG_CONFIG["source"]

#get environment Variable
COMPOSER_ENVIRONMENT = os.environ.get('ENVIRONMENT', 'dev').lower()

# dag_folder = os.path.dirname(os.path.realpath(__file__))
# config_path = os.path.join(dag_folder, "config_files/finance_inventory_dailyinv_config.yaml")

DAG_HOME = '/home/airflow/gcs/dags'

if COMPOSER_ENVIRONMENT == "prod":
    env_config_path = os.path.join(DAG_HOME, f"env_config/env_config.yaml") 
else:
    env_config_path = os.path.join(DAG_HOME, f"env_config/env_config_{COMPOSER_ENVIRONMENT}.yaml")

dag_config_path = os.path.join(DAG_HOME, "dag_config/finance/finance_sales_budget.yaml")

def load_config_local(path: str) -> dict:
    with open(path, "r") as f:
        return yaml.safe_load(f)
    
ENV_CONFIG = load_config_local(env_config_path)['environments'][COMPOSER_ENVIRONMENT]
DAG_CONFIG = load_config_local(dag_config_path)

# -----------------------
# Constants
# -----------------------
GCS_BUCKET = ENV_CONFIG["buckets"]["common"]
PROJECT_ID = ENV_CONFIG["project_id"]
REGION = ENV_CONFIG["region"]
REPOSITORY_ID = ENV_CONFIG["dataform"]["repository_id"]
SERVICE_ACCOUNT = ENV_CONFIG["dataform"]["service_account"]
RELEASECONFIGS = ENV_CONFIG["dataform"]["release_config"]
INCLUDED_TAGS = DAG_CONFIG["dataform_included_tags"]
INVENTORY_PREFIXES = DAG_CONFIG["inventory_prefixes"]
MOVE_TASKS = DAG_CONFIG["move_tasks"]
ERROR_TASKS = DAG_CONFIG["error_tasks"]
SOURCES = DAG_CONFIG["source"]
LANDING_BUCKET = ENV_CONFIG["buckets"]["landing"]
ARCHIVE_BUCKET = ENV_CONFIG["buckets"]["archive"]
ERROR_BUCKET = ENV_CONFIG["buckets"]["error"]

# -----------------------
# DAG Arguments
# -----------------------
default_args = {
    "owner": "daily_budget",
    "start_date": pendulum.today("UTC").subtract(days=1),
    "retries": 1,
    "retry_delay": timedelta(minutes=2),
}

# -----------------------
# Python Helpers
# -----------------------
def check_file_dates(bucket_name):
    client = storage.Client()
    today = datetime.utcnow().date()

    for prefix in INVENTORY_PREFIXES:
        logger.info(f"\nChecking blobs under prefix: {prefix}")
        blobs = list(client.list_blobs(bucket_name, prefix=prefix))

        if not blobs:
            logger.info(f"No blobs found for prefix: {prefix}")
            continue

        found_recent = False
        for blob in blobs:
            updated_date = blob.updated.date()
            logger.info(f"Blob: {blob.name}, Updated: {updated_date}")
            if updated_date == today:
                found_recent = True
            else:
                logger.info("Blob not updated today.")

        if not found_recent:
            logger.info("Some blobs are not updated today. Returning 'skip_dataform'")
            return "skip_dataform"

    logger.info("\nAll blobs are updated today. Returning 'create_compilation_result'")
    return "create_compilation_result"

def move_files_with_prefix(source_bucket_name, destination_bucket_name, source_object, destination_object, **kwargs):
    logger = LoggingMixin().log
    client = storage.Client()

    source_prefix = source_object.rstrip('*')
    destination_prefix = destination_object.rstrip('/')

    source_bucket = client.bucket(source_bucket_name)
    destination_bucket = client.bucket(destination_bucket_name)

    blobs = client.list_blobs(source_bucket_name, prefix=source_prefix)
    timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")

    for blob in blobs:
        if blob.name.endswith('/'):
            continue

        relative_path = blob.name[len(source_prefix):]
        base_name = os.path.basename(relative_path)

        if '.' in base_name:
            name, ext = os.path.splitext(base_name)
            new_name = f"{name}_{timestamp}{ext}"
        else:
            new_name = f"{base_name}_{timestamp}"

        # Add folder if present
        folder = os.path.dirname(relative_path)
        final_path = f"{destination_prefix}/{folder}/{new_name}" if folder else f"{destination_prefix}/{new_name}"

        destination_blob = destination_bucket.blob(final_path)
        source_bucket.copy_blob(blob, destination_bucket, final_path)
        blob.delete()

        logger.info(f"Moved: {blob.name} → {final_path}")

@provide_session
def decide_file_transfer(source: str, session=None, **kwargs):
    dag_run = kwargs["dag_run"]
    task_id_to_check = f"dataform_{source}_raw_to_lake"
    ti = session.query(TaskInstance).filter(
        TaskInstance.dag_id == dag_run.dag_id,
        TaskInstance.task_id == task_id_to_check,
        TaskInstance.execution_date == dag_run.execution_date,
    ).first()

    if ti and ti.state == State.SUCCESS:
        return f"archive_files_{source}"
    else:
        return f"error_files_{source}"

def build_dataform_operator(tag, dag):
    task_id = f"dataform_{tag.replace('-', '_')}"
    return DataformCreateWorkflowInvocationOperator(
        task_id=task_id,
        project_id=PROJECT_ID,
        region=REGION,
        repository_id=REPOSITORY_ID,
        workflow_invocation={
            "compilation_result": "{{ ti.xcom_pull(task_ids='create_compilation_result')['name'] }}",
            "invocation_config": {
                "included_tags": [tag],
                "transitive_dependencies_included": False,
                "service_account": SERVICE_ACCOUNT,
            },
        },
        dag=dag,
    )

# -----------------------
# DAG Definition
# -----------------------
with DAG(
    dag_id="planned_budget_sales",
    default_args=default_args,
    schedule_interval="0 13 * * *", # Execute Daily at 9am UTC
    catchup=False,
    tags=["inventory", "budget", "daily"],
) as dag:

    start = DummyOperator(task_id="start")
    finish = DummyOperator(task_id="done", trigger_rule=TriggerRule.ALL_DONE)

    branch = BranchPythonOperator(
        task_id="check_gcs_mod_dates",
        python_callable=check_file_dates,
        op_kwargs={"bucket_name": GCS_BUCKET},
    )

    skip = DummyOperator(task_id="skip_dataform")

    compile = DataformCreateCompilationResultOperator(
        task_id="create_compilation_result",
        project_id=PROJECT_ID,
        region=REGION,
        repository_id=REPOSITORY_ID,
        compilation_result={
            "release_config": f"projects/{PROJECT_ID}/locations/{REGION}/repositories/{REPOSITORY_ID}/releaseConfigs/{RELEASECONFIGS}"
        },
    )

    start >> branch
    branch >> skip >> finish
    branch >> compile

    previous = compile
    dataform_tasks = []
    


    for tag in INCLUDED_TAGS:
        task = build_dataform_operator(tag, dag)
        previous >> task
        previous = task
        dataform_tasks.append(task)

    for source in SOURCES:
        branch_decision = BranchPythonOperator(
            task_id=f"branch_decision_{source}",
            python_callable=decide_file_transfer,
            op_kwargs={"source": source},
            trigger_rule=TriggerRule.ALL_DONE,
        )

        move_cfg = next((item for item in MOVE_TASKS if item["name"] == source), None)
        error_cfg = next((item for item in ERROR_TASKS if item["name"] == source), None)

        if move_cfg is None:
            raise ValueError(f"No MOVE_TASKS config found for source: {source}")
        if error_cfg is None:
            raise ValueError(f"No ERROR_TASKS config found for source: {source}")

        archive_task = PythonOperator(
            task_id=f"archive_files_{source}",
            python_callable=move_files_with_prefix,
            op_kwargs={
                "source_bucket_name": LANDING_BUCKET,
                "destination_bucket_name": ARCHIVE_BUCKET,
                "source_object": move_cfg["source_object"],
                "destination_object": move_cfg["move_destination_object"],
            },
        )

        error_task = PythonOperator(
            task_id=f"error_files_{source}",
            python_callable=move_files_with_prefix,
            op_kwargs={
                "source_bucket_name": LANDING_BUCKET,
                "destination_bucket_name": ERROR_BUCKET,
                "source_object": error_cfg["source_object"],
                "destination_object": error_cfg["error_destination_object"],
            },
        )

        # Link tasks
        last_dataform = next(t for t in dataform_tasks if source in t.task_id)
        last_dataform >> branch_decision
        branch_decision >> archive_task >> finish
        branch_decision >> error_task >> finish
