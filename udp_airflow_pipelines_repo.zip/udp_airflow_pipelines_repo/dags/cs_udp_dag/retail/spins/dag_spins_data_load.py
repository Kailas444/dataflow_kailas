import pendulum
from airflow import DAG
from cs_orchestration_fw.utils.base_logger import get_logger
from cs_orchestration_fw.dag.dag_creator import DagCreator

logger = get_logger(__name__)

try:
    dag_creator_obj = DagCreator("retail/spins_data_load_config.yaml",None)
    globals()[dag_creator_obj.dag_id] = dag_creator_obj.create_dag_from_config()

    logger.info("the created dag is %s", dag_creator_obj)

except Exception as exp:
    logger.error(f"An error occurred: {exp}")
    raise
