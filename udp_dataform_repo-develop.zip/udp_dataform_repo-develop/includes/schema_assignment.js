// includes/schema_assignment.js

// This file defines global variables for schema names based on the 'environment' variable.
// It will be executed as a prehook by including it in dataform.json or workflow_settings.yaml.

const environment = dataform.projectConfig.vars.environment;

let raw_dataset;
let lake_dataset;
let finance_dataset;
let dim_dataset;
let temp_dataset;
let shared_dim;
let sales_dataset;
let wh_dataset;
let wh_gold_dataset;
let retail_dataset;
let audit_dataset;


switch (environment) {
  case "dev":
    raw_dataset = "raw_layer";
    lake_dataset = "lake_layer";
    finance_dataset = "finance_silver";
    silver_warehouse_dataset = "warehouse_silver";
    dim_dataset = "master_silver";
    shared_dim = "shared_dimensions";
    sales_dataset = "sales_silver";
    temp_dataset = "temp_layer";
    wh_dataset = "warehouse_silver";
    wh_gold_dataset = "warehouse_gold";
    retail_dataset = "retail_sales_silver";
    audit_dataset = "udp_audit";
    break;
  case "uat":
    raw_dataset = "raw_layer_uat";
    lake_dataset = "lake_layer_uat";
    finance_dataset = "finance_silver_uat";
    silver_warehouse_dataset = "warehouse_silver_uat";
    dim_dataset = "master_silver_uat";
    sales_dataset = "sales_silver";
    shared_dim = "shared_dimensions_uat";
    temp_dataset = "temp_layer";
    wh_dataset = "warehouse_silver";
    wh_gold_dataset = "warehouse_gold";
    retail_dataset = "retail_sales_silver";
    audit_dataset = "udp_audit";
    break;
  case "production":
    raw_dataset = "raw_layer";
    lake_dataset = "lake_layer";
    finance_dataset = "finance_silver";
    silver_warehouse_dataset = "warehouse_silver";
    dim_dataset = "master_silver";
    shared_dim = "shared_dimensions";
    sales_dataset = "sales_silver";
    temp_dataset = "temp_layer";
    wh_dataset = "warehouse_silver";
    wh_gold_dataset = "warehouse_gold";
    retail_dataset = "retail_sales_silver";
    audit_dataset = "udp_audit";
    break;
  default:
    throw new Error(`Unknown environment: ${environment}. Please set 'environment' var to 'dev', 'uat', or 'production'.`);
}

// Register these as global compilation variables
// This makes them accessible via ${dataform.projectConfig.vars.raw_schema} etc.
dataform.projectConfig.vars.raw_dataset = raw_dataset;
dataform.projectConfig.vars.lake_dataset = lake_dataset;
dataform.projectConfig.vars.silver_warehouse_dataset = silver_warehouse_dataset;
dataform.projectConfig.vars.finance_dataset = finance_dataset;
dataform.projectConfig.vars.dim_dataset = dim_dataset;
dataform.projectConfig.vars.shared_dim = shared_dim;
dataform.projectConfig.vars.sales_dataset = sales_dataset;
dataform.projectConfig.vars.temp_dataset = temp_dataset;
dataform.projectConfig.vars.wh_dataset = wh_dataset;
dataform.projectConfig.vars.wh_gold_dataset = wh_gold_dataset;
dataform.projectConfig.vars.retail_dataset = retail_dataset;
dataform.projectConfig.vars.audit_dataset = audit_dataset;


// You can also log for debugging during local development (these logs won't appear in Cloud Logging)
console.log(`Dataform Environment: ${environment}`);
console.log(`Raw Schema: ${raw_dataset}`);
console.log(`Staging Schema: ${lake_dataset}`);
console.log(`Silver Warehouse Schema: ${silver_warehouse_dataset}`);
console.log(`Processed Schema: ${finance_dataset}`);
console.log(`Dimension Schema: ${dim_dataset}`);
console.log(`Dimension Schema: ${temp_dataset}`);
console.log(`Processed Schema: ${sales_dataset}`);
console.log(`Dimension Schema: ${shared_dim}`);
console.log(`Dimension Schema: ${wh_dataset}`);
console.log(`Dimension Schema: ${wh_gold_dataset}`);
console.log(`Dimension Schema: ${audit_dataset}`);
