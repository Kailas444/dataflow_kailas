// File: includes/common_functions.js

/**
 * Separates a dataset and table name.
 * @returns timestamp as int64 An object containing the separate components.
 */
// Define the arrow function
const getDagRunTime = () => {

  let runTimeValue = parseInt(dataform.projectConfig.vars.dag_run_time)

  if (dataform.projectConfig.vars.dag_run_time === "19000101") {

    const now = new Date();

    const pad = (n, width = 2) => n.toString().padStart(width, "0");

    const year = now.getFullYear();
    const month = pad(now.getMonth() + 1);
    const day = pad(now.getDate());
    const hour = pad(now.getHours());
    const minute = pad(now.getMinutes());
    const second = pad(now.getSeconds());
    const millis = String(now.getMilliseconds()).padStart(3, "0");
  
  // const microseconds = (now.getMilliseconds() * 1000).toString().padStart(6, "0");

    // Combine all parts
    const datetimeStr = `${year}${month}${day}${hour}${minute}${second}${millis}`; 
    
    runTimeValue =  BigInt(datetimeStr); 

  }
  dataform.projectConfig.vars.dag_run_time = runTimeValue
  return runTimeValue
};

/**
 * Separates a dataset and table name.
 * @param {string} full_name - The input string (e.g., "gcp_project.my_dataset.my_table").
 * @returns {object} An object containing the separate components.
 */
// Define the arrow function
const parseValues = (input) => {

  const cleanedInput = input.replace(/`/g, '');
  const parts = cleanedInput.split('.');

  if (parts.length === 3) {
    return parts.slice(-2); // return last 2 values
  } else if (parts.length === 2) {
    return parts; // return both values
  } else {
    throw new Error(`Invalid input: expected 2 or 3 values, got ${parts.length}`);
  }
};

/**
 * Generates a SQL statement.
 * @param {string} source - Source Table name - Format dataset.table_name.
 * @param {string} target - Target Table name - Format dataset.table_name.
 * @returns {string} The Insert SQL statement.
 */
const buildAuditQuery = (source, target, sourcetype) => {

  if (typeof source !== "string") {
    throw new Error("Parameter 'Source Table ' must be a string");
  }

  if (typeof target !== "string") {
    throw new Error("Parameter 'Target Table' must be a string");
  }

  if (!Number.isInteger(sourcetype)) {
    throw new Error("Parameter 'source type code' must be an integer");
  }else if (sourcetype < 0 || sourcetype > 3 )
  {
    throw new Error("Parameter 'source type code' should be between 0 and 3");
  }

  let sourceTableCol;
  let from_clause;

  const [sourceDataset, sourceTable] = parseValues(source);
  const [targetDataset, targetTable] = parseValues(target);

  if (sourcetype === 0) {
      sourceTableCol = `REGEXP_EXTRACT(_FILE_NAME, r'/([^/]+)$')`;
      from_clause = `${target}` ;
  }else if (sourcetype === 1) {
      sourceTableCol = `"${sourceTable}"`;
      from_clause = `${target}` ;
  }else if (sourcetype === 2) {
      sourceTableCol = `"${sourceTable}"`;
      // from_clause = `${target}` ; 
      from_clause = target ; 
  }else {
      sourceTableCol = `"${sourceTable}"`;
      from_clause = `\`${source}\`` 
  }
  const runTimeValue = getDagRunTime();

  const query = `
                SELECT  CURRENT_DATE("${dataform.projectConfig.vars.default_tz}") pipeline_run_date, 
                        "${dataform.projectConfig.vars.dag_name}"                 dag_name,
                         ${runTimeValue}                                          dag_execution_time,
                        "${sourceDataset}"                                        source_dataset,
                         ${sourceTableCol}                                        source_table_name,
                        "${targetDataset}"                                        target_dataset,
                        "${targetTable}"                                          target_table_name,                       
                        COUNT(*)                                                  impacted_rows,
                        ${sourcetype}                                             source_type_cde,
                        CURRENT_DATETIME("${dataform.projectConfig.vars.default_tz}") target_load_ts,
                        CURRENT_DATETIME("${dataform.projectConfig.vars.default_tz}") audit_created_ts,
                        CURRENT_DATETIME("${dataform.projectConfig.vars.default_tz}") audit_updated_ts                       
                FROM   ${from_clause}
                GROUP BY 4,5,6,7
                `;
  return query;
};

/**
 * Generates a SQL statement to Insert records into Audit Record.
 * @param {string} Source Table - Source Table name - Format dataset.table_name.
 * @param {string} Target Table - Target Table name - Format  dataset.table_name.
 * @returns {string} The Insert SQL statement.
 */
const insertAuditData = (source_tables, target_table, sourcetype) => {

    const audit_table = `${dataform.projectConfig.vars.audit_dataset}.udp_audit_metadata`
    let queries = [];

    if (Array.isArray(source_tables)){

      for (const item of source_tables) {
        const query = buildAuditQuery(item,target_table,sourcetype);
        queries.push(query);
      }      

    }else if (typeof source_tables === "string"){

        const query = buildAuditQuery(source_tables,target_table,sourcetype);
        queries.push(query);
    }else {
      throw new Error("Parameter 'source_tables' must be a string or array of strings");
    }

    const select_clause = queries.join("\nUNION ALL\n");
    const insert_clause = `INSERT INTO ${audit_table}`
    
    return `${insert_clause}
            ${select_clause}
            `;
};

/**
 * Generates a SQL statement to Insert Watermark data.
 * @param {string} Source Table - Source Table name - Format dataset.table_name.
 * @param {array}  keys         - Should have value for Min Max Partition Key and Ingested Row Identified in BQ JSON Object
 * @returns {string} The Insert SQL statement.
 */
const insertWaterMarkTracker = (source_table, keys) => {

    const [min_partition,max_partition,rowid] = keys

    if (rowid === null || rowid === undefined) {
      throw new Error("Parameter 'bqjsonobj' cannot be null or undefined");
    }   

    const identifier = String(rowid).trim();

    // Check if string starts with JSON_OBJECT
    if (!identifier.startsWith("JSON_OBJECT")) {
      throw new Error("Parameter 'bqjsonobj' must start with 'JSON_OBJECT'");
    }    

    const audit_table = `${dataform.projectConfig.vars.audit_dataset}.udp_watermark_tracker`
    const runTimeValue = getDagRunTime();
    const [sourceDataset, sourceTable] = parseValues(source_table);

    const insert_clause = `INSERT INTO ${audit_table}`;

    const select_clause = `
                  SELECT  CURRENT_DATE("${dataform.projectConfig.vars.default_tz}") pipeline_run_date, 
                          "${dataform.projectConfig.vars.dag_name}"                 dag_name,
                           ${runTimeValue}                                          dag_execution_time,
                          "${sourceDataset}"                                        source_dataset,
                          "${sourceTable}"                                          source_table_name,
                          "${min_partition}"                                        min_partition_key,
                          "${max_partition}"                                        max_partition_key,
                           ${identifier}                                            ingested_row_identifier,
                          "I"                                                       ingestion_status,
                          CURRENT_DATETIME("${dataform.projectConfig.vars.default_tz}") audit_created_ts,
                          CURRENT_DATETIME("${dataform.projectConfig.vars.default_tz}") audit_updated_ts                       
                  `;

    const delete_query = deleteWaterMarkTracker(source_table);              

            
    return `${delete_query}
            ${insert_clause}
            ${select_clause}
           `  


};

const deleteWaterMarkTracker = (source_table) => {

    const audit_table = `${dataform.projectConfig.vars.audit_dataset}.udp_watermark_tracker`
    const runTimeValue = getDagRunTime();
    const [sourceDataset, sourceTable] = parseValues(source_table); 

    const delete_query = `
                          DELETE FROM ${audit_table}
                          WHERE dag_name           = "${dataform.projectConfig.vars.dag_name}"
                          AND   dag_execution_time =  ${runTimeValue}
                          AND   source_dataset     = "${sourceDataset}"
                          AND   source_table_name  = "${sourceTable}"
                          AND   ingestion_status   = 'I';
                         ` ; 

    return delete_query                      

}

const updateWaterMarkTracker = (source_table) => {

    const audit_table = `${dataform.projectConfig.vars.audit_dataset}.udp_watermark_tracker`
    const runTimeValue = getDagRunTime();
    const [sourceDataset, sourceTable] = parseValues(source_table); 

    const update_query = `
                          UPDATE ${audit_table}
                          SET ingestion_status     = 'C'
                          WHERE dag_name           = "${dataform.projectConfig.vars.dag_name}"
                          AND   dag_execution_time =  ${runTimeValue}
                          AND   source_dataset     = "${sourceDataset}"
                          AND   source_table_name  = "${sourceTable}"
                          AND   ingestion_status   = 'I';
                         ` ; 

    return update_query                      

}



// module.exports = {
//     insertAuditData, insertWaterMarkTracker, buildAuditQuery, parseValues, deleteWaterMarkTracker
// };
