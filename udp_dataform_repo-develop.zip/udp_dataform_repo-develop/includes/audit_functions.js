/**
 * Class responsible for building and managing audit metadata operations in BigQuery.
 * 
 * Handles insert, update, and delete operations for watermark tracking
 * as part of the UDP (Unified Data Platform) audit process.
 */
class AuditWatermark {
  /**
   * Creates an instance of AuditMetadata.
   * 
   * @param {string} reftablename          - The Current Context Model table name.
   * @param {string} refsourcetablename    - The Source Model table name.
   */
  constructor(ctx,dataset,tablename) {

    if (!tablename) {
      throw new Error("Parameters 'tablename' cannot be null or undefined.");
    }

    // this.refTable = ctx.ref(tablename);
    // this.refFromTable = ctx.ref(fromtablename);

    // const [currentDataset, currentTable] = this.parseValues(this.refTable);
    // const [sourceDataset, sourceTable] = this.parseValues(this.refFromTable);

    const currentDataset = dataset
    const currentTable = tablename
    const currentProjectId =  dataform.projectConfig.defaultDatabase;
    this.refFromTable = `\`${currentProjectId}.${currentDataset}.${currentTable}\``; 

    this.dataSet = currentDataset;
    // this.sourceDS = sourceDataset;
    this.tableName = currentTable;
    // this.sourceTable = sourceTable;
    this.waterMarkTable = ctx.ref("udp_watermark_tracker");    
    this.dagRunTime = this.getDagRunTime();
    this.ctx = ctx
  }

  /**
   * Generates a Dataform reference string for the target table.
   * 
   * @returns {string} A formatted Dataform reference string.
   */
  getTableReference() {
    return `\${ref("${this.targettable}")}`;
  }

  /**
   * Builds an INSERT query for the UDP watermark tracker audit table.
   * 
   * @param {Array} cols - Array containing [min_partition, max_partition, rowid].
   * @param {string} where_clause - Table Where Clause.
   * @throws {Error} If rowid is null/undefined or not starting with 'JSON_OBJECT'.
   * @returns {string} A full SQL query string (DELETE + INSERT).
   */
  insertSelectWaterMarkTracker = (fromdataset, fromtablename, cols,whereclause) => {

    // const refFromTable = this.ctx.ref(tablename);
    const currentProjectId =  dataform.projectConfig.defaultDatabase;
    const refFromTable = `\`${currentProjectId}.${fromdataset}.${fromtablename}\``;     

    const [partition_col, rowid] = cols;

    if (rowid === null || rowid === undefined) {
      throw new Error("Parameter 'rowid' cannot be null or undefined");
    }

    const identifier = String(rowid).trim();

    if (!identifier.startsWith("JSON_OBJECT")) {
      throw new Error("Parameter 'rowid' must start with 'JSON_OBJECT'");
    }

    const delete_query = this.deleteWaterMarkTracker();

    const insert_query = `
      INSERT INTO ${this.waterMarkTable}
      SELECT
        CURRENT_DATE("${dataform.projectConfig.vars.default_tz}")           AS pipeline_run_date,
        "${dataform.projectConfig.vars.dag_name}"                           AS dag_name,
        DATETIME("${dataform.projectConfig.vars.dag_run_time}")             AS dag_execution_ts,
        "${this.dataSet}"                                                   AS dataset_name,
        "${this.tableName}"                                                 AS table_name,
        CAST(MIN(${partition_col}) AS STRING)                               AS min_partition_key,
        CAST(MAX(${partition_col}) AS STRING)                               AS max_partition_key,
        ${identifier}                                                       AS row_identifiers,
        "I"                                                                 AS status_cde,
        CURRENT_DATETIME("${dataform.projectConfig.vars.default_tz}")       AS audit_created_ts,
        CURRENT_DATETIME("${dataform.projectConfig.vars.default_tz}")       AS audit_updated_ts
      FROM ${refFromTable}
      WHERE ${whereclause};  
    `;

    return `${delete_query}\n${insert_query}`;
  };

  /**
   * Builds an INSERT query for the UDP watermark tracker audit table.
   * 
   * @param {Array} colvalues - Array containing values for Columns[min_partition, max_partition, rowid].
   * @throws {Error} If rowid is null/undefined or not starting with 'JSON_OBJECT'.
   * @returns {string} A full SQL query string (DELETE + INSERT).
   */
  insertWaterMarkTracker = (colvalues) => {
    const [min_partition, max_partition, rowid] = colvalues;

    if (rowid === null || rowid === undefined) {
      throw new Error("Parameter 'rowid' cannot be null or undefined");
    }

    const identifier = String(rowid).trim();

    if (!identifier.startsWith("JSON_OBJECT")) {
      throw new Error("Parameter 'rowid' must start with 'JSON_OBJECT'");
    }

    const delete_query = this.deleteWaterMarkTracker();

    const insert_query = `
      INSERT INTO ${this.waterMarkTable}
      SELECT
        CURRENT_DATE("${dataform.projectConfig.vars.default_tz}")           AS pipeline_run_date,
        "${dataform.projectConfig.vars.dag_name}"                           AS dag_name,
        DATETIME("${dataform.projectConfig.vars.dag_run_time}")             AS dag_execution_ts,
        "${this.dataSet}"                                                   AS dataset_name,
        "${this.tableName}"                                                 AS table_name,
        CAST(${min_partition} AS STRING)                                    AS min_partition_key,
        CAST(${max_partition} AS STRING)                                    AS max_partition_key,
        ${identifier}                                                       AS row_identifiers,
        "I"                                                                 AS status_cde,
        CURRENT_DATETIME("${dataform.projectConfig.vars.default_tz}")       AS audit_created_ts,
        CURRENT_DATETIME("${dataform.projectConfig.vars.default_tz}")       AS audit_updated_ts;
    `;

    return `${delete_query}\n${insert_query}`;
  };  

  /**
   * Builds a DELETE query for the UDP watermark tracker audit table.
   * 
   * @param {string} source_table - The fully qualified source table name.
   * @returns {string} A SQL DELETE query string.
   */
  deleteWaterMarkTracker = () => {

    return `
      DELETE FROM ${this.waterMarkTable}
      WHERE dag_name           = "${dataform.projectConfig.vars.dag_name}"
      AND   dag_execution_ts = DATETIME("${dataform.projectConfig.vars.dag_run_time}")
      AND   dataset_name       = "${this.dataSet}"
      AND   table_name         = "${this.tableName}"
      AND   status_cde         = 'I';
    `;
  };

  /**
   * Builds a Select query for the UDP watermark tracker audit table.
   * 
   * @param {string} source_table - The fully qualified source table name.
   * @returns {string} A SQL DELETE query string.
   */
  selectWaterMarkTracker = (tablename) => {


    const [sourceDataset, sourceTable] = this.isTable(tablename) ? this.parseValues(tablename) : this.parseValues(this.ctx.ref(tablename));

    return `
      SELECT AS STRUCT min_partition_key,max_partition_key,row_identifiers
      FROM ${this.waterMarkTable}
      WHERE dag_name           = "${dataform.projectConfig.vars.dag_name}"
      AND   dag_execution_ts   = DATETIME("${dataform.projectConfig.vars.dag_run_time}")
      AND   dataset_name       = "${sourceDataset}"
      AND   table_name         = "${sourceTable}"
      AND   status_cde         = 'I'
    `;
  };

  /**
   * Builds a Select query for the UDP watermark tracker audit table.
   * 
   * @param {string} source_table - The fully qualified source table name.
   * @returns {string} A SQL DELETE query string.
   */
  selectCompletedWaterMarkTracker = (tablename) => {

    const [sourceDataset, sourceTable] = this.isTable(tablename) ? this.parseValues(tablename) : this.parseValues(this.ctx.ref(tablename));

    return `
      SELECT AS STRUCT min_partition_key,max_partition_key,row_identifiers
      FROM ${this.waterMarkTable}
      WHERE dag_name           = "${dataform.projectConfig.vars.dag_name}"
      AND   dag_execution_ts   = DATETIME("${dataform.projectConfig.vars.dag_run_time}")
      AND   dataset_name       = "${sourceDataset}"
      AND   table_name         = "${sourceTable}"
      AND   audit_updated_ts   = (
                                    SELECT  MAX(audit_updated_ts)
                                    FROM    ${this.waterMarkTable}
                                    WHERE dag_name           = "${dataform.projectConfig.vars.dag_name}"
                                    AND   dag_execution_ts   = DATETIME("${dataform.projectConfig.vars.dag_run_time}")
                                    AND   dataset_name       = "${sourceDataset}"
                                    AND   table_name         = "${sourceTable}"                                    
                                 )
    `;
  };      

  /**
   * Builds an UPDATE query for the UDP watermark tracker audit table.
   * Marks ingestion_status = 'C' (Completed).
   * 
   * @param {string} source_table - The fully qualified source table name.
   * @returns {string} A SQL UPDATE query string.
   */
  updateWaterMarkTracker = (tablenames) => {

    let queries = [];

    if (Array.isArray(tablenames)){

      for (const item of tablenames) {

        const [sourceDataset, sourceTable] = this.isTable(item) ? this.parseValues(item) : this.parseValues(this.ctx.ref(item));

        const query = `
                        UPDATE ${this.waterMarkTable}
                        SET status_cde = 'C',audit_updated_ts = CURRENT_DATETIME("${dataform.projectConfig.vars.default_tz}")
                        WHERE dag_name           = "${dataform.projectConfig.vars.dag_name}"
                        AND   dag_execution_ts   = DATETIME("${dataform.projectConfig.vars.dag_run_time}")
                        AND   dataset_name       = "${sourceDataset}"
                        AND   table_name         = "${sourceTable}"
                        AND   status_cde         = 'I';
                      `;
        queries.push(query);
      }      

    }else if (typeof tablenames === "string"){

        const [sourceDataset, sourceTable] = this.isTable(tablenames) ? this.parseValues(tablenames) : this.parseValues(this.ctx.ref(tablenames));
        const query = `
                        UPDATE ${this.waterMarkTable}
                        SET status_cde = 'C',audit_updated_ts = CURRENT_DATETIME("${dataform.projectConfig.vars.default_tz}")
                        WHERE dag_name           = "${dataform.projectConfig.vars.dag_name}"
                        AND   dag_execution_ts   = DATETIME("${dataform.projectConfig.vars.dag_run_time}")
                        AND   dataset_name       = "${sourceDataset}"
                        AND   table_name         = "${sourceTable}"
                        AND   status_cde         = 'I';
                      `;        
        queries.push(query);
    }else {
      throw new Error("Parameter 'tablenames' must be a string or array of strings");
    }    

    const update_query = queries.join("\n");

    return update_query;   
  };

  /**
   * Gets the current DAG runtime value.
   * If `dag_run_time` is "19000101", it generates a new timestamp-like BigInt value.
   * 
   * @returns {bigint|number} The DAG run time as BigInt (or number if provided).
   */
  getDagRunTime = () => {
    return dataform.projectConfig.vars.dag_run_time;
  };

  /**
   * Splits a fully-qualified BigQuery table name into [dataset, table].
   * 
   * @param {string} input - The full table name (e.g., `project.dataset.table` or `dataset.table`).
   * @throws {Error} If input doesn't contain 2 or 3 components.
   * @returns {Array<string>} An array containing [dataset, table].
   */
  parseValues = (input) => {
    const cleanedInput = input.replace(/`/g, "");
    const parts = cleanedInput.split(".");

    if (parts.length === 3) {
      return parts.slice(-2); // dataset, table
    } else if (parts.length === 2) {
      return parts;
    } else {
      throw new Error(`Invalid input: expected 2 or 3 values, got ${parts.length}`);
    }
  };

  /**
   * Splits a fully-qualified BigQuery table name into [dataset, table].
   * 
   * @param {string} input - The full table name (e.g., `project.dataset.table` or `dataset.table`).
   * @throws {Error} If input doesn't contain 2 or 3 components.
   * @returns {Array<string>} An array containing [dataset, table].
   */
  isTable = (input) => {
    const cleanedInput = input.replace(/`/g, "");
    const parts = cleanedInput.split(".");

    if (parts.length === 3 || parts.length === 2) {
      return true; // Provide the input value has proj.ds.tbl part or ds.tbl
    } else {
      return false; // Dataform Config Name. Need to Resolve
    }
  };  
}

// Export the class so it can be used in your SQLX files
module.exports = {
    AuditWatermark
};