import React from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
} from "react-router-dom";
import { Result, Button } from "antd";
import ManagerInsights from "./components/screens/managerInsights";

import "./App.css";
import InventoryAging from "./components/screens/inventoryAging";
import AppLayout from "./components/layout";
import AlertCenter from "./components/screens/alertCenter";
import Overview from "./components/screens/overview";

// Sample pages
const Home: React.FC = () => <h1>Home Page</h1>;

// 404 Page
const NotFound: React.FC = () => (
  <Result
    status="404"
    title="404"
    subTitle="Sorry, the page you visited does not exist."
    extra={
      <Button
        type="primary"
        onClick={() => (window.location.href = "/manager-insights")}
      >
        Back Home
      </Button>
    }
  />
);

const App: React.FC = () => {
  return (
    <div className="app-container">
      <Router>
        <Routes>
          {/* Default route redirects to /overview */}
          <Route path="/" element={<Navigate to="/overview" replace />} />

          {/* App routes */}
          <Route
            path="/manager-insights"
            element={
              <AppLayout
                headerTitle="Manager Insights"
                mainContent={<ManagerInsights />}
              />
            }
          />
          <Route
            path="/inventory-aging"
            element={
              <AppLayout
                headerTitle="Inventory Aging"
                mainContent={<InventoryAging />}
              />
            }
          />

          <Route
            path="/alert-center"
            element={
              <AppLayout
                headerTitle="Alert Center"
                mainContent={<AlertCenter />}
              />
            }
          />

          <Route
            path="/overview"
            element={
              <AppLayout headerTitle="Overview" mainContent={<Overview />} />
            }
          />

          {/* 404 route */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </Router>
    </div>
  );
};

export default App;
