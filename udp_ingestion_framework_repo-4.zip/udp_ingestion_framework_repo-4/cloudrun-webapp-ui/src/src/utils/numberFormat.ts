const percentvalue = ["outOfStock"]

export function formatNumber(num: number, type : any = ""): string {
  
  if (percentvalue.includes(type)) {
    return (num).toFixed(1).replace(/\.0$/, "") + "%";
  } else if (num >= 1_000_000) {
    return (num / 1_000_000).toFixed(1).replace(/\.0$/, "") + "M";
  } else if (num >= 1_000) {
    return (num / 1_000).toFixed(1).replace(/\.0$/, "") + "K";
  }
  return num.toFixed(1);
}

export const formatNumberWithCommas = (num: any): string => {
  if (num === null || num === undefined || isNaN(num)) return "-";
  return Number(num).toLocaleString("en-US"); 
};