interface InputData {
  inventoryOrganisationName: string;
  warehouseName: string;
  itemDepartment: string;
}

interface OutputFormat {
  [value: string]: { value: number; label: string }[];
}

function transformData(data: InputData[]): OutputFormat {
  const result: OutputFormat = {};

  data.forEach((item) => {
    Object.entries(item).forEach(([field, value]) => {
      if (!result[field]) {
        result[field] = [];
      }
      result[field].push({
        value: value,
        label: value,
      });
    });
  });

  return result;
}

export default transformData;
