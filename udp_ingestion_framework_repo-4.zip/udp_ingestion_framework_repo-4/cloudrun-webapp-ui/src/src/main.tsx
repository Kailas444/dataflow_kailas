import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.tsx'
import "./styles/global.css"
import { Provider } from "react-redux";
import { store } from "./redux/store.tsx";
import "../src/components/common/chartSetup.ts";

createRoot(document.getElementById('root')!).render(
  <Provider store={store}>
    <App />
  </Provider>
)
