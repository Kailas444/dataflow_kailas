import { configureStore } from "@reduxjs/toolkit";
import globalFiltersReducer from "./reducers/globalFilter";
import managerInsightReducer from "./reducers/managerInsights"
import inventoryAgingReducer from "./reducers/inventoryAging"
import alertCenterReducer from "./reducers/alertCenter"

export const store = configureStore({
  reducer: {
    globalFilters: globalFiltersReducer,
    managerInsight : managerInsightReducer,
    inventoryAging : inventoryAgingReducer,
    alertCenter : alertCenterReducer
  },
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
