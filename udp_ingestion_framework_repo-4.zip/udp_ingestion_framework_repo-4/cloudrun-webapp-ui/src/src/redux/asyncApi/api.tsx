import axios from "axios";

const serverURL = import.meta.env.VITE_SERVER_BASE_URL

const api = axios.create({
  baseURL: serverURL,
});

export default api;
