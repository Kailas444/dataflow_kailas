import { createAsyncThunk } from "@reduxjs/toolkit";
import api from "./api";
import type { RootState } from "../store";

export const getAlertCenterTable = createAsyncThunk(
  "/api/alert_center/alert-dashboard",
  async ({ page , limit}: { page: any , limit : any},
    { rejectWithValue, getState }) => {
    const state = getState() as RootState;
    const {
      globalFilters: {
        filterSelectedOptions: {
          inventoryOrganization = [],
          warehouseName = [],
          itemDepartment = [],
          itemCategory = [],
          itemCode = [],
          itemDescription = [],
        },
      },
    } = state;
    console.log("state", state);
    try {
      const response = await api.post(
        "/api/alert_center/alert-dashboard",
    {
          inventoryOrganisationName:
            inventoryOrganization.length > 0 ? inventoryOrganization : "ALL",
          warehouseName: warehouseName.length > 0 ? warehouseName : "ALL",
          itemDepartment: itemDepartment.length > 0 ? itemDepartment : "ALL",
          itemCategory: itemCategory.length > 0 ? itemCategory : "ALL",
          itemCode: itemCode.length > 0 ? itemCode : "ALL",
          itemDescription: itemDescription.length > 0 ? itemDescription : "ALL",
          page,
          limit
        }
      );
      return response.data;
    } catch (error: any) {
      return rejectWithValue(
        error.response?.data?.message || "Something went wrong"
      );
    }
  }
);
