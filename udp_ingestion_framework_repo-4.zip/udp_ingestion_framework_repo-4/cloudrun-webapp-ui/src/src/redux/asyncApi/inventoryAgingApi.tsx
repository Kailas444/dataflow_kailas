import { createAsyncThunk } from "@reduxjs/toolkit";
import api from "./api";
import type { RootState } from "../store";

export const getInventoryStatusData = createAsyncThunk(
  "/api/inventory_aging/inventory-values",
  async (
    {
      agingBucket,
      replenishmentStatus,
      riskCategory,
      extrawarehouseName
    }: {
      agingBucket: string;
      replenishmentStatus: string;
      riskCategory?: string;
      extrawarehouseName : string
    },
    { rejectWithValue, getState }
  ) => {
    const state = getState() as RootState;
    const {
      globalFilters: {
        filterSelectedOptions: {
          inventoryOrganization = [],
          warehouseName = [],
          itemDepartment = [],
          itemCategory = [],
          itemCode = [],
          itemDescription = [],
        },
      },
    } = state;
    console.log("stateprivate", state);
    try {
      const response = await api.post("/api/inventory_aging/inventory-values", {
        inventoryOrganisationName:
          inventoryOrganization.length > 0 ? inventoryOrganization : "ALL",
   warehouseName: (warehouseName.length > 0 && !!extrawarehouseName) ? [...warehouseName, extrawarehouseName] : warehouseName.length > 0 ? warehouseName : !!extrawarehouseName ? [extrawarehouseName] : "ALL",
        itemDepartment: itemDepartment.length > 0 ? itemDepartment : "ALL",
        itemCategory: itemCategory.length > 0 ? itemCategory : "ALL",
        itemCode: itemCode.length > 0 ? itemCode : "ALL",
        itemDescription: itemDescription.length > 0 ? itemDescription : "ALL",
        agingBucket,
        replenishmentStatus,
        riskCategory,
      });
      return response.data;
    } catch (error: any) {
      return rejectWithValue(
        error.response?.data?.message || "Something went wrong"
      );
    }
  }
);

export const getDaysInStockData = createAsyncThunk(
  "/api/inventory_aging/stock-days",
  async (
    {
      agingBucket,
      replenishmentStatus,
      riskCategory,
      extrawarehouseName
    }: {
      agingBucket: string;
      replenishmentStatus: string;
      riskCategory: string;
      extrawarehouseName : string
    },
    { rejectWithValue, getState }
  ) => {
    const state = getState() as RootState;
    const {
      globalFilters: {
        filterSelectedOptions: {
          inventoryOrganization = [],
          warehouseName = [],
          itemDepartment = [],
          itemCategory = [],
          itemCode = [],
          itemDescription = [],
        },
      },
    } = state;
    console.log("stateprivate", state);
    try {
      const response = await api.post("/api/inventory_aging/stock-days", {
        inventoryOrganisationName:
          inventoryOrganization.length > 0 ? inventoryOrganization : "ALL",
  warehouseName: (warehouseName.length > 0 && !!extrawarehouseName) ? [...warehouseName, extrawarehouseName] : warehouseName.length > 0 ? warehouseName : !!extrawarehouseName ? [extrawarehouseName] : "ALL",
        itemDepartment: itemDepartment.length > 0 ? itemDepartment : "ALL",
        itemCategory: itemCategory.length > 0 ? itemCategory : "ALL",
        itemCode: itemCode.length > 0 ? itemCode : "ALL",
        itemDescription: itemDescription.length > 0 ? itemDescription : "ALL",
        agingBucket,
        replenishmentStatus,
        riskCategory,
      });
      return response.data;
    } catch (error: any) {
      return rejectWithValue(
        error.response?.data?.message || "Something went wrong"
      );
    }
  }
);

export const getReplenishmentStatusData = createAsyncThunk(
  "/api/inventory_aging/replenishment-status",
  async (
    {
      agingBucket,
      replenishmentStatus,
      riskCategory,
      extrawarehouseName
    }: {
      agingBucket: string;
      replenishmentStatus: string;
      riskCategory: string;
      extrawarehouseName : string
    },
    { rejectWithValue, getState }
  ) => {
    const state = getState() as RootState;
    const {
      globalFilters: {
        filterSelectedOptions: {
          inventoryOrganization = [],
          warehouseName = [],
          itemDepartment = [],
          itemCategory = [],
          itemCode = [],
          itemDescription = [],
        },
      },
    } = state;
    console.log("stateprivate", state);
    try {
      const response = await api.post(
        "/api/inventory_aging/replenishment-status",
        {
          inventoryOrganisationName:
            inventoryOrganization.length > 0 ? inventoryOrganization : "ALL",
  warehouseName: (warehouseName.length > 0 && !!extrawarehouseName) ? [...warehouseName, extrawarehouseName] : warehouseName.length > 0 ? warehouseName : !!extrawarehouseName ? [extrawarehouseName] : "ALL",
          itemDepartment: itemDepartment.length > 0 ? itemDepartment : "ALL",
          itemCategory: itemCategory.length > 0 ? itemCategory : "ALL",
          itemCode: itemCode.length > 0 ? itemCode : "ALL",
          itemDescription: itemDescription.length > 0 ? itemDescription : "ALL",
          agingBucket,
          replenishmentStatus,
          riskCategory,
        }
      );
      return response.data;
    } catch (error: any) {
      return rejectWithValue(
        error.response?.data?.message || "Something went wrong"
      );
    }
  }
);

export const getAgingBucketWarehouseData = createAsyncThunk(
  "/api/inventory_aging/inventory-values-warehouse",
  async (
    {
      agingBucket,
      replenishmentStatus,
      riskCategory,
    }: {
      agingBucket: string;
      replenishmentStatus: string;
      riskCategory: string;
    },
    { rejectWithValue, getState }
  ) => {
    const state = getState() as RootState;
    const {
      globalFilters: {
        filterSelectedOptions: {
          inventoryOrganization = [],
          warehouseName = [],
          itemDepartment = [],
          itemCategory = [],
          itemCode = [],
          itemDescription = [],
        },
      },
    } = state;
    console.log("stateprivate", state);
    try {
      const response = await api.post(
        "/api/inventory_aging/inventory-values-warehouse",
        {
          inventoryOrganisationName:
            inventoryOrganization.length > 0 ? inventoryOrganization : "ALL",
          warehouseName: warehouseName.length > 0 ? warehouseName : "ALL",
          itemDepartment: itemDepartment.length > 0 ? itemDepartment : "ALL",
          itemCategory: itemCategory.length > 0 ? itemCategory : "ALL",
          itemCode: itemCode.length > 0 ? itemCode : "ALL",
          itemDescription: itemDescription.length > 0 ? itemDescription : "ALL",
          agingBucket,
          replenishmentStatus,
          riskCategory,
        }
      );
      return response.data;
    } catch (error: any) {
      return rejectWithValue(
        error.response?.data?.message || "Something went wrong"
      );
    }
  }
);

export const getAgingInventoryBucket = createAsyncThunk(
  "/api/inventory_aging/inventory-aging-bucket",
  async (
    {
      agingBucket,
      replenishmentStatus,
      riskCategory,
      extrawarehouseName,
    }: {
      agingBucket: string;
      replenishmentStatus: string;
      riskCategory: string;
      extrawarehouseName : string
    },
    { rejectWithValue, getState }
  ) => {
    const state = getState() as RootState;
    const {
      globalFilters: {
        filterSelectedOptions: {
          inventoryOrganization = [],
          warehouseName = [],
          itemDepartment = [],
          itemCategory = [],
          itemCode = [],
          itemDescription = [],
        },
      },
    } = state;
    console.log("stateprivate", state);
    try {
      const response = await api.post(
        "/api/inventory_aging/inventory-aging-bucket",
        {
          inventoryOrganisationName:
            inventoryOrganization.length > 0 ? inventoryOrganization : "ALL",
          warehouseName: (warehouseName.length > 0 && !!extrawarehouseName) ? [...warehouseName, extrawarehouseName] : warehouseName.length > 0 ? warehouseName : !!extrawarehouseName ? [extrawarehouseName] : "ALL",
          itemDepartment: itemDepartment.length > 0 ? itemDepartment : "ALL",
          itemCategory: itemCategory.length > 0 ? itemCategory : "ALL",
          itemCode: itemCode.length > 0 ? itemCode : "ALL",
          itemDescription: itemDescription.length > 0 ? itemDescription : "ALL",
          agingBucket,
          replenishmentStatus,
          riskCategory,
        }
      );
      return response.data;
    } catch (error: any) {
      return rejectWithValue(
        error.response?.data?.message || "Something went wrong"
      );
    }
  }
);
