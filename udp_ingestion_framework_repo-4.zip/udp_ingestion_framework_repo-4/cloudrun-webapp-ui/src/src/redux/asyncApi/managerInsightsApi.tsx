import { createAsyncThunk } from "@reduxjs/toolkit";
import api from "./api";
import type { RootState } from "../store";

export const getPrivateDistributionQuantity = createAsyncThunk(
  "/api/manager_insights/pri-distribution-quantity",
  async (
    {
      kpiFilter,
      selectedgraphValue,
    }: { kpiFilter: string; selectedgraphValue: string },
    { rejectWithValue, getState }
  ) => {
    const state = getState() as RootState;
    const {
      globalFilters: {
        filterSelectedOptions: {
          inventoryOrganization = [],
          warehouseName = [],
          itemDepartment = [],
          itemCategory = [],
          itemCode = [],
          itemDescription = [],
        },
      },
    } = state;
    console.log("stateprivate", state);
    try {
      const response = await api.post(
        "/api/manager_insights/pri-distribution-quantity",
        {
          inventoryOrganisationName:
            inventoryOrganization.length > 0 ? inventoryOrganization : "ALL",
          warehouseName: warehouseName.length > 0 ? warehouseName : "ALL",
          itemDepartment: itemDepartment.length > 0 ? itemDepartment : "ALL",
          itemCategory: itemCategory.length > 0 ? itemCategory : "ALL",
          itemCode: itemCode.length > 0 ? itemCode : "ALL",
          itemDescription: itemDescription.length > 0 ? itemDescription : "ALL",
          kpiFilter,
          selectedgraphValue,
        }
      );
      return response.data;
    } catch (error: any) {
      return rejectWithValue(
        error.response?.data?.message || "Something went wrong"
      );
    }
  }
);

export const getInventoryDistributionDepartment = createAsyncThunk(
  "/api/manager_insights/inv-distribution-department",
  async (
    {
      kpiFilter,
      selectedgraphValue,
    }: { kpiFilter: string; selectedgraphValue: string },
    { rejectWithValue, getState }
  ) => {
    const state = getState() as RootState;
    const {
      globalFilters: {
        filterSelectedOptions: {
          inventoryOrganization = [],
          warehouseName = [],
          itemDepartment = [],
          itemCategory = [],
          itemCode = [],
          itemDescription = [],
        },
      },
    } = state;
    console.log("stateprivate", state);
    try {
      const response = await api.post(
        "/api/manager_insights/inv-distribution-department",
        {
          inventoryOrganisationName:
            inventoryOrganization.length > 0 ? inventoryOrganization : "ALL",
          warehouseName: warehouseName.length > 0 ? warehouseName : "ALL",
          itemDepartment: itemDepartment.length > 0 ? itemDepartment : "ALL",
          itemCategory: itemCategory.length > 0 ? itemCategory : "ALL",
          itemCode: itemCode.length > 0 ? itemCode : "ALL",
          itemDescription: itemDescription.length > 0 ? itemDescription : "ALL",
          kpiFilter,
          selectedgraphValue,
        }
      );
      return response.data;
    } catch (error: any) {
      return rejectWithValue(
        error.response?.data?.message || "Something went wrong"
      );
    }
  }
);

export const getKPICardData = createAsyncThunk(
  "/api/manager_insights/kpi-cards",
  async (_, { rejectWithValue, getState }) => {
    const state = getState() as RootState;
    const {
      globalFilters: {
        filterSelectedOptions: {
          inventoryOrganization = [],
          warehouseName = [],
          itemDepartment = [],
          itemCategory = [],
          itemCode = [],
          itemDescription = [],
        },
      },
    } = state;
    console.log("stateprivate", state);
    try {
      const response = await api.post("/api/manager_insights/kpi-cards", {
        inventoryOrganisationName:
          inventoryOrganization.length > 0 ? inventoryOrganization : "ALL",
        warehouseName: warehouseName.length > 0 ? warehouseName : "ALL",
        itemDepartment: itemDepartment.length > 0 ? itemDepartment : "ALL",
        itemCategory: itemCategory.length > 0 ? itemCategory : "ALL",
        itemCode: itemCode.length > 0 ? itemCode : "ALL",
        itemDescription: itemDescription.length > 0 ? itemDescription : "ALL",
      });
      return response.data;
    } catch (error: any) {
      return rejectWithValue(
        error.response?.data?.message || "Something went wrong"
      );
    }
  }
);

export const getInventoryWarehouse = createAsyncThunk(
  "/api/manager_insights/inv-warehouse",
  async (
    {
      kpiSelected,
      xAxisSelected,
    }: { kpiSelected: string; xAxisSelected: string },
    { rejectWithValue, getState }
  ) => {
    const state = getState() as RootState;
    const {
      globalFilters: {
        filterSelectedOptions: {
          inventoryOrganization = [],
          warehouseName = [],
          itemDepartment = [],
          itemCategory = [],
          itemCode = [],
          itemDescription = [],
        },
      },
    } = state;
    console.log("stateprivate", state);
    try {
      const response = await api.post("/api/manager_insights/inv-warehouse", {
        inventoryOrganisationName:
          inventoryOrganization.length > 0 ? inventoryOrganization : "ALL",
        warehouseName: warehouseName.length > 0 ? warehouseName : "ALL",
        itemDepartment: itemDepartment.length > 0 ? itemDepartment : "ALL",
        itemCategory: itemCategory.length > 0 ? itemCategory : "ALL",
        itemCode: itemCode.length > 0 ? itemCode : "ALL",
        itemDescription: itemDescription.length > 0 ? itemDescription : "ALL",
        kpiSelected,
        xAxisSelected,
      });
      return response.data;
    } catch (error: any) {
      return rejectWithValue(
        error.response?.data?.message || "Something went wrong"
      );
    }
  }
);
export const getInventoryDistributionCategory = createAsyncThunk(
  "/api/manager_insights/inv-distribution-category",
  async (
    {
      kpiFilter,
      selectedgraphValue,
      selectedDeptValue,
    }: {
      kpiFilter: string;
      selectedgraphValue: string;
      selectedDeptValue: string;
    },
    { rejectWithValue, getState }
  ) => {
    const state = getState() as RootState;
    const {
      globalFilters: {
        filterSelectedOptions: {
          inventoryOrganization = [],
          warehouseName = [],
          itemDepartment = [],
          itemCategory = [],
          itemCode = [],
          itemDescription = [],
        },
      },
    } = state;
    console.log("stateprivate", state);
    try {
      const response = await api.post(
        "/api/manager_insights/inv-distribution-category",
        {
          inventoryOrganisationName:
            inventoryOrganization.length > 0 ? inventoryOrganization : "ALL",
          warehouseName: warehouseName.length > 0 ? warehouseName : "ALL",
          itemDepartment: itemDepartment.length > 0 ? itemDepartment : "ALL",
          itemCategory: itemCategory.length > 0 ? itemCategory : "ALL",
          itemCode: itemCode.length > 0 ? itemCode : "ALL",
          itemDescription: itemDescription.length > 0 ? itemDescription : "ALL",
          kpiFilter,
          selectedgraphValue,
          selectedDeptValue,
        }
      );
      return response.data;
    } catch (error: any) {
      return rejectWithValue(
        error.response?.data?.message || "Something went wrong"
      );
    }
  }
);
export const getProductTableData = createAsyncThunk(
  "/api/manager_insights/inv-distribution-product",
  async (
    params: {
      pageNo: number;
      limit: number;
      granularity1: string;
      granularity2: string;
      kpiFilter?: string;
      selectedgraphValue?: string;
      selectedDeptValue?: string;
      selectedCategoryValue?: string;
      agingBucket?: string;
      replenishmentStatus?: string;
      riskCategory?: string;
      extrawarehouseName?: string;
    },
    { rejectWithValue, getState }
  ) => {
    const state = getState() as RootState;
    const {
      globalFilters: {
        filterSelectedOptions: {
          inventoryOrganization = [],
          warehouseName = [],
          itemDepartment = [],
          itemCategory = [],
          itemCode = [],
          itemDescription = [],
        },
      },
    } = state;
    console.log("stateprivate", state);
    try {
      const response = await api.post(
        "/api/manager_insights/inv-distribution-product",
        {
          inventoryOrganisationName:
            inventoryOrganization.length > 0 ? inventoryOrganization : "ALL",
          warehouseName:
            warehouseName.length > 0 && !!params.extrawarehouseName
              ? [...warehouseName, params.extrawarehouseName]
              : warehouseName.length > 0
              ? warehouseName
              : !!params.extrawarehouseName
              ? [params.extrawarehouseName]
              : "ALL",
          itemDepartment: itemDepartment.length > 0 ? itemDepartment : "ALL",
          itemCategory: itemCategory.length > 0 ? itemCategory : "ALL",
          itemCode: itemCode.length > 0 ? itemCode : "ALL",
          itemDescription: itemDescription.length > 0 ? itemDescription : "ALL",
          granularity1: params.granularity1, // selected granularity1
          granularity2: params.granularity2, // selected granularity2
          pageNo: params.pageNo, // current page number
          limit: params.limit, // rows per page
          kpiFilter: params.kpiFilter,
          selectedGraphValue: params.selectedgraphValue,
          selectedDeptValue: params.selectedDeptValue,
          selectedCategoryValue: params.selectedCategoryValue,
          agingBucket: params.agingBucket,
          replenishmentStatus: params.replenishmentStatus,
          riskCategory: params.riskCategory,
        }
      );
      return response.data;
    } catch (error: any) {
      return rejectWithValue(
        error.response?.data?.message || "Something went wrong"
      );
    }
  }
);
export const getRefreshDate = createAsyncThunk(
  "/api/manager_insights/max-inv-date",
  async (_, { rejectWithValue, getState }) => {
    const state = getState() as RootState;
    const {
      globalFilters: {
        filterSelectedOptions: {
          inventoryOrganisation = [],
          warehouseName = [],
          itemDepartment = [],
          itemCategory = [],
          itemCode = [],
          itemDescription = [],
        },
      },
    } = state;
    console.log("stateprivate", state);
    try {
      const response = await api.get("/api/manager_insights/max-inv-date", {
        inventoryOrganisationName:
          inventoryOrganisation.length > 0 ? inventoryOrganisation : "ALL",
        warehouseName: warehouseName.length > 0 ? warehouseName : "ALL",
        itemDepartment: itemDepartment.length > 0 ? itemDepartment : "ALL",
        itemCategory: itemCategory.length > 0 ? itemCategory : "ALL",
        itemCode: itemCode.length > 0 ? itemCode : "ALL",
        itemDescription: itemDescription.length > 0 ? itemDescription : "ALL",
      });
      return response.data;
    } catch (error: any) {
      return rejectWithValue(
        error.response?.data?.message || "Something went wrong"
      );
    }
  }
);
