import { createAsyncThunk } from "@reduxjs/toolkit";
import api from "./api";
import type { RootState } from "../store";

export const getGlobalFilters = createAsyncThunk(
  "api/manager_insights/global-filters",
  async (payload: {
    filterName: string;
    selectedFilterValue: Record<string, string[]>;
    searchTerm: string;
  }, { rejectWithValue, getState }) => {
    const state = getState() as RootState;
    console.log("state", state);
    try {
      const response = await api.post(
        "api/manager_insights/global-filters",
        // state.globalFilters.filterSelectedOptions
        payload
      );
      return response.data;
    } catch (error: any) {
      return rejectWithValue(
        error.response?.data?.message || "Something went wrong"
      );
    }
  }
);
