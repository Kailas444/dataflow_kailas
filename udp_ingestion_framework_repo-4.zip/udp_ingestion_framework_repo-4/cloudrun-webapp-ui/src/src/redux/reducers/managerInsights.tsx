import { createSlice } from "@reduxjs/toolkit";
import {
  getInventoryDistributionCategory,
  getInventoryDistributionDepartment,
  getInventoryWarehouse,
  getKPICardData,
  getPrivateDistributionQuantity,
  getProductTableData,
  getRefreshDate,
} from "../asyncApi/managerInsightsApi";

interface managerInsightState {
  KPICardData: any[];
  KPICardDataLoading: boolean;
  privateDistributionQuantity: any[];
  privateDistributionQuantityLoading: boolean;
  inventoryDistributionDept: any[];
  inventoryDistributionDeptLoading: boolean;
  warehouseChart: any;
  warehouseChartLoading: boolean;
  inventoryDistributionCat: any;
  inventoryDistributionCatLoading: boolean;
  productTable: any;
  productFirstTableRow: any;
  productTableLoading: boolean;
  refreshDate: string;
  loading: boolean;
  error: string | null;
}

const initialState: managerInsightState = {
  KPICardData: [],
  KPICardDataLoading: false,
  privateDistributionQuantity: [],
  privateDistributionQuantityLoading: false,
  inventoryDistributionDept: [],
  inventoryDistributionDeptLoading: false,
  warehouseChart: [],
  warehouseChartLoading: false,
  inventoryDistributionCat: [],
  inventoryDistributionCatLoading: false,
  productTable: [],
  productFirstTableRow : null,
  productTableLoading: false,
  refreshDate: "",
  loading: false,
  error: null,
};

// Async thunk for API call

const managerInsightSlice = createSlice({
  name: "managerInsight",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(getKPICardData.pending, (state) => {
        state.loading = true;
        (state.KPICardDataLoading = true), (state.error = null);
      })
      .addCase(getKPICardData.fulfilled, (state, action) => {
        state.loading = false;
        (state.KPICardDataLoading = false),
          console.log(state, "statekpi", action);
        state.KPICardData = action.payload.data;
      })
      .addCase(getKPICardData.rejected, (state, action) => {
        state.loading = false;
        (state.KPICardDataLoading = false),
          (state.error = action.payload as string);
      })
      .addCase(getPrivateDistributionQuantity.pending, (state) => {
        state.loading = true;
        state.privateDistributionQuantityLoading = true;
        state.error = null;
      })
      .addCase(getPrivateDistributionQuantity.fulfilled, (state, action) => {
        state.loading = false;
        state.privateDistributionQuantityLoading = false;
        const result = action.payload.result[0];
        const privateData = Object.keys(result);
        const resultData = privateData.map((obj) => {
          return {
            label: obj,
            data: result[obj].toFixed(1),
          };
        });
        state.privateDistributionQuantity = resultData;
      })
      .addCase(getPrivateDistributionQuantity.rejected, (state, action) => {
        state.loading = false;
        state.privateDistributionQuantityLoading = false;
        state.error = action.payload as string;
      })
      .addCase(getInventoryDistributionDepartment.pending, (state) => {
        state.loading = true;
        state.inventoryDistributionDeptLoading = true;
        state.error = null;
      })
      .addCase(
        getInventoryDistributionDepartment.fulfilled,
        (state, action) => {
          console.log("getPrivateDistributionQuantity", action);
          state.loading = false;
          state.inventoryDistributionDeptLoading = false;
          state.inventoryDistributionDept = action.payload.result;
        }
      )
      .addCase(getInventoryDistributionDepartment.rejected, (state, action) => {
        state.loading = false;
        state.inventoryDistributionDeptLoading = false;
        state.error = action.payload as string;
      })
      .addCase(getInventoryWarehouse.pending, (state) => {
        state.loading = true;
        state.warehouseChartLoading = true;
        state.error = null;
      })
      .addCase(getInventoryWarehouse.fulfilled, (state, action) => {
        console.log("getPrivateDistributionQuantity", action);
        state.loading = false;
        state.warehouseChartLoading = false;
        state.warehouseChart = action.payload.result;
      })
      .addCase(getInventoryWarehouse.rejected, (state, action) => {
        state.loading = false;
        state.warehouseChartLoading = false;
        state.error = action.payload as string;
      })
      .addCase(getInventoryDistributionCategory.pending, (state) => {
        state.loading = true;
        state.inventoryDistributionCatLoading = true;
        state.error = null;
      })
      .addCase(getInventoryDistributionCategory.fulfilled, (state, action) => {
        console.log("getPrivateDistributionQuantity", action);
        state.loading = false;
        state.inventoryDistributionCatLoading = false;
        state.inventoryDistributionCat = action.payload.result;
      })
      .addCase(getInventoryDistributionCategory.rejected, (state, action) => {
        state.loading = false;
        state.inventoryDistributionCatLoading = false;
        state.error = action.payload as string;
      })
      .addCase(getProductTableData.pending, (state) => {
        state.loading = true;
        state.productTableLoading = true;
        state.error = null;
      })
      .addCase(getProductTableData.fulfilled, (state, action) => {
        console.log("getPrivateDistributionQuantity", action);
        state.loading = false;
        state.productTableLoading = false;
        state.productTable = action.payload;

        const grandTotalRow = (action.payload.rows || [])?.find(
              (item: any, idx: any) => item.whse_name === "Grand Total"
            ) || state.productFirstTableRow;

        state.productFirstTableRow = grandTotalRow;
      })
      .addCase(getProductTableData.rejected, (state, action) => {
        state.loading = false;
        state.productTableLoading = false;
        state.error = action.payload as string;
      })
      .addCase(getRefreshDate.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(getRefreshDate.fulfilled, (state, action) => {
        console.log("getPrivateDistributionQuantity", action);
        state.loading = false;
        state.refreshDate = action.payload.maxDate;
      })
      .addCase(getRefreshDate.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export default managerInsightSlice.reducer;
