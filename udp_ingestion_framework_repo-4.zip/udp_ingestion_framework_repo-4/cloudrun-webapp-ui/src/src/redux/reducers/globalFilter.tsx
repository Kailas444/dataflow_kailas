// features/users/userSlice.ts

import { createSlice } from "@reduxjs/toolkit";
import type { PayloadAction } from "@reduxjs/toolkit";
import api from "../asyncApi/api";
import { getGlobalFilters } from "../asyncApi/globalFiltersApi";
import transformData from "../../utils/dataFormat";

interface globalFiltersState {
  filterOptions: any;
  filterSelectedOptions: any;
  loading: boolean;
  error: string | null;
}

const initialState: globalFiltersState = {
  filterOptions: {
    inventoryOrganization: [],
    itemDepartment: [],
    warehouseName: [],
    itemCategory: [],
    itemCode:[],
    itemDescription:[]
  },
  filterSelectedOptions: {
    inventoryOrganization: [],
    itemDepartment: [],
    warehouseName: [],
    itemCategory: [],
    itemCode:[],
    itemDescription:[]
  },
  loading: false,
  error: null,
};

// Define action payload type for updating filterSelectedOptions
interface UpdateFilterSelectedOptionsPayload {
  name: string;
  selected: string[];
}

const globalFiltersSlice = createSlice({
  name: "globalFilters",
  initialState,
  reducers: {
    // Add reducer to update filterSelectedOptions
    updateFilterSelectedOptions: (
      state,
      action: PayloadAction<UpdateFilterSelectedOptionsPayload>
    ) => {
      const { name, selected } = action.payload;
      state.filterSelectedOptions[name] = selected;
    },
     updateBulkFilterSelection: (
      state,
      action: PayloadAction<any>
    ) => {
      state.filterSelectedOptions = {
        ...state.filterSelectedOptions, 
        ... action.payload
      };
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(getGlobalFilters.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(getGlobalFilters.fulfilled, (state, action) => {
        console.log("action", action);
        state.loading = false;
        state.filterOptions = action.payload.data;
      })
      .addCase(getGlobalFilters.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

// Export the new action
export const { updateFilterSelectedOptions, updateBulkFilterSelection } = globalFiltersSlice.actions;

export default globalFiltersSlice.reducer;