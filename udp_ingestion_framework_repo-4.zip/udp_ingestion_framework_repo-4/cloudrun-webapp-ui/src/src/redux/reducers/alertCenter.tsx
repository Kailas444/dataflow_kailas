import { createSlice } from "@reduxjs/toolkit";
import type { PayloadAction } from "@reduxjs/toolkit";
import { getAlertCenterTable } from "../asyncApi/alertCenter";

interface globalFiltersState {
  alertTableData: any;
  alertTableCount : any;
  alertTableDataLoading: boolean;
  loading: boolean;
  error: string | null;
}

const initialState: globalFiltersState = {
  alertTableData: [],
  alertTableCount : null,
  alertTableDataLoading: false,
  loading: false,
  error: null,
};

const alertCenterSlice = createSlice({
  name: "alertCenter",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(getAlertCenterTable.pending, (state) => {
        state.loading = true;
        state.alertTableDataLoading = true;
        state.error = null;
      })
      .addCase(getAlertCenterTable.fulfilled, (state, action) => {
        console.log("action", action.payload);
        state.loading = false;
         state.alertTableDataLoading = false;
        state.alertTableData = action.payload.result;
        state.alertTableCount = action.payload.count
      })
      .addCase(getAlertCenterTable.rejected, (state, action) => {
        state.loading = false;
         state.alertTableDataLoading = false;
        state.error = action.payload as string;
      });
  },
});

export default alertCenterSlice.reducer;
