import { createSlice } from "@reduxjs/toolkit";
import {
  getAgingBucketWarehouseData,
  getAgingInventoryBucket,
  getDaysInStockData,
  getInventoryStatusData,
  getReplenishmentStatusData,
} from "../asyncApi/inventoryAgingApi";
import { getProductTableData } from "../asyncApi/managerInsightsApi";

interface managerInsightState {
  inventoryStatus: any;
  inventoryStatusLoading: boolean;
  daysInStock: any;
  daysInStockLoading: boolean;
  replenishmentStatus: any;
  replenishmentStatusLoading: boolean;
  agingBucketWarehouse: any;
  agingBucketWarehouseLoading: boolean;
  agingInventoryBucket: any;
  agingInventoryBucketLoading: boolean;
  agingProductTable: any;
  agingProductTableLoading: boolean;
  agingFirstProductRow: any;
  loading: boolean;
  error: string | null;
}

const initialState: managerInsightState = {
  inventoryStatus: [],
  inventoryStatusLoading: false,
  daysInStock: [],
  daysInStockLoading: false,
  replenishmentStatus: [],
  replenishmentStatusLoading: false,
  agingBucketWarehouse: [],
  agingBucketWarehouseLoading: false,
  agingInventoryBucket: [],
  agingInventoryBucketLoading: false,
  agingProductTable: [],
  agingFirstProductRow: null,
  agingProductTableLoading: false,
  loading: false,
  error: null,
};

// Async thunk for API call

const inventoryAgingSlice = createSlice({
  name: "inventoryAging",
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      .addCase(getInventoryStatusData.pending, (state) => {
        state.loading = true;
        state.inventoryStatusLoading = true;
        state.error = null;
      })
      .addCase(getInventoryStatusData.fulfilled, (state, action) => {
        state.loading = false;
        state.inventoryStatusLoading = false;
        state.inventoryStatus = action.payload.result;
      })
      .addCase(getInventoryStatusData.rejected, (state, action) => {
        state.loading = false;
        state.inventoryStatusLoading = false;
        state.error = action.payload as string;
      })
      .addCase(getDaysInStockData.pending, (state) => {
        state.loading = true;
        state.daysInStockLoading = true;
        state.error = null;
      })
      .addCase(getDaysInStockData.fulfilled, (state, action) => {
        state.loading = false;
        state.daysInStockLoading = false;
        state.daysInStock = action.payload.result;
      })
      .addCase(getDaysInStockData.rejected, (state, action) => {
        state.loading = false;
        state.daysInStockLoading = false;
        state.error = action.payload as string;
      })
      .addCase(getReplenishmentStatusData.pending, (state) => {
        state.loading = true;
        state.replenishmentStatusLoading = true;
        state.error = null;
      })
      .addCase(getReplenishmentStatusData.fulfilled, (state, action) => {
        state.loading = false;
        state.replenishmentStatusLoading = false;

        state.replenishmentStatus = action.payload.rows;
      })
      .addCase(getReplenishmentStatusData.rejected, (state, action) => {
        state.loading = false;
        state.replenishmentStatusLoading = false;
        state.error = action.payload as string;
      })
      .addCase(getAgingBucketWarehouseData.pending, (state) => {
        state.loading = true;
        state.agingBucketWarehouseLoading = true;
        state.error = null;
      })
      .addCase(getAgingBucketWarehouseData.fulfilled, (state, action) => {
        state.loading = false;
        state.agingBucketWarehouseLoading = false;
        state.agingBucketWarehouse = action.payload.rows;
      })
      .addCase(getAgingBucketWarehouseData.rejected, (state, action) => {
        state.loading = false;
        state.agingBucketWarehouseLoading = false;
        state.error = action.payload as string;
      })
      .addCase(getAgingInventoryBucket.pending, (state) => {
        state.loading = true;
        state.agingInventoryBucketLoading = true;
        state.error = null;
      })
      .addCase(getAgingInventoryBucket.fulfilled, (state, action) => {
        state.loading = false;
        state.agingInventoryBucketLoading = false;
        state.agingInventoryBucket = action.payload.result;
      })
      .addCase(getAgingInventoryBucket.rejected, (state, action) => {
        state.loading = false;
        state.agingInventoryBucketLoading = false;
        state.error = action.payload as string;
      })
      .addCase(getProductTableData.pending, (state) => {
        state.loading = true;
        state.agingProductTableLoading = true;
        state.error = null;
      })
      .addCase(getProductTableData.fulfilled, (state, action) => {
        state.loading = false;
        state.agingProductTableLoading = false;
        state.agingProductTable = action.payload;
        const grandTotalRow =
          (action.payload.rows || [])?.find(
            (item : any, idx : any) => item.whse_name === "Grand Total"
          ) || state.agingFirstProductRow;

        state.agingFirstProductRow = grandTotalRow;
      })
      .addCase(getProductTableData.rejected, (state, action) => {
        state.loading = false;
        state.agingProductTableLoading = false;
        state.error = action.payload as string;
      });
  },
});

export default inventoryAgingSlice.reducer;
