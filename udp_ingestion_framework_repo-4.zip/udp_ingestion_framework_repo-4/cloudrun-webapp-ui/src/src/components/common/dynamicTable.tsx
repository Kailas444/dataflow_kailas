import React, { useState } from "react";
import { Pagination, Spin, Table, Tooltip } from "antd";
import "../../styles/global.css";
import { formatNumberWithCommas } from "../../utils/numberFormat";

interface Measure {
  label: string;
  value: string;
  tooltip?: string;
}

interface DynamicTableProps {
  granularity1: string;
  granularity1Label: string;
  granularity2: string;
  granularity2Label: string;
  measureNames?: Measure[];
  riskCategory?: any;
  apiData: any[];
  firstRow?: any;
  totalCount: number;
  pageSize?: number;
  onPageChange?: (page: number, pageSize: number) => void;
  loading?: boolean;
}

const fieldMapping: Record<string, string> = {
  warehouseName: "whse_name",
  itemCategory: "cs_item_category_desc",
  itemStatusCode: "inventory_item_status_cde",
  privateDistribution: "Private_Label_Flag_desc",
  ssic: "ssic_num",
  itemCode: "product_id",
  itemDescription: "master_item_description",
  itemDepartment: "dept_desc",
  vendorName: "vendor_name",
};

const riskCategoryLabelMap: Record<string, string> = {
  CD_age_of_inventory: "CD Age of Inventory",
  LD_age_of_inventory: "LD Age of Inventory",
  LD_age_of_inventory_chg: "LD Age of Inventory Chg",
  L14D_age_of_inventory_chg: "L14D Age of Inventory Chg",
  L14D_age_of_inventory: "L14D Age of Inventory",
};

const DynamicGranularityTable: React.FC<DynamicTableProps> = ({
  granularity1,
  granularity2,
  measureNames = [],
  riskCategory = [],
  apiData = [],
  firstRow = null,
  totalCount,
  pageSize = 20,
  onPageChange,
  loading = false,
  granularity1Label,
  granularity2Label,
}) => {
  const [currentPage, setCurrentPage] = useState(1);
  const [currentPageSize, setCurrentPageSize] = useState(pageSize);

  const limitedMeasures = Array.isArray(measureNames)
    ? measureNames.slice(0, 8)
    : [];

  const headerStyle: React.CSSProperties = {
    backgroundColor: "#E6F7FF",
    fontWeight: 600,
  };

  const headerTooltipMap: Record<string, string> = measureNames.reduce(
    (acc: any, curr: any) => {
      acc[curr.value] = curr.tooltip;
      return acc;
    },
    {}
  );

  const getColumnTitleWithTooltip = (title: string, key: string) => (
    <Tooltip
      color="white"
      arrow={false}
      title={
        <span
          style={{
            color: "black",
            fontSize: "12px",
          }}
        >
          {headerTooltipMap[key] || title}
        </span>
      }
    >
      <span
        style={{
          cursor: "pointer",
        }}
      >
        {title}
      </span>
    </Tooltip>
  );

  const columns = [
    {
      title: getColumnTitleWithTooltip(
        granularity1Label || "Granularity1",
        fieldMapping[granularity1] || granularity1
      ),
      dataIndex: fieldMapping[granularity1] || granularity1,
      key: fieldMapping[granularity1] || granularity1,
      width: measureNames.length > 0 ? "5%" : "10%",
      className: "col-granularity1",
      // sorter: (a: any, b: any) =>
      //   (a[fieldMapping[granularity1]] || "").localeCompare(
      //     b[fieldMapping[granularity1]] || ""
      //   ),
        showSorterTooltip: false,
      render: (_: any, record: any, index: number) => {
        if (index === 0) {
          return {
            children: "Grand Total",
            props: {
              colSpan: 2,
            },
          };
        }
        const value = record[fieldMapping[granularity1] || granularity1];
        return {
          children: value,
          props: {},
        };
      },
      onHeaderCell: () => ({ style: headerStyle }),
    },
    {
      title: getColumnTitleWithTooltip(
        granularity2Label || "Granularity2",
        fieldMapping[granularity2] || granularity2
      ),
      dataIndex: fieldMapping[granularity2] || granularity2,
      key: fieldMapping[granularity2] || granularity2,
      width: measureNames.length > 0 ? "5%" : "90%",
      className: "col-granularity2",
      // sorter: (a: any, b: any) =>
      //   (a[fieldMapping[granularity2]] || "").localeCompare(
      //     b[fieldMapping[granularity2]] || ""
      //   ),
        showSorterTooltip: false,
      render: (_: any, record: any, index: number) => {
        if (index === 0) {
          return {
            children: null,
            props: {
              colSpan: 0,
            },
          };
        }
        const value = record[fieldMapping[granularity2] || granularity2];
        return {
          children: value,
          props: {},
        };
      },
      onHeaderCell: () => ({ style: headerStyle }),
    },
    ...limitedMeasures.map((measure) => ({
      title: getColumnTitleWithTooltip(measure.label, measure.value),
      dataIndex: measure.value,
      key: measure.value,
      width: `${60 / limitedMeasures.length}%`,
      className: "col-measure",
      align: "right",
      // sorter: (a: any, b: any) => {
      //   const valA = a[measure.value];
      //   const valB = b[measure.value];
      //   if (valA === null || valA === undefined) return -1;
      //   if (valB === null || valB === undefined) return 1;
      //   return Number(valA) - Number(valB);
      // },
      showSorterTooltip: false,
      render: (_: any, record: any) => {
        const val = record[measure.value];
        if (
          measure.value === "CD_OOS_pct" ||
          measure.value === "LD_OOS_pct" ||
          measure.value === "L14D_OOS_pct_chg" ||
          measure.value === "L14D_OOS_PCT"
        ) {
          return val !== null && val !== undefined && !isNaN(val)
            ? formatNumberWithCommas(Number(val).toFixed(1)) + "%"
            : null;
        } else {
          return val !== null && val !== undefined && !isNaN(val)
            ? formatNumberWithCommas(Number(val).toFixed(2))
            : null;
        }
      },
      onHeaderCell: () => ({ style: headerStyle }),
    })),
  ];

  const data = apiData.length
    ? [
        ...apiData
          .filter((item, idx) => item.whse_name !== "Grand Total")
          .map((elm) => ({ ...elm, key: JSON.stringify(elm) })),
      ]
    : [];

  return (
    <>
      <Table
        bordered
        loading={loading}
        columns={columns}
        dataSource={[...(firstRow ? [firstRow] : []), ...data]}
        className="dynamic-table"
        pagination={false}
      />
      <div
        style={{
          marginTop: 16,
          textAlign: "right",
          display: "flex",
          justifyContent: "end",
        }}
      >
        <Pagination
          current={currentPage}
          pageSize={currentPageSize}
          total={totalCount}
          showSizeChanger
          pageSizeOptions={["5", "10", "20", "50"]}
          onChange={(page, size) => {
            setCurrentPage(page);
            setCurrentPageSize(size);
            if (onPageChange) {
              onPageChange(page, size);
            }
          }}
        />
      </div>
    </>
  );
};

export default DynamicGranularityTable;
