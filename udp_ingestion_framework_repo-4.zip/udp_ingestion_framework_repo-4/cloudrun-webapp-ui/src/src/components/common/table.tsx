import React from "react";
import { Spin, Table } from "antd";

interface DynamicTableProps {
  columns: { title: string; dataIndex: string; key: string }[];
  data: Record<string, any>[];
  pagination?: {
    pageSize?: number;
    current?: number;
    total?: number;
    onChange?: (page: number, pageSize: number) => void;
  };
  loading?: boolean;
}

const DynamicTable: React.FC<DynamicTableProps> = ({
  columns,
  data,
  pagination,
  loading = false,
}) => {
  const styledColumns = columns.map((col) => ({
    ...col,
    onHeaderCell: () =>
      ({
        style: {
          backgroundColor: "#e6f7ff",
          fontWeight: "bold",
          textAlign: "center",
        },
      } as React.HTMLAttributes<HTMLElement>),
  }));

  return (
    <Spin spinning={loading} delay={500}>
      <Table
        columns={styledColumns}
        dataSource={data}
        pagination={{
          pageSize: pagination?.pageSize || 5,
          current: pagination?.current,
          total: pagination?.total,
          onChange: pagination?.onChange,
        }}
        bordered
        rowKey={(record) => record.key || record.id}
      />
    </Spin>
  );
};

export default DynamicTable;
