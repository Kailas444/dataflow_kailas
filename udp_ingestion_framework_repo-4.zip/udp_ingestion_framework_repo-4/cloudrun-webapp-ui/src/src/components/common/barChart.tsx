import React, { memo } from "react";
// import {
//   Chart as ChartJS,
//   CategoryScale,
//   LinearScale,
//   BarElement,
//   Title,
//   Tooltip,
//   Legend,
// } from "chart.js";
import { Chart } from "react-chartjs-2";
import "../../styles/global.css";
import { Spin } from "antd";
import { formatNumber } from "../../utils/numberFormat";

// ChartJS.register(
//   CategoryScale,
//   LinearScale,
//   BarElement,
//   Title,
//   Tooltip,
//   Legend
// );

interface DynamicBarChartProps {
  data: any[];
  selectedValue: any;
  onSelect: (value: string) => void;
  xLabel?: string;
  yLabel?: string;
  barColor?: string;
  fadedColor?: string;
  barThickness?: any;
  className?: string;
  tooltipFormatter?: (context: any) => string | string[];
  loading?: boolean;
  xAxisRotation?: number;
  xAxisFontSize?: number;
  yAxisFontSize?: number;
}

const DynamicBarChart: React.FC<DynamicBarChartProps> = ({
  data = [],
  selectedValue = null,
  onSelect = () => {},
  xLabel = "",
  yLabel = "",
  barThickness = 20,
  className,
  tooltipFormatter,
  loading = false,
  xAxisRotation = 0,
  xAxisFontSize = 12,
  yAxisFontSize = 12,
}) => {
  const labels = data.map((obj) => obj.labels);
  const values = data.map((obj) => obj.value);
  const colors = data.map((obj) => obj.color || "#DB2032");
  console.log("selceted", selectedValue);
  // const getBarColors = labels.map((lbl) =>
  //   selectedValue !== lbl
  //     ? "#DB203266"
  //     : "#DB2032"
  // );

  const chartData = {
    labels,
    datasets: [
      {
        label: "Values",
        data: values,
        backgroundColor: colors,
        // barThickness: barThickness,
        // maxBarThickness: barThickness,
        categoryPercentage: 1.0,
        barPercentage: 0.7,
        className: className,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { display: false },
      title: { display: !!xLabel || !!yLabel, text: "" },
      datalabels: { display: false },
      tooltip: {
        enabled: true,
        backgroundColor: "#fff", // ✅ white background
        titleColor: "#000", // ✅ black title
        bodyColor: "#000", // ✅ black body
        borderColor: "#ddd", // ✅ light gray border
        borderWidth: 1,
        displayColors: false, // ✅ hides the color box
        caretSize: 0, // ✅ removes arrow
        caretPadding: 0,
        titleFont: {
          size: 12,
          weight: "500",
        },
        bodyFont: {
          size: 12,
          weight: "500",
        },
        cornerRadius: 4,
        callbacks: {
          title: () => "",
          label: (context: any) => {
            // 🔹 use custom formatter if provided, else fallback
            if (tooltipFormatter) {
              return tooltipFormatter(context);
            }
            const label = context.label || "";
            const value = context.raw;
            return [`Label: ${label}`, `Value: ${value}`];
          },
        },
      },
    },
    scales: {
      x: {
        title: {
          display: !!xLabel,
          text: xLabel,
          font: { size: 12, weight: "bold" as const },
        },
        grid: { display: false },
        ticks: {
          autoSkip: false,
          minRotation: xAxisRotation,
          maxRotation: xAxisRotation,
          font: { size: xAxisFontSize },
        },
      },
      y: {
        title: {
          display: !!yLabel,
          text: yLabel,
          font: { size: 12, weight: "bold" as const },
        },
        beginAtZero: true,
        grid: { display: false },
        ticks: {
          font: { size: yAxisFontSize },
          callback: function (value: any) {
            return formatNumber(value);
          },
        },
      },
    },
    onClick: (_: unknown, elements: any[]) => {
      if (elements?.length > 0) {
        const { index } = elements[0];
        const label = chartData.labels[index] as string;
        // onSelect(label);
        if (selectedValue === label) {
          onSelect(null);
        } else {
          onSelect(label);
        }
      }
    },
  };

  return (
    <Spin spinning={loading} delay={500}>
      <Chart
        type="bar"
        data={chartData}
        options={options}
        className={className}
      />
    </Spin>
  );
};

export default memo(DynamicBarChart);
