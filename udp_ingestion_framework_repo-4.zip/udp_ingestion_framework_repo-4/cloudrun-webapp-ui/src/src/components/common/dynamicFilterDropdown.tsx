import React, { useCallback, useEffect, useState } from "react";
import {
  Dropdown,
  Button,
  Checkbox,
  Tooltip,
  Divider,
  Input,
  Spin,
} from "antd";
import { DownOutlined, SearchOutlined } from "@ant-design/icons";
import { debounce } from "lodash";
import { useLocation } from "react-router-dom";

interface FilterOption {
  label: string;
  value: string;
}

interface DynamicFilterDropdownProps {
  name: string;
  options: FilterOption[];
  selectedValues?: string | string[];
  onChange: (selected: string[], name: string) => void;
  defaultTitle?: string;
  width?: number | string;
  multiple?: boolean;
  onOpenDropDown?: (name: string) => void;
  onSearch?: (name: string, search: string) => void;
  onApply?: (selected: string[], name: string) => void;
  loading?: boolean;
}

const DynamicFilterDropdown: React.FC<DynamicFilterDropdownProps> = ({
  name,
  options,
  selectedValues = [],
  onChange,
  defaultTitle = "Filter",
  width = 160,
  multiple = true,
  onOpenDropDown,
  onSearch,
  onApply,
  loading = false,
}) => {
  const location = useLocation();
  const initSelected: string[] = Array.isArray(selectedValues)
    ? (selectedValues as string[])
    : selectedValues
    ? [selectedValues as string]
    : [];
  console.log("selectedValues", name, selectedValues);
  const [selected, setSelected] = useState<string[]>(initSelected);
  const [tempSelected, setTempSelected] = useState<string[]>(initSelected);
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");

  const debouncedSearch = useCallback(
    debounce((value: string) => {
      if (onSearch) {
        onSearch(name, value);
      }
    }, 500),
    [name, onSearch]
  );

  // cleanup debounce on unmount
  useEffect(() => {
    return () => {
      debouncedSearch.cancel();
    };
  }, [debouncedSearch]);

  useEffect(() => {
    if (
      options.length > 0 &&
      selectedValues?.length > 0 &&
      typeof selectedValues === "object"
    ) {
      setSelected(selectedValues);
    }
  }, [location.search, options]);

  const handleOpenChange = (flag: boolean) => {
    if (flag) {
      if (multiple) setTempSelected(selected);
      if (onOpenDropDown) onOpenDropDown(name);
    }
    if (!flag) setSearch("");
    setOpen(flag);
  };

  const toggleInArray = (arr: string[], v: string) =>
    arr.includes(v) ? arr.filter((x) => x !== v) : [...arr, v];

  const handleCheckboxChange = (value: string) => {
    if (multiple) {
      setTempSelected((prev) => toggleInArray(prev, value));
    } else {
      const next = [value];
      setSelected(next);
      onChange(next, name);
      setOpen(false);
    }
  };

  const handleApply = () => {
    setSelected(tempSelected);
    onChange(tempSelected, name);
    if (onApply) {
      onApply(tempSelected, name);
    }
    setOpen(false);
    setSearch("");
  };

  const handleReset = () => {
    setTempSelected([]);
    setSelected([]);
    onChange([], name);
    setSearch("");
    if (!multiple) setOpen(false);
  };

  const handleSearchChange = (value: string) => {
    setSearch(value);

    if (value.length >= 2) {
      debouncedSearch(value);
    }

    console.log("handleSearchChange", name, value);
  };

  const normalizedOptions = options
    ?.map((o) => ({
      label: o.label,
      value: o.value ?? o.label, // fallback to label if value not provided
    }))
    .filter(
      (opt, index, self) =>
        index === self.findIndex((o) => o.label === opt.label) // ✅ keep first unique label
    );

  // ✅ Move selected options to the top
  const sortedOptions = React.useMemo(() => {
    if (!normalizedOptions) return [];
    const selectedSet = new Set(selected);
    return [
      ...normalizedOptions.filter((o) => selectedSet.has(o.value)),
      ...normalizedOptions.filter((o) => !selectedSet.has(o.value)),
    ];
  }, [normalizedOptions, selected]);

  const selectedText =
    selected
      .map(
        (val) => normalizedOptions.find((o) => o.value === val)?.label || val
      )
      .filter(Boolean)
      .join(", ") || "Select";

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
      <span style={{ fontSize: 12, fontWeight: 600, textAlign: "center" }}>
        {defaultTitle}
      </span>

      <Dropdown
        open={open}
        onOpenChange={handleOpenChange}
        trigger={["click"]}
        dropdownRender={() => (
          <div
            style={{
              background: "#fff",
              border: "1px solid #f0f0f0",
              borderRadius: 4,
              boxShadow: "0 2px 8px rgba(0,0,0,0.15)",
              width,
              display: "flex",
              flexDirection: "column",
              maxHeight: 300,
            }}
            onClick={(e) => e.stopPropagation()}
          >
            {/* 🔍 Search box (fixed at top) */}
            {multiple && (
              <div
                style={{
                  padding: "5px 10px",
                  borderBottom: "1px solid #f0f0f0",
                }}
              >
                <Input
                  size="small"
                  placeholder="Search..."
                  prefix={<SearchOutlined />}
                  value={search}
                  onChange={(e) => handleSearchChange(e.target.value)}
                />
              </div>
            )}

            {/* Scrollable options */}
            <div
              style={{
                flex: 1,
                overflowY: "auto",
                padding: "0 10px",
              }}
            >
              {loading && (
                <div style={{ padding: 20, textAlign: "center" }}>
                  <Spin size="small" />
                </div>
              )}

              {!loading && sortedOptions?.length > 0 && (
                <>
                  {sortedOptions.map((option) => (
                    <div
                      key={option.value}
                      style={{
                        padding: "5px 6px",
                        cursor: "pointer",
                        display: "flex",
                        alignItems: "center",
                        fontSize: "10px",
                      }}
                      onClick={(e) => {
                        e.stopPropagation();
                        if (!multiple) {
                          handleCheckboxChange(option.value); // ✅ Select directly
                        }
                      }}
                    >
                      {multiple ? (
                        <Checkbox
                          disabled={false}
                          checked={
                            multiple
                              ? tempSelected.includes(option.value)
                              : selected.includes(option.value)
                          }
                          onChange={() => handleCheckboxChange(option.value)}
                          style={{ fontSize: "10px" }}
                        >
                          {option.label}
                        </Checkbox>
                      ) : (
                        <span
                          style={{
                            fontSize: "10px",
                            fontWeight: selected.includes(option.value)
                              ? 600
                              : 400,
                            color: selected.includes(option.value)
                              ? "#1677ff"
                              : "#000",
                          }}
                        >
                          {option.label}
                        </span>
                      )}
                    </div>
                  ))}
                  {multiple &&
                    (name === "itemCategory" || name === "itemCode") && (
                      <div
                        style={{
                          padding: "5px 6px",
                          color: "#999",
                          cursor: "not-allowed",
                        }}
                      >
                        Please search for more options
                      </div>
                    )}
                </>
              )}
            </div>

            {/* Footer - fixed at bottom */}
            {multiple && (
              <>
                <Divider style={{ margin: "6px 0" }} />
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    padding: "5px 10px",
                  }}
                  onClick={(e) => e.stopPropagation()}
                >
                  <Button size="small" onClick={handleReset}>
                    Reset
                  </Button>
                  <Button type="primary" size="small" onClick={handleApply}>
                    Apply
                  </Button>
                </div>
              </>
            )}
          </div>
        )}
      >
        <Tooltip
          title={selectedText}
          arrow={false}
          overlayInnerStyle={{
            backgroundColor: "#fff",
            color: "#000",
            fontSize: 12,
            fontWeight: 500,
            border: "1px solid #ddd",
            borderRadius: 4,
          }}
          overlayStyle={{ maxWidth: 250 }}
        >
          <Button
            onClick={() => setOpen((v) => !v)}
            style={{
              width,
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              overflow: "hidden",
            }}
          >
            <span
              style={{
                flex: 1,
                whiteSpace: "nowrap",
                overflow: "hidden",
                textOverflow: "ellipsis",
                marginRight: 4,
                fontSize: 12,
                fontWeight: 500,
              }}
            >
              {selectedText}
            </span>
            <DownOutlined />
          </Button>
        </Tooltip>
      </Dropdown>
    </div>
  );
};

export default DynamicFilterDropdown;
