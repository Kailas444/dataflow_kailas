// Sushma - PopoverExample.tsx
import React, { useState } from "react";
import { Popover, Button } from "antd";
import { CloseOutlined, ReadOutlined } from "@ant-design/icons";

const KPI_DESCRIPTIONS: Record<string, string> = {
  "Inventory Value": "Total monetory worth of the stock we currently hold in the warehouse",
  "Inventory Quantity": "The number of units/items of a product currently available in the stock",
  "SKU(Stock Keeping Unit)": "It is a unique code or identifier for each item/product in the inventory",
  "WOH(Weeks on Hand)": "How many weeks the current stock will last based on last 13 week average sales",
  "OOS (Out of Stock)": "Items that are not available in inventory - usually with inventory quantity = 0",
  "Upcoming Expiries SKUs": "Items that are about to expire on the basis of days left to expire. By Default it is 7 days",
  "Excess Inventory SKU": "Any Product (SKU) that has more stock than needed based on expected demand, reorder levels, or inventory norms",
  "Excess Inventory Qty": "How much of current stock exceeds the optimal or maximum required level for each SKU",
  "Excess Inventory Value": "How much money is blocked up in overstocked items",
  "Inventory Level" : "On the basis of Weeks on hand products are classifed in to low, normal , excess and out of stock",
  "Current Day KPI's": "The above KPIs are calculated at the day level, with the current day representing the most recent  date",
  "Last Day KPI's(Last Day KPI's)": "KPIs based on the immediate preceding day",
  "Last 14 Day AverageKPI's(Last 14 Days KPI's)": "KPI's related to last 14 days average value",
  "Aging Bucket by Inventory Quantity": "Show how many SKUs (in percentage) fall into aging buckets such as: 0-30 days, 31-60 days, 61-90 days, 91+ days",
  "Aging Bucket by Inventory Value": "Show the total inventory value ($) (in percentage) by how many days old the inventory is, fall into aging buckets such as : 0-30 days, 31-60 days, 61-90 days, 91+ days",
  "Replenishment Status": "Helps track whick SKUs are - InStock or are Below Reorder Point",
  "Aging Inventory Status": "Helps to monitor the health of the stock over time - identifying Not at Risk, Half Life Products, Near Expiry and Expired that may need action",
  "Private Label Distribution by Quantity": "Show how private label products are distributed across total quantity sold or moved -i.e. what % of the business is driven by private labels vs national labels",
  "Inventory Distribution by Department": "Show how inventory is distributed across different departments based on metric selected in the size and color of the heatmap",
  "Inventory Distribution by Category": "Show how inventory is distributed across product categories based on metric selected in the size and color of the heatmap",
  "Inventory Distribution by SKU": "Display how inventory is distributed across SKUs using for a selected combination",
  "Weighted Inventory Age": "Average Number of days the product has been in the inventory",
  "Product ID Distribution by Weighted Inventory Age": "Distribution of Product IDs by Weighted Inventory Age in the Product Table on Current Day, last Day and Last 14 days level"
};

const Glossary: React.FC = () => {
  const [open, setOpen] = useState(false);

  const content = (
    <div style={{ width: 500, maxHeight: 500, overflowY: "auto" }}>
      {Object.entries(KPI_DESCRIPTIONS).map(([kpi, desc]) => (
        <p key={kpi}>
          <strong>{kpi}:</strong> {desc}
        </p>
      ))}
    </div>
  );

  const title = (
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
      <span>KPI Definitions</span>
      <CloseOutlined
        onClick={() => setOpen(false)}
        style={{ cursor: "pointer", color: "#999" }}
      />
    </div>
  );

  return (
    <Popover
      content={content}
      title={title}
      trigger="click"
      placement="right"
      zIndex={9999}
      open={open}
      onOpenChange={(visible) => setOpen(visible)}
    >
      <ReadOutlined style={{ fontSize: "20px" }} />
    </Popover>
  );
};

export default Glossary;
