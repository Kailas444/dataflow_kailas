import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  LineElement,
  PointElement,
  ScatterController,
  BubbleController,
  Legend,
  ArcElement,
} from "chart.js";
import { TreemapController, TreemapElement } from "chartjs-chart-treemap";
import ChartDataLabels from "chartjs-plugin-datalabels";
 
ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  LineElement,
  PointElement,
  ScatterController,
  BubbleController,
  Legend,
  ArcElement,
  TreemapController,
  TreemapElement,
  ChartDataLabels
);