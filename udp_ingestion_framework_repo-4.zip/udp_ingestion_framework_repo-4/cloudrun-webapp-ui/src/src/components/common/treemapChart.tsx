import React, { memo } from "react";
// import { Chart as ChartJS, Title, Tooltip, Legend } from "chart.js";
// import { TreemapController, TreemapElement } from "chartjs-chart-treemap";
import { Chart } from "react-chartjs-2";
import "chartjs-chart-treemap";
// import ChartDataLabels from "chartjs-plugin-datalabels";
import { Spin } from "antd";

// ChartJS.register(
//   Title,
//   Tooltip,
//   Legend,
//   TreemapController,
//   TreemapElement,
//   ChartDataLabels
// );

interface ChildChartProps {
  name: string;
  data: any[];
  selectedValue: any;
  onSelect: (value: string | null, name: string) => void;
  loading?: boolean;
  tooltipFormatter?: (node: any) => string;
}

function TreemapChart({
  name = "",
  data,
  selectedValue,
  onSelect,
  loading = false,
  tooltipFormatter,
}: ChildChartProps) {
  const values = data.map((obj) => obj.highlightValue);
  const minValue = Math.min(...values);
  const maxValue = Math.max(...values);

  const interpolateColor = (
    minColor: string,
    maxColor: string,
    factor: number
  ) => {
    const c1 = parseInt(minColor.slice(1), 16);
    const c2 = parseInt(maxColor.slice(1), 16);

    const r1 = (c1 >> 16) & 0xff;
    const g1 = (c1 >> 8) & 0xff;
    const b1 = c1 & 0xff;

    const r2 = (c2 >> 16) & 0xff;
    const g2 = (c2 >> 8) & 0xff;
    const b2 = c2 & 0xff;

    const r = Math.round(r1 + factor * (r2 - r1));
    const g = Math.round(g1 + factor * (g2 - g1));
    const b = Math.round(b1 + factor * (b2 - b1));

    return `rgb(${r},${g},${b})`;
  };

  const steps = 10;
  const colorSteps = Array.from({ length: steps }, (_, i) =>
    interpolateColor("#9cd0d1", "#2f628c", i / (steps - 1))
  );

  const top10ByValue = new Set(
    [...data]
      .sort((a, b) => b.value - a.value)
      .slice(0, 10)
      .map((d) => d.label)
  );
  const top5ByHighlight = new Set(
    [...data]
      .sort((a, b) => b.highlightValue - a.highlightValue)
      .slice(0, 5)
      .map((d) => d.label)
  );

  const treemapData = {
    datasets: [
      {
        label: "Treemap",
        tree: [...data],
        key: "value",
        borderColor: (ctx: any) => {
          const node = ctx.raw?._data;
          if (!node) return "#fff";

          return selectedValue === node.label ? "#ff0000" : "#fff";
        },
        borderWidth: 2,
        backgroundColor: (ctx: any) => {
          const node = ctx.raw?._data;
          if (!node) return "#8BDEB4";
          // if (selectedValue && node.label !== selectedValue) {
          //   //return "rgba(200,200,200,0.3)";
          // }
          const factor =
            maxValue === minValue
              ? 0
              : (node.highlightValue - minValue) / (maxValue - minValue);
          const stepIndex = Math.min(
            steps - 1,
            Math.round(factor * (steps - 1))
          );
          return colorSteps[stepIndex];
        },
      },
    ],
  };

  const treemapOptions = {
    animation: false, // 🔴 disable all animations
    animations: {
      colors: false,
      x: false,
      y: false,
    },
    transitions: {
      active: {
        animation: {
          duration: 0,
        },
      },
      show: {
        animations: {
          x: { duration: 0 },
          y: { duration: 0 },
        },
      },
      hide: {
        animations: {
          x: { duration: 0 },
          y: { duration: 0 },
        },
      },
    },
    onClick: (_: unknown, elements: any[]) => {
      if (elements?.length > 0) {
        console.log("elementstreemap", elements);
        const node = elements[0].element.$context.raw._data;
        // onSelect(node.label, name);
        if (selectedValue === node.label) {
          onSelect(null, name);
        } else {
          onSelect(node.label, name);
        }
      }
    },
    maintainAspectRatio: false,
    resizeDelay: 200,
    plugins: {
      title: { display: true },
      legend: { display: false },
      tooltip: {
        enabled: true,
        backgroundColor: "#fff",
        titleColor: "#000",
        bodyColor: "#000",
        borderColor: "#ddd",
        borderWidth: 1,
        displayColors: false,
        caretSize: 0,
        caretPadding: 0,
        titleFont: {
          size: 12,
          weight: "500",
        },
        bodyFont: {
          size: 12,
          weight: "500",
        },
        cornerRadius: 4,
        callbacks: {
          title: () => "",
          label: (ctx: any) => {
            const node = ctx.raw?._data;
            if (!node) return "";
            return tooltipFormatter
              ? tooltipFormatter(node)
              : `Label: ${node.label}, Value: ${node.value}, Highlight: ${node.highlightValue}`;
          },
        },
      },
      datalabels: {
        color: "white",
        font: { size: 12, weight: "bold" },
        align: "center",
        anchor: "center",
        clip: true,
        formatter: (ctx: any) => {
          const node = ctx?._data;
          if (!node) return null;

          const label = node.label || "";
          if (!top10ByValue.has(node.label) && !top5ByHighlight.has(node.label))
            return null;

          const maxChars = 8;
          return label.length > maxChars
            ? label.substring(0, maxChars) + "…"
            : label;
        },
      },
    },
  };

  return (
    <Spin spinning={loading} delay={500}>
      <div>
        <Chart
          type="treemap"
          data={treemapData}
          options={treemapOptions}
          className="treemap-chart"
        />
      </div>
    </Spin>
  );
}

export default memo(TreemapChart);
