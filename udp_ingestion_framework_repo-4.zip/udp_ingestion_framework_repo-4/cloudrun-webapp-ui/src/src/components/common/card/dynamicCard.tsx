// Sushma - DynamicCard Component
import React from "react";
import { Card } from "antd";

interface DynamicCardProps {
  title: string;
  subtitle?: string;
  action?: React.ReactNode; // Right side component
  children: React.ReactNode; // Center content
  width?: number | string;
  height?: number | string;
  style?: React.CSSProperties;
}

const DynamicCard: React.FC<DynamicCardProps> = ({
  title,
  subtitle,
  action,
  children,
  // width = "100%",
  // height = 300,
  style,
}) => {
  return (
    <Card
      style={{
        // width,
        // height,
        ...style,
        display: "flex",
        flexDirection: "column",
        // width:"fit-content"
      }}
      bodyStyle={{
        flex: 1,
        display: "flex",
        flexDirection: "column",
        padding: "10px",
      }}
    >
      {/* Header Row */}
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          marginBottom : "5px"
        }}
      >
        {/* Left - Title */}
        <div>
          <div style={{ fontWeight: 700, fontSize: "13px" }}>{title}</div>
          {subtitle && (
            <div style={{ fontWeight: 700, fontSize: "16px" }}>
              {subtitle}
            </div>
          )}
        </div>

        {/* Right - Action */}
        <div style={{marginLeft :"10px"}}>{action}</div>
      </div>

      {/* Center - Main Content */}
      <div
        style={{
          flex: 1,
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        {children}
      </div>
    </Card>
  );
};

export default DynamicCard;
