import React from "react";
import { Typography } from "antd";
import { CaretUpFilled, CaretDownFilled } from "@ant-design/icons";

const { Text } = Typography;

interface ActionProps {
  lastDayValue: number;
  last14DayValue: number;
  isDecreaseGood?: boolean; // 🔹 New prop
}

const CardAction: React.FC<ActionProps> = ({ lastDayValue, last14DayValue, isDecreaseGood = false }) => {
  const getArrow = (value: number) => {
    if (isDecreaseGood) {
      // 🔹 Decrease = green, Increase = red
      return value < 0 ? (
        <CaretDownFilled style={{ color: "green", fontSize: 10 }} />
      ) : (
        <CaretUpFilled style={{ color: "red", fontSize: 10 }} />
      );
    } else {
      // 🔹 Increase = green, Decrease = red
      return value >= 0 ? (
        <CaretUpFilled style={{ color: "green", fontSize: 10 }} />
      ) : (
        <CaretDownFilled style={{ color: "red", fontSize: 10 }} />
      );
    }
  };

  return (
    <div style={{ display: "flex", flexDirection: "column" }}>
      {/* Line 1 */}
      <div style={{ display: "flex", alignItems: "center", marginBottom: 4, minWidth: 82 }}>
        <span style={{ width: 16, display: "flex", justifyContent: "center" }}>
          {getArrow(lastDayValue)}
        </span>
        <Text strong style={{ marginLeft: 4, fontSize: 8 }}>
          {Math.abs(lastDayValue) + "%"}
        </Text>
        <Text type="secondary" style={{ marginLeft: 4, fontSize: 8 }}>
          Last Day
        </Text>
      </div>

      {/* Line 2 */}
      <div style={{ display: "flex", alignItems: "center", minWidth: 76 }}>
        <span style={{ width: 16, display: "flex", justifyContent: "center" }}>
          {getArrow(last14DayValue)}
        </span>
        <Text strong style={{ marginLeft: 4, fontSize: 8 }}>
          {Math.abs(last14DayValue) + "%"}
        </Text>
        <Text type="secondary" style={{ marginLeft: 4, fontSize: 8 }}>
          Last 14 DA
        </Text>
      </div>
    </div>
  );
};

export default CardAction;
