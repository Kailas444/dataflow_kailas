import React, { memo } from "react";
// import {
//   Chart as ChartJS,
//   CategoryScale,
//   LinearScale,
//   BarElement,
//   PointElement,
//   Title,
//   Tooltip,
//   Legend,
// } from "chart.js";
import { Chart } from "react-chartjs-2";
import { formatNumber, formatNumberWithCommas } from "../../utils/numberFormat";
import { Spin } from "antd";

// ChartJS.register(
//   CategoryScale,
//   LinearScale,
//   BarElement,
//   PointElement, // needed for circles
//   Title,
//   Tooltip,
//   Legend
// );

interface ChildChartProps {
  name: string;
  data: any[];
  selectedValue: any;
  onSelect: (value: string | null, name: string) => void;
  xLabel?: string;
  yLabel?: string;
  loading?: boolean;
  rotationFilter?: boolean;
  tooltipFormatter?: (node: any) => string[];
  className?: string;
}

function WarehouseChart({
  name = "",
  data = [],
  selectedValue,
  onSelect,
  xLabel = "",
  yLabel = "",
  loading = false,
  rotationFilter = false,
  tooltipFormatter,
  className = "",
}: ChildChartProps) {
  const labels = data.map((obj) => obj.labels);
  const barData = data.map((obj) => obj.barData);
  const circleData = data.map((obj) => obj.circleData);

  // const labels =  ["January", "February", "March", "April", "May", "June", "July"];
  // const barData = [300, 450, 700, 200, 600, 900, 500];
  // const circleData = [280, 470, 680, 220, 580, 880, 520];

  // ✅ Apply blur effect if selection is active
  const getBarColors = labels.map(
    (lbl) =>
      selectedValue && selectedValue !== lbl
        ? "#DB203266" // faded
        : "#DB2032" // normal
  );

  const getCircleColors = labels.map((lbl) =>
    selectedValue && selectedValue !== lbl ? "#2f628c" : "#2f628c"
  );

  const chartData = {
    labels,
    datasets: [
      {
        type: "scatter" as const,
        // label: "L14 DA",
        label: "L14 Day Average",
        data: circleData.map((value, index) => ({ x: index, y: value })),
        backgroundColor: getCircleColors,
        pointRadius: 4.5,
        pointHoverRadius: 4.5,
        pointStyle: "circle",
        order: 1,
      },
      {
        type: "bar" as const,
        // label: "KPI",
        label: yLabel || "KPI",
        data: barData,
        backgroundColor: getBarColors,
        pointStyle: "rect",
        order: 2,
        barPercentage: 0.8, // default 0.9
        categoryPercentage: 0.4, // default 0.8
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    resizeDelay: 200,
    plugins: {
      legend: {
        display: true,
        position: "top" as const,
        align: "center" as const,
        labels: {
          usePointStyle: true,
          // boxWidth: 10,
          boxHeight: 10,
          pointStyleWidth: 14,
          font: {
            size: 12,
            weight: "500" as const,
          },
          color: "#333",
          boxWidth: 20,
          padding: 10,
        },
      },
      title: { display: true },
      datalabels: {
        display: false,
      },
      tooltip: {
        enabled: true,
        backgroundColor: "#fff",
        titleColor: "#000",
        bodyColor: "#000",
        borderColor: "#ddd",
        borderWidth: 1,
        displayColors: false,
        caretSize: 0,
        caretPadding: 0,
        titleFont: {
          size: 12,
          weight: "500",
        },
        bodyFont: {
          size: 12,
          weight: "500",
        },
        cornerRadius: 4,
        position: "nearest",
        yAlign: "bottom",
        callbacks: {
          title: function () {
            return "";
          },
          // label: (ctx: any) => {
          //   const index = ctx.dataIndex;
          //   const datasetIndex = ctx.datasetIndex;
          //   const xValue = labels[index];
          //   const yValue =
          //     datasetIndex === 0 ? circleData[index] : barData[index];

          //   return tooltipFormatter
          //     ? tooltipFormatter({
          //         xLabel,
          //         xValue,
          //         yLabel,
          //         yValue,
          //         dataset: circleData[index],
          //       })
          //     : [];
          // },
          label: (ctx: any) => {
            const index = ctx.dataIndex;
            const xValue = labels[index];
            const barValue = barData[index];
            const circleValue = circleData[index];

            // ✅ Always return one tooltip block, regardless of bar/scatter
            return tooltipFormatter
              ? tooltipFormatter({
                  xLabel,
                  xValue,
                  yLabel,
                  yValue: barValue,
                  dataset: circleValue,
                })
              : [];
          },
        },
      },
    },
    scales: {
      x: {
        title: {
          display: !!xLabel,
          text: xLabel,
          font: { size: 14, weight: "bold" as const },
        },
        ticks: {
          autoSkip: false,
          minRotation: rotationFilter ? 90 : 0,
          maxRotation: rotationFilter ? 90 : 0,
          font: {
            size: 9, // smaller font size
          },
        },
        grid: {
          drawTicks: false,
          drawBorder: false, // hides the x-axis line
          display: false,
        },
        // min: 0, // start index
        // max: 12, // show only first 10 bars
      },
      y: {
        title: {
          display: !!yLabel,
          text: yLabel,
          font: { size: 14, weight: "bold" as const },
        },
        beginAtZero: true,
        ticks: {
          callback: function (value: number | string) {
            return formatNumber(Number(value));
          },
          font: {
            size: 9, // smaller font size
          },
        },
        grid: {
          display: false, // ✅ Removes horizontal grid lines
        },
      },
    },
    datasets: {
      bar: {
        barPercentage: 0.2, // default 0.9
        categoryPercentage: 0.4, // default 0.8
      },
    },
    // ✅ Chart.js click handler
    onClick: (_: unknown, elements: any[]) => {
      if (elements?.length > 0) {
        const { index } = elements[0];
        console.log(
          chartData.labels,
          "elements",
          index,
          chartData.labels[index],
          elements[0]
        );
        const label = chartData.labels[index] as string;
        console.log("labelbar", label);
        if (selectedValue === label) {
          onSelect(null, name);
        } else {
          onSelect(label, name);
        }
        // onSelect(label, name);
      }
    },
  };
  return (
    <Spin spinning={loading} delay={500}>
      <div>
        <Chart
          type="bar"
          options={options}
          data={chartData}
          className={`warehouse-chart ${className || ""}`}
        />
      </div>
    </Spin>
  );
}
export default memo(WarehouseChart);
