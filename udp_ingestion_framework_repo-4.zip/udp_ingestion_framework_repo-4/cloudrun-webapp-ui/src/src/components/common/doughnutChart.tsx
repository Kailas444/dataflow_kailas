import React, { memo } from "react";
// import { Chart as ChartJS, ArcElement, Tooltip, Legend } from "chart.js";
import { Doughnut } from "react-chartjs-2";
import { Spin } from "antd";

// ChartJS.register(ArcElement, Tooltip, Legend);

interface ChildChartProps {
  name?: string;
  data: any[];
  selectedValue: any;
  onSelect: (value: string | null, name: string) => void;
  className: any;
  loading?: boolean;
  showLegend?: boolean;
  tooltipFormatter?: (context: any) => string | string[];
  legendLabels?: string[];
}
function DoughnutChart({
  name = "",
  data = [],
  selectedValue,
  onSelect,
  className,
  loading = false,
  showLegend = true,
  tooltipFormatter,
  legendLabels, 
}: ChildChartProps) {
  console.log("datadoughnut", data);
  const labels = data.map((obj) => obj.label);
  const chartData = data.map((obj) => obj.data);
  const backgroundColor = data.map((obj) => obj.bgColor);
  const colors = ["#fc9226", "#2f628c", "#ed6657", "#71b0b2"];
  const fadedColors = ["#DFFDF6", "#FFE3E0", "#F7B5B8", "#C9F5E0"];
  const doughnutData = {
    labels,
    datasets: [
      {
        // label: "Votes",
        data: chartData,
        backgroundColor: backgroundColor,
        borderWidth: 1,
      },
    ],
  };
  const options = {
    responsive: true,
    maintainAspectRatio: false,
    resizeDelay: 200,
    cutout: "70%",
    animation: false, // 🔴 disable all animations
    animations: {
      colors: false,
      x: false,
      y: false,
    },
    transitions: {
      active: {
        animation: {
          duration: 0,
        },
      },
      show: {
        animations: {
          colors: { duration: 0 },
          x: { duration: 0 },
          y: { duration: 0 },
        },
      },
      hide: {
        animations: {
          colors: { duration: 0 },
          x: { duration: 0 },
          y: { duration: 0 },
        },
      },
    },
    plugins: {
      legend: showLegend
        ? {
            position: "bottom" as const,
            labels: {
              usePointStyle: true,
              pointStyle: "circle",
              filter: (legendItem: any) =>
                !legendLabels || legendLabels.includes(legendItem.text),
            },
          }
        : { display: false },
      title: { display: true },
      datalabels: {
        color: "white",
        formatter: (value: number) => `${value}%`,
        font: {
          size: 9,
        },
      },
      tooltip: {
        enabled: true,
        backgroundColor: "#fff",
        titleColor: "#000",
        bodyColor: "#000",
        borderColor: "#ddd",
        borderWidth: 1,
        displayColors: false,
        caretSize: 0,
        caretPadding: 0,
        cornerRadius: 4,
        titleFont: {
          size: 12,
          weight: "500",
        },
        bodyFont: {
          size: 12,
          weight: "500",
        },
        callbacks: {
          title: function () {
            return ""; 
          },
          label: function (context: any) {
            console.log("contectdough", context, data[context.dataIndex]);
            const {invQtyCD, invValueCD} =  data[context.dataIndex]
            if (tooltipFormatter) {
              return tooltipFormatter({...context, invQtyCD, invValueCD});
            }
            const label = context.label || "";
            const value = context.raw;
            return [`Label: ${label}`, `Value: ${value}%`];
          },
        },
      },
    },
    onClick: (_: unknown, elements: any[]) => {
      if (elements?.length > 0) {
        const { index } = elements[0];
        const label = doughnutData.labels[index] as string;
        // onSelect(label, name);
        if (selectedValue === label) {
          onSelect(null, name);
        } else {
          onSelect(label, name);
        }
      }
    },
  };

  return (
    <Spin spinning={loading} delay={500}>
      <div>
        <Doughnut data={doughnutData} options={options} className={className} />
      </div>
    </Spin>
  );
}

export default memo(DoughnutChart);
