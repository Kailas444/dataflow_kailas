// import React, { memo } from "react";
// // import {
// //   Chart as ChartJS,
// //   CategoryScale,
// //   LinearScale,
// //   PointElement,
// //   Tooltip,
// //   Legend,
// // } from "chart.js";
// // import ChartDataLabels from "chartjs-plugin-datalabels";
// import { Bubble } from "react-chartjs-2";
// import { Spin } from "antd";

// // ChartJS.register(
// //   CategoryScale,
// //   LinearScale,
// //   PointElement,
// //   Tooltip,
// //   Legend,
// //   ChartDataLabels
// // );

// interface ChildChartProps {
//   name: string;
//   data: { r: number; label: string; highlightValue: number }[];
//   selectedValue: any;
//   onSelect: (value: string | null, name: string) => void;
//   loading?: boolean;
//   tooltipFormatter?: (node: any) => string;
// }

// function BubbleChart({
//   name = "",
//   data = [],
//   selectedValue,
//   onSelect,
//   loading = false,
//   tooltipFormatter,
// }: ChildChartProps) {
//   const getCenteredXY = () => {
//     const centerX = 0.5; // normalized center
//     const centerY = 0.5;
//     const spreadX = 0.7;
//     const spreadY = 0.7;

//     return {
//       x: +(centerX + (Math.random() - 0.5) * spreadX).toFixed(2),
//       y: +(centerY + (Math.random() - 0.5) * spreadY).toFixed(2),
//     };
//   };

//   // --- normalize bubble size based on r ---
//   const maxR = Math.max(...data.map((d) => d.r));
//   const minR = Math.min(...data.map((d) => d.r));

//   const normalizeR = (value: number) => {
//     const minSize = 5;
//     const maxSize = 50;
//     if (maxR === minR) return (minSize + maxSize) / 2;
//     return ((value - minR) / (maxR - minR)) * (maxSize - minSize) + minSize;
//   };

//   // --- normalize bubble color based on highlightValue ---
//   const maxHighlight = Math.max(...data.map((d) => d.highlightValue));
//   const minHighlight = Math.min(...data.map((d) => d.highlightValue));

//   const normalizeHighlight = (value: number) => {
//     if (maxHighlight === minHighlight) return 0.5; // avoid divide by zero
//     return (value - minHighlight) / (maxHighlight - minHighlight);
//   };

//   // function to interpolate between two hex colors
//   const interpolateColor = (
//     minColor: string,
//     maxColor: string,
//     factor: number
//   ) => {
//     const c1 = parseInt(minColor.slice(1), 16);
//     const c2 = parseInt(maxColor.slice(1), 16);

//     const r1 = (c1 >> 16) & 0xff;
//     const g1 = (c1 >> 8) & 0xff;
//     const b1 = c1 & 0xff;

//     const r2 = (c2 >> 16) & 0xff;
//     const g2 = (c2 >> 8) & 0xff;
//     const b2 = c2 & 0xff;

//     const r = Math.round(r1 + factor * (r2 - r1));
//     const g = Math.round(g1 + factor * (g2 - g1));
//     const b = Math.round(b1 + factor * (b2 - b1));

//     return `rgb(${r},${g},${b})`;
//   };

//   // --- transform dataset ---
//   const transformedData = data.map((obj) => {
//     const { x, y } = getCenteredXY();
//     return {
//       ...obj,
//       x,
//       y,
//       r: normalizeR(obj.r), // radius based on r
//       label: obj.label,
//     };
//   });

//   // ✅ Sort by radius so biggest bubble is last (on top)
//   transformedData.sort((a, b) => a.highlightValue - b.highlightValue);

//   const colorStops = [
//     { stop: 0, color: "#d0f0f5" }, // very light cyan
//     { stop: 0.25, color: "#9cd0d1" }, // light teal
//     { stop: 0.5, color: "#4a90a4" }, // medium teal-blue
//     { stop: 0.75, color: "#2f628c" }, // dark blue
//     { stop: 1, color: "#1a2f4c" }, // very dark navy
//   ];

//   const getGradientColor = (
//     stops: { stop: number; color: string }[],
//     factor: number
//   ) => {
//     // Clamp between 0 and 1
//     factor = Math.max(0, Math.min(1, factor));

//     for (let i = 0; i < stops.length - 1; i++) {
//       const { stop: s1, color: c1 } = stops[i];
//       const { stop: s2, color: c2 } = stops[i + 1];

//       if (factor >= s1 && factor <= s2) {
//         const localFactor = (factor - s1) / (s2 - s1);
//         return interpolateColor(c1, c2, localFactor);
//       }
//     }

//     return stops[stops.length - 1].color; // fallback last
//   };

//   const bubbleData = {
//     datasets: [
//       {
//         label: "Bubble Dataset",
//         data: transformedData,
//         backgroundColor: (ctx: any) => {
//           const raw = ctx.raw;
//           let factor = normalizeHighlight(raw?.highlightValue || 0);

//           // Optional: emphasize contrast using exponential scale
//           factor = Math.pow(factor, 0.5); // smaller values become lighter

//           // return interpolateColor("#9cd0d1", "#2f628c", factor);
//           return getGradientColor(colorStops, factor);
//         },
//       },
//     ],
//   };

//   const bubbleOptions = {
//     animation: false,
//     animations: {
//       colors: false,
//       x: false,
//       y: false,
//       r: false,
//     },
//     transitions: {
//       active: {
//         animation: {
//           duration: 0,
//         },
//       },
//       show: {
//         animations: {
//           x: { duration: 0 },
//           y: { duration: 0 },
//           r: { duration: 0 },
//         },
//       },
//       hide: {
//         animations: {
//           x: { duration: 0 },
//           y: { duration: 0 },
//           r: { duration: 0 },
//         },
//       },
//     },
//     maintainAspectRatio: false,
//     resizeDelay: 200,
//     layout: {
//       padding: 5,
//     },
//     plugins: {
//       legend: {
//         display: false, // ✅ removes legend
//       },
//       datalabels: {
//         display: true,
//         color: "white",
//         font: { weight: "bold", size: 6 },
//         clip: false,
//         formatter: (value: any) => {
//           if (value.r < 35) return ""; // small bubbles no label

//           const label = value.label || "";

//           // 🔑 Split long labels into 2 lines (max 8 chars each line)
//           const maxCharsPerLine = 8;
//           if (label.length > maxCharsPerLine) {
//             const firstLine = label.substring(0, maxCharsPerLine);
//             const secondLine = label.substring(maxCharsPerLine);
//             return [firstLine, secondLine]; // array → renders as multiline
//           }

//           return label;
//         },
//       },
//       tooltip: {
//         enabled: true,
//         backgroundColor: "#fff",
//         titleColor: "#000",
//         bodyColor: "#000",
//         borderColor: "#ddd",
//         borderWidth: 1,
//         displayColors: false,
//         caretSize: 0,
//         caretPadding: 0,
//         titleFont: {
//           size: 12,
//           weight: "500",
//         },
//         bodyFont: {
//           size: 12,
//           weight: "500",
//         },
//         cornerRadius: 4,
//         position: "nearest",
//         yAlign: "bottom",
//         callbacks: {
//           label: (ctx: any) => {
//             const raw = ctx.raw;
//             console.log("rawbubble", ctx);
//             return tooltipFormatter
//               ? tooltipFormatter({
//                   ...raw,
//                   index: ctx.dataIndex,
//                   data: ctx.dataset.data,
//                 })
//               : `Label: ${raw.label}, Value: ${raw.value}, Highlight: ${raw.highlightValue}`;
//           },
//         },
//       },
//     },
//     scales: {
//       x: {
//         display: false,
//         min: 0, // chart fully fits bubbles horizontally
//         max: 1,
//         grid: { display: false },
//         ticks: { display: false },
//       },
//       y: {
//         display: false,
//         min: 0, // chart fully fits bubbles vertically
//         max: 1,
//         grid: { display: false },
//         ticks: { display: false },
//       },
//     },

//     onClick: (_: unknown, elements: any[]) => {
//       if (elements?.length > 0) {
//         const { index } = elements[0];
//         const label = transformedData[index].label as string;
//         // onSelect(label, name);
//         if (selectedValue === label) {
//           onSelect(null, name);
//         } else {
//           onSelect(label, name);
//         }
//       }
//     },
//   };

//   return (
//     <Spin spinning={loading} delay={500}>
//       <div>
//         <Bubble
//           data={bubbleData}
//           options={bubbleOptions}
//           className="bubble-chart"
//         />
//       </div>
//     </Spin>
//   );
// }

// export default memo(BubbleChart);

import React, { useRef, useEffect, memo } from "react";
import * as d3 from "d3";
import { Spin } from "antd";

interface BubbleData {
  r: number;
  label: string;
  highlightValue: number;
  x?: number; // Added by D3 simulation
  y?: number; // Added by D3 simulation
}

interface ChildChartProps {
  name: string;
  data: BubbleData[];
  selectedValue?: string | null;
  onSelect: (value: string | null, name: string) => void;
  loading?: boolean;
  tooltipFormatter?: (node: BubbleData) => string;
}

const BubbleChart: React.FC<ChildChartProps> = ({
  name = "",
  data = [],
  selectedValue,
  onSelect,
  loading = false,
  tooltipFormatter,
}) => {
  const ref = useRef<SVGSVGElement | null>(null);

  useEffect(() => {
    console.log("datbubble", data);
    if (!data || data.length === 0) {
      // ref.current = null;
      return;
    }

    const width = 600;
    const height = 495;

    // Clear previous SVG content
    const svg = d3.select(ref.current);
    svg.selectAll("*").remove();
    svg.attr("width", width).attr("height", height);

    // Normalize radius
    const minR = d3.min(data, (d) => d.r) ?? 5;
    const maxR = d3.max(data, (d) => d.r) ?? 50;
    const rScale = d3.scaleLinear().domain([minR, maxR]).range([5, 50]);

    // Normalize color based on highlightValue
    const minH = d3.min(data, (d) => d.highlightValue) ?? 0;
    const maxH = d3.max(data, (d) => d.highlightValue) ?? 1;
    const colorScale = d3
      .scaleLinear<string>()
      .domain([minH, maxH])
      .range(["#9cd0d1", "#2f628c"]);

    // Simulation for bubble positioning
    const simulation = d3
      .forceSimulation<BubbleData>(data)
      .force("x", d3.forceX(width / 2).strength(0.05))
      .force("y", d3.forceY(height / 2).strength(0.05))
      .force(
        "collide",
        d3.forceCollide((d) => rScale(d.r) + 2)
      )
      .stop();

    for (let i = 0; i < 300; ++i) simulation.tick();

    // Create or select tooltip
    let tooltip = d3.select("body").select<HTMLDivElement>("#bubble-tooltip");
    if (tooltip.empty()) {
      // tooltip = d3
      //   .select("body")
      //   .append("div")
      //   .attr("id", "bubble-tooltip")
      //   .style("position", "absolute")
      //   .style("pointer-events", "none")
      //   .style("padding", "6px 8px")
      //   .style("background", "#fff")
      //   .style("border", "1px solid #ddd")
      //   .style("border-radius", "4px")
      //   .style("font-size", "12px")
      //   .style("font-weight", "500")
      //   .style("color", "#000")
      //   .style("opacity", 0)
      //   .style("z-index", "1000")
      //   .style("box-shadow", "0 2px 4px rgba(0,0,0,0.2)");
      tooltip = d3
        .select("body")
        .append("div")
        .attr("id", `bubble-tooltip-${name}`) // Use unique ID to avoid conflicts
        .style("position", "absolute")
        .style("pointer-events", "none")
        .style("padding", "6px 8px")
        .style("background", "#fff")
        .style("border", "1px solid #ddd")
        .style("border-radius", "4px")
        .style("font-size", "12px")
        .style("font-weight", "500")
        .style("color", "#000")
        .style("opacity", 0)
        .style("z-index", "9999") // Increase z-index
        .style("box-shadow", "0 2px 4px rgba(0,0,0,0.2)");
    }

    // Draw nodes
    const nodes = svg
      .selectAll("g")
      .data(data)
      .enter()
      .append("g")
      .attr("transform", (d) => `translate(${d.x},${d.y})`);

    // Circles with tooltip and click events
    nodes
      .append("circle")
      .attr("r", (d) => rScale(d.r))
      .attr("fill", (d) => colorScale(d.highlightValue))
      .attr("stroke", (d) => (selectedValue === d.label ? "#ff0000" : "#fff"))
      .attr("stroke-width", 2)
      .on("click", (event: MouseEvent, d) => {
        event.stopPropagation();
        onSelect(selectedValue === d.label ? null : d.label, name);
      })
      // .on("mouseover", function (event: MouseEvent, d) {
      //   d3.select(this).style("cursor", "pointer");
      //   const formattedText = tooltipFormatter
      //     ? tooltipFormatter({ ...d })
      //     : `Label: ${d.label}, Value: ${d.r}, Highlight: ${d.highlightValue}`;
      //   tooltip.html(formattedText).style("opacity", 1);
      // })

      .on("mouseover", function (event: MouseEvent, d) {
        d3.select(this).style("cursor", "pointer");
        const formattedText = tooltipFormatter
          ? tooltipFormatter(d) // No need to spread d since it's already the node
          : `Label: ${d.label}, Value: ${d.r}, Highlight: ${d.highlightValue}`;
        tooltip.html(formattedText).style("opacity", 1);
      })
      // .on("mousemove", (event: MouseEvent) => {
      //   // Position tooltip below the bubble, similar to Recharts 'nearest' with 'yAlign: bottom'
      //   const circle = d3.select(event.currentTarget);
      //   const radius = parseFloat(circle.attr("r"));
      //   const [x, y] = d3.pointer(event, svg.node());
      //   tooltip
      //     .style("left", `${x + width / 2 + 10}px`) // Offset from bubble center
      //     .style("top", `${y + height / 2 + radius + 10}px`); // Below bubble
      // })

      .on("mousemove", (event: MouseEvent) => {
        const [x, y] = d3.pointer(event, document.body); // Use document.body for global coordinates
        tooltip
          .style("left", `${x + 10}px`) // Offset slightly to the right of the mouse
          .style("top", `${y + 10}px`); // Offset below the mouse
      })
      .on("mouseout", function () {
        d3.select(this).style("cursor", "default");
        tooltip.style("opacity", 0);
      });

    // Labels
    nodes
      .append("text")
      .attr("text-anchor", "middle")
      .attr("dy", ".35em")
      .style("fill", "#fff")
      .style("font-size", "8px")
      .style("pointer-events", "none")
      .each(function (d) {
        const radius = rScale(d.r);
        const label = d.label || "";

        if (radius < 20) return;

        const numLines = radius > 35 ? 2 : 3;
        const maxCharsPerLine = Math.ceil(label.length / numLines);

        const lines: string[] = [];
        for (let i = 0; i < label.length; i += maxCharsPerLine) {
          lines.push(label.substring(i, i + maxCharsPerLine));
        }

        const text = d3.select(this);
        lines.forEach((line, i) => {
          text
            .append("tspan")
            .text(line)
            .attr("x", 0)
            .attr("dy", i === 0 ? 0 : "1.1em");
        });
      });

    // Cleanup tooltip on unmount
    // return () => {
    //   tooltip.remove();
    // };
    return () => {
      d3.select(`#bubble-tooltip-${name}`).remove(); // Remove only this chart's tooltip
    };
  }, [data, selectedValue, onSelect, tooltipFormatter, name]);

  return (
    <Spin spinning={loading} delay={500}>
      <div className="bubble-chart">
        {data && data.length > 0 ? (
          <svg ref={ref} style={{ display: "block" }} />
        ) : null}
      </div>
    </Spin>
  );
};

export default memo(BubbleChart);
