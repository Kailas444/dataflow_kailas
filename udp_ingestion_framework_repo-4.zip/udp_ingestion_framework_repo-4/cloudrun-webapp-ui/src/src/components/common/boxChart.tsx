import React from "react";
import { Card, Row, Col, Spin } from "antd";

export interface BoxData {
  title: string;
  value: string | number;
  subValue?: string | number;
  bgColor?: string;
  titleColor?: string;
  month: string;
}

interface BoxesProps {
  data: BoxData[];
  className?: string;
  selectedValue: any;
  onSelect: (value: string | null) => void;
  loading?: boolean;
}

const Boxes: React.FC<BoxesProps> = ({
  data,
  className,
  selectedValue,
  onSelect,
  loading = false,
}) => {
  console.log("boxchart", data);
  return (
    <Row gutter={[16, 16]}>
      {data.map((item, index) => (
        <Col
          xs={24}
          sm={12}
          md={12}
          lg={12}
          key={index}
          onClick={() => {
            if (selectedValue === item.title) {
              onSelect(null);
            } else {
              onSelect(item.title);
            }
            // onSelect(item.title);
          }}
        >
          <Spin spinning={loading} delay={500}>
            <Card
              bordered
              className={className}
              style={{ borderRadius: 12, backgroundColor: item.bgColor }}
            >
              <p
                style={{
                  fontSize: "10px",
                  fontWeight: "bold",
                  margin: "8px 0",
                  color: item.titleColor,
                }}
              >
                {item.title}
              </p>
              <p
                style={{
                  fontSize: "16px",
                  fontWeight: "bold",
                  margin: "8px 0",
                }}
              >
                {item.value}
              </p>
              {item.subValue && (
                <p style={{ fontSize: "10px", color: "gray", margin: 0 }}>
                  {item.subValue}
                </p>
              )}
            </Card>
          </Spin>
        </Col>
      ))}
    </Row>
  );
};

export default Boxes;
