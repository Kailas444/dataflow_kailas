// StackedBarChart.tsx
import React, { memo } from "react";
// import {
//   Chart as ChartJS,
//   CategoryScale,
//   LinearScale,
//   BarElement,
//   Title,
//   Tooltip,
//   Legend,
// } from "chart.js";
import { Bar } from "react-chartjs-2";
import { Spin } from "antd";

// ChartJS.register(
//   CategoryScale,
//   LinearScale,
//   BarElement,
//   Title,
//   Tooltip,
//   Legend
// );

interface StackedBarChartProps {
  data: { labels: string[]; datasets: any[] };
  title?: string;
  selectedValue: any;
  onSelect: (value: any | null) => void;
  loading?: boolean;
  tooltipFormatter?: (context: any) => string | string[];
}

const StackedBarChart: React.FC<StackedBarChartProps> = ({
  data,
  title,
  selectedValue,
  onSelect,
  loading = false,
  tooltipFormatter,
}) => {
  // Add faded colors logic if needed
  const colors = ["#fc9226", "#2f628c", "#ed6657", "#71b0b2"];
  const fadedColors = ["#DFFDF6", "#FFE3E0", "#F7B5B8", "#C9F5E0"];

  // Apply fade effect if selectedValue exists
  const datasets = data.datasets.map((ds, idx) => ({
    ...ds,
    backgroundColor:
      selectedValue?.stackedBarChart &&
      selectedValue.stackedBarChart !== ds.label
        ? fadedColors[idx]
        : colors[idx],
    barThickness: 8,
    maxBarThickness: 8,
  
  }));

  const chartData = {
    labels: data.labels,
    datasets,
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    resizeDelay: 200,
    plugins: {
      title: {
        display: !!title,
        text: title,
      },
      datalabels: { display: false },
      legend: {
        position: "top" as const,
        labels: {
          usePointStyle: true,
          pointStyle: "circle",
        },
      },
      tooltip: {
        enabled: true,
        backgroundColor: "#fff",
        titleColor: "#000",
        bodyColor: "#000",
        borderColor: "#ddd",
        borderWidth: 1,
        displayColors: false,
        caretSize: 0,
        caretPadding: 0,
        titleFont: {
          size: 12,
          weight: "500",
        },
        bodyFont: {
          size: 12,
          weight: "500",
        },
        cornerRadius: 4,
        callbacks: {
          title: function () {
            return "";
          },
          label: function (context: any) {
             const { dataIndex } = context; 
            console.log("contectdouh", context.dataset?.dataTooltipValue?.[dataIndex], dataIndex);
            if (tooltipFormatter) {
              return tooltipFormatter(context);
            }
            const label = context.label || "";
            const value = context.raw;
            return [`Label: ${label}`, `Value: ${value.toFixed(1)}%`];
          },
        },
      },
    },
    scales: {
      x: {
        stacked: true,
        categoryPercentage: 0.4,
        barPercentage: 0.5,
        grid: {
          display: false,
        },
        ticks: {
          autoSkip: false,
          minRotation: 90,
          maxRotation: 90,
          font: {
            size: 9,
          },
        },
      },
      y: {
        stacked: true,
        beginAtZero: true,
        grid: {
          display: false,
        },
        ticks: {
          callback: function (value: number | string) {
            return value + "%";
          },
        },
      },
    },
    onClick: (_: unknown, elements: any[]) => {
      if (elements?.length > 0) {
        const { datasetIndex , index} = elements[0]; 
        const dsLabel = chartData.datasets[datasetIndex].label;
        const warehouseLabel = chartData.labels[index]
        console.log("stackbar",chartData.labels[index], index, chartData.datasets[datasetIndex])
        // onSelect(label);
        if (selectedValue === dsLabel) {
          onSelect({
            dsLabel: null,
            warehouseLabel: null
          });
        } else {
          onSelect({
            dsLabel: dsLabel,
            warehouseLabel: warehouseLabel,
          });
        }
      }
    },
  };

  return (
    <Spin spinning={loading} delay={500}>
      <Bar data={chartData} options={options} className="stacked-bar-chart" />
    </Spin>
  );
};

export default memo(StackedBarChart);
