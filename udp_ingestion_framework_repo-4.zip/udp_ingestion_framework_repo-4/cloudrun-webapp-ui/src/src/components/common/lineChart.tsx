import React, { memo } from "react";
// import {
//   Chart as ChartJS,
//   LineElement,
//   CategoryScale,
//   LinearScale,
//   PointElement,
//   Tooltip,
//   Legend,
// } from "chart.js";
import { Line } from "react-chartjs-2";
import { Spin } from "antd";
import { formatNumber } from "../../utils/numberFormat";

// ChartJS.register(
//   LineElement,
//   CategoryScale,
//   LinearScale,
//   PointElement,
//   Tooltip,
//   Legend
// );

interface SimpleLineChartProps {
  labels: string[];
  data: any;
  label?: string;
  borderColor?: string;
  loading?: boolean;
}

const SimpleLineChart: React.FC<SimpleLineChartProps> = ({
  labels,
  data,
  label = "Dataset",
  borderColor = "#ECB581",
  loading = false,
}) => {
  const chartData = {
    labels,
    datasets: [
      {
        label,
        data,
        borderColor,
        borderWidth: 2,
        tension: 0.3,
        fill: false,
        pointRadius: 1.5,
        pointHoverRadius: 0,
      },
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    resizeDelay: 200,
    plugins: {
      legend: { display: false },
      tooltip: { enabled: false }, 
      datalabels: {
        backgroundColor: "white", 
        borderRadius: 4,
        color: "black",
        padding: 5,
        font: {
          size: 8,
        },
        align: (context: any) => {
          if (context.dataIndex === 0) return "right"; 
          if (context.dataIndex === context.dataset.data.length - 1) {
            return "left"; 
          } else if (context.dataIndex === context.dataset.data.length - 2) {
            return "left"; 
          }
          return "right";
        },
        anchor: "end",
        formatter: (value: any) => formatNumber(value),
        display: (context: any) => context.active, // ✅ show only on hover
      },
    },
    scales: {
      x: {
        grid: { display: false },
        ticks: {
          autoSkip: false,
          // maxRotation: 0,
          // minRotation: 0,
          font: {
            size: 6,
          },
        },
      },
      y: {
        display: false, // completely hide y-axis
      },
    },
  };

  return (
    <Spin spinning={loading} delay={500}>
      <div style={{ width: "100%", height: "100%" }}>
        <Line data={chartData} options={options} width={600} />
      </div>
    </Spin>
  );
};

export default memo(SimpleLineChart);
