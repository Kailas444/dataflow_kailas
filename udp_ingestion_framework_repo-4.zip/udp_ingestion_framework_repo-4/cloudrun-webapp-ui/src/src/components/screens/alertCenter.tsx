import "../../styles/global.css";
import { ExportOutlined, FundOutlined } from "@ant-design/icons";
import DynamicTable from "../common/table";
import DynamicCard from "../common/card/dynamicCard";
import { Tag, Badge, Tooltip } from "antd";
import type { AppDispatch } from "../../redux/store";
import { useDispatch, useSelector } from "react-redux";
//import { getalertCenterdashboard } from "../../redux/asyncApi/alerCenterApi";
import { useEffect, useState } from "react";
import { getAlertCenterTable } from "../../redux/asyncApi/alertCenter";
import { useNavigate } from "react-router-dom";
import { formatNumberWithCommas } from "../../utils/numberFormat";
import {
  updateBulkFilterSelection,
  updateFilterSelectedOptions,
} from "../../redux/reducers/globalFilter";

const AlertCenter: React.FC<any> = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch<AppDispatch>();
  const {
    alertCenter: {
      alertTableData = {},
      alertTableCount = null,
      alertTableDataLoading = false,
    },
  } = useSelector((state: any) => state);

  const [pageNumber, setPageNumber] = useState(1);
  const [pageSize, setPageSize] = useState(10);

  //   const tableData = [
  //     {
  //       key: 1,
  //       alertid: "A01",
  //       alertcategory: "Aging Risk",
  //       warehousename: "Brattleboro",
  //       summary: "18% SKUs (1,890 SKUs) aged > 120 days with limited sales.",
  //       severity: "High",
  //       impactvalue: "$2,63,00,000",
  //       suggestedaction: "Action 1",
  //     },
  //     {
  //       key: 1,
  //       alertid: "A02",
  //       alertcategory: "Overstock Risk",
  //       warehousename: "Mauldin",
  //       summary: "$8.5M in stock value has > 12 weeks of supply in 4 category. ",
  //       severity: "High",
  //       impactvalue: "$19,00,000",
  //       suggestedaction: "Action 2",
  //     },
  //     {
  //       key: 1,
  //       alertid: "A03",
  //       alertcategory: "Stockout Risk",
  //       warehousename: "Baldwin",
  //       summary: "5% of SKUs droppped to < 2 weeks of supply in 4 category",
  //       severity: "Medium",
  //       impactvalue: "$4,20,000",
  //       suggestedaction: "Action 3",
  //     },
  //     {
  //       key: 1,
  //       alertid: "A04",
  //       alertcategory: "Top seller OOS Risk",
  //       warehousename: "Brattleboro",
  //       summary: "50 top selling SKUs dropped to < 4 weeks of supply",
  //       severity: "Low",
  //       impactvalue: "$10,50,000",
  //       suggestedaction: "Action 4",
  //     },
  //   ];

  const columns = [
    {
      title: "Alert Id",
      dataIndex: "alert_id",
      key: "alert_id",
    },
    {
      title: "Alert Catergory",
      dataIndex: "alert_category",
      key: "alert_category",
    },
    {
      title: "Warehouse Name",
      dataIndex: "warehouseName",
      key: "warehouseName",
    },

    {
      title: "Summary",
      dataIndex: "summary",
      key: "summary",
    },
    {
      title: "Severity",
      dataIndex: "severity",
      key: "severity",
      render: (severity: string) => {
        let color =
          severity === "High"
            ? "#FDD3D0"
            : severity === "medium"
            ? "#FFF1C2"
            : "#CFF7D3";

        let badgeColor =
          severity === "High"
            ? "#EC221F"
            : severity === "medium"
            ? "#E8B931"
            : "#14AE5C";
        return (
          <Tag
            color={color}
            style={{
              display: "flex",
              alignItems: "center",
              gap: 6,
              borderRadius: "999px",
              color: "black",
            }}
          >
            <Badge color={badgeColor} />
            <span>{severity}</span>
          </Tag>
        );
      },
    },
    {
      title: "Impact Value",
      dataIndex: "impact_value",
      key: "impact_value",
      // render: (value: any) => {
      //   return formatNumberWithCommas(value);
      // },
    },
    {
      title: "Suggested Action",
      dataIndex: "suggested_action",
      key: "suggested_action",
    },
    {
      title: "", // No header
      dataIndex: "",
      render: (_, record) => (
        <Tooltip
          color="white"
          arrow={false}
          getPopupContainer={(trigger) => trigger.parentNode as HTMLElement}
          title={
            <span style={{ color: "black", fontSize: 12 }}>
              Go to Manager Insights
            </span>
          }
        >
          <ExportOutlined
            style={{ cursor: "pointer" }}
            onClick={() => {
              navigate("/manager-insights", {
                state: {
                  alertId: record.alert_id,
                  requiredData: {
                    warehouseName: record.warehouseName,
                    itemCode: record.itemCode,
                    itemCategory: record.itemCategory,
                  },
                },
              });
            }}
          />
        </Tooltip>
      ),
      key: "",
    },
    {
      title: "",
      dataIndex: "",
      render: (_, record) => (
        <Tooltip
          color="white"
          arrow={false}
          getPopupContainer={(trigger) => trigger.parentNode as HTMLElement}
          title={
            <span style={{ color: "black", fontSize: 12 }}>
              Go to Inventory Aging
            </span>
          }
        >
          <FundOutlined
            style={{ cursor: "pointer" }}
            onClick={() =>
              navigate("/inventory-aging", {
                state: {
                  alertId: record.alert_id,
                  requiredData: {
                    warehouseName: record.warehouseName,
                    itemCode: record.itemCode,
                    itemCategory: record.itemCategory,
                  },
                },
              })
            }
          />
        </Tooltip>
      ),
      key: "",
    },
  ];

  useEffect(() => {
    dispatch(
      getAlertCenterTable({
        page: pageNumber,
        limit: pageSize,
      })
    );
  }, [pageNumber, pageSize, dispatch]);

  return (
    <DynamicCard
      title=""
      action={null}
      //   headerMarginBottom="0px"
      style={{
        backgroundColor: "white",
        padding: "5px",
      }}
    >
      <div style={{ width: "100%" }}>
        <DynamicTable
          columns={columns}
          data={alertTableData}
          loading={alertTableDataLoading}
          pagination={{
            current: pageNumber,
            pageSize: pageSize,
            total: alertTableCount,
            onChange: (page, size) => {
              setPageNumber(page);
              setPageSize(size);
            },
          }}
        />
      </div>
    </DynamicCard>
  );
};

export default AlertCenter;
