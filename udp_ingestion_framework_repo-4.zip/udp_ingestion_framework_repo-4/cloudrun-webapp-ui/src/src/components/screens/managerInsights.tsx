import React, { useEffect, useState } from "react";
import WarehouseChart from "../common/barWithScatterChart";
import DoughnutChart from "../common/doughnutChart";
import TreemapChart from "../common/treemapChart";
import BubbleChart from "../common/bubbleChart";
import DynamicCard from "../common/card/dynamicCard";
import {
  Alert,
  Button,
  Checkbox,
  Col,
  Input,
  message,
  Modal,
  Row,
  Slider,
  Space,
  Table,
} from "antd";
import SimpleLineChart from "../common/lineChart";
import CardAction from "../common/card/cardAction";
import DynamicFilterDropdown from "../common/dynamicFilterDropdown";
import "../../styles/managerInsights.css";
import DynamicTable from "../common/table";
import { FilterOutlined } from "@ant-design/icons";
import { color } from "chart.js/helpers";
import { useDispatch, useSelector } from "react-redux";
import type { AppDispatch } from "../../redux/store";
import {
  getInventoryDistributionCategory,
  getInventoryDistributionDepartment,
  getInventoryWarehouse,
  getKPICardData,
  getPrivateDistributionQuantity,
  getProductTableData,
} from "../../redux/asyncApi/managerInsightsApi";
import { formatNumber, formatNumberWithCommas } from "../../utils/numberFormat";
import DynamicGranularityTable from "../common/dynamicTable";
import { useLocation } from "react-router-dom";
import { updateBulkFilterSelection } from "../../redux/reducers/globalFilter";

interface TableRecord {
  key: number;
  name: string;
  age: number;
  email: string;
}
interface FilterOption {
  label: string;
  value: string;
}

function ManagerInsights() {
  const location = useLocation();
  const dispatch = useDispatch<AppDispatch>();
  const { alertId, requiredData } = location.state || {};
  const {
    managerInsight: {
      privateDistributionQuantity = [],
      inventoryDistributionDept = [],
      KPICardData = [],
      warehouseChart = [],
      inventoryDistributionCat = [],
      productTable = [],
      warehouseChartLoading = false,
      inventoryDistributionDeptLoading = false,
      privateDistributionQuantityLoading = false,
      KPICardDataLoading = false,
      inventoryDistributionCatLoading = false,
      productTableLoading = false,
      productFirstTableRow = null,
    },
    globalFilters: { filterSelectedOptions = {} },
  } = useSelector((state: any) => state);
  const [graphValues, setGraphValues] = useState<any>({
    // warehouseChart: [
    //   {
    //     labels: "January",
    //     barData: 300,
    //     circleData: 280,
    //   },
    //   {
    //     labels: "February",
    //     barData: 450,
    //     circleData: 470,
    //   },
    //   {
    //     labels: "March",
    //     barData: 460,
    //     circleData: 480,
    //   },
    //   {
    //     labels: "April",
    //     barData: 480,
    //     circleData: 200,
    //   },
    //   {
    //     labels: "May",
    //     barData: 260,
    //     circleData: 180,
    //   },
    // ],
    treemapChart: [
      { category: "Apples", month: "January", value: 30 },
      { category: "Bananas", month: "January", value: 20 },
      { category: "Cherries", month: "February", value: 15 },
      { category: "Dates", month: "February", value: 50 },
      { category: "Elderberries", month: "March", value: 25 },
    ],
    // doughnutChart: [
    //   {
    //     label: "red",
    //     data: 12,
    //     month: "March",
    //   },
    //   {
    //     label: "blue",
    //     data: 10,
    //     month: "February",
    //   },
    // ],
    bubbleChart: [
      { r: 20, label: "January" },
      { r: 18, label: "January" },
      { r: 15, label: "February" },
      { r: 22, label: "February" },
      { r: 17, label: "March" },
      { r: 19, label: "March" },

      { r: 20, label: "January" },
      { r: 18, label: "January" },
      { r: 15, label: "February" },
      { r: 22, label: "February" },
      { r: 17, label: "March" },
      { r: 19, label: "March" },
      { r: 20, label: "January" },
      { r: 18, label: "January" },
      { r: 15, label: "February" },
      { r: 22, label: "February" },
      { r: 17, label: "March" },
      { r: 19, label: "March" },
      { r: 20, label: "January" },
      { r: 18, label: "January" },
      { r: 15, label: "February" },
      { r: 22, label: "February" },
      { r: 17, label: "March" },
      { r: 19, label: "March" },
      { r: 20, label: "January" },
      { r: 18, label: "January" },
      { r: 15, label: "February" },
      { r: 22, label: "February" },
      { r: 17, label: "March" },
      { r: 19, label: "March" },
      { r: 20, label: "January" },
      { r: 18, label: "January" },
      { r: 15, label: "February" },
      { r: 22, label: "February" },
      { r: 17, label: "March" },
      { r: 19, label: "March" },
      { r: 20, label: "January" },
      { r: 18, label: "January" },
      { r: 15, label: "February" },
      { r: 22, label: "February" },
      { r: 17, label: "March" },
      { r: 19, label: "March" },
      { r: 20, label: "January" },
      { r: 18, label: "January" },
      { r: 15, label: "February" },
      { r: 22, label: "February" },
      { r: 17, label: "March" },
      { r: 19, label: "March" },
      { r: 20, label: "January" },
      { r: 18, label: "January" },
      { r: 15, label: "February" },
      { r: 22, label: "February" },
      { r: 17, label: "March" },
      { r: 19, label: "March" },
      { r: 20, label: "January" },
      { r: 18, label: "January" },
      { r: 15, label: "February" },
      { r: 22, label: "February" },
      { r: 17, label: "March" },
      { r: 19, label: "March" },
      { r: 20, label: "January" },
      { r: 18, label: "January" },
      { r: 15, label: "February" },
      { r: 22, label: "February" },
      { r: 17, label: "March" },
      { r: 19, label: "March" },
      { r: 20, label: "January" },
      { r: 18, label: "January" },
      { r: 15, label: "February" },
      { r: 22, label: "February" },
      { r: 17, label: "March" },
      { r: 19, label: "March" },
      { r: 20, label: "January" },
      { r: 18, label: "January" },
      { r: 15, label: "February" },
      { r: 22, label: "February" },
      { r: 17, label: "March" },
      { r: 19, label: "March" },
    ],
    tableData: [
      { key: 1, warehouse: "WestField,MA", prodid: 28, inventoryqty: 4563 },
      { key: 2, warehouse: "Windsor", prodid: 34, inventoryqty: 6743 },
      { key: 3, warehouse: "Lancaster,NY", prodid: 42, inventoryqty: 2467 },
      { key: 4, warehouse: "WestField,MA", prodid: 28, inventoryqty: 4563 },
      { key: 5, warehouse: "Windsor", prodid: 34, inventoryqty: 6743 },
      { key: 6, warehouse: "Lancaster,NY", prodid: 42, inventoryqty: 2467 },
    ],
  });

  const [selectedWarehouseValue, setSelectedWarehouseValue] = useState<any>("");
  const [selectedDeptValue, setSelectedDeptValue] = useState<string | null>(
    null
  );
  const [selectedCategoryValue, setSelectedCategoryValue] = useState<
    string | null
  >(null);
  const [alertVisible, setAlertVisible] = useState(false);

  const [modalVisible, setModalVisible] = useState(false);

  const onCloseModal = () => {
    setModalVisible(false);
  };
  const [selectedFilters, setSelectedFilters] = useState<any>({
    size: "",
    color: "",
  });
  const [
    inventoryDistributionDeptFilters,
    setInventoryDistributionDeptFilters,
  ] = useState<any>({
    size: "inventoryValue",
    color: "inventoryQty",
  });
  const [warehouseSelectedFilters, setWarehouseSelectedFilters] = useState<any>(
    {
      axis: "whseId",
      kpi: "inventoryValue",
      topn: 20,
    }
  );
  // const [defaultTableFilters, setDefaultTableFilters] = useState<any>({
  //   granularity1: "warehouseName",
  //   granularity2: "itemCategory",
  //   measureNames: "",
  // });
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);

  const [checked, setChecked] = useState<boolean>(false);
  const showModal = () => {
    setTempSelection(selectedTableFilters); // preload
    setIsModalOpen(true);
  };
  const handleCancel = () => setIsModalOpen(false);
  const [selectedTableFilters, setSelectedTableFilters] = useState<string[]>(
    []
  );
  const [tempSelection, setTempSelection] = useState<string[]>([]);
  const [filterSelections, setFilterSelections] = useState<
    Record<string, string[]>
  >({});

  const measureOptions = [
    { label: "CD Inventory Value", value: "CD_inventory_value" },
    { label: "CD Inventory Qty", value: "CD_prod_qty" },
    { label: "CD WOH", value: "CD_WOH" },
    { label: "CD OOS Pct", value: "CD_OOS_pct" },
    { label: "CD SKU", value: "CD_sku" },
    { label: "CD Excess SKU", value: "CD_excess_sku" },
    { label: "CD Excess Qty", value: "CD_excess_qty" },
    { label: "CD Exp Prod", value: "CD_exp_prod" },
    { label: "LD Inventory Value", value: "LD_inventory_value" },
    { label: "LD Inventory Value Change", value: "LD_inventory_value_chg" },
    { label: "LD Inventory Qty", value: "LD_prod_qty" },
    { label: "LD Inventory Qty Change", value: "LD_prod_qty_chg" },
    { label: "LD WOH", value: "LD_days_WOH" },
    { label: "LD WOH Change", value: "LD_days_WOH_chg" },
    { label: "LD OOS Pct", value: "LD_OOS_pct" },
    { label: "LD OOS Pct Change", value: "LD_OOS_pct_chg" },
    { label: "LD SKU", value: "LD_sku" },
    { label: "LD SKU Change", value: "LD_sku_chg" },

    { label: "LD Excess SKU", value: "LD_excess_sku" },
    { label: "LD Excess SKU Change", value: "LD_excess_sku_chg" },
    { label: "LD Excess Qty", value: "LD_excess_qty" },
    { label: "LD Excess Qty Change", value: "LD_excess_qty_chg" },

    { label: "LD Exp Prod", value: "LD_exp_prod" },
    { label: "LD Exp Prod Change", value: "LD_exp_prod_chg" },
    { label: "L14D Inventory Value", value: "L14D_inventory_value" },
    {
      label: "L14D Inventory Value Change",
      value: "L14D_inventory_value_chg",
    },
    { label: "L14D Inventory Qty Change", value: "L14D_prod_qty_chg" },
    { label: "L14D Inventory Qty", value: "L14D_prod_qty" },
    { label: "L14D WOH", value: "L14_days_WOH" },
    { label: "L14D WOH Change", value: "L14D_WOH_chg" },
    { label: "L14D OOS Pct", value: "L14D_OOS_PCT" },
    { label: "L14D OOS Pct Change", value: "L14D_OOS_pct_chg" },
    { label: "L14D SKU", value: "L14D_sku" },
    { label: "L14D SKU Change", value: "L14D_sku_chg" },
    { label: "L14D Excess SKU", value: "L14_days_excess_sku" },
    { label: "L14D Excess SKU Change", value: "L14D_excess_sku_chg" },
    { label: "L14D Excess Qty", value: "L14D_excess_qty" },
    { label: "L14D Excess Qty Change", value: "L14D_excess_qty_chg" },
    { label: "L14D Exp Prod", value: "L14D_exp_prod" },
    { label: "L14D Exp Prod Change", value: "L14D_exp_prod_chg" },
  ];

  const defaultMeasureKeys = [
    "CD_inventory_value",
    "CD_prod_qty",
    "CD_WOH",
    "CD_OOS_pct",
    "CD_sku",
    "CD_excess_sku",
    "CD_excess_qty",
    "CD_exp_prod",
  ];

  const [defaultTableFilters, setDefaultTableFilters] = useState({
    granularity1: "warehouseName",
    granularity2: "itemCategory",
    measureNames: measureOptions.filter((opt) =>
      defaultMeasureKeys.includes(opt.value)
    ),
    riskCategory: "",
  });

  if (
    (typeof defaultTableFilters.granularity1 === "string"
      ? defaultTableFilters.granularity1 === "itemCode"
      : defaultTableFilters.granularity1[0] === "itemCode") ||
    (typeof defaultTableFilters.granularity2 === "string"
      ? defaultTableFilters.granularity2 === "itemCode"
      : defaultTableFilters.granularity2[0] === "itemCode")
  ) {
    measureOptions.push({
      label: "CD Age of Inventory",
      value: "CD_age_of_inventory",
    });
    measureOptions.push({
      label: "LD Age of Inventory",
      value: "LD_age_of_inventory",
    });
    measureOptions.push({
      label: "LD Age of Inventory Chg",
      value: "LD_age_of_inventory_chg",
    });
    measureOptions.push({
      label: "L14D Age of Inventory Chg",
      value: "L14D_age_of_inventory_chg",
    });
    measureOptions.push({
      label: "L14D Age of Inventory",
      value: "L14D_age_of_inventory",
    });
  }

  const bubbleTopNOptions = [
    { label: "Top 20", value: 20 },
    { label: "Top 40", value: 40 },
    { label: "Top 60", value: 60 },
    { label: "Top 80", value: 80 },
    { label: "Top 100", value: 100 },
  ];

  const [bubbbleTopN, setBubbleTopN] = useState(100);

  const filterOptions: FilterOption[] = [
    { label: "Sales Flag", value: "salesFlag" },
    { label: "Item Status", value: "itemStatus" },
    { label: "Promotion Flag", value: "promotionFlag" },
    { label: "Forecast Flag", value: "forecastFlag" },
    // { label: "Level of granularity", value: "granularity" },
  ];

  const warehouseKpiOptions = [
    {
      label: "Inventory Value",
      value: "inventoryValue",
    },
    { label: "Inventory Qty", value: "inventoryQty" },
    { label: "WOH", value: "WOH" },
    { label: "Out Of Stock", value: "outOfStock" },
    { label: "Count of SKU", value: "countofSKU" },
    {
      label: "Excess Inventory SKU",
      value: "excessInventorySKU",
    },
    {
      label: "Excess Inventory Qty",
      value: "excessInventoryQty",
    },
  ];

  const warehouseAxisOptions = [
    {
      label: "Organization Code",
      value: "organizationCde",
    },
    { label: "Warehouse Name", value: "whseName" },
    { label: "Warehouse ID", value: "whseId" },
  ];

  const handleCheckboxChange = (value: string, checked: boolean) => {
    if (checked) {
      setTempSelection([...tempSelection, value]);
    } else {
      setTempSelection(tempSelection.filter((item) => item !== value));
    }
  };

  const handleAddFilters = () => {
    setSelectedTableFilters(tempSelection);

    // initialize empty selections for new filters
    const newSelections: Record<string, string[]> = { ...filterSelections };
    tempSelection.forEach((filter) => {
      if (!newSelections[filter]) {
        newSelections[filter] = [];
      }
    });
    setFilterSelections(newSelections);

    setIsModalOpen(false);
  };

  const handleFilterChange = (filter: string, values: string[]) => {
    setFilterSelections({
      ...filterSelections,
      [filter]: values,
    });
  };

  const columns = [
    {
      title: "Warehouse",
      dataIndex: "warehouse",
      key: "warehouse",
    },
    {
      title: "Prod Id",
      dataIndex: "prodid",
      key: "prodid",
    },
    {
      title: "Inventory Qty",
      dataIndex: "inventoryqty",
      key: "inventoryqty",
    },
  ];
  // const handleSelection = (label: any, name: string) => {
  //   const keys = name.split(",");
  //   setSelectedValue({
  //     ...selectedValue,
  //     ...keys.reduce((acc: any, curr: string) => {
  //       acc[curr] = selectedValue[curr] === label ? null : label;

  //       return acc;
  //     }, {}),
  //   });
  // };

  const handleSelection = (value: string | null, name: string) => {
    setSelectedWarehouseValue(value);
  };

  const granularityOptions = [
    {
      label: "Warehouse Name",
      value: "warehouseName",
    },
    { label: "Item Category", value: "itemCategory" },
    { label: "Item Status Code", value: "itemStatusCode" },
    {
      label: "Private Distribution",
      value: "privateDistribution",
    },
    { label: "ssic", value: "ssic" },
    {
      label: "Item Code",
      value: "itemCode",
    },
    {
      label: "Item Description",
      value: "itemDescription",
    },
    {
      label: "Item Department",
      value: "itemDepartment",
    },
    {
      label: "Vendor Name",
      value: "vendorName",
    },
  ];

  const riskCategoryOptions = [
    { label: "Low Risk", value: "Low Risk" },
    { label: "Moderate Risk", value: "Moderate Risk" },
    { label: "High Risk", value: "High Risk" },
    { label: "Expired", value: "Expired" },
  ];

  const handleDeptSelection = (value: string | null) => {
    setSelectedDeptValue(value);
  };

  const handleCategorySelection = (value: string | null) => {
    setSelectedCategoryValue(value);
  };

  const labels = ["25", "26", "27", "28", "29", "30", "31"];
  const values = ["", "", "", 430, "", "", 470];

  const options = [
    { label: "Inventory Qty", value: "Inventory Qty" },
    { label: "Inventory value", value: "Inventory value" },
    { label: "out of stock", value: "out of stock" },
  ];

  const getDoughnutColors = (label: string) => {
    if (label === "Private") return { bgColor: "#fc9226" };
    return {
      bgColor: "#2f628c",
    };
  };

  const formattedPrivateDistributionQuantity = (
    privateDistributionQuantity || []
  ).map((obj: any) => {
    const { bgColor } = getDoughnutColors(obj.label);
    return {
      ...obj,
      bgColor,
    };
  });

  useEffect(() => {
    if (requiredData) {
      dispatch(
        updateBulkFilterSelection({
          ...(requiredData.warehouseName
            ? { warehouseName: [requiredData.warehouseName] }
            : {}),
          ...(requiredData.itemCode ? { itemCode: requiredData.itemCode } : {}),
          ...(requiredData.itemCategory
            ? { itemCategory: requiredData.itemCategory }
            : {}),
        })
      );
    }

    console.log("AlertID:", alertId);
    console.log("Required Data:", requiredData);
  }, [alertId, requiredData, dispatch]);
  // useEffect(() => {
  //   const queryParams = new URLSearchParams(location.search);

  //   const warehouseName = queryParams.get("warehouseName");
  //   const itemCode = queryParams.get("itemCode");
  //   const itemCategory = queryParams.get("itemCategory");

  //   if (warehouseName || itemCode || itemCategory) {
  //     dispatch(
  //       updateBulkFilterSelection({
  //         ...(warehouseName
  //           ? {
  //               warehouseName: warehouseName.split(",").map(decodeURIComponent),
  //             }
  //           : {}),
  //         ...(itemCode
  //           ? { itemCode: itemCode.split(",").map(decodeURIComponent) }
  //           : {}),
  //         ...(itemCategory
  //           ? { itemCategory: itemCategory.split(",").map(decodeURIComponent) }
  //           : {}),
  //       })
  //     );
  //   }

  //   console.log("Queryvalue", warehouseName, itemCode, itemCategory);
  // }, [location.search]);

  useEffect(() => {
    dispatch(getKPICardData());
  }, [filterSelectedOptions]);
  useEffect(() => {
    dispatch(
      getPrivateDistributionQuantity({
        kpiFilter: warehouseSelectedFilters.kpi,
        selectedgraphValue: selectedWarehouseValue
          ? selectedWarehouseValue
          : "",
      })
    );
  }, [
    filterSelectedOptions,
    warehouseSelectedFilters.kpi,
    selectedWarehouseValue,
  ]);

  useEffect(() => {
    dispatch(
      getInventoryWarehouse({
        kpiSelected: warehouseSelectedFilters.kpi,
        xAxisSelected: warehouseSelectedFilters.axis,
      })
    );
  }, [
    filterSelectedOptions,
    warehouseSelectedFilters.kpi,
    warehouseSelectedFilters.axis,
  ]);
  useEffect(() => {
    dispatch(
      getInventoryDistributionDepartment({
        kpiFilter: warehouseSelectedFilters.axis,
        selectedgraphValue: selectedWarehouseValue
          ? selectedWarehouseValue
          : "",
      })
    );
  }, [
    filterSelectedOptions,
    warehouseSelectedFilters.axis,
    selectedWarehouseValue,
  ]);
  useEffect(() => {
    dispatch(
      getInventoryDistributionCategory({
        kpiFilter: warehouseSelectedFilters.axis,
        selectedgraphValue: selectedWarehouseValue
          ? selectedWarehouseValue
          : "",
        selectedDeptValue: selectedDeptValue ? selectedDeptValue : "",
      })
    );
  }, [
    filterSelectedOptions,
    warehouseSelectedFilters.axis,
    selectedWarehouseValue,
    selectedDeptValue,
  ]);

  useEffect(() => {
    dispatch(
      getProductTableData({
        pageNo: 1,
        limit: 20,
        granularity1:
          typeof defaultTableFilters.granularity1 === "string"
            ? defaultTableFilters.granularity1
            : defaultTableFilters.granularity1[0],
        granularity2:
          typeof defaultTableFilters.granularity2 === "string"
            ? defaultTableFilters.granularity2
            : defaultTableFilters.granularity2[0],
        kpiFilter: warehouseSelectedFilters.axis,
        selectedgraphValue: selectedWarehouseValue
          ? selectedWarehouseValue
          : "",
        selectedDeptValue: selectedDeptValue ? selectedDeptValue : "",
        selectedCategoryValue: selectedCategoryValue
          ? selectedCategoryValue
          : "",
        riskCategory: defaultTableFilters.riskCategory
          ? defaultTableFilters.riskCategory
          : "",
      })
    );
  }, [
    defaultTableFilters.granularity1,
    defaultTableFilters.granularity2,
    defaultTableFilters.riskCategory,
    dispatch,
    filterSelectedOptions,
    warehouseSelectedFilters.axis,
    selectedWarehouseValue,
    selectedDeptValue,
    selectedCategoryValue,
  ]);

  console.log(filterSelectedOptions, "filterSelectedOptions");

  const onClose = (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
    setAlertVisible(false);
  };

  const departmentOptions = [
    { label: "Inventory Value", value: "inventoryValue" },
    { label: "Inventory Qty", value: "inventoryQty" },
    { label: "WOH", value: "WOH" },
    { label: "Out Of Stock", value: "outOfStock" },
    { label: "Count of SKU", value: "countofSKU" },
    {
      label: "Excess Inventory SKU",
      value: "excessInventorySKU",
    },
    {
      label: "Excess Inventory Qty",
      value: "excessInventoryQty",
    },
  ];

  const addTooltipKeys = (data: { label: string; value: string }[] = []) => {
    const replacements: Record<string, string> = {
      L14D: "Last 14 Day",
      CD: "Current Day",
      LD: "Last Day",
      WOH: "Week On Hand",
      OOS: "Out Of Stock",
      Qty: "Quantity",
      SKU: "Stock Keeping Unit",
      Pct: "Percentage",
      Exp: "Upcoming Expiry",
      Prod: "Products",
    };

    return data.map(({ label, value }) => {
      let tooltip = label;
      Object.keys(replacements).forEach((key) => {
        if (tooltip.includes(key)) {
          tooltip = tooltip.replaceAll(key, replacements[key]);
        }
      });
      return { label, value, tooltip };
    });
  };

  return (
    <div>
      <div style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
        <div>
          <Space direction="vertical" size={16} style={{ width: "100%" }}>
            <Row gutter={[10, 10]}>
              {KPICardData.map((obj) => {
                console.log("objkpi", obj);
                return (
                  <Col span={6}>
                    <DynamicCard
                      title={obj.title}
                      subtitle={
                        obj.title === "Out of Stock"
                          ? `${formatNumber(
                              Number(Number(obj.value || 0).toFixed(2))
                            )}%`
                          : obj.title === "Total Inventory Value"
                          ? `$${formatNumber(
                              Number(Number(obj.value || 0).toFixed(2))
                            )}`
                          : formatNumber(
                              Number(Number(obj.value || 0).toFixed(2))
                            )
                      }
                      action={
                        <CardAction
                          lastDayValue={Number(
                            Number(obj.ld_value || 0).toFixed(2)
                          )}
                          last14DayValue={Number(
                            Number(obj.l14_value || 0).toFixed(2)
                          )}
                          isDecreaseGood={
                            obj.title === "Out of Stock" ||
                            obj.title === "Excess Inventory SKU" ||
                            obj.title === "Excess Inventory Quantity" ||
                            obj.title === "Upcoming Expiries"
                          }
                        />
                      }
                      style={{ backgroundColor: "white" }}
                    >
                      <div>
                        <SimpleLineChart
                          key="1"
                          labels={obj.x_axis}
                          data={obj.y_axis.map((value) =>
                            Number(value || 0).toFixed(2)
                          )}
                          loading={KPICardDataLoading}
                        />
                      </div>
                    </DynamicCard>
                  </Col>
                );
              })}

              <Col span={16}>
                <DynamicCard
                  title={`${
                    warehouseKpiOptions.find(
                      (o) => o.value === warehouseSelectedFilters.kpi
                    )?.label || warehouseSelectedFilters.kpi
                  } By ${
                    warehouseAxisOptions.find(
                      (o) => o.value === warehouseSelectedFilters.axis
                    )?.label || warehouseSelectedFilters.axis
                  }`}
                  action={
                    <div style={{ display: "flex", gap: "10px" }}>
                      <DynamicFilterDropdown
                        defaultTitle="X-axis"
                        multiple={false}
                        options={warehouseAxisOptions}
                        selectedValues={warehouseSelectedFilters.axis}
                        onChange={(selected) => {
                          console.log("selectedkpi", selected);
                          setWarehouseSelectedFilters({
                            ...warehouseSelectedFilters,
                            axis: selected[0],
                          });
                        }}
                      />
                      <DynamicFilterDropdown
                        defaultTitle="KPI"
                        multiple={false}
                        options={warehouseKpiOptions}
                        selectedValues={warehouseSelectedFilters.kpi}
                        onChange={(selected) =>
                          setWarehouseSelectedFilters({
                            ...warehouseSelectedFilters,
                            kpi: selected[0],
                          })
                        }
                      />
                      <div style={{ display: "flex", flexDirection: "column" }}>
                        <span style={{ fontSize: 12, fontWeight: 600 }}>
                          Top N
                        </span>
                        <Input
                          type="text"
                          value={warehouseSelectedFilters.topn}
                          readOnly // ✅ make it display-only
                          style={{ width: 100 }}
                        />

                        {/* 🔹 Slider controls the input */}
                        <Slider
                          min={1}
                          max={20}
                          value={warehouseSelectedFilters.topn}
                          onChange={(value) =>
                            setWarehouseSelectedFilters((prev) => ({
                              ...prev,
                              topn: value as number, // ✅ sync to state
                            }))
                          }
                          style={{ flex: 1 }}
                          tooltip={{
                            formatter: (val) => `Top ${val}`,
                            overlayInnerStyle: {
                              backgroundColor: "#fff",
                              color: "#000",
                              fontSize: 12,
                              fontWeight: 500,
                              border: "1px solid #ddd",
                              borderRadius: 4,
                            },
                            overlayStyle: { maxWidth: 250 },
                            arrow: false,
                          }}
                        />
                      </div>
                    </div>
                  }
                  style={{ backgroundColor: "white" }}
                >
                  <WarehouseChart
                    name="warehouseChart,doughnutChart,treemapChart,bubbleChart"
                    // data={graphValues.warehouseChart}
                    data={
                      (warehouseChart || [])
                        .slice(0, warehouseSelectedFilters.topn) // limit by topn

                        .map((obj, key) => ({
                          labels: obj[warehouseSelectedFilters.axis],
                          barData: obj[warehouseSelectedFilters.kpi],
                          circleData: obj["l14" + warehouseSelectedFilters.kpi],
                        }))
                      // .sort((a, b) => b.barData - a.barData)
                    }
                    selectedValue={selectedWarehouseValue}
                    onSelect={handleSelection}
                    rotationFilter={
                      warehouseSelectedFilters.axis === "whseName"
                    }
                    xLabel={
                      warehouseAxisOptions.find(
                        (obj) => obj.value === warehouseSelectedFilters.axis
                      )?.label
                    }
                    yLabel={
                      warehouseKpiOptions.find(
                        (obj) => obj.value === warehouseSelectedFilters.kpi
                      )?.label
                    }
                    loading={warehouseChartLoading}
                    tooltipFormatter={(node) => {
                      console.log("nodewarehouse", node);
                      return [
                        `${node.xLabel}: ${node.xValue}`,
                        `${node.yLabel}: ${
                          node.yLabel === "Inventory Value"
                            ? `$${formatNumber(node.yValue)}`
                            : node.yLabel === "Out Of Stock"
                            ? `${formatNumber(node.yValue)}%`
                            : formatNumber(node.yValue)
                        }`,
                        `L14DA ${node.yLabel}: ${
                          node.yLabel === "Inventory Value"
                            ? `$${formatNumber(node.dataset)}`
                            : node.yLabel === "Out Of Stock"
                            ? `${formatNumber(node.dataset)}%`
                            : formatNumber(node.dataset)
                        }`,
                      ];
                    }}
                  />
                </DynamicCard>
              </Col>
              <Col span={8}>
                <DynamicCard
                  title={`Private Label Distribution By Quantity ${
                    selectedWarehouseValue
                      ? ` for ${selectedWarehouseValue}`
                      : ""
                  }`}
                  action={null}
                  style={{ backgroundColor: "white" }}
                >
                  <div
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "center",
                    }}
                  >
                    <DoughnutChart
                      key="doughnut"
                      className="doughnut-chart"
                      name="doughnutChart,treemapChart,bubbleChart"
                      data={formattedPrivateDistributionQuantity}
                      // selectedValue={selectedValue}
                      onSelect={handleSelection}
                      loading={privateDistributionQuantityLoading}
                    />
                  </div>
                </DynamicCard>
              </Col>
              <Col span={14}>
                <DynamicCard
                  title={`Inventory distribution by Department ${
                    selectedWarehouseValue
                      ? ` for ${selectedWarehouseValue}`
                      : ""
                  } ( ${
                    inventoryDistributionDeptFilters.size
                      ? `Size : ${
                          departmentOptions.find(
                            (obj: any) =>
                              obj.value ===
                              inventoryDistributionDeptFilters.size
                          )?.label
                        }`
                      : ""
                  } 
                  ${
                    inventoryDistributionDeptFilters.color
                      ? `Color : ${
                          departmentOptions.find(
                            (obj: any) =>
                              obj.value ===
                              inventoryDistributionDeptFilters.color
                          )?.label
                        }`
                      : ""
                  } )`}
                  action={
                    <div style={{ display: "flex", gap: "10px" }}>
                      <DynamicFilterDropdown
                        defaultTitle="Size"
                        multiple={false}
                        options={departmentOptions}
                        selectedValues={inventoryDistributionDeptFilters.size}
                        onChange={(selected) =>
                          setInventoryDistributionDeptFilters({
                            ...inventoryDistributionDeptFilters,
                            size: selected[0],
                          })
                        }
                      />
                      <DynamicFilterDropdown
                        defaultTitle="Color"
                        multiple={false}
                        options={departmentOptions}
                        selectedValues={inventoryDistributionDeptFilters.color}
                        onChange={(selected) =>
                          setInventoryDistributionDeptFilters({
                            ...inventoryDistributionDeptFilters,
                            color: selected[0],
                          })
                        }
                      />
                    </div>
                  }
                  style={{ backgroundColor: "white" }}
                >
                  <TreemapChart
                    name="treemapChart,bubbleChart"
                    data={inventoryDistributionDept.map((obj) => {
                      return {
                        label: obj.inventoryDescription,
                        value: obj[inventoryDistributionDeptFilters.size],
                        highlightValue:
                          obj[inventoryDistributionDeptFilters.color],
                        sizeLabel: departmentOptions.find(
                          (obj) =>
                            obj.value === inventoryDistributionDeptFilters.size
                        )?.label,

                        colorLabel: departmentOptions.find(
                          (obj) =>
                            obj.value === inventoryDistributionDeptFilters.color
                        )?.label,
                      };
                    })}
                    selectedValue={selectedDeptValue}
                    onSelect={handleDeptSelection}
                    loading={inventoryDistributionDeptLoading}
                    tooltipFormatter={(node) => {
                      const l14sizeKey = `l14${inventoryDistributionDeptFilters.size}Chg`;
                      const l14ColorKey = `l14${inventoryDistributionDeptFilters.color}Chg`;
                      return [
                        `Department: ${node.label}`,
                        `${node.sizeLabel}: ${
                          node.sizeLabel === "Inventory Value"
                            ? `$${formatNumber(
                                node.value,
                                inventoryDistributionDeptFilters.size
                              )}`
                            : formatNumber(
                                node.value,
                                inventoryDistributionDeptFilters.size
                              )
                        }`,
                        `${node.colorLabel}: ${
                          node.colorLabel === "Inventory Value"
                            ? `$${formatNumber(
                                node.highlightValue,
                                inventoryDistributionDeptFilters.color
                              )}`
                            : formatNumber(
                                node.highlightValue,
                                inventoryDistributionDeptFilters.color
                              )
                        }`,
                        `${
                          node.sizeLabel
                        } Vs L14DA : ${inventoryDistributionDept[node._idx]?.[
                          l14sizeKey
                        ]?.toFixed(1)}%`,
                        `${
                          node.colorLabel
                        } Vs L14DA : ${inventoryDistributionDept[node._idx]?.[
                          l14ColorKey
                        ]?.toFixed(1)}%`,
                      ];
                    }}
                  />
                </DynamicCard>
              </Col>
              <Col span={10}>
                <DynamicCard
                  title={`Inventory distribution by Category ${
                    selectedWarehouseValue
                      ? ` for ${selectedWarehouseValue}`
                      : ""
                  } ( ${
                    inventoryDistributionDeptFilters.size
                      ? `Size : ${
                          departmentOptions.find(
                            (obj: any) =>
                              obj.value ===
                              inventoryDistributionDeptFilters.size
                          )?.label
                        }`
                      : ""
                  } 
                  ${
                    inventoryDistributionDeptFilters.color
                      ? `Color : ${
                          departmentOptions.find(
                            (obj: any) =>
                              obj.value ===
                              inventoryDistributionDeptFilters.color
                          )?.label
                        }`
                      : ""
                  } )
                  ${
                    selectedDeptValue ? `Department : ${selectedDeptValue}` : ""
                  }
                  `}
                  action={
                    <DynamicFilterDropdown
                      defaultTitle="Top N"
                      multiple={false}
                      options={bubbleTopNOptions}
                      selectedValues={[bubbbleTopN]} // topN state from useState
                      onChange={(selected) => setBubbleTopN(selected[0])}
                    />
                  }
                  style={{ backgroundColor: "white" }}
                >
                  {/* <BubbleChart
                    name="bubbleChart"
                    data={(inventoryDistributionCat || [])
                      .slice(0, bubbbleTopN)
                      .map((obj, key) => {
                        console.log(obj, "warehouseobj", key);
                        return {
                          label: obj.csItemCategoryDesc,
                          r: obj[inventoryDistributionDeptFilters.size],
                          highlightValue:
                            obj[inventoryDistributionDeptFilters.color],
                          sizeLabel: departmentOptions.find(
                            (obj) =>
                              obj.value ===
                              inventoryDistributionDeptFilters.size
                          )?.label,

                          colorLabel: departmentOptions.find(
                            (obj) =>
                              obj.value ===
                              inventoryDistributionDeptFilters.color
                          )?.label,
                        };
                      })}
                    selectedValue={selectedCategoryValue}
                    onSelect={handleCategorySelection}
                    loading={inventoryDistributionCatLoading}
                    tooltipFormatter={(node) => {
                      const l14sizeKey = `l14${inventoryDistributionDeptFilters.size}Chg`;
                      const l14ColorKey = `l14${inventoryDistributionDeptFilters.color}Chg`;

                      const currentObje =
                        inventoryDistributionCat.find(
                          (obj) =>
                            obj.csItemCategoryDesc ===
                            node.data[node.index].label
                        ) || {};
                      const sizeValue =
                        currentObje?.[inventoryDistributionDeptFilters.size];
                      const l14sizeValue = currentObje?.[l14sizeKey];
                      const l14colorValue = currentObje?.[l14ColorKey];

                      return [
                        `Category: ${node.label}`,
                        `${node.sizeLabel}: ${
                          node.sizeLabel === "Inventory Value"
                            ? `$${formatNumber(
                                sizeValue,
                                inventoryDistributionDeptFilters.size
                              )}`
                            : formatNumber(
                                sizeValue,
                                inventoryDistributionDeptFilters.size
                              )
                        }`,
                        `${node.colorLabel}: ${
                          node.colorLabel === "Inventory Value"
                            ? `$${formatNumber(
                                node.highlightValue,
                                inventoryDistributionDeptFilters.color
                              )}`
                            : formatNumber(
                                node.highlightValue,
                                inventoryDistributionDeptFilters.color
                              )
                        }`,
                        `${node.sizeLabel} Vs L14DA : ${l14sizeValue.toFixed(
                          1
                        )}%`,
                        `${node.colorLabel} Vs L14DA : ${l14colorValue.toFixed(
                          1
                        )}%`,
                      ];
                    }} */}
                  <BubbleChart
                    name="bubbleChart"
                    data={(inventoryDistributionCat || [])
                      .slice(0, bubbbleTopN)
                      .map((obj, key) => {
                        console.log(obj, "warehouseobj", key);
                        return {
                          label: obj.csItemCategoryDesc,
                          r: obj[inventoryDistributionDeptFilters.size],
                          highlightValue:
                            obj[inventoryDistributionDeptFilters.color],
                          sizeLabel: departmentOptions.find(
                            (obj) =>
                              obj.value ===
                              inventoryDistributionDeptFilters.size
                          )?.label,

                          colorLabel: departmentOptions.find(
                            (obj) =>
                              obj.value ===
                              inventoryDistributionDeptFilters.color
                          )?.label,
                        };
                      })}
                    selectedValue={selectedCategoryValue}
                    onSelect={handleCategorySelection}
                    loading={inventoryDistributionCatLoading}
                    // tooltipFormatter={(node) => {
                    //   const l14sizeKey = `l14${inventoryDistributionDeptFilters.size}Chg`;
                    //   const l14ColorKey = `l14${inventoryDistributionDeptFilters.color}Chg`;

                    //   const currentObje =
                    //     inventoryDistributionCat.find(
                    //       (obj) =>
                    //         obj.csItemCategoryDesc ===
                    //         node.data[node.index].label
                    //     ) || {};
                    //   const sizeValue =
                    //     currentObje?.[inventoryDistributionDeptFilters.size];
                    //   const l14sizeValue = currentObje?.[l14sizeKey];
                    //   const l14colorValue = currentObje?.[l14ColorKey];

                    //   return [
                    //     `Category: ${node.label}`,
                    //     `${node.sizeLabel}: ${
                    //       node.sizeLabel === "Inventory Value"
                    //         ? `$${formatNumber(
                    //             sizeValue,
                    //             inventoryDistributionDeptFilters.size
                    //           )}`
                    //         : formatNumber(
                    //             sizeValue,
                    //             inventoryDistributionDeptFilters.size
                    //           )
                    //     }`,
                    //     `${node.colorLabel}: ${
                    //       node.colorLabel === "Inventory Value"
                    //         ? `$${formatNumber(
                    //             node.highlightValue,
                    //             inventoryDistributionDeptFilters.color
                    //           )}`
                    //         : formatNumber(
                    //             node.highlightValue,
                    //             inventoryDistributionDeptFilters.color
                    //           )
                    //     }`,
                    //     `${node.sizeLabel} Vs L14DA : ${l14sizeValue.toFixed(
                    //       1
                    //     )}%`,
                    //     `${node.colorLabel} Vs L14DA : ${l14colorValue.toFixed(
                    //       1
                    //     )}%`,
                    //   ];
                    // }}
                    tooltipFormatter={(node) => {
                      const l14sizeKey = `l14${inventoryDistributionDeptFilters.size}Chg`;
                      const l14ColorKey = `l14${inventoryDistributionDeptFilters.color}Chg`;

                      const currentObje =
                        inventoryDistributionCat.find(
                          (obj) => obj.csItemCategoryDesc === node.label // Fix: Use node.label directly
                        ) || {};
                      const sizeValue =
                        currentObje?.[inventoryDistributionDeptFilters.size];
                      const l14sizeValue = currentObje?.[l14sizeKey];
                      const l14colorValue = currentObje?.[l14ColorKey];

                      return [
                        `Category: ${node.label}`,
                        `${node.sizeLabel}: ${
                          node.sizeLabel === "Inventory Value"
                            ? `$${formatNumber(
                                sizeValue,
                                inventoryDistributionDeptFilters.size
                              )}`
                            : formatNumber(
                                sizeValue,
                                inventoryDistributionDeptFilters.size
                              )
                        }`,
                        `${node.colorLabel}: ${
                          node.colorLabel === "Inventory Value"
                            ? `$${formatNumber(
                                node.highlightValue,
                                inventoryDistributionDeptFilters.color
                              )}`
                            : formatNumber(
                                node.highlightValue,
                                inventoryDistributionDeptFilters.color
                              )
                        }`,
                        `${node.sizeLabel} Vs L14DA: ${l14sizeValue?.toFixed(
                          1
                        )}%`,
                        `${node.colorLabel} Vs L14DA: ${l14colorValue?.toFixed(
                          1
                        )}%`,
                      ].join("<br />"); // Join with <br /> for line breaks in HTML
                    }}
                  />
                </DynamicCard>
              </Col>
            </Row>
          </Space>
        </div>
        <div>
          <Row gutter={[16, 16]}>
            <Col span={24}>
              <DynamicCard
                title={`Inventory Distribution By Product ${
                  selectedWarehouseValue
                    ? ` for ${
                        warehouseAxisOptions.find(
                          (obj) => obj.value === warehouseSelectedFilters.axis
                        )?.label
                      } : ${selectedWarehouseValue}`
                    : ""
                } ${
                  selectedDeptValue ? `Department : ${selectedDeptValue}` : ""
                } ${
                  selectedCategoryValue
                    ? `Category : ${selectedCategoryValue}`
                    : ""
                }`}
                action={
                  <div style={{ display: "flex", gap: "10px" }}>
                    {/* <Button className="border-btn">Download as CSV</Button> */}
                    <Button
                      type="primary"
                      className="filled-btn"
                      onClick={showModal}
                    >
                      <FilterOutlined />
                      Add Filter
                    </Button>
                    <Modal
                      title="Add Filters"
                      centered
                      open={isModalOpen}
                      onCancel={handleCancel}
                      footer={null}
                      width="400px"
                    >
                      <div style={{ display: "flex", flexDirection: "column" }}>
                        {filterOptions.map((filter) => (
                          <Checkbox
                            key={filter.value}
                            checked={tempSelection.includes(filter.value)}
                            onChange={(e) =>
                              handleCheckboxChange(
                                filter.value,
                                e.target.checked
                              )
                            }
                          >
                            {filter.label}
                          </Checkbox>
                        ))}
                      </div>
                      <div style={{ display: "flex", justifyContent: "end" }}>
                        <Button
                          type="primary"
                          className="filled-btn"
                          onClick={handleAddFilters}
                        >
                          Add Selected Filters
                        </Button>
                      </div>
                    </Modal>
                  </div>
                }
                style={{ backgroundColor: "white" }}
              >
                <div
                  style={{
                    width: "100%",
                    display: "flex",
                    flexDirection: "column",
                  }}
                >
                  <div
                    style={{
                      marginTop: "16px",
                      display: "flex",
                      gap: "10px",
                      flexWrap: "wrap",
                    }}
                  >
                    <DynamicFilterDropdown
                      defaultTitle="Granularity1"
                      multiple={false}
                      options={granularityOptions}
                      selectedValues={defaultTableFilters.granularity1}
                      onChange={(selected) =>
                        setDefaultTableFilters({
                          ...defaultTableFilters,
                          granularity1: selected,
                        })
                      }
                    />
                    <DynamicFilterDropdown
                      defaultTitle="Granularity2"
                      multiple={false}
                      options={granularityOptions}
                      selectedValues={defaultTableFilters.granularity2}
                      onChange={(selected) =>
                        setDefaultTableFilters({
                          ...defaultTableFilters,
                          granularity2: selected,
                        })
                      }
                    />

                    <DynamicFilterDropdown
                      defaultTitle="Measure Names"
                      multiple={true}
                      options={measureOptions}
                      selectedValues={defaultTableFilters.measureNames.map(
                        (m) => m.value
                      )}
                      onChange={(selectedValues: string[]) => {
                        if (selectedValues.length > 8) {
                          setModalVisible(true);
                          return;
                        }

                        const selectedMeasures = selectedValues.map(
                          (val) =>
                            measureOptions.find((opt) => opt.value === val) || {
                              label: val,
                              value: val,
                            }
                        );

                        setDefaultTableFilters({
                          ...defaultTableFilters,
                          measureNames: selectedMeasures,
                        });
                      }}
                    />

                    <DynamicFilterDropdown
                      defaultTitle="Risk Category"
                      multiple={true}
                      options={riskCategoryOptions}
                      selectedValues={defaultTableFilters.riskCategory}
                      onChange={(selected) =>
                        setDefaultTableFilters({
                          ...defaultTableFilters,
                          riskCategory: selected,
                        })
                      }
                    />
                    <Modal
                      open={modalVisible}
                      onCancel={onCloseModal}
                      footer={[
                        <Button key="ok" type="primary" onClick={onCloseModal}>
                          OK
                        </Button>,
                      ]}
                      title="Warning"
                    >
                      <Alert
                        message="You can select a maximum of 8 measures. Please unselect and select again."
                        type="warning"
                        showIcon
                      />
                    </Modal>

                    {/* {selectedTableFilters.map((filter) => {
                      const option = filterOptions.find(
                        (f) => f.value === filter
                      );
                      return (
                        <DynamicFilterDropdown
                          key={filter}
                          defaultTitle={option?.label || "Select Option"}
                          options={options} // your dropdown options list
                          selectedValues={filterSelections[filter] || []}
                          onChange={(selected) =>
                            handleFilterChange(filter, selected)
                          }
                        />
                      );
                    })} */}
                  </div>
                  <p style={{ fontSize: "10px" }}>
                    Note* <br />
                    Please select filters from Measure Names to see more columns{" "}
                    <br />
                    CD - Current Day Value <br />
                    LD - Last Day Value <br />
                    L14D - Last 14 Days Average Value
                  </p>
                  <div style={{ marginTop: "10px" }}>
                    <DynamicGranularityTable
                      granularity1={defaultTableFilters.granularity1}
                      granularity1Label={
                        granularityOptions.find((obj) => {
                          const header =
                            typeof defaultTableFilters.granularity1 === "string"
                              ? defaultTableFilters.granularity1
                              : defaultTableFilters.granularity1[0];
                          return obj.value === header;
                        })?.label || "Granularity1"
                      }
                      granularity2={defaultTableFilters.granularity2}
                      granularity2Label={
                        granularityOptions.find((obj) => {
                          const header =
                            typeof defaultTableFilters.granularity2 === "string"
                              ? defaultTableFilters.granularity2
                              : defaultTableFilters.granularity2[0];
                          return obj.value === header;
                        })?.label || "Granularity2"
                      }
                      measureNames={
                        defaultTableFilters.measureNames.length > 0
                          ? addTooltipKeys(defaultTableFilters.measureNames)
                          : []
                      }
                      riskCategory={defaultTableFilters.riskCategory}
                      apiData={productTable.rows}
                      firstRow={productFirstTableRow}
                      totalCount={productTable.count}
                      pageSize={20} // rows per page
                      onPageChange={(page, pageSize) => {
                        dispatch(
                          getProductTableData({
                            pageNo: page,
                            limit: pageSize,
                            granularity1:
                              typeof defaultTableFilters.granularity1 ===
                              "string"
                                ? defaultTableFilters.granularity1
                                : defaultTableFilters.granularity1[0],
                            granularity2:
                              typeof defaultTableFilters.granularity2 ===
                              "string"
                                ? defaultTableFilters.granularity2
                                : defaultTableFilters.granularity2[0],
                            riskCategory: defaultTableFilters.riskCategory,
                            kpiFilter: warehouseSelectedFilters.axis,
                            selectedgraphValue: selectedWarehouseValue
                              ? selectedWarehouseValue
                              : "",
                            selectedDeptValue: selectedDeptValue
                              ? selectedDeptValue
                              : "",
                            selectedCategoryValue: selectedCategoryValue
                              ? selectedCategoryValue
                              : "",
                          })
                        );
                      }}
                      loading={productTableLoading}
                    />
                  </div>
                </div>
              </DynamicCard>
            </Col>
          </Row>
        </div>
      </div>
    </div>
  );
}

export default ManagerInsights;
