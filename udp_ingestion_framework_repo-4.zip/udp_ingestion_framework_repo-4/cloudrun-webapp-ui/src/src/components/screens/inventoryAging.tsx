import { Alert, Button, Col, Modal, Row, Space } from "antd";
import React, { useEffect, useState } from "react";
import DynamicCard from "../common/card/dynamicCard";
import StackedBarChart from "../common/stackedBarChart";
import DynamicBarChart from "../common/barChart";
import DoughnutChart from "../common/doughnutChart";
import Boxes from "../common/boxChart";
import DynamicTable from "../common/table";
import DynamicFilterDropdown from "../common/dynamicFilterDropdown";
import "../../styles/global.css";
import Header from "../layout/header";
import {
  getAgingBucketWarehouseData,
  getAgingInventoryBucket,
  getDaysInStockData,
  getInventoryStatusData,
  getReplenishmentStatusData,
} from "../../redux/asyncApi/inventoryAgingApi";
import { useDispatch, useSelector } from "react-redux";
import type { AppDispatch } from "../../redux/store";
import { formatNumber } from "../../utils/numberFormat";
import { getProductTableData } from "../../redux/asyncApi/managerInsightsApi";
import DynamicGranularityTable from "../common/dynamicTable";
import { useLocation } from "react-router-dom";
import { updateBulkFilterSelection } from "../../redux/reducers/globalFilter";

const InventoryAging: React.FC<any> = () => {
  const location = useLocation();
  const dispatch = useDispatch<AppDispatch>();
  const { alertId, requiredData } = location.state || {};

  const {
    inventoryAging: {
      inventoryStatus = [],
      daysInStock = [],
      replenishmentStatus = [],
      agingBucketWarehouse = [],
      agingInventoryBucket = [],
      agingProductTable = [],
      agingFirstProductRow = null,
      inventoryStatusLoading = false,
      agingInventoryBucketLoading = false,
      agingBucketWarehouseLoading = false,
      daysInStockLoading = false,
      replenishmentStatusLoading = false,
      agingProductTableLoading = false,
    },
    globalFilters: { filterSelectedOptions = {} },
  } = useSelector((state: any) => state);

  const measureOptions = [
    { label: "CD Inventory Value", value: "CD_inventory_value" },
    { label: "CD Inventory Qty", value: "CD_prod_qty" },
    { label: "CD WOH", value: "CD_WOH" },
    { label: "CD OOS Pct", value: "CD_OOS_pct" },
    { label: "CD SKU", value: "CD_sku" },
    { label: "CD Excess SKU", value: "CD_excess_sku" },
    { label: "CD Excess Qty", value: "CD_excess_qty" },
    { label: "CD Exp Prod", value: "CD_exp_prod" },
    { label: "LD Inventory Value", value: "LD_inventory_value" },
    { label: "LD Inventory Value Change", value: "LD_inventory_value_chg" },
    { label: "LD Inventory Qty", value: "LD_prod_qty" },
    { label: "LD Inventory Qty Change", value: "LD_prod_qty_chg" },
    { label: "LD WOH", value: "LD_days_WOH" },
    { label: "LD WOH Change", value: "LD_days_WOH_chg" },
    { label: "LD OOS Pct", value: "LD_OOS_pct" },
    { label: "LD OOS Pct Change", value: "LD_OOS_pct_chg" },
    { label: "LD SKU", value: "LD_sku" },
    { label: "LD SKU Change", value: "LD_sku_chg" },

    { label: "LD Excess SKU", value: "LD_excess_sku" },
    { label: "LD Excess SKU Change", value: "LD_excess_sku_chg" },
    { label: "LD Excess Qty", value: "LD_excess_qty" },
    { label: "LD Excess Qty Change", value: "LD_excess_qty_chg" },

    { label: "LD Exp Prod", value: "LD_exp_prod" },
    { label: "LD Exp Prod Change", value: "LD_exp_prod_chg" },
    { label: "L14D Inventory Value", value: "L14D_inventory_value" },
    {
      label: "L14D Inventory Value Change",
      value: "L14D_inventory_value_chg",
    },
    { label: "L14D Inventory Qty Change", value: "L14D_prod_qty_chg" },
    { label: "L14D Inventory Qty", value: "L14D_prod_qty" },
    { label: "L14D WOH", value: "L14_days_WOH" },
    { label: "L14D WOH Change", value: "L14D_WOH_chg" },
    { label: "L14D OOS Pct", value: "L14D_OOS_PCT" },
    { label: "L14D OOS Pct Change", value: "L14D_OOS_pct_chg" },
    { label: "L14D SKU", value: "L14D_sku" },
    { label: "L14D SKU Change", value: "L14D_sku_chg" },
    { label: "L14D Excess SKU", value: "L14_days_excess_sku" },
    { label: "L14D Excess SKU Change", value: "L14D_excess_sku_chg" },
    { label: "L14D Excess Qty", value: "L14D_excess_qty" },
    { label: "L14D Excess Qty Change", value: "L14D_excess_qty_chg" },
    { label: "L14D Exp Prod", value: "L14D_exp_prod" },
    { label: "L14D Exp Prod Change", value: "L14D_exp_prod_chg" },
  ];

  const riskCategoryOptions = [
    { label: "Low Risk", value: "Low Risk" },
    { label: "Moderate Risk", value: "Moderate Risk" },
    { label: "High Risk", value: "High Risk" },
    { label: "Expired", value: "Expired" },
  ];

  const defaultMeasureKeys = [
    "CD_inventory_value",
    "CD_prod_qty",
    "CD_WOH",
    "CD_OOS_pct",
    "CD_sku",
    "CD_excess_sku",
    "CD_excess_qty",
    "CD_exp_prod",
  ];

  const [defaultTableFilters, setDefaultTableFilters] = useState<any>({
    granularity1: "warehouseName",
    granularity2: "itemCategory",
    measureNames: measureOptions.filter((opt) =>
      defaultMeasureKeys.includes(opt.value)
    ),
    riskCategory: "",
  });
  const [alertVisible, setAlertVisible] = useState(false);
  const [modalVisible, setModalVisible] = useState(false);

  const onCloseModal = () => {
    setModalVisible(false);
  };
  const [graphValues, setGraphValues] = useState<any>({
    // barChart: [
    //   { labels: "Apples", month: "January", value: 30 },
    //   { labels: "Bananas", month: "January", value: 20 },
    //   { labels: "Cherries", month: "February", value: 15 },
    //   { labels: "Dates", month: "February", value: 10 },
    //   { labels: "Elderberries", month: "March", value: 25 },
    // ],
    // barChart2: [
    //   { labels: "Reorder", month: "January", value: 12 },
    //   { labels: "Instock", month: "February", value: 19 },
    // ],
    doughnutChartValue: [
      {
        label: "red",
        data: 12,
        month: "January",
      },
      {
        label: "blue",
        data: 10,
        month: "February",
      },
      {
        label: "red",
        data: 12,
        month: "March",
      },
      {
        label: "blue",
        data: 10,
        month: "April",
      },
    ],
    doughnutChartQty: [
      {
        label: "red",
        data: 12,
        month: "February",
      },
      {
        label: "blue",
        data: 10,
        month: "January",
      },
      {
        label: "red",
        data: 12,
        month: "March",
      },
      {
        label: "blue",
        data: 10,
        month: "April",
      },
    ],
    stackedBarChart: [
      {
        label: "Product A",
        data: [30, 20, 50, 40],
        month: "January",
      },
      {
        label: "Product B",
        data: [40, 30, 20, 50],
        month: "February",
      },
      {
        label: "Product C",
        data: [20, 40, 30, 10],
        month: "March",
      },
      {
        label: "Product D",
        data: [10, 25, 15, 35],
        month: "April",
      },
    ],
    // boxData: [
    //   {
    //     title: "Not At Risk",
    //     value: "$944.4M",
    //     subValue: "267.1K Products",
    //     bgColor: "#EAF6ED",
    //     titleColor: "#24A148",
    //     month: "January",
    //   },
    //   {
    //     title: "Half Life Products",
    //     value: "$85.2M",
    //     subValue: "43.5k Products",
    //     bgColor: "#FDF8E6",
    //     titleColor: "#907209",
    //     month: "February",
    //   },
    //   {
    //     title: "Near Expiry",
    //     value: "$15.7M",
    //     subValue: "11.0K Products",
    //     bgColor: "#FBE8E9",
    //     titleColor: "#E01F29",
    //     month: "March",
    //   },
    //   {
    //     title: "Expired",
    //     value: "$17.0 M",
    //     subValue: "9.4K Products",
    //     bgColor: "#E6E7E8",
    //     titleColor: "#333333",
    //     month: "March",
    //   },
    // ],
    tableData: [
      { key: 1, warehouse: "WestField,MA", prodid: 28, inventoryqty: 4563 },
      { key: 2, warehouse: "Windsor", prodid: 34, inventoryqty: 6743 },
      { key: 3, warehouse: "Lancaster,NY", prodid: 42, inventoryqty: 2467 },
      { key: 4, warehouse: "WestField,MA", prodid: 28, inventoryqty: 4563 },
      { key: 5, warehouse: "Windsor", prodid: 34, inventoryqty: 6743 },
      { key: 6, warehouse: "Lancaster,NY", prodid: 42, inventoryqty: 2467 },
    ],
  });
  const [selectedValue, setSelectedValue] = useState<any>("");
  const [selectedWarehouseValue, setSelectedWarehouseValue] = useState<any>("");
  const [selectedReplenishmentStatus, setSelectedReplenishmentStatus] =
    useState<any>("");
  const [selectedRiskCategory, setSelectedRiskCategory] = useState<any>("");
  const getColors = (index: number, activeColor: boolean) => {
    if (index === 0)
      return !activeColor
        ? { bgColor: "#EAF6ED", titleColor: "#24A148" }
        : { bgColor: "#9ee0aeff", titleColor: "#229e45ff" };
    if (index === 1)
      return !activeColor
        ? { bgColor: "#FDF8E6", titleColor: "#907209" }
        : { bgColor: "#f5db80ff", titleColor: "#b28d08ff" };
    if (index === 2)
      return !activeColor
        ? { bgColor: "#FBE8E9", titleColor: "#E01F29" }
        : { bgColor: "#f8aeb2ff", titleColor: "#f23e47ff" };
    return !activeColor
      ? { bgColor: "#E6E7E8", titleColor: "#333333" }
      : { bgColor: "#afb1b3ff", titleColor: "#2a2929ff" };
  };

  const getDoughnutColors = (label: string) => {
    if (label === "0-30 Days") return { bgColor: "#fc9226" };

    if (label === "31-60 Days")
      return {
        bgColor: "#2f628c",
      };

    if (label === "61-90 Days")
      return {
        bgColor: "#ed6657",
      };

    return {
      bgColor: "#71b0b2",
    };
  };
  const [selectedTableFilters, setSelectedTableFilters] = useState<any>({
    granularity1: "",
    granularity2: "",
    measureNames: "",
  });

  const handleSelection = (value: any | null) => {
    setSelectedValue(value);
  };

  const handleWarehouseSelection = (value: any | null) => {
    setSelectedValue(value.dsLabel);
    setSelectedWarehouseValue(value.warehouseLabel);
  };

  const handleReplenishmentSelection = (value: string | null) => {
    setSelectedReplenishmentStatus(value);
  };

  const handleRiskCategory = (value: string | null) => {
    setSelectedRiskCategory(value);
  };

  const [warehouseSelectedFilters, setWarehouseSelectedFilters] = useState<{
    selected: "Inv_qty_%" | "Inv_value_%";
  }>({
    selected: "Inv_qty_%",
  });

  const columns = [
    {
      title: "Warehouse",
      dataIndex: "warehouse",
      key: "warehouse",
    },
    {
      title: "Prod Id",
      dataIndex: "prodid",
      key: "prodid",
    },
    {
      title: "Inventory Qty",
      dataIndex: "inventoryqty",
      key: "inventoryqty",
    },
  ];

  const options = [
    { label: "Inventory Qty", value: "Inventory Qty" },
    { label: "Inventory value", value: "Inventory value" },
    { label: "out of stock", value: "out of stock" },
  ];

  useEffect(() => {
    if (requiredData) {
      dispatch(
        updateBulkFilterSelection({
          ...(requiredData.warehouseName
            ? { warehouseName: [requiredData.warehouseName] }
            : {}),
          ...(requiredData.itemCode
            ? { itemCode: requiredData.itemCode.map(Number) }
            : {}),
          ...(requiredData.itemCategory
            ? { itemCategory: requiredData.itemCategory }
            : {}),
        })
      );
    }

    console.log("AlertID:", alertId);
    console.log("Required Data:", requiredData);
  }, [alertId, requiredData, dispatch]);

  // useEffect(() => {
  //   const queryParams = new URLSearchParams(location.search);

  //   const warehouseName = queryParams.get("warehouseName");
  //   const itemCode = queryParams.get("itemCode");
  //   const itemCategory = queryParams.get("itemCategory");

  //   if (warehouseName || itemCode || itemCategory) {
  //     dispatch(
  //       updateBulkFilterSelection({
  //         ...(warehouseName
  //           ? {
  //               warehouseName: warehouseName.split(",").map(decodeURIComponent),
  //             }
  //           : {}),
  //         ...(itemCode
  //           ? { itemCode: itemCode.split(",").map(decodeURIComponent) }
  //           : {}),
  //         ...(itemCategory
  //           ? { itemCategory: itemCategory.split(",").map(decodeURIComponent) }
  //           : {}),
  //       })
  //     );
  //   }

  //   console.log("Queryvalue", warehouseName, itemCode, itemCategory);
  // }, [location.search]);

  useEffect(() => {
    dispatch(
      getInventoryStatusData({
        agingBucket: selectedValue ? selectedValue : "",
         extrawarehouseName: selectedWarehouseValue ? selectedWarehouseValue : "",
        replenishmentStatus: selectedReplenishmentStatus
          ? selectedReplenishmentStatus
          : "",
      })
    );
    dispatch(
      getDaysInStockData({
        agingBucket: selectedValue ? selectedValue : "",
         extrawarehouseName: selectedWarehouseValue ? selectedWarehouseValue : "",
        replenishmentStatus: selectedReplenishmentStatus
          ? selectedReplenishmentStatus
          : "",
        riskCategory: selectedRiskCategory ? selectedRiskCategory : "",
      })
    );
    dispatch(
      getReplenishmentStatusData({
        agingBucket: selectedValue ? selectedValue : "",
           extrawarehouseName: selectedWarehouseValue ? selectedWarehouseValue : "",
        replenishmentStatus: selectedReplenishmentStatus
          ? selectedReplenishmentStatus
          : "",
        riskCategory: selectedRiskCategory ? selectedRiskCategory : "",
      })
    );

    dispatch(
      getAgingInventoryBucket({
        agingBucket: selectedValue ? selectedValue : "",
        extrawarehouseName: selectedWarehouseValue ? selectedWarehouseValue : "",
        replenishmentStatus: selectedReplenishmentStatus
          ? selectedReplenishmentStatus
          : "",
        riskCategory: selectedRiskCategory ? selectedRiskCategory : "",
      })
    );
  }, [
    filterSelectedOptions,
    selectedValue,
    selectedReplenishmentStatus,
    selectedRiskCategory,
    selectedWarehouseValue
  ]);

  useEffect(() => {
    dispatch(
      getAgingBucketWarehouseData({
        agingBucket: selectedValue ? selectedValue : "",
        replenishmentStatus: selectedReplenishmentStatus
          ? selectedReplenishmentStatus
          : "",
        riskCategory: selectedRiskCategory ? selectedRiskCategory : "",
      })
    );
  }, [
    filterSelectedOptions,
    selectedValue,
    selectedReplenishmentStatus,
    selectedRiskCategory,
  ]);

  useEffect(() => {
    dispatch(
      getProductTableData({
        pageNo: 1,
        limit: 10,
        granularity1: defaultTableFilters.granularity1,
        granularity2: defaultTableFilters.granularity2,
        agingBucket: selectedValue ? selectedValue : "",
           extrawarehouseName: selectedWarehouseValue ? selectedWarehouseValue : "",
        replenishmentStatus: selectedReplenishmentStatus
          ? selectedReplenishmentStatus
          : "",
        riskCategory: defaultTableFilters.riskCategory,
      })
    );
  }, [
    defaultTableFilters.granularity1,
    defaultTableFilters.granularity2,
    defaultTableFilters.riskCategory,
    dispatch,
    selectedValue,
    selectedReplenishmentStatus,
    selectedRiskCategory,
    selectedWarehouseValue
  ]);

  const warehouseKpiOptions = [
    {
      label: "Inventory Value",
      value: "inventoryValue",
    },
    { label: "Inventory Qty", value: "inventoryQty" },
  ];

  const transformedData = (kpi: "Inv_qty_%" | "Inv_value_%") => {
    if (!agingBucketWarehouse?.length) return { labels: [], datasets: [] };
    const slicedData = agingBucketWarehouse.slice(0, 20);
    console.log("slicedData", slicedData, kpi);
    const labels = slicedData.map((obj: any) => obj.whse_name);
    const kpiFilter = typeof kpi === "string" ? kpi : kpi[0];

    const datasets = [
      {
        label: "0-30 Days",
        data: slicedData.map((obj: any) => obj[`0-30 Days ${kpiFilter}`]),
        dataTooltipValue: slicedData.map(
          (obj: any) => obj[`0-30 Days ${kpiFilter.replace("_%", "")}`]
        ),
        backgroundColor: "#71b0b2",
        barThickness: 20,
        maxBarThickness: 20,
      },
      {
        label: "31-60 Days",
        data: slicedData.map((obj) => obj[`31-60 Days ${kpiFilter}`]),
        dataTooltipValue: slicedData.map(
          (obj) => obj[`31-60 Days ${kpiFilter.replace("_%", "")}`]
        ),
        backgroundColor: "#ed6657",
        barThickness: 20,
        maxBarThickness: 20,
      },
      {
        label: "61-90 Days",
        data: slicedData.map((obj) => obj[`61-90 Days ${kpiFilter}`]),
        dataTooltipValue: slicedData.map(
          (obj) => obj[`61-90 Days ${kpiFilter.replace("_%", "")}`]
        ),
        backgroundColor: "#fc9226",
        barThickness: 20,
        maxBarThickness: 20,
      },
      {
        label: "90+ Days",
        data: slicedData.map((obj) => obj[`90+ Days ${kpiFilter}`]),
        dataTooltipValue: slicedData.map(
          (obj) => obj[`90+ Days ${kpiFilter.replace("_%", "")}`]
        ),
        backgroundColor: "#4a77aa",
        barThickness: 20,
        maxBarThickness: 20,
      },
    ];

    return { labels, datasets };
  };

  const getAgeColor = (range: string) => {
    const [start, end] = range.split("-").map(Number);
    const age = end;
    if (age >= 0 && age <= 30) return "#fc9226";
    if (age >= 31 && age <= 60) return "#2f628c";
    if (age >= 61 && age <= 90) return "#ed6657";
    return "#71b0b2";
  };

  // transform data for the chart
  const chartData = (daysInStock || []).map((obj) => ({
    labels: obj.weightedInventoryAge, // keep API label
    value: obj.inventoryQty,
    color: getAgeColor(obj.weightedInventoryAge), // assign color only
  }));

  console.log("selectedValue", selectedValue);

  const granularityOptions = [
    {
      label: "Warehouse Name",
      value: "warehouseName",
    },
    { label: "Item Category", value: "itemCategory" },
    { label: "Item Status Code", value: "itemStatusCode" },
    {
      label: "Private Distribution",
      value: "privateDistribution",
    },
    { label: "ssic", value: "ssic" },
    {
      label: "Item Code",
      value: "itemCode",
    },
    {
      label: "Item Description",
      value: "itemDescription",
    },
    {
      label: "Item Department",
      value: "itemDepartment",
    },
    {
      label: "Vendor Name",
      value: "vendorName",
    },
  ];

  const inventoryWarehouseOptions = [
    { label: "Inventory Quantity", value: "Inv_qty_%" },
    { label: "Inventory Value", value: "Inv_value_%" },
  ];

  const addTooltipKeys = (data: { label: string; value: string }[] = []) => {
    const replacements: Record<string, string> = {
      L14D: "Last 14 Day",
      CD: "Current Day",
      LD: "Last Day",
      WOH: "Week On Hand",
      OOS: "Out Of Stock",
      Qty: "Quantity",
      SKU: "Stock Keeping Unit",
      Pct: "Percentage",
      Exp: "Upcoming Expiry",
      Prod: "Products",
    };

    return data.map(({ label, value }) => {
      let tooltip = label;
      Object.keys(replacements).forEach((key) => {
        if (tooltip.includes(key)) {
          tooltip = tooltip.replaceAll(key, replacements[key]);
        }
      });
      return { label, value, tooltip };
    });
  };

  // Data for both doughnut charts (all aging buckets)

  const doughnutChartData = (agingInventoryBucket || []).map((obj) => {
    const { bgColor } = getDoughnutColors(obj.agingBucket);
    return {
      label: obj.agingBucket,
      data: obj.pctInvValueCD.toFixed(1),
      bgColor,
      invQtyCD: obj.invQtyCD,
      invValueCD: obj.invValueCD,
    };
  });

  const doughnutChartQtyData = (agingInventoryBucket || []).map((obj) => {
    const { bgColor } = getDoughnutColors(obj.agingBucket);
    return {
      label: obj.agingBucket,
      data: obj.pctInvQtyCD.toFixed(1),
      bgColor,
      invQtyCD: obj.invQtyCD,
      invValueCD: obj.invValueCD,
    };
  });

  return (
    <div>
      <div style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
        <div>
          <Space direction="vertical" size={16} style={{ width: "100%" }}>
            <Row gutter={[10, 10]}>
              <Col span={12}>
                <DynamicCard
                  title=""
                  action={null}
                  style={{ backgroundColor: "white" }}
                >
                  <div
                    style={{
                      display: "flex",
                      alignItems: "start",
                    }}
                  >
                    <div style={{ flex: 1 }}>
                      <p
                        style={{
                          fontSize: 14,
                          fontWeight: 700,
                          margin: 0,
                        }}
                      >
                        Inventory value by Aging Bucket
                      </p>
                      <DoughnutChart
                        key="doughnutChartValue"
                        className="doughnut-chart2"
                        // data={(agingInventoryBucket || []).map((obj, key) => {
                        //   const { bgColor } = getDoughnutColors(
                        //     obj.agingBucket
                        //   );
                        //   return {
                        //     label: obj.agingBucket,
                        //     data: obj.pctInvValueCD.toFixed(1),
                        //     bgColor,
                        //   };
                        // })}
                        data={doughnutChartData}
                        selectedValue={selectedValue}
                        onSelect={handleSelection}
                        loading={agingInventoryBucketLoading}
                        legendLabels={["0-30 Days", "31-60 Days"]}
                        tooltipFormatter={(context) => [
                          `Aging Bucket: ${context.label}`,
                          `Inventory Value : $${formatNumber(
                            context.invValueCD
                          )}`,
                          `Inventory Value Percentage: ${context.raw}%`,
                        ]}
                      />
                    </div>
                    <div style={{ flex: 1 }}>
                      <p
                        style={{
                          fontSize: 14,
                          fontWeight: 700,
                          margin: 0,
                        }}
                      >
                        Inventory Qty by Aging Bucket
                      </p>
                      <DoughnutChart
                        key="doughnutChartQty"
                        className="doughnut-chart2"
                        // data={(agingInventoryBucket || []).map((obj, key) => {
                        //   const { bgColor } = getDoughnutColors(
                        //     obj.agingBucket
                        //   );
                        //   return {
                        //     label: obj.agingBucket,
                        //     data: obj.pctInvQtyCD.toFixed(1),
                        //     bgColor,
                        //   };
                        // })}
                        data={doughnutChartQtyData}
                        selectedValue={selectedValue}
                        onSelect={handleSelection}
                        loading={agingInventoryBucketLoading}
                        legendLabels={["61-90 Days", "90+ Days"]}
                        tooltipFormatter={(context) => {
                          console.log(
                            "contextdough",
                            context,
                            agingInventoryBucket,
                            agingInventoryBucket.invValueCD
                          );
                          return [
                            `Aging Bucket: ${context.label}`,
                            `Inventory Qty : ${formatNumber(context.invQtyCD)}`,
                            `Inventory Qty Percentage: ${context.raw}%`,
                          ];
                        }}
                        //  showLegend={false}
                      />
                    </div>
                  </div>
                </DynamicCard>
              </Col>
              <Col span={12}>
                <DynamicCard
                  title="Aging Bucket By Warehouse name"
                  action={
                    <DynamicFilterDropdown
                      defaultTitle="KPI"
                      multiple={false}
                      options={inventoryWarehouseOptions}
                      selectedValues={warehouseSelectedFilters.selected}
                      onChange={(selected) =>
                        setWarehouseSelectedFilters({ selected })
                      }
                    />
                  }
                  style={{ backgroundColor: "white" }}
                >
                  <StackedBarChart
                    title=""
                    // data={graphValues.stackedBarChart}
                    data={transformedData(warehouseSelectedFilters.selected)}
                    selectedValue={selectedValue}
                    onSelect={handleWarehouseSelection}
                    loading={agingBucketWarehouseLoading}
                    tooltipFormatter={(context) => {
                      console.log("contexttreemapp", context);

                      const warehouseSelectedFiltersSelected =
                        typeof warehouseSelectedFilters.selected === "string"
                          ? warehouseSelectedFilters.selected
                          : warehouseSelectedFilters.selected[0];

                      return [
                        `Aging Bucket: ${context.dataset.label}`,
                        `Warehouse Name : ${context.label}`,
                        `${
                          inventoryWarehouseOptions.find(
                            (obj) =>
                              obj.value === warehouseSelectedFiltersSelected
                          )?.label
                        }: ${
                          inventoryWarehouseOptions.find(
                            (obj) =>
                              obj.value === warehouseSelectedFiltersSelected
                          )?.label === "Inventory Value"
                            ? `$${formatNumber(
                                context.dataset.dataTooltipValue[
                                  context.dataIndex
                                ]
                              )}`
                            : formatNumber(
                                context.dataset.dataTooltipValue[
                                  context.dataIndex
                                ]
                              )
                        }`,
                        `${
                          inventoryWarehouseOptions.find(
                            (obj) =>
                              obj.value === warehouseSelectedFiltersSelected
                          )?.label + "(Percent Of Total)"
                        }: ${context.raw.toFixed(1)}%`,
                      ];
                    }}
                  />
                </DynamicCard>
              </Col>
              <Col span={12}>
                <DynamicCard
                  title="Days in Stock"
                  action={null}
                  style={{ backgroundColor: "white" }}
                >
                  <DynamicBarChart
                    data={chartData}
                    selectedValue={selectedValue}
                    onSelect={handleSelection}
                    barColor="#DB2032"
                    fadedColor="#DB203266"
                    className="bar-chart"
                    tooltipFormatter={(context) => [
                      `Age of Inventory: ${context.label}`,
                      `Inventory: ${context.raw}`,
                    ]}
                    loading={daysInStockLoading}
                    xAxisRotation={90}
                    xAxisFontSize={12}
                    yAxisFontSize={12}
                  />
                </DynamicCard>
              </Col>
              <Col span={6}>
                <DynamicCard
                  title="Replenishment Status"
                  action={null}
                  style={{ backgroundColor: "white" }}
                >
                  <DynamicBarChart
                    data={(replenishmentStatus || []).map((obj, key) => ({
                      labels: obj.Replenishment_Status,
                      value: obj.count,
                    }))}
                    selectedValue={selectedReplenishmentStatus}
                    onSelect={handleReplenishmentSelection}
                    barColor="#DB2032"
                    fadedColor="#DB203266"
                    barThickness={40}
                    className="bar-chart2"
                    loading={replenishmentStatusLoading}
                  />
                </DynamicCard>
              </Col>
              <Col span={6}>
                <DynamicCard
                  title="Aging Inventory Status"
                  action={null}
                  style={{ backgroundColor: "white" , height:"320px"}}
                >
                  <Boxes
                    data={(inventoryStatus || []).map((obj, index) => {
                      const activeColor =
                        selectedRiskCategory === obj.riskCategory;
                      const { bgColor, titleColor } = getColors(
                        index,
                        activeColor
                      );
                      return {
                        title: obj.riskCategory,
                        value: formatNumber(obj.inventoryValue),
                        subValue: formatNumber(obj.inventoryQty) + " Products",
                        bgColor,
                        titleColor,
                      };
                    })}
                    selectedValue={selectedRiskCategory}
                    onSelect={handleRiskCategory}
                    className="box-chart"
                    loading={inventoryStatusLoading}
                  />
                </DynamicCard>
              </Col>
              <Col span={24}>
                <DynamicCard
                  title="Detailed Analysis by Product"
                  action={null}
                  style={{ backgroundColor: "white" }}
                >
                  <div
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      width: "100%",
                    }}
                  >
                    <div style={{ display: "flex", gap: "10px" }}>
                      <DynamicFilterDropdown
                        defaultTitle="Granularity1"
                        multiple={false}
                        options={granularityOptions}
                        selectedValues={defaultTableFilters.granularity1}
                        onChange={(selected) =>
                          setDefaultTableFilters({
                            ...defaultTableFilters,
                            granularity1: selected,
                          })
                        }
                      />
                      <DynamicFilterDropdown
                        defaultTitle="Granularity2"
                        multiple={false}
                        options={granularityOptions}
                        selectedValues={defaultTableFilters.granularity2}
                        onChange={(selected) =>
                          setDefaultTableFilters({
                            ...defaultTableFilters,
                            granularity2: selected,
                          })
                        }
                      />

                      <DynamicFilterDropdown
                        defaultTitle="Measure Names"
                        multiple={true}
                        options={measureOptions}
                        selectedValues={defaultTableFilters.measureNames.map(
                          (m) => m.value
                        )}
                        onChange={(selectedValues: string[]) => {
                          if (selectedValues.length > 8) {
                            setModalVisible(true);
                            return;
                          }

                          const selectedMeasures = selectedValues.map(
                            (val) =>
                              measureOptions.find(
                                (opt) => opt.value === val
                              ) || {
                                label: val,
                                value: val,
                              }
                          );

                          setDefaultTableFilters({
                            ...defaultTableFilters,
                            measureNames: selectedMeasures,
                          });
                        }}
                      />

                      <DynamicFilterDropdown
                        defaultTitle="Risk Category"
                        multiple={true}
                        options={riskCategoryOptions}
                        selectedValues={defaultTableFilters.riskCategory}
                        onChange={(selected) =>
                          setDefaultTableFilters({
                            ...defaultTableFilters,
                            riskCategory: selected,
                          })
                        }
                      />
                      <Modal
                        open={modalVisible}
                        onCancel={onCloseModal}
                        footer={[
                          <Button
                            key="ok"
                            type="primary"
                            onClick={onCloseModal}
                          >
                            OK
                          </Button>,
                        ]}
                        title="Warning"
                      >
                        <Alert
                          message="You can select a maximum of 8 measures. Please unselect and select again."
                          type="warning"
                          showIcon
                        />
                      </Modal>
                    </div>

                    <p style={{ fontSize: "10px" }}>
                      Note* <br />
                      Please select filters from Measure Names to see more
                      columns <br />
                      CD - Current Day Value <br />
                      LD - Last Day Value <br />
                      L14D - Last 14 Days Average Value
                    </p>
                    <div style={{ marginTop: "10px" }}>
                      <DynamicGranularityTable
                        granularity1={defaultTableFilters.granularity1}
                        granularity1Label={
                          granularityOptions.find((obj) => {
                            const header =
                              typeof defaultTableFilters.granularity1 ===
                              "string"
                                ? defaultTableFilters.granularity1
                                : defaultTableFilters.granularity1[0];
                            return obj.value === header;
                          })?.label || "Granularity1"
                        }
                        granularity2={defaultTableFilters.granularity2}
                        granularity2Label={
                          granularityOptions.find((obj) => {
                            const header =
                              typeof defaultTableFilters.granularity2 ===
                              "string"
                                ? defaultTableFilters.granularity2
                                : defaultTableFilters.granularity2[0];
                            return obj.value === header;
                          })?.label || "Granularity2"
                        }
                        measureNames={
                          defaultTableFilters.measureNames.length > 0
                            ? addTooltipKeys(defaultTableFilters.measureNames)
                            : []
                        }
                        riskCategory={defaultTableFilters.riskCategory}
                        apiData={agingProductTable.rows}
                        firstRow={agingFirstProductRow}
                        totalCount={agingProductTable.count}
                        loading={agingProductTableLoading}
                        pageSize={10} // rows per page
                        onPageChange={(page, pageSize) => {
                          dispatch(
                            getProductTableData({
                              pageNo: page,
                              limit: pageSize,
                              granularity1: defaultTableFilters.granularity1,
                              granularity2: defaultTableFilters.granularity2,
                              agingBucket: selectedValue ? selectedValue : "",
                              replenishmentStatus: selectedReplenishmentStatus
                                ? selectedReplenishmentStatus
                                : "",
                              riskCategory: defaultTableFilters.riskCategory,
                            })
                          );
                        }}
                        // loading={productTableLoading}
                      />
                    </div>
                  </div>
                </DynamicCard>
              </Col>
            </Row>
          </Space>
        </div>
      </div>
    </div>
  );
};

export default InventoryAging;
