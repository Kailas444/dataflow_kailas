import React from "react";

// const App: React.FC = () => {
function App() {
  return (
    <div
      style={{
        width: "100vw",
        height: "100vh",
        display: "flex",
        position: "relative",
      }}
    >
      {/* Left half */}
      <div style={{ flex: 1, backgroundColor: "white" }} />

      {/* Right half */}
      <div style={{ flex: 1, backgroundColor: "orange" }} />

      {/* Center box */}
      <div
        style={{
          position: "absolute",
          top: "50%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          backgroundColor: "black",
          color: "white",
          borderRadius: "8px",
          width:"85%",
          height:"500px"
        }}
      >
        <div>Text One</div>
        <div>Text Two</div>
      </div>
    </div>
  );
};

export default App;
