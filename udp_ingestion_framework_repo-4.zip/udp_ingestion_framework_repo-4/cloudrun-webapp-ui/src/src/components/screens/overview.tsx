import React, { useEffect, useState } from "react";
import WarehouseChart from "../common/barWithScatterChart";
import DoughnutChart from "../common/doughnutChart";
import TreemapChart from "../common/treemapChart";
import BubbleChart from "../common/bubbleChart";
import DynamicCard from "../common/card/dynamicCard";
import "../../styles/overview.css";
import {
  Alert,
  Button,
  Card,
  Checkbox,
  Col,
  Input,
  message,
  Modal,
  Row,
  Slider,
  Space,
  Spin,
  Table,
  Tooltip,
} from "antd";
import SimpleLineChart from "../common/lineChart";
import CardAction from "../common/card/cardAction";
import DynamicFilterDropdown from "../common/dynamicFilterDropdown";
import "../../styles/managerInsights.css";
import DynamicTable from "../common/table";
import { FilterOutlined, InfoCircleOutlined } from "@ant-design/icons";
import { color } from "chart.js/helpers";
import { useDispatch, useSelector } from "react-redux";
import type { AppDispatch } from "../../redux/store";
import {
  getInventoryDistributionCategory,
  getInventoryDistributionDepartment,
  getInventoryWarehouse,
  getKPICardData,
  getPrivateDistributionQuantity,
  getProductTableData,
} from "../../redux/asyncApi/managerInsightsApi";
import { formatNumber, formatNumberWithCommas } from "../../utils/numberFormat";
import DynamicGranularityTable from "../common/dynamicTable";
import { Link } from "react-router-dom";
import { getAlertCenterTable } from "../../redux/asyncApi/alertCenter";

interface TableRecord {
  key: number;
  name: string;
  age: number;
  email: string;
}
interface FilterOption {
  label: string;
  value: string;
}

function Overview() {
  const dispatch = useDispatch<AppDispatch>();
  const {
    managerInsight: {
      privateDistributionQuantity = [],
      inventoryDistributionDept = [],
      KPICardData = [],
      warehouseChart = [],
      inventoryDistributionCat = [],
      productTable = [],
      warehouseChartLoading = false,
      inventoryDistributionDeptLoading = false,
      privateDistributionQuantityLoading = false,
      KPICardDataLoading = false,
      inventoryDistributionCatLoading = false,
      productTableLoading = false,
    },
    globalFilters: { filterSelectedOptions = {} },
    alertCenter: { alertTableData = [], alertTableDataLoading = false },
  } = useSelector((state: any) => state);

  const [selectedWarehouseValue, setSelectedWarehouseValue] = useState<any>("");
  const [selectedDeptValue, setSelectedDeptValue] = useState<string | null>(
    null
  );
  const [selectedCategoryValue, setSelectedCategoryValue] = useState<
    string | null
  >(null);
  const [alertVisible, setAlertVisible] = useState(false);

  const [modalVisible, setModalVisible] = useState(false);

  const onCloseModal = () => {
    setModalVisible(false);
  };
  const [selectedFilters, setSelectedFilters] = useState<any>({
    size: "",
    color: "",
  });
  const [
    inventoryDistributionDeptFilters,
    setInventoryDistributionDeptFilters,
  ] = useState<any>({
    size: "inventoryValue",
    color: "inventoryQty",
  });
  const [warehouseSelectedFilters, setWarehouseSelectedFilters] = useState<any>(
    {
      axis: "whseId",
      kpi: "inventoryValue",
      topn: 20,
    }
  );

  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [checked, setChecked] = useState<boolean>(false);
  const showModal = () => {
    setTempSelection(selectedTableFilters); // preload
    setIsModalOpen(true);
  };
  const handleCancel = () => setIsModalOpen(false);
  const [selectedTableFilters, setSelectedTableFilters] = useState<string[]>(
    []
  );
  const [tempSelection, setTempSelection] = useState<string[]>([]);
  const [filterSelections, setFilterSelections] = useState<
    Record<string, string[]>
  >({});

  const measureOptions = [
    { label: "CD Inventory Value", value: "CD_inventory_value" },
    { label: "CD Inventory Qty", value: "CD_prod_qty" },
    { label: "CD WOH", value: "CD_WOH" },
    { label: "CD OOS Pct", value: "CD_OOS_pct" },
    { label: "CD SKU", value: "CD_sku" },
    { label: "CD Excess SKU", value: "CD_excess_sku" },
    { label: "CD Excess Qty", value: "CD_excess_qty" },
    { label: "CD Exp Prod", value: "CD_exp_prod" },
    { label: "LD Inventory Value", value: "LD_inventory_value" },
    { label: "LD Inventory Value Change", value: "LD_inventory_value_chg" },
    { label: "LD Inventory Qty", value: "LD_prod_qty" },
    { label: "LD Inventory Qty Change", value: "LD_prod_qty_chg" },
    { label: "LD WOH", value: "LD_days_WOH" },
    { label: "LD WOH Change", value: "LD_days_WOH_chg" },
    { label: "LD OOS Pct", value: "LD_OOS_pct" },
    { label: "LD OOS Pct Change", value: "LD_OOS_pct_chg" },
    { label: "LD SKU", value: "LD_sku" },
    { label: "LD SKU Change", value: "LD_sku_chg" },

    { label: "LD Excess SKU", value: "LD_excess_sku" },
    { label: "LD Excess SKU Change", value: "LD_excess_sku_chg" },
    { label: "LD Excess Qty", value: "LD_excess_qty" },
    { label: "LD Excess Qty Change", value: "LD_excess_qty_chg" },

    { label: "LD Exp Prod", value: "LD_exp_prod" },
    { label: "LD Exp Prod Change", value: "LD_exp_prod_chg" },
    { label: "L14D Inventory Value", value: "L14D_inventory_value" },
    {
      label: "L14D Inventory Value Change",
      value: "L14D_inventory_value_chg",
    },
    { label: "L14D Inventory Qty Change", value: "L14D_prod_qty_chg" },
    { label: "L14D Inventory Qty", value: "L14D_prod_qty" },
    { label: "L14D WOH", value: "L14_days_WOH" },
    { label: "L14D WOH Change", value: "L14D_WOH_chg" },
    { label: "L14D OOS Pct", value: "L14D_OOS_PCT" },
    { label: "L14D OOS Pct Change", value: "L14D_OOS_pct_chg" },
    { label: "L14D SKU", value: "L14D_sku" },
    { label: "L14D SKU Change", value: "L14D_sku_chg" },
    { label: "L14D Excess SKU", value: "L14_days_excess_sku" },
    { label: "L14D Excess SKU Change", value: "L14D_excess_sku_chg" },
    { label: "L14D Excess Qty", value: "L14D_excess_qty" },
    { label: "L14D Excess Qty Change", value: "L14D_excess_qty_chg" },
    { label: "L14D Exp Prod", value: "L14D_exp_prod" },
    { label: "L14D Exp Prod Change", value: "L14D_exp_prod_chg" },
  ];

  const defaultMeasureKeys = [
    "CD_inventory_value",
    "CD_prod_qty",
    "CD_WOH",
    "CD_OOS_pct",
    "CD_sku",
    "CD_excess_sku",
    "CD_excess_qty",
    "CD_exp_prod",
  ];

  const [defaultTableFilters, setDefaultTableFilters] = useState({
    granularity1: "warehouseName",
    granularity2: "itemCategory",
    measureNames: measureOptions.filter((opt) =>
      defaultMeasureKeys.includes(opt.value)
    ),
    riskCategory: "",
  });

  if (
    (typeof defaultTableFilters.granularity1 === "string"
      ? defaultTableFilters.granularity1 === "itemCode"
      : defaultTableFilters.granularity1[0] === "itemCode") ||
    (typeof defaultTableFilters.granularity2 === "string"
      ? defaultTableFilters.granularity2 === "itemCode"
      : defaultTableFilters.granularity2[0] === "itemCode")
  ) {
    measureOptions.push({
      label: "CD Age of Inventory",
      value: "CD_age_of_inventory",
    });
    measureOptions.push({
      label: "LD Age of Inventory",
      value: "LD_age_of_inventory",
    });
    measureOptions.push({
      label: "LD Age of Inventory Chg",
      value: "LD_age_of_inventory_chg",
    });
    measureOptions.push({
      label: "L14D Age of Inventory Chg",
      value: "L14D_age_of_inventory_chg",
    });
    measureOptions.push({
      label: "L14D Age of Inventory",
      value: "L14D_age_of_inventory",
    });
  }

  const bubbleTopNOptions = [
    { label: "Top 20", value: 20 },
    { label: "Top 40", value: 40 },
    { label: "Top 60", value: 60 },
    { label: "Top 80", value: 80 },
    { label: "Top 100", value: 100 },
  ];

  const [bubbbleTopN, setBubbleTopN] = useState(100);

  const filterOptions: FilterOption[] = [
    { label: "Sales Flag", value: "salesFlag" },
    { label: "Item Status", value: "itemStatus" },
    { label: "Promotion Flag", value: "promotionFlag" },
    { label: "Forecast Flag", value: "forecastFlag" },
    { label: "Level of granularity", value: "granularity" },
  ];

  const warehouseKpiOptions = [
    {
      label: "Inventory Value",
      value: "inventoryValue",
    },
    { label: "Inventory Qty", value: "inventoryQty" },
    { label: "WOH", value: "WOH" },
    { label: "Out Of Stock", value: "outOfStock" },
    { label: "Count of SKU", value: "countofSKU" },
    {
      label: "Excess Inventory SKU",
      value: "excessInventorySKU",
    },
    {
      label: "Excess Inventory Qty",
      value: "excessInventoryQty",
    },
  ];

  const warehouseAxisOptions = [
    {
      label: "Organization Code",
      value: "organizationCde",
    },
    { label: "Warehouse Name", value: "whseName" },
    { label: "Warehouse ID", value: "whseId" },
  ];

  const handleCheckboxChange = (value: string, checked: boolean) => {
    if (checked) {
      setTempSelection([...tempSelection, value]);
    } else {
      setTempSelection(tempSelection.filter((item) => item !== value));
    }
  };

  const handleAddFilters = () => {
    setSelectedTableFilters(tempSelection);

    // initialize empty selections for new filters
    const newSelections: Record<string, string[]> = { ...filterSelections };
    tempSelection.forEach((filter) => {
      if (!newSelections[filter]) {
        newSelections[filter] = [];
      }
    });
    setFilterSelections(newSelections);

    setIsModalOpen(false);
  };

  const handleSelection = (value: string | null, name: string) => {
    setSelectedWarehouseValue(value);
  };

  const labels = ["25", "26", "27", "28", "29", "30", "31"];
  const values = ["", "", "", 430, "", "", 470];

  const options = [
    { label: "Inventory Qty", value: "Inventory Qty" },
    { label: "Inventory value", value: "Inventory value" },
    { label: "out of stock", value: "out of stock" },
  ];

  useEffect(() => {
    dispatch(
      getAlertCenterTable({
        // page: pageNumber,
        // limit: pageSize,
      })
    );
  }, [dispatch]);

  useEffect(() => {
    dispatch(getKPICardData());
  }, [filterSelectedOptions]);

  useEffect(() => {
    dispatch(
      getInventoryWarehouse({
        kpiSelected: warehouseSelectedFilters.kpi,
        xAxisSelected: warehouseSelectedFilters.axis,
      })
    );
  }, [
    filterSelectedOptions,
    warehouseSelectedFilters.kpi,
    warehouseSelectedFilters.axis,
  ]);

  return (
    <div>
      <div style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
        <div>
          <Space direction="vertical" size={16} style={{ width: "100%" }}>
            <Row gutter={[10, 10]}>
              {KPICardData.map((obj) => {
                console.log("objkpi", obj);
                return (
                  <Col span={6}>
                    <DynamicCard
                      title={obj.title}
                      subtitle={
                        obj.title === "Out of Stock"
                          ? `${formatNumber(
                              Number(Number(obj.value || 0).toFixed(2))
                            )}%`
                          : obj.title === "Total Inventory Value"
                          ? `$${formatNumber(
                              Number(Number(obj.value || 0).toFixed(2))
                            )}`
                          : formatNumber(
                              Number(Number(obj.value || 0).toFixed(2))
                            )
                      }
                      action={
                        <CardAction
                          lastDayValue={Number(
                            Number(obj.ld_value || 0).toFixed(2)
                          )}
                          last14DayValue={Number(
                            Number(obj.l14_value || 0).toFixed(2)
                          )}
                          isDecreaseGood={
                            obj.title === "Out of Stock" ||
                            obj.title === "Excess Inventory SKU" ||
                            obj.title === "Excess Inventory Quantity" ||
                            obj.title === "Upcoming Expiries"
                          }
                        />
                      }
                      style={{ backgroundColor: "white" }}
                    >
                      <div>
                        <SimpleLineChart
                          key="1"
                          labels={obj.x_axis}
                          data={obj.y_axis.map((value) =>
                            Number(value || 0).toFixed(2)
                          )}
                          loading={KPICardDataLoading}
                        />
                      </div>
                    </DynamicCard>
                  </Col>
                );
              })}

              <Col span={16}>
                <DynamicCard
                  title={`${
                    warehouseKpiOptions.find(
                      (o) => o.value === warehouseSelectedFilters.kpi
                    )?.label || warehouseSelectedFilters.kpi
                  } By ${
                    warehouseAxisOptions.find(
                      (o) => o.value === warehouseSelectedFilters.axis
                    )?.label || warehouseSelectedFilters.axis
                  }`}
                  action={
                    <div style={{ display: "flex", gap: "10px" }}>
                      <DynamicFilterDropdown
                        defaultTitle="X-axis"
                        multiple={false}
                        options={warehouseAxisOptions}
                        selectedValues={warehouseSelectedFilters.axis}
                        onChange={(selected) => {
                          console.log("selectedkpi", selected);
                          setWarehouseSelectedFilters({
                            ...warehouseSelectedFilters,
                            axis: selected[0],
                          });
                        }}
                      />
                      <DynamicFilterDropdown
                        defaultTitle="KPI"
                        multiple={false}
                        options={warehouseKpiOptions}
                        selectedValues={warehouseSelectedFilters.kpi}
                        onChange={(selected) =>
                          setWarehouseSelectedFilters({
                            ...warehouseSelectedFilters,
                            kpi: selected[0],
                          })
                        }
                      />
                      <div style={{ display: "flex", flexDirection: "column" }}>
                        <span style={{ fontSize: 12, fontWeight: 600 }}>
                          Top N
                        </span>
                        <Input
                          type="text"
                          value={warehouseSelectedFilters.topn}
                          readOnly // ✅ make it display-only
                          style={{ width: 100 }}
                        />

                        {/* 🔹 Slider controls the input */}
                        <Slider
                          min={1}
                          max={20}
                          value={warehouseSelectedFilters.topn}
                          onChange={(value) =>
                            setWarehouseSelectedFilters((prev) => ({
                              ...prev,
                              topn: value as number, // ✅ sync to state
                            }))
                          }
                          style={{ flex: 1 }}
                          tooltip={{
                            formatter: (val) => `Top ${val}`,
                            overlayInnerStyle: {
                              backgroundColor: "#fff",
                              color: "#000",
                              fontSize: 12,
                              fontWeight: 500,
                              border: "1px solid #ddd",
                              borderRadius: 4,
                            },
                            overlayStyle: { maxWidth: 250 },
                            arrow: false,
                          }}
                        />
                      </div>
                    </div>
                  }
                  style={{ backgroundColor: "white" }}
                >
                  <WarehouseChart
                    data={
                      (warehouseChart || [])
                        .slice(0, warehouseSelectedFilters.topn) // limit by topn

                        .map((obj, key) => ({
                          labels: obj[warehouseSelectedFilters.axis],
                          barData: obj[warehouseSelectedFilters.kpi],
                          circleData: obj["l14" + warehouseSelectedFilters.kpi],
                        }))
                      // .sort((a, b) => b.barData - a.barData)
                    }
                    className="overview-warehouse-chart"
                    selectedValue={selectedWarehouseValue}
                    onSelect={handleSelection}
                    rotationFilter={
                      warehouseSelectedFilters.axis === "whseName"
                    }
                    xLabel={
                      warehouseAxisOptions.find(
                        (obj) => obj.value === warehouseSelectedFilters.axis
                      )?.label
                    }
                    yLabel={
                      warehouseKpiOptions.find(
                        (obj) => obj.value === warehouseSelectedFilters.kpi
                      )?.label
                    }
                    loading={warehouseChartLoading}
                    tooltipFormatter={(node) => [
                      `${node.xLabel}: ${node.xValue}`,
                      `${node.yLabel}: ${formatNumber(node.yValue)}`,
                      `L14D % Change: ${formatNumber(node.dataset.toFixed(1))}`,
                    ]}
                  />
                </DynamicCard>
              </Col>
              <Col span={8}>
                <DynamicCard
                  title="Top Alerts"
                  action={
                    <Link
                      to="/alert-center"
                      style={{
                        textDecoration: "underline",
                        color: "black",
                        fontSize: "10px",
                      }}
                    >
                      View all alerts
                    </Link>
                  }
                  style={{ backgroundColor: "white" }}
                >
                  <Spin spinning={alertTableDataLoading}>
                    <div
                      style={{
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "center",
                        gap: "10px",
                      }}
                    >
                      {alertTableData.slice(0, 3).map((item: any) => (
                        <Card key={item.id} className="alert-cards">
                          <div style={{ display: "flex", padding: "5px" }}>
                            <InfoCircleOutlined
                              style={{ color: "#1890ff", fontSize: "24px" }}
                            />
                            <p>{item.summary}</p>
                          </div>
                        </Card>
                      ))}
                    </div>
                  </Spin>
                </DynamicCard>
              </Col>
            </Row>
          </Space>
        </div>
      </div>
    </div>
  );
}

export default Overview;
