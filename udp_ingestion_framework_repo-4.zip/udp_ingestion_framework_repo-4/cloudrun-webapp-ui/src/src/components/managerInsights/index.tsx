// import React, { useEffect, useState } from "react";
// import WarehouseChart from "../common/barWithScatterChart";
// import DoughnutChart from "../common/doughnutChart";
// import TreemapChart from "../common/treemapChart";
// import BubbleChart from "../common/bubbleChart";
// import DynamicCard from "../common/card/dynamicCard";
// import {
//   Button,
//   Checkbox,
//   Col,
//   Input,
//   Modal,
//   Row,
//   Slider,
//   Space,
//   Table,
// } from "antd";
// import SimpleLineChart from "../common/lineChart";
// import CardAction from "../common/card/cardAction";
// import DynamicFilterDropdown from "../common/dynamicFilterDropdown";
// import "../../styles/managerInsights.css";
// import DynamicTable from "../common/table";
// import { FilterOutlined } from "@ant-design/icons";
// import { color } from "chart.js/helpers";
// import { useDispatch, useSelector } from "react-redux";
// import type { AppDispatch } from "../../redux/store";
// import {
//   getInventoryDistributionCategory,
//   getInventoryDistributionDepartment,
//   getInventoryWarehouse,
//   getKPICardData,
//   getPrivateDistributionQuantity,
//   getProductTableData,
// } from "../../redux/asyncApi/managerInsightsApi";
// import { formatNumber } from "../../utils/numberFormat";
// import DynamicGranularityTable from "../common/dynamicTable";

// interface TableRecord {
//   key: number;
//   name: string;
//   age: number;
//   email: string;
// }
// interface FilterOption {
//   label: string;
//   value: string;
// }

// function ManagerInsights() {
//   const dispatch = useDispatch<AppDispatch>();
//   const {
//     managerInsight: {
//       privateDistributionQuantity = [],
//       inventoryDistributionDept = [],
//       KPICardData = [],
//       warehouseChart = [],
//       inventoryDistributionCat = [],
//       productTable = [],
//     },
//     globalFilters: { filterSelectedOptions = {} },
//   } = useSelector((state: any) => state);
//   const [graphValues, setGraphValues] = useState<any>({
//     // warehouseChart: [
//     //   {
//     //     labels: "January",
//     //     barData: 300,
//     //     circleData: 280,
//     //   },
//     //   {
//     //     labels: "February",
//     //     barData: 450,
//     //     circleData: 470,
//     //   },
//     //   {
//     //     labels: "March",
//     //     barData: 460,
//     //     circleData: 480,
//     //   },
//     //   {
//     //     labels: "April",
//     //     barData: 480,
//     //     circleData: 200,
//     //   },
//     //   {
//     //     labels: "May",
//     //     barData: 260,
//     //     circleData: 180,
//     //   },
//     // ],
//     treemapChart: [
//       { category: "Apples", month: "January", value: 30 },
//       { category: "Bananas", month: "January", value: 20 },
//       { category: "Cherries", month: "February", value: 15 },
//       { category: "Dates", month: "February", value: 50 },
//       { category: "Elderberries", month: "March", value: 25 },
//     ],
//     // doughnutChart: [
//     //   {
//     //     label: "red",
//     //     data: 12,
//     //     month: "March",
//     //   },
//     //   {
//     //     label: "blue",
//     //     data: 10,
//     //     month: "February",
//     //   },
//     // ],
//     bubbleChart: [
//       { r: 20, label: "January" },
//       { r: 18, label: "January" },
//       { r: 15, label: "February" },
//       { r: 22, label: "February" },
//       { r: 17, label: "March" },
//       { r: 19, label: "March" },

//       { r: 20, label: "January" },
//       { r: 18, label: "January" },
//       { r: 15, label: "February" },
//       { r: 22, label: "February" },
//       { r: 17, label: "March" },
//       { r: 19, label: "March" },
//       { r: 20, label: "January" },
//       { r: 18, label: "January" },
//       { r: 15, label: "February" },
//       { r: 22, label: "February" },
//       { r: 17, label: "March" },
//       { r: 19, label: "March" },
//       { r: 20, label: "January" },
//       { r: 18, label: "January" },
//       { r: 15, label: "February" },
//       { r: 22, label: "February" },
//       { r: 17, label: "March" },
//       { r: 19, label: "March" },
//       { r: 20, label: "January" },
//       { r: 18, label: "January" },
//       { r: 15, label: "February" },
//       { r: 22, label: "February" },
//       { r: 17, label: "March" },
//       { r: 19, label: "March" },
//       { r: 20, label: "January" },
//       { r: 18, label: "January" },
//       { r: 15, label: "February" },
//       { r: 22, label: "February" },
//       { r: 17, label: "March" },
//       { r: 19, label: "March" },
//       { r: 20, label: "January" },
//       { r: 18, label: "January" },
//       { r: 15, label: "February" },
//       { r: 22, label: "February" },
//       { r: 17, label: "March" },
//       { r: 19, label: "March" },
//       { r: 20, label: "January" },
//       { r: 18, label: "January" },
//       { r: 15, label: "February" },
//       { r: 22, label: "February" },
//       { r: 17, label: "March" },
//       { r: 19, label: "March" },
//       { r: 20, label: "January" },
//       { r: 18, label: "January" },
//       { r: 15, label: "February" },
//       { r: 22, label: "February" },
//       { r: 17, label: "March" },
//       { r: 19, label: "March" },
//       { r: 20, label: "January" },
//       { r: 18, label: "January" },
//       { r: 15, label: "February" },
//       { r: 22, label: "February" },
//       { r: 17, label: "March" },
//       { r: 19, label: "March" },
//       { r: 20, label: "January" },
//       { r: 18, label: "January" },
//       { r: 15, label: "February" },
//       { r: 22, label: "February" },
//       { r: 17, label: "March" },
//       { r: 19, label: "March" },
//       { r: 20, label: "January" },
//       { r: 18, label: "January" },
//       { r: 15, label: "February" },
//       { r: 22, label: "February" },
//       { r: 17, label: "March" },
//       { r: 19, label: "March" },
//       { r: 20, label: "January" },
//       { r: 18, label: "January" },
//       { r: 15, label: "February" },
//       { r: 22, label: "February" },
//       { r: 17, label: "March" },
//       { r: 19, label: "March" },
//     ],
//     tableData: [
//       { key: 1, warehouse: "WestField,MA", prodid: 28, inventoryqty: 4563 },
//       { key: 2, warehouse: "Windsor", prodid: 34, inventoryqty: 6743 },
//       { key: 3, warehouse: "Lancaster,NY", prodid: 42, inventoryqty: 2467 },
//       { key: 4, warehouse: "WestField,MA", prodid: 28, inventoryqty: 4563 },
//       { key: 5, warehouse: "Windsor", prodid: 34, inventoryqty: 6743 },
//       { key: 6, warehouse: "Lancaster,NY", prodid: 42, inventoryqty: 2467 },
//     ],
//   });

//   const [selectedValue, setSelectedValue] = useState<any>({});
//   const [selectedFilters, setSelectedFilters] = useState<any>({
//     size: "",
//     color: "",
//   });
//   const [
//     inventoryDistributionDeptFilters,
//     setInventoryDistributionDeptFilters,
//   ] = useState<any>({
//     size: "inventoryValue",
//     color: "WOH",
//   });
//   const [warehouseSelectedFilters, setWarehouseSelectedFilters] = useState<any>(
//     {
//       axis: "whseId",
//       kpi: "inventoryValue",
//       topn: 20,
//     }
//   );
//   const [defaultTableFilters, setDefaultTableFilters] = useState<any>({
//     granularity1: "warehouseName",
//     granularity2: "itemCategory",
//     measureNames: "",
//   });
//   const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
//   const [checked, setChecked] = useState<boolean>(false);
//   const showModal = () => {
//     setTempSelection(selectedTableFilters); // preload
//     setIsModalOpen(true);
//   };
//   const handleCancel = () => setIsModalOpen(false);
//   const [selectedTableFilters, setSelectedTableFilters] = useState<string[]>(
//     []
//   );
//   const [tempSelection, setTempSelection] = useState<string[]>([]);
//   const [filterSelections, setFilterSelections] = useState<
//     Record<string, string[]>
//   >({});

//   const measureOptions = [
//     { label: "CD Inventory Value", value: "CD_inventory_value" },
//     { label: "LD Inventory Value", value: "LD_inventory_value" },
//     { label: "CD Prod Qty", value: "CD_prod_qty" },
//   ];

//   const filterOptions: FilterOption[] = [
//     { label: "Sales Flag", value: "salesFlag" },
//     { label: "Item Status", value: "itemStatus" },
//     { label: "Promotion Flag", value: "promotionFlag" },
//     { label: "Forecast Flag", value: "forecastFlag" },
//     { label: "Level of granularity", value: "granularity" },
//   ];

//   const warehouseKpiOptions = [
//     {
//       label: "Inventory Value",
//       value: "inventoryValue",
//     },
//     { label: "Inventory Qty", value: "inventoryQty" },
//     { label: "WOH", value: "WOH" },
//     { label: "Out Of Stock", value: "outOfStock" },
//     { label: "Count of SKU", value: "countofSKU" },
//     {
//       label: "Excess Inventory SKU",
//       value: "excessInventorySKU",
//     },
//     {
//       label: "Excess Inventory Qty",
//       value: "excessInventoryQty",
//     },
//   ];

//   const warehouseAxisOptions = [
//     {
//       label: "Organization Code",
//       value: "organizationCde",
//     },
//     { label: "Warehouse Name", value: "whseName" },
//     { label: "Warehouse ID", value: "whseId" },
//   ];

//   const handleCheckboxChange = (value: string, checked: boolean) => {
//     if (checked) {
//       setTempSelection([...tempSelection, value]);
//     } else {
//       setTempSelection(tempSelection.filter((item) => item !== value));
//     }
//   };

//   const handleAddFilters = () => {
//     setSelectedTableFilters(tempSelection);

//     // initialize empty selections for new filters
//     const newSelections: Record<string, string[]> = { ...filterSelections };
//     tempSelection.forEach((filter) => {
//       if (!newSelections[filter]) {
//         newSelections[filter] = [];
//       }
//     });
//     setFilterSelections(newSelections);

//     setIsModalOpen(false);
//   };

//   const handleFilterChange = (filter: string, values: string[]) => {
//     setFilterSelections({
//       ...filterSelections,
//       [filter]: values,
//     });
//   };

//   const columns = [
//     {
//       title: "Warehouse",
//       dataIndex: "warehouse",
//       key: "warehouse",
//     },
//     {
//       title: "Prod Id",
//       dataIndex: "prodid",
//       key: "prodid",
//     },
//     {
//       title: "Inventory Qty",
//       dataIndex: "inventoryqty",
//       key: "inventoryqty",
//     },
//   ];
//   const handleSelection = (label: any, name: string) => {
//     const keys = name.split(",");
//     setSelectedValue({
//       ...selectedValue,
//       ...keys.reduce((acc: any, curr: string) => {
//         acc[curr] = selectedValue[curr] === label ? null : label;

//         return acc;
//       }, {}),
//     });
//   };

//   const labels = ["25", "26", "27", "28", "29", "30", "31"];
//   const values = ["", "", "", 430, "", "", 470];

//   const options = [
//     { label: "Inventory Qty", value: "Inventory Qty" },
//     { label: "Inventory value", value: "Inventory value" },
//     { label: "out of stock", value: "out of stock" },
//   ];

//   useEffect(() => {
//     dispatch(getPrivateDistributionQuantity());
//   }, [filterSelectedOptions]);

//   useEffect(() => {
//     dispatch(getKPICardData());
//   }, [filterSelectedOptions]);
//   useEffect(() => {
//     dispatch(getInventoryWarehouse());
//   }, [filterSelectedOptions]);
//   useEffect(() => {
//     dispatch(getInventoryDistributionDepartment());
//   }, [filterSelectedOptions]);
//   useEffect(() => {
//     dispatch(getInventoryDistributionCategory());
//   }, [filterSelectedOptions]);

//   useEffect(() => {
//     dispatch(
//       getProductTableData({
//         pageNo: 1,
//         limit: 10,
//         granularity1: defaultTableFilters.granularity1,
//         granularity2: defaultTableFilters.granularity2,
//       })
//     );
//   }, [
//     defaultTableFilters.granularity1,
//     defaultTableFilters.granularity2,
//     dispatch,
//     filterSelectedOptions,
//   ]);

//   const handleTopNChange = (value: number) => {
//     setWarehouseSelectedFilters((prev) => ({
//       ...prev,
//       topn: value,
//     }));
//   };

//   // 🔹 Sync value when input changes manually
//   const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
//     const val = Number(e.target.value) || 0;
//     setWarehouseSelectedFilters((prev) => ({
//       ...prev,
//       topn: val,
//     }));
//   };

//   console.log(filterSelectedOptions, "filterSelectedOptions");

//   return (
//     <div>
//       <div style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
//         <div>
//           <Space direction="vertical" size={16} style={{ width: "100%" }}>
//             <Row gutter={[10, 10]}>
//               {KPICardData.map((obj) => {
//                 console.log("objkpi", obj);
//                 return (
//                   <Col span={6}>
//                     <DynamicCard
//                       title={obj.title}
//                       subtitle={
//                         obj.title === "Out of Stock"
//                           ? `${formatNumber(
//                               Number(Number(obj.value || 0).toFixed(2))
//                             )}%`
//                           : formatNumber(
//                               Number(Number(obj.value || 0).toFixed(2))
//                             )
//                       }
//                       action={
//                         <CardAction
//                           lastDayValue={Number(
//                             Number(obj.ld_value || 0).toFixed(2)
//                           )}
//                           last14DayValue={Number(
//                             Number(obj.l14_value || 0).toFixed(2)
//                           )}
//                         />
//                       }
//                       style={{ backgroundColor: "white" }}
//                     >
//                       <div>
//                         <SimpleLineChart
//                           key="1"
//                           labels={obj.x_axis}
//                           data={obj.y_axis.map((value) =>
//                             Number(value || 0).toFixed(2)
//                           )}
//                         />
//                       </div>
//                     </DynamicCard>
//                   </Col>
//                 );
//               })}

//               <Col span={16}>
//                 <DynamicCard
//                   title="Inventory value by Warehouse"
//                   action={
//                     <div style={{ display: "flex", gap: "10px" }}>
//                       <DynamicFilterDropdown
//                         defaultTitle="X-axis"
//                         multiple={false}
//                         options={warehouseAxisOptions}
//                         selectedValues={warehouseSelectedFilters.axis}
//                         onChange={(selected) => {
//                           console.log("selectedkpi", selected);
//                           setWarehouseSelectedFilters({
//                             ...warehouseSelectedFilters,
//                             axis: selected[0],
//                           });
//                         }}
//                       />
//                       <DynamicFilterDropdown
//                         defaultTitle="KPI"
//                         multiple={false}
//                         options={warehouseKpiOptions}
//                         selectedValues={warehouseSelectedFilters.kpi}
//                         onChange={(selected) =>
//                           setWarehouseSelectedFilters({
//                             ...warehouseSelectedFilters,
//                             kpi: selected[0],
//                           })
//                         }
//                       />
//                       <div
//                         style={{
//                           display: "flex",
//                           alignItems: "center",
//                           gap: "16px",
//                           marginBottom: "20px",
//                         }}
//                       >
//                         <Input
//                           type="number"
//                           value={warehouseSelectedFilters.topn}
//                           onChange={handleInputChange}
//                           style={{ width: 100 }}
//                         />

//                         {/* 🔹 Slider controls the input */}
//                         <Slider
//                           min={1}
//                           max={100}
//                           value={warehouseSelectedFilters.topn}
//                           onChange={handleTopNChange}
//                           style={{ flex: 1 }}
//                         />
//                       </div>
//                     </div>
//                   }
//                   style={{ backgroundColor: "white" }}
//                 >
//                   <WarehouseChart
//                     name="warehouseChart,doughnutChart,treemapChart,bubbleChart"
//                     // data={graphValues.warehouseChart}
//                     data={(warehouseChart || [])
//                       .slice(0, warehouseSelectedFilters.topn) // limit by topn
//                       .map((obj, key) => ({
//                         labels: obj[warehouseSelectedFilters.axis],
//                         barData: obj[warehouseSelectedFilters.kpi],
//                         circleData: obj["l14" + warehouseSelectedFilters.kpi],
//                       }))}
//                     selectedValue={selectedValue}
//                     onSelect={handleSelection}
//                     xLabel={
//                       warehouseAxisOptions.find(
//                         (obj) => obj.value === warehouseSelectedFilters.axis
//                       )?.label
//                     }
//                     yLabel={
//                       warehouseKpiOptions.find(
//                         (obj) => obj.value === warehouseSelectedFilters.kpi
//                       )?.label
//                     }
//                   />
//                 </DynamicCard>
//               </Col>
//               <Col span={8}>
//                 <DynamicCard
//                   title="Private Label Distribution By Quantity "
//                   action={null}
//                   style={{ backgroundColor: "white" }}
//                 >
//                   <div
//                     style={{
//                       display: "flex",
//                       flexDirection: "column",
//                       alignItems: "center",
//                     }}
//                   >
//                     <DoughnutChart
//                       key="doughnut"
//                       className="doughnut-chart"
//                       name="doughnutChart,treemapChart,bubbleChart"
//                       data={privateDistributionQuantity}
//                       selectedValue={selectedValue}
//                       onSelect={handleSelection}
//                       backgroundColor={["#E01F29", "#32D181"]}
//                     />
//                   </div>
//                 </DynamicCard>
//               </Col>
//               <Col span={14}>
//                 <DynamicCard
//                   title={`Inventory distribution by Department ${
//                     selectedValue.warehouseChart
//                       ? ` for ${selectedValue.warehouseChart}`
//                       : ""
//                   } ${
//                     selectedFilters.size ? `size : ${selectedFilters.size}` : ""
//                   } 
//                   ${
//                     selectedFilters.color
//                       ? `color : ${selectedFilters.color}`
//                       : ""
//                   }`}
//                   action={
//                     <div style={{ display: "flex", gap: "10px" }}>
//                       <DynamicFilterDropdown
//                         defaultTitle="Size"
//                         multiple={false}
//                         options={[
//                           { label: "Inventory Value", value: "inventoryValue" },
//                           { label: "Inventory Qty", value: "inventoryQty" },
//                           { label: "WOH", value: "WOH" },
//                           { label: "Out Of Stock", value: "outOfStock" },
//                           { label: "Count of SKU", value: "countofSKU" },
//                           {
//                             label: "Excess Inventory SKU",
//                             value: "excessInventorySKU",
//                           },
//                           {
//                             label: "Excess Inventory Qty",
//                             value: "excessInventoryQty",
//                           },
//                         ]}
//                         selectedValues={inventoryDistributionDeptFilters.size}
//                         onChange={(selected) =>
//                           setInventoryDistributionDeptFilters({
//                             ...inventoryDistributionDeptFilters,
//                             size: selected[0],
//                           })
//                         }
//                       />
//                       <DynamicFilterDropdown
//                         defaultTitle="Color"
//                         multiple={false}
//                         options={[
//                           { label: "Inventory Value", value: "inventoryValue" },
//                           { label: "Inventory Qty", value: "inventoryQty" },
//                           { label: "WOH", value: "WOH" },
//                           { label: "Out Of Stock", value: "outOfStock" },
//                           { label: "Count of SKU", value: "countofSKU" },
//                           {
//                             label: "Excess Inventory SKU",
//                             value: "excessInventorySKU",
//                           },
//                           {
//                             label: "Excess Inventory Qty",
//                             value: "excessInventoryQty",
//                           },
//                         ]}
//                         selectedValues={inventoryDistributionDeptFilters.color}
//                         onChange={(selected) =>
//                           setInventoryDistributionDeptFilters({
//                             ...inventoryDistributionDeptFilters,
//                             color: selected[0],
//                           })
//                         }
//                       />
//                     </div>
//                   }
//                   style={{ backgroundColor: "white" }}
//                 >
//                   <TreemapChart
//                     name="treemapChart,bubbleChart"
//                     data={inventoryDistributionDept.map((obj) => {
//                       return {
//                         label: obj.inventoryDescription,
//                         value: obj[inventoryDistributionDeptFilters.size],
//                         highlightValue : obj[inventoryDistributionDeptFilters.color],
//                       };
//                     })}
//                     selectedValue={selectedValue}
//                     onSelect={handleSelection}
//                   />
//                 </DynamicCard>
//               </Col>
//               <Col span={10}>
//                 <DynamicCard
//                   title={`Inventory Distribution By Category ${
//                     selectedValue.warehouseChart
//                       ? ` for ${selectedValue.warehouseChart} ${inventoryDistributionDeptFilters.size}`
//                       : ""
//                   }`}
//                   action={null}
//                   style={{ backgroundColor: "white" }}
//                 >
//                   <BubbleChart
//                     name="bubbleChart"
//                     data={(inventoryDistributionCat || []).map((obj, key) => {
//                       console.log(obj, "warehouseobj", key);
//                       return {
//                         label: obj.csItemCategoryDesc,
//                         r: obj[inventoryDistributionDeptFilters.size],
//                       };
//                     })}
//                     selectedValue={selectedValue}
//                     onSelect={handleSelection}
//                   />
//                 </DynamicCard>
//               </Col>
//             </Row>
//           </Space>
//         </div>
//         <div>
//           <Row gutter={[16, 16]}>
//             <Col span={24}>
//               <DynamicCard
//                 title="Inventory Distribution By Product"
//                 action={
//                   <div style={{ display: "flex", gap: "10px" }}>
//                     <Button className="border-btn">Download as CSV</Button>
//                     <Button
//                       type="primary"
//                       className="filled-btn"
//                       onClick={showModal}
//                     >
//                       <FilterOutlined />
//                       Add Filter
//                     </Button>
//                     <Modal
//                       title="Add Filters"
//                       centered
//                       open={isModalOpen}
//                       onCancel={handleCancel}
//                       footer={null}
//                       width="400px"
//                     >
//                       <div style={{ display: "flex", flexDirection: "column" }}>
//                         {filterOptions.map((filter) => (
//                           <Checkbox
//                             key={filter.value}
//                             checked={tempSelection.includes(filter.value)}
//                             onChange={(e) =>
//                               handleCheckboxChange(
//                                 filter.value,
//                                 e.target.checked
//                               )
//                             }
//                           >
//                             {filter.label}
//                           </Checkbox>
//                         ))}
//                       </div>
//                       <div style={{ display: "flex", justifyContent: "end" }}>
//                         <Button
//                           type="primary"
//                           className="filled-btn"
//                           onClick={handleAddFilters}
//                         >
//                           Add Selected Filters
//                         </Button>
//                       </div>
//                     </Modal>
//                   </div>
//                 }
//                 style={{ backgroundColor: "white" }}
//               >
//                 <div
//                   style={{
//                     width: "100%",
//                     display: "flex",
//                     flexDirection: "column",
//                   }}
//                 >
//                   <div
//                     style={{
//                       marginTop: "16px",
//                       display: "flex",
//                       gap: "10px",
//                       flexWrap: "wrap",
//                     }}
//                   >
//                     <DynamicFilterDropdown
//                       defaultTitle="Granularity1"
//                       multiple={false}
//                       options={[
//                         {
//                           label: "Warehouse Name",
//                           value: "warehouseName",
//                         },
//                         { label: "Item Category", value: "itemCategory" },
//                         { label: "Item Status Code", value: "itemStatusCode" },
//                         {
//                           label: "Private Distribution",
//                           value: "privateDistribution",
//                         },
//                         { label: "ssic", value: "ssic" },
//                         {
//                           label: "Item Code",
//                           value: "itemCode",
//                         },
//                         {
//                           label: "Item Description",
//                           value: "itemDescription",
//                         },
//                         {
//                           label: "Item Department",
//                           value: "itemDepartment",
//                         },
//                         {
//                           label: "Vendor Name",
//                           value: "vendorName",
//                         },
//                       ]}
//                       selectedValues={defaultTableFilters.granularity1}
//                       onChange={(selected) =>
//                         setDefaultTableFilters({
//                           ...defaultTableFilters,
//                           granularity1: selected,
//                         })
//                       }
//                     />
//                     <DynamicFilterDropdown
//                       defaultTitle="Granularity2"
//                       multiple={false}
//                       options={[
//                         {
//                           label: "Warehouse Name",
//                           value: "warehouseName",
//                         },
//                         { label: "Item Category", value: "itemCategory" },
//                         { label: "Item Status Code", value: "itemStatusCode" },
//                         {
//                           label: "Private Distribution",
//                           value: "privateDistribution",
//                         },
//                         { label: "ssic", value: "ssic" },
//                         {
//                           label: "Item Code",
//                           value: "itemCode",
//                         },
//                         {
//                           label: "Item Description",
//                           value: "itemDescription",
//                         },
//                         {
//                           label: "Item Department",
//                           value: "itemDepartment",
//                         },
//                         {
//                           label: "Vendor Name",
//                           value: "vendorName",
//                         },
//                       ]}
//                       selectedValues={defaultTableFilters.granularity2}
//                       onChange={(selected) =>
//                         setDefaultTableFilters({
//                           ...defaultTableFilters,
//                           granularity2: selected,
//                         })
//                       }
//                     />
//                     <DynamicFilterDropdown
//                       defaultTitle="Measure Names"
//                       multiple={true}
//                       options={measureOptions}
//                       selectedValues={defaultTableFilters.measureNames}
//                       onChange={(selectedValues: string[]) => {
//                         // Map selected values to objects with labels
//                         const selectedMeasures = selectedValues.map(
//                           (val) =>
//                             measureOptions.find((opt) => opt.value === val) || {
//                               label: val,
//                               value: val,
//                             }
//                         );
//                         setDefaultTableFilters({
//                           ...defaultTableFilters,
//                           measureNames: selectedMeasures,
//                         });
//                       }}
//                     />
//                     {/* {selectedTableFilters.map((filter) => {
//                       const option = filterOptions.find(
//                         (f) => f.value === filter
//                       );
//                       return (
//                         <DynamicFilterDropdown
//                           key={filter}
//                           defaultTitle={option?.label || "Select Option"}
//                           options={options} // your dropdown options list
//                           selectedValues={filterSelections[filter] || []}
//                           onChange={(selected) =>
//                             handleFilterChange(filter, selected)
//                           }
//                         />
//                       );
//                     })} */}
//                   </div>
//                   <p>
//                     *Please select filters from Measure Names to see more
//                     columns
//                   </p>
//                   <div style={{ marginTop: "10px" }}>
//                     {/* <DynamicTable
//                       columns={columns}
//                       data={graphValues.tableData}
//                     /> */}
//                     <DynamicGranularityTable
//                       granularity1={defaultTableFilters.granularity1}
//                       granularity2={defaultTableFilters.granularity2}
//                       measureNames={defaultTableFilters.measureNames}
//                       apiData={productTable.rows}
//                       totalCount={productTable.count}
//                       pageSize={10} // rows per page
//                       onPageChange={(page, pageSize) => {
//                         dispatch(
//                           getProductTableData({
//                             pageNo: page,
//                             limit: pageSize,
//                             granularity1: defaultTableFilters.granularity1,
//                             granularity2: defaultTableFilters.granularity2,
//                           })
//                         );
//                       }}
//                     />
//                   </div>
//                 </div>
//               </DynamicCard>
//             </Col>
//           </Row>
//         </div>
//       </div>
//     </div>
//   );
// }

// export default ManagerInsights;
