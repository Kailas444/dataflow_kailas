import React, { useEffect } from "react";
import CSLogo from "../../assets/cns logo.svg";
import "../../styles/header.css";
import Glossary from "../common/glossary";

interface HeaderProps {
  title: string;
}

const Header: React.FC<HeaderProps> = ({ title }) => {
  return (
    <div
      style={{
        padding: "5px",
        display: "flex",
        alignItems: "center",
        gap:"10px"
      }}
    >
      {/* Logo */}
      <div
        style={{ marginRight: "20px", fontWeight: "bold", fontSize: "16px" }}
      >
        <img src={CSLogo} alt="CS Logo" width={100} height={40} />
      </div>
      <div style={{ fontWeight: "bold", fontSize: "18px" }}>{title}</div>
      <div>
        <Glossary />
      </div>
    </div>
  );
};

export default Header;
