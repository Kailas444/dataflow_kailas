import React from "react";
import Sidebar from "./sidebar";
import SubHeader from "./subHeader";
import "../../styles/layout.css";
import Header from "./header";

interface LayoutProps {
  mainContent: React.ReactNode;
   headerTitle: string; 
}

const Layout: React.FC<LayoutProps> = ({ mainContent, headerTitle }) => {
  const headerHeight = 64; 
  const sidebarWidth = 60; 
  return (
    <div style={{ minHeight: "100vh" }}>
      {/* Fixed Header */}
      <div
        style={{
          position: "fixed",
          top: 0,
          left: 0,
          right: 0,
          height: headerHeight,
          zIndex: 1100,
          background:"white"
        }}
      >
        <Header title={headerTitle}/>
      </div>

      {/* Fixed Sidebar (starts below header) */}
      <div
        style={{
          position: "fixed",
          top: headerHeight,
          left: 0,
          bottom: 0,
          width: sidebarWidth,
          background: "#fff",
          borderRight: "1px solid #f0f0f0",
          zIndex: 1000,
        }}
      >
        <Sidebar />
      </div>

      {/* Scrollable Right Content Area */}
      <div
        style={{
          marginLeft: sidebarWidth,
          paddingTop: headerHeight,
          display: "flex",
          flexDirection: "column",
          minHeight: "100vh",
          overflow: "hidden",
        }}
      >
        {/* SubHeader stays above content, scrolls away with content */}
        <SubHeader />

        {/* Scrollable main content */}
        <div
          style={{
            flex: 1,
            // overflowY: "auto",
            padding: "16px",
          }}
          className="main-content"
        >
          {mainContent}
        </div>
      </div>
    </div>
  );
};

export default Layout;
