import React, { useEffect, useState } from "react";
import DynamicFilterDropdown from "../common/dynamicFilterDropdown";
import { Button, Modal, Table } from "antd";
import { PushpinOutlined, ReloadOutlined } from "@ant-design/icons";
import "../../styles/subHeader.css";
import { getGlobalFilters } from "../../redux/asyncApi/globalFiltersApi";
import { useDispatch, useSelector } from "react-redux";
import type { AppDispatch } from "../../redux/store";
import { updateFilterSelectedOptions } from "../../redux/reducers/globalFilter";
import {
  getInventoryDistributionCategory,
  getInventoryDistributionDepartment,
  getInventoryWarehouse,
  getKPICardData,
  getPrivateDistributionQuantity,
  getRefreshDate,
} from "../../redux/asyncApi/managerInsightsApi";
import { useLocation } from "react-router-dom";

interface DataType {
  key: string;
  col1: string;
  col2: string;
  col3: string;
  col4: string;
  col5: string;
  col6: string;
  col7: string;
  col8: string;
}

const SubHeader: React.FC<any> = () => {
  const dispatch = useDispatch<AppDispatch>();
  const location = useLocation();
  const {
    globalFilters: { filterOptions = {}, filterSelectedOptions = {} },
    managerInsight: { refreshDate = "" },
  } = useSelector((state: any) => state);
  const showCustomize = location.pathname.includes("/inventory-aging");
  const [isApply, setIsApply] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [lastRefreshDate, setLastRefreshDate] = useState("31-08-2025");
  const showModal = () => setIsModalOpen(true);
  const handleCancel = () => setIsModalOpen(false);
  const options = [
    { label: "Option 1", value: "1" },
    { label: "Option 2", value: "2" },
    { label: "Option 3", value: "3" },
  ];
  const columns = [
    {
      title: "", // No header
      dataIndex: "col1",
      key: "col1",
      render: () => <PushpinOutlined />,
      width: 50,
    },
    { title: "KPI ID", dataIndex: "col2", key: "col2" },
    { title: "KPI Name", dataIndex: "col3", key: "col3" },
    { title: "KPI Description", dataIndex: "col4", key: "col4" },
    { title: "KPI Value", dataIndex: "col5", key: "col5" },
    { title: "Change of YOY", dataIndex: "col6", key: "col6" },
    { title: "Deviation YOY", dataIndex: "col7", key: "col7" },
    {
      title: "Details",
      dataIndex: "col8",
      key: "col8",
      render: (_: any, record: any) => (
        <a href="#" style={{ textDecoration: "underline", color: "#DB2032" }}>
          View Details
        </a>
      ),
    },
  ];

  const data: DataType[] = [
    {
      key: "1",
      col1: "",
      col2: "K_ID101",
      col3: "Total Inventory value",
      col4: "Total monetary worth of the stock we currently hold in the warehouse",
      col5: "$1,153.3M",
      col6: "0.6%",
      col7: "5.8%",
      col8: "View",
    },
    {
      key: "2",
      col1: "",
      col2: "K_ID102",
      col3: "Total Inventory qty",
      col4: "The number of units/items of a product currently available in the stock",
      col5: "64.8M",
      col6: "0.7%",
      col7: "4.8%",
      col8: "View",
    },
    {
      key: "3",
      col1: "",
      col2: "K_ID103",
      col3: "Week On hand",
      col4: "How many weeks the current stock will last based on last 13 week average sales",
      col5: "4.56",
      col6: "0.5%",
      col7: "9.0%",
      col8: "View",
    },
    {
      key: "4",
      col1: "",
      col2: "K_ID104",
      col3: "Out of Stock",
      col4: "Items that are not available in inventory - usually with prod quantity = 0",
      col5: "7.61%",
      col6: "0.0%",
      col7: "0.8%",
      col8: "View",
    },
  ];

  const fetchGlobalFilters = async (
    filterName: string,
    searchTerm: string = ""
  ) => {
    try {
      setLoading(true);
      await dispatch(
        getGlobalFilters({
          filterName,
          selectedFilterValue: {
            ...filterSelectedOptions,
            [filterName]: filterSelectedOptions[filterName] || [],
          },
          searchTerm,
        })
      );
    } finally {
      setLoading(false);
    }
  };

  // useEffect(() => {
  //   if (isApply) {
  //     dispatch(getPrivateDistributionQuantity());
  //     dispatch(getKPICardData());
  //     dispatch(getInventoryWarehouse());
  //     dispatch(getInventoryDistributionDepartment());
  //     dispatch(getInventoryDistributionCategory());
  //     setIsApply(false);
  //   }
  // }, [isApply]);

  useEffect(() => {
    dispatch(getRefreshDate());
  }, []);

  console.log(filterSelectedOptions, "filterSelectedOptions");
  return (
    <div>
      <div
        style={{
          display: "flex",
          gap: "10px",
          padding: "20px",
          alignItems: "end",
        }}
      >
        <DynamicFilterDropdown
          name="inventoryOrganization"
          multiple={true}
          loading={loading}
          options={filterOptions.inventoryOrganization}
          selectedValues={filterSelectedOptions["inventoryOrganization"] || []}
          onChange={(selected, name) => {
            {
              console.log(selected, "selectedonchangr", name);
            }
            dispatch(updateFilterSelectedOptions({ name, selected }));
          }}
          defaultTitle="Inventory Organization"
          onOpenDropDown={(name) => fetchGlobalFilters(name)}
          onSearch={(name, term) => fetchGlobalFilters(name, term)}
        />
        <DynamicFilterDropdown
          name="warehouseName"
          defaultTitle="Warehouse Name"
          loading={loading}
          multiple={true}
          options={[
            ...(filterSelectedOptions["warehouseName"] || []).map((val: any) => ({
              key: val,
              label: val,
            })),
            ...filterOptions.warehouseName,
          ]}
          selectedValues={filterSelectedOptions["warehouseName"] || []}
          onChange={(selected, name) => {
            {
              console.log(selected, "selectedonchangr", name);
            }
            dispatch(updateFilterSelectedOptions({ name, selected }));
          }}
          onOpenDropDown={(name) => fetchGlobalFilters(name)}
          onSearch={(name, term) => fetchGlobalFilters(name, term)}
        />
        <DynamicFilterDropdown
          name="itemDepartment"
          defaultTitle="Item Department"
          loading={loading}
          multiple={true}
          options={filterOptions.itemDepartment}
          selectedValues={filterSelectedOptions["itemDepartment"] || []}
          onChange={(selected, name) => {
            {
              console.log(selected, "selectedonchangr", name);
            }
            dispatch(updateFilterSelectedOptions({ name, selected }));
          }}
          onOpenDropDown={(name) => fetchGlobalFilters(name)}
          onSearch={(name, term) => fetchGlobalFilters(name, term)}
        />
        <DynamicFilterDropdown
          name="itemCategory"
          defaultTitle="Item Category"
          loading={loading}
          multiple={true}
          // options={filterOptions.itemCategory}
          options={[
            ...(filterSelectedOptions["itemCategory"] || []).map((val: any) => ({
              key: val,
              label: val,
            })),
            ...filterOptions.itemCategory,
          ]}
          selectedValues={filterSelectedOptions["itemCategory"] || []}
          onChange={(selected, name) =>
            dispatch(updateFilterSelectedOptions({ name, selected }))
          }
          onOpenDropDown={(name) => fetchGlobalFilters(name)}
          onSearch={(name, term) => fetchGlobalFilters(name, term)}
        />
        <DynamicFilterDropdown
          name="itemCode"
          defaultTitle="Item Code"
          loading={loading}
          multiple={true}
          // options={filterOptions.itemCode}
            options={[
            ...(filterSelectedOptions["itemCode"] || []).map((val: any) => ({
              key: val,
              label: val,
            })),
            ...filterOptions.itemCode,
          ]}
          selectedValues={filterSelectedOptions["itemCode"] || []}
          onChange={(selected, name) =>
            dispatch(updateFilterSelectedOptions({ name, selected }))
          }
          onOpenDropDown={(name) => fetchGlobalFilters(name)}
          onSearch={(name, term) => fetchGlobalFilters(name, term)}
        />
        <DynamicFilterDropdown
          name="itemDescription"
          defaultTitle="Item Description"
          loading={loading}
          multiple={true}
          options={filterOptions.itemDescription}
          selectedValues={filterSelectedOptions["itemDescription"] || []}
          onChange={(selected, name) =>
            dispatch(updateFilterSelectedOptions({ name, selected }))
          }
          onOpenDropDown={(name) => fetchGlobalFilters(name)}
          onSearch={(name, term) => fetchGlobalFilters(name, term)}
        />
        {/* <Button type="primary" onClick={() => setIsApply(true)}>
          Apply
        </Button> */}
        {!showCustomize && (
          <Button onClick={showModal} className="customize-btn">
            Customize
          </Button>
        )}

        <Modal
          title="KPI List"
          open={isModalOpen}
          onCancel={handleCancel}
          footer={null}
          width="100%"
        >
          <Table
            columns={columns}
            dataSource={data}
            pagination={false}
            bordered
          />
        </Modal>
      </div>
      <div
        style={{
          display: "flex",
          justifyContent: "end",
          gap: "6px",
          marginRight: "24px",
        }}
      >
        <ReloadOutlined style={{ fontSize: "12px" }} />
        <span style={{ fontSize: "8px" }}>
          Last Refresh Date - {refreshDate}
        </span>
      </div>
    </div>
  );
};

export default SubHeader;
