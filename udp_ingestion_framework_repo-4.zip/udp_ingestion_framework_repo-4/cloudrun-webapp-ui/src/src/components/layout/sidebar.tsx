import React from "react";
import { Layout, Tooltip } from "antd";
import { useNavigate, useLocation } from "react-router-dom";
import InventoryIcon from "../../assets/inventoryaging.svg";
import ManagerIcon from "../../assets/managerinsights.svg";
import AlertCenterIcon from "../../assets/alertCenter.svg";
import OverviewIcon from "../../assets/overview.svg";
import "../../styles/header.css";

const { Sider } = Layout;

const Sidebar: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation(); 
  return (
    <Sider
      width={60}
      collapsed
      collapsedWidth={80}
      trigger={null}
      style={{
        background: "#fff",
        borderRight: "1px solid #f0f0f0",
      }}
      className="side-bar"
    >
      <div className="sidebar-container">
      
        {/* Overview */}
         <Tooltip
          title="Overview"
          placement="right"
          overlayClassName="custom-tooltip"
        >
          <div
            className={`sidebar-icon ${
              location.pathname === "/overview" ? "active" : ""
            }`}
            onClick={() => navigate("/overview")}
          >
            <img src={OverviewIcon} alt="Overview" width={24} height={24} />
          </div>
        </Tooltip>

         {/* Alert Center */}
         <Tooltip
          title="Alert Center"
          placement="right"
          overlayClassName="custom-tooltip"
        >
          <div
            className={`sidebar-icon ${
              location.pathname === "/alert-center" ? "active" : ""
            }`}
            onClick={() => navigate("/alert-center")}
          >
            <img src={AlertCenterIcon} alt="Alert" width={24} height={24} />
          </div>
        </Tooltip>

         {/* Manager Insights */}
        <Tooltip
          title="Manager Insights"
          placement="right"
          overlayClassName="custom-tooltip"
        >
          <div
            className={`sidebar-icon ${
              location.pathname === "/manager-insights" ? "active" : ""
            }`}
            onClick={() => navigate("/manager-insights")}
          >
            <img src={ManagerIcon} alt="Manager" width={20} height={18} />
          </div>
        </Tooltip>

           {/* Inventory Aging */}
        <Tooltip
          title="Inventory Aging"
          placement="right"
          overlayClassName="custom-tooltip"
        >
          <div
            className={`sidebar-icon ${
              location.pathname === "/inventory-aging" ? "active" : ""
            }`}
            onClick={() => navigate("/inventory-aging")}
          >
            <img src={InventoryIcon} alt="Inventory" width={20} height={18} />
          </div>
        </Tooltip>
      </div>
    </Sider>
  );
};

export default Sidebar;
