
"""
||================================================================================
||Script Name   : main.py
||Dag Name      : spin_weekly_store_extract_dag
||CloudRun Job  : spin_weekly_store_extract_job
||Author        : Your Name Here
||Created Date  : 30-04-2025
||Created By    : Nitin Kumar Gaur
||Last Modified : 10-07-2025
||Modified By   : 
||Version       : 1.2.0
||Description   : 
||    This script authenticates the SPINS API, generates a data extract 
||    via GraphQL, downloads and decompresses the data, uploads it to Google 
||    Cloud Storage, and logs the process. And then
||    load the data into cloud storage.
||Notes         :
||    - Ensure Google Cloud credentials are available in the environment.
||    - This script is designed to run on a schedule via Airflow.
||================================================================================
"""
# --------------------------------------------------------------
# Imports - External Libraries for Networking, GCS, Parsing, etc.
# --------------------------------------------------------------
import requests                                 # To make HTTP API calls
import json                                     # To handle JSON data
import os                                       # For reading environment variables and file operations
import gzip                                     # To decompress GZIP files
import shutil                                   # For file manipulation (copying)
from google.cloud import storage                # Google Cloud Storage client
import time                                     # For retries/waiting
from datetime import datetime, timezone         # For generating timestamps
import logging                                  # For logging pipeline activity
import yaml                                     # To parse YAML config from GCS
from io import BytesIO                          # To handle in-memory file-like objects

# --------------------------------------------------------------
# Global Logger Setup - Structured output with timestamp & level
# --------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger()

# --------------------------------------------------------------
# SpinsExtractPipeline Class - Encapsulates the full ETL process
# --------------------------------------------------------------
class SpinsExtractPipeline:
    def __init__(self):
        # Load secrets from environment variables (Cloud Run)
        self.client_id = os.environ["spins_client_id"]
        self.client_secret = os.environ["spins_client_secret"]
        config_bucket = os.environ["config_bucket"]
        config_path = os.environ["config_path"]

        # Load YAML configuration from GCS path
        self.config = self._load_config(config_bucket, config_path)

        # Extract parameters from config
        self.gcs_bucket = self.config["gcs_bucket_name"]
        self.gcs_dest_path = self.config["gcs_dest_path"]
        self.auth_url = self.config["spins_auth_url"]
        self.graphql_url = self.config["spins_graphql_url"]
        self.audience = self.config["audience"]
        self.extract_variables = self.config["create_extract_variables"]
        self.filename_prefix = self.config.get("filename_prefix", "spins_weekly_store")
        self.chunk_size = self.config.get("download_chunk_size_mb", 10) * 1024 * 1024
        self.max_retries = self.config.get("max_retries", 10)
        self.wait_seconds = self.config.get("wait_seconds", 30)

        # Generate timestamp to suffix filenames uniquely
        self.timestamp = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S")

        # GraphQL mutation query to trigger the extract request
        self.extract_mutation = """
        mutation CreateExtractForWeeklyStoreInsightsInTrend(
          $trend: TrendInput!,
          $select: [StoreInsightsSelectInput!]!,
          $where: [StoreInsightsWhereInput!]!,
          $format: ExtractFormat!
        ) {
          createExtractForWeeklyStoreInsightsInTrend(
            trend: $trend,
            select: $select,
            where: $where,
            format: $format
          ) {
            id
          }
        }
        """

    # ----------------------------------------------------------
    # Load YAML config file from GCS bucket
    # ----------------------------------------------------------
    def _load_config(self, bucket_name, blob_name):
        try:
            storage_client = storage.Client()
            bucket = storage_client.bucket(bucket_name)
            blob = bucket.blob(blob_name)
            content = blob.download_as_bytes()
            return yaml.safe_load(BytesIO(content))  # Parse YAML into Python dict
        except Exception as e:
            logger.error(f"Failed to load config from GCS: {e}")
            raise

    # ----------------------------------------------------------
    # Auth API - Fetch OAuth token using client credentials flow
    # ----------------------------------------------------------
    def authenticate(self):
        try:
            payload = {
                "client_id": self.client_id,
                "client_secret": self.client_secret,
                "audience": self.audience,
                "grant_type": "client_credentials"
            }
            headers = {"Content-Type": "application/json"}
            response = requests.post(self.auth_url, json=payload, headers=headers)
            response.raise_for_status()
            token = response.json()["access_token"]
            logger.info("Token received successfully.")
            return token
        except Exception as e:
            logger.error(f"Token fetch failed: {e}")
            raise

    # ----------------------------------------------------------
    # Triggers the extract job on SPINS API using GraphQL mutation
    # ----------------------------------------------------------
    def trigger_extract(self, token):
        try:
            headers = {
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json"
            }
            response = requests.post(
                self.graphql_url,
                json={"query": self.extract_mutation, "variables": self.extract_variables},
                headers=headers
            )
            response.raise_for_status()
            result = response.json()
            logger.info(f"Extract trigger response: {result}")
            extract_id = result.get("data", {}).get("createExtractForWeeklyStoreInsightsInTrend", {}).get("id")
            if not extract_id:
                raise Exception("Extract creation failed or extract ID not found.")
            return extract_id
        except Exception as e:
            logger.error(f"Create extract API error: {e}")
            raise

    # ----------------------------------------------------------
    # Waits for extract to be completed, retries until ready
    # ----------------------------------------------------------
    def wait_for_extract(self, token, extract_id):
        # GraphQL query to check extract status
        query = """
        query GetExtract($id: ID!) {
          extract(id: $id) {
            id
            urls
            format
            status
            createdAt
          }
        }
        """
        variables = {"id": extract_id}
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }

        for attempt in range(self.max_retries):
            logger.info(f"Checking extract status (attempt {attempt + 1})...")
            try:
                response = requests.post(
                    self.graphql_url,
                    json={"query": query, "variables": variables},
                    headers=headers
                )
                response.raise_for_status()
                data = response.json().get("data", {}).get("extract", {})
                status = data.get("status")
                urls = data.get("urls", [])

                if status == "DONE" and urls:
                    logger.info(f"Extract is ready with {len(urls)} file(s).")
                    for i, url in enumerate(urls, start=1):
                        logger.info(f"{i}. {url}")
                    return urls
                else:
                    logger.info(f"Status: {status}. Retrying in {self.wait_seconds} seconds...")
                    time.sleep(self.wait_seconds)
            except Exception as e:
                logger.warning(f"Error during extract status check: {e}")
                time.sleep(self.wait_seconds)
        raise TimeoutError("Extract was not ready after maximum retries.")

    # ----------------------------------------------------------
    # Handles downloading, decompressing, and uploading all files
    # ----------------------------------------------------------
    def process_and_upload_files(self, urls):
        for index, url in enumerate(urls):
            gz_file = f"{self.filename_prefix}_{self.timestamp}_{index + 1}.csv.gz"
            csv_file = gz_file.replace(".gz", "")
            gcs_file_path = f"{self.gcs_dest_path}/{self.filename_prefix}_{self.timestamp}_{index + 1}.csv"

            self._download_file(url, gz_file)
            self._decompress_gzip(gz_file, csv_file)
            self._upload_to_gcs(csv_file, gcs_file_path)

            os.remove(gz_file)
            os.remove(csv_file)
            logger.info(f"Cleaned up local files: {gz_file}, {csv_file}")

    # ----------------------------------------------------------
    # Downloads file from SPINS extract URL
    # ----------------------------------------------------------
    def _download_file(self, url, local_path): #todo: check for concurrent downalod like 4 files at at time
        try:
            logger.info(f"Downloading file from: {url}")
            with requests.get(url, stream=True) as r:
                r.raise_for_status()
                total_size = int(r.headers.get('Content-Length', 0))
                logger.info(f"File size: {total_size / 1024 / 1024:.2f} MB")
                with open(local_path, "wb") as f:
                    for chunk in r.iter_content(chunk_size=self.chunk_size):
                        if chunk:
                            f.write(chunk)
        except Exception as e:
            logger.error(f"Download failed: {e}")
            raise

    # ----------------------------------------------------------
    # Decompresses .gz file to .csv
    # ----------------------------------------------------------
    def _decompress_gzip(self, file_path, decompressed_path):
        try:
            logger.info(f"Decompressing file: {file_path}")
            with gzip.open(file_path, 'rb') as f_in:
                with open(decompressed_path, 'wb') as f_out:
                    shutil.copyfileobj(f_in, f_out)
        except Exception as e:
            logger.error(f"Decompression failed: {e}")
            raise

    # ----------------------------------------------------------
    # Uploads the final CSV file to Google Cloud Storage bucket
    # ----------------------------------------------------------
    def _upload_to_gcs(self, local_path, destination_blob_name):
        try:
            logger.info(f"Uploading to GCS: gs://{self.gcs_bucket}/{destination_blob_name}")
            storage_client = storage.Client()
            bucket = storage_client.bucket(self.gcs_bucket)
            blob = bucket.blob(destination_blob_name)
            blob.chunk_size = self.chunk_size
            blob.upload_from_filename(local_path, content_type="text/csv")
        except Exception as e:
            logger.error(f"GCS upload failed: {e}")
            raise

def main():
    try:
        # Initialize the SPINS extract pipeline with configuration and credentials
        pipeline = SpinsExtractPipeline()
        
        # Authenticate with the SPINS API to get a bearer token
        token = pipeline.authenticate()
        
        # Trigger the extract job on the SPINS API and retrieve the extract ID
        extract_id = pipeline.trigger_extract(token)
        
        # Poll the SPINS API until the extract is ready and get the list of downloadable URLs
        urls = pipeline.wait_for_extract(token, extract_id)
        
        # Download, decompress, and upload each extract file to the configured GCS location
        pipeline.process_and_upload_files(urls)
        
        # Log success after the pipeline completes all steps
        logger.info("Pipeline completed successfully.")
    except Exception as e:
        # Log any errors encountered during the pipeline execution
        logger.error(f"Pipeline failed: {e}")

if __name__ == "__main__":
    main()
