#!/usr/bin/env bash
set -euo pipefail

# Variables
DEV_PROJECT="gc-proj-udp-dev-54a3"
PROD_PROJECT="gc-proj-udp-dev-54a3"
IMAGE_NAME="cloud-run-spins-ingest-gcs"
ARTIFACT_REG="udp-cswg-dckr-artreg"
REGION="us-east4"
JOB_PROD="job_prod.yaml"

# Download gcrane
echo "Downloading gcrane..."
curl -L \
  "https://github.com/google/go-containerregistry/releases/latest/download/go-containerregistry_Linux_x86_64.tar.gz" \
  -o go-containerregistry.tar.gz

# Extract and install
echo "Extracting gcrane..."
tar -zxvf go-containerregistry.tar.gz
chmod +x gcrane
sudo mv gcrane /usr/local/bin/
rm -f go-containerregistry.tar.gz

echo "Using Dev project: $DEV_PROJECT"
echo "Using Dev project: $PROD_PROJECT"
echo "Using Image Name: $IMAGE_NAME"
echo "Using Repo: $ARTIFACT_REG"
echo "Image Region: $REGION"
echo "Cloud Run Job File $JOB_PROD"

read -p "Press Enter to continue or Ctrl+C to cancel..."

# Copy image from Dev to Prod
echo "Copying image from Dev to Prod..."
gcrane cp \
  "${REGION}-docker.pkg.dev/${DEV_PROJECT}/${ARTIFACT_REG}/${IMAGE_NAME}:latest" \
  "${REGION}-docker.pkg.dev/${PROD_PROJECT}/${ARTIFACT_REG}/${IMAGE_NAME}:latest"

echo "Running gcloud to create Cloud Run Job.."
gcloud run jobs replace "$JOB_PROD" --region ${REGION}

echo "Image copied successfully."
