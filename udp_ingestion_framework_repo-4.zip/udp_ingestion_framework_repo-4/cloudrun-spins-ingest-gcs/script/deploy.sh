#!/bin/bash
set -e  # Exit on first error

# --- Get script directory so paths work regardless of where script is run from ---
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC_DIR="$(cd "${SCRIPT_DIR}/../src" && pwd)"

# Read environment argument
ENV="$1"

if [[ -z "$ENV" ]]; then
  echo "ERROR: No environment specified. Usage: $0 <dev|prod>"
  exit 1
fi

# Set project & job file based on environment
if [[ "$ENV" == "prod" ]]; then
  PROJECT="gc-proj-udp-dev-54a3"
  JOB_FILE="${SCRIPT_DIR}/job_prod.yaml"
elif [[ "$ENV" == "dev" ]]; then
  PROJECT="gc-proj-udp-dev-54a3"
  JOB_FILE="${SCRIPT_DIR}/job_dev.yaml"
else
  echo "ERROR: Invalid environment '$ENV'. Use 'dev' or 'prod'."
  exit 1
fi

REGION="us-east4"
REPO="udp-cswg-dckr-artreg"
IMAGE_NAME="cloud-run-spins-ingest-gcs"

echo "Using project: $PROJECT"
echo "Using job file: $JOB_FILE"
echo "Source directory: $SRC_DIR"
echo "Script directory: $SCRIPT_DIR"
echo "Using Region: $REGION"
echo "Using Repo: $REPO"
echo "Image Name: $IMAGE_NAME"

read -p "Press Enter to continue or Ctrl+C to cancel..."

docker build --progress=plain -f "${SRC_DIR}/Dockerfile" -t ${IMAGE_NAME} "${SRC_DIR}"

docker tag ${IMAGE_NAME} ${REGION}-docker.pkg.dev/${PROJECT}/${REPO}/${IMAGE_NAME}

docker push ${REGION}-docker.pkg.dev/${PROJECT}/${REPO}/${IMAGE_NAME}

gcloud run jobs replace "$JOB_FILE" --region ${REGION}

echo "Deployment complete."