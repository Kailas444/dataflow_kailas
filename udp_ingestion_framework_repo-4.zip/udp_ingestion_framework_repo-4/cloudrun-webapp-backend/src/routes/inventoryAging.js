const detailedAnalysisData = require("../controllers/InventoryAging/detailedAnalysisData")
const inventoryAgingValues = require("../controllers/InventoryAging/inventoryAgingValues")
const inventoryAgingWarehouse = require("../controllers/InventoryAging/inventoryAgingWarehouse")
const replenishmentStatusDisplay = require("../controllers/InventoryAging/replenishmentStatusDisplay")
const inventoryAgingBucket = require("../controllers/InventoryAging/inventoryAgingBucket")
const stockDays = require("../controllers/InventoryAging/stockDays")


let express = require("express")

let router = express.Router()

// router.get("/global-filters", inventoryAging.getGlobalFilters)
router.post("/inventory-values", inventoryAgingValues)
router.post("/inventory-values-warehouse", inventoryAgingWarehouse)
router.post("/detail-analysis", detailedAnalysisData)
router.post("/replenishment-status", replenishmentStatusDisplay)
router.post("/stock-days", stockDays)
router.post("/inventory-aging-bucket", inventoryAgingBucket)


module.exports = router