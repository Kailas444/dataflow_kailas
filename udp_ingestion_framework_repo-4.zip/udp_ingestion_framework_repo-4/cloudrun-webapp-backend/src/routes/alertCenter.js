const { alertDashboard } = require("../controllers/alertCenter/alertDashboard")

let express = require("express")

let router = express.Router()

// router.get("/global-filters", inventoryAging.getGlobalFilters)
router.post("/alert-dashboard", alertDashboard)


module.exports = router