const { getGlobalFilters } = require("../controllers/ManagerInsights/getGlobalFilters");
const kpiCardsData = require("../controllers/ManagerInsights/kpiCardsData")
const kpiCustomizeData = require("../controllers/ManagerInsights/kpiCustomizeData")
const inventoryCategory = require("../controllers/ManagerInsights/inventoryCategory")
const { inventoryWarehouse } = require("../controllers/ManagerInsights/inventoryWarehouse")
const inventoryDepartment = require("../controllers/ManagerInsights/inventoryDepartment")
const privateDistributionQuantity = require("../controllers/ManagerInsights/privateDistributionQuantity")
const inventoryProduct = require("../controllers/ManagerInsights/inventoryProduct")
const maxInvDate = require("../controllers/ManagerInsights/maxInventoryDate")

const express = require("express")

const router = express.Router()

console.log("Loading managerInsights routes...");
router.post("/global-filters", getGlobalFilters)
router.post("/kpi-cards", kpiCardsData)
router.post("/kpi-customize", kpiCustomizeData)
router.post("/inv-warehouse", inventoryWarehouse)
router.post("/pri-distribution-quantity", privateDistributionQuantity)
router.post("/inv-distribution-category", inventoryCategory)
router.post("/inv-distribution-department", inventoryDepartment)
router.post("/inv-distribution-product", inventoryProduct)
router.get("/max-inv-date", maxInvDate)





module.exports = router