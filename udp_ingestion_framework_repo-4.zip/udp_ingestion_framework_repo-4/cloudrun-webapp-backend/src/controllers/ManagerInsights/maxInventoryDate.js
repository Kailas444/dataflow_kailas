const bigquery = require("../../connection/db.config");
const { baseTable } = require("../../connection/constant");
 
const maxInventoryDate = async (req, res) => {
    try {
        const maxDateQuery = `SELECT CAST(MAX(inventory_date) AS STRING) AS maxDate FROM ${baseTable}`;
        const [rows] = await bigquery.query({ query: maxDateQuery });
 
        const maxDateRaw = rows.length > 0 ? rows[0].maxDate : null;
 
        let formattedMaxDate = null;
        if (maxDateRaw) {
        const dateObj = new Date(maxDateRaw);
        const options = { day: 'numeric', month: 'long', year: 'numeric' };
        formattedMaxDate = dateObj.toLocaleDateString('en-GB', options); // "8 September 2025"
        }
 
        return res.status(200).json({
            success: true,
            maxDate: formattedMaxDate,
        });
 
    } catch (error) {
        console.error('Error in max date query:', error.message);
        return res.status(400).json({
            success: false,
            message: error.message || 'Invalid request',
        });
    }
}
 
 
module.exports = maxInventoryDate