const { inventoryCategoryQuery } = require("../../queryBuilder/ManagerInsights/inventoryCategoryQuery")
const { mapInventoryDepartment } = require("../../mappers/mapInventoryDepartment")
const bigquery = require("../../connection/db.config")

const inventoryCategory = async (req, res) => {
    try {
        const filters = req.body;

        const data = await inventoryCategoryQuery({ filters });

        const [rows] = await bigquery.query({
            query: data.query
        });
        // Optional: transform rows
        const result = mapInventoryDepartment(rows);

        return res.status(200).json({
            success: true,
            result: result,
        });
    } catch (error) {
        console.error('Error in getGlobalFilters:', error.message);
        return res.status(400).json({
            success: false,
            message: error.message || 'Invalid request',
        });
    }
}

// const transformFilterData = (rows) => {
//   const result = {};

//   for (const row of rows) {
//     for (const key in row) {
//       const value = row[key]?.value ?? row[key];  // extract .value from BigQueryDate
//       if (!result[key]) {
//         result[key] = [];
//       }
//       result[key].push(value);
//     }
//   }

//   return result;
// };

module.exports = inventoryCategory