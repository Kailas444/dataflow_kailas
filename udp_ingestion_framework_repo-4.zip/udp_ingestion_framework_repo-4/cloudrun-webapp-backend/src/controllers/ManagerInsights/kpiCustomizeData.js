const { kpiCustomizeDataQuery } = require("../../queryBuilder/ManagerInsights/kpiCustomizeDataQuery")

const kpiCustomizeData = async (req, res) => {
    try {
        const filters = req.body;

        const data = await kpiCustomizeDataQuery(filters);

        return res.status(200).json({
            success: true,
            data,
        });
    } catch (error) {
        console.error('Error in getGlobalFilters:', error.message);
        return res.status(400).json({
            success: false,
            message: error.message || 'Invalid request',
        });
    }
}


module.exports = kpiCustomizeData