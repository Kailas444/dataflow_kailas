const { inventoryDepartmentQuery } = require("../../queryBuilder/ManagerInsights/inventoryDepartmentQuery")
const { mapInventoryDepartment } = require("../../mappers/mapInventoryDepartment")
const bigquery = require("../../connection/db.config")

const inventoryDepartment = async (req, res) => {
    try {
        const filters = req.body;

        const data = await inventoryDepartmentQuery({ filters });


        const [rows] = await bigquery.query({
            query: data.query
        });


       const result = mapInventoryDepartment(rows);
        return res.status(200).json({
            success: true,
            result
        });
    } catch (error) {
        console.error('Error in inventoryDepartment:', error.message);
        return res.status(400).json({
            success: false,
            message: error.message || 'Invalid request',
        });
    }
}


module.exports = inventoryDepartment