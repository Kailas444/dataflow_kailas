const { privateDistributionQuantityQuery } = require("../../queryBuilder/ManagerInsights/privateDistributionQuantityQuery")
const bigquery = require("../../connection/db.config")
const { mapPrivateDistribution } = require("../../mappers/mapPrivateDistribution")

const privateDistributionQuantity = async (req, res) => {
    try {
        const filters = req.body;

        const data = await privateDistributionQuantityQuery({ filters });

        const [rows] = await bigquery.query({
            query: data.query
        });

        const result = mapPrivateDistribution(rows)

        return res.status(200).json({
            success: true,
            result
        });
    } catch (error) {
        console.error('Error in getGlobalFilters:', error.message);
        return res.status(400).json({
            success: false,
            message: error.message || 'Invalid request',
        });
    }
}


module.exports = privateDistributionQuantity