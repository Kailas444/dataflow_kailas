const {
  kpiCardsDataQuery,
} = require("../../queryBuilder/ManagerInsights/kpiCardsDataQuery");
const bigquery = require("../../connection/db.config");

const kpiCardsData = async (req, res) => {
  try {
    const filters = req.body;

    const { query1, query2 } = await kpiCardsDataQuery({ filters });

    // ✅ Correct BigQuery query execution
    const [summaryRows] = await bigquery.query({ query: query2 });
    const [dailyRows] = await bigquery.query({ query: query1 });

    console.log(dailyRows);

    const transformedData = transformFilterData(summaryRows, dailyRows);

    //const transformedData = transformFilterData(summaryRows, dailyRows);

    return res.status(200).json({
      success: true,
      data: transformedData,
    });
  } catch (error) {
    console.error("Error in KPI card data:", error.message);
    return res.status(400).json({
      success: false,
      message: error.message || "Invalid request",
    });
  }
};

const transformFilterData = (summaryRows, dailyRows) => {
  const summary = summaryRows[0] || {};
  const flatDaily = {};
  for (const row of dailyRows) {
    for (const key in row) {
      if (!flatDaily[key]) {
        flatDaily[key] = [];
      }

      // Handle inventory_date formatting
      if (key === "inventory_date" && row[key]?.value) {
        const fullDate = row[key].value; // '2025-09-08'
        const mmdd = fullDate.slice(5); // Extracts '09-08'
        flatDaily[key].push(mmdd);
      } else {
        flatDaily[key].push(row[key]);
      }
    }
  }

  const metrics = [
    {
      title: "Total Inventory Value",
      cdKey: "CD_inventory_value",
      ldKey: "LD_inventory_value_chg",
      l14Key: "L14_days_inventory_value_chg",
      yKey: "inventory_value",
    },
    {
      title: "Total Inventory Quantity",
      cdKey: "CD_prod_qty",
      ldKey: "LD_prod_qty_chg",
      l14Key: "L14_days_prod_qty_chg",
      yKey: "inventory_qty",
    },
    {
      title: "Week on Hand",
      cdKey: "CD_days_WOH",
      ldKey: "LD_days_WOH_chg",
      l14Key: "L14_days_WOH_chg",
      yKey: "WOH",
    },
    {
      title: "Out of Stock",
      cdKey: "CD_OOS_pct",
      ldKey: "LD_OOS_pct_chg",
      l14Key: "L14_OOS_pct_chg",
      yKey: "OOS",
    },
    {
      title: "Count of SKU",
      cdKey: "CD_sku",
      ldKey: "LD_sku_chg",
      l14Key: "L14_days_sku_chg",
      yKey: "SKU",
    },
    {
      title: "Excess Inventory SKU",
      cdKey: "CD_excess_sku",
      ldKey: "LD_excess_sku_chg",
      l14Key: "L14_days_excess_sku_chg",
      yKey: "excess_inv_sku",
    },
    {
      title: "Excess Inventory Quantity",
      cdKey: "CD_excess_qty",
      ldKey: "LD_excess_qty_chg",
      l14Key: "L14_days_excess_qty_chg",
      yKey: "excess_inv_qty",
    },
    {
      title: "Upcoming Expiries",
      cdKey: "CD_exp_prod",
      ldKey: "LD_exp_prod_chg",
      l14Key: "L14_days_exp_prod_chg",
      yKey: "UPC_Exp_Prod",
    },
  ];

  return metrics.map((metric) => ({
    title: metric.title,
    value: summary[metric.cdKey] ?? "0",
    ld_value: summary[metric.ldKey] ?? "0",
    l14_value: summary[metric.l14Key] ?? "0",
    x_axis: flatDaily["inventory_date"] || [],
    y_axis: flatDaily[metric.yKey] || [],
  }));
};

module.exports = kpiCardsData;
