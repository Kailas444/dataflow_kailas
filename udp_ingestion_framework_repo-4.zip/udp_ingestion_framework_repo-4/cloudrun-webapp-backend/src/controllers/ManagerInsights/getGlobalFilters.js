const { getGlobalFiltersQuery } = require('../../queryBuilder/ManagerInsights/getGlobalFiltersQuery');
const bigquery = require("../../connection/db.config");

const getGlobalFilters = async (req, res) => {
  try {
    const { filterName, selectedFilterValue, searchTerm } = req.body;

    if (!filterName || !selectedFilterValue || typeof selectedFilterValue !== 'object') {
      return res.status(400).json({
        success: false,
        message: 'Invalid payload structure',
      });
    }

    // ✅ Correctly pass entire selectedFilterValue object
    const filters = {
      filterName,
      selectedFilterValue,
      searchTerm: searchTerm || ''
    };

    // Build query
    const data = await getGlobalFiltersQuery(filters);

    // Run BigQuery
    const [rows] = await bigquery.query({
      query: data.query
    });

    // Transform response
    const transformedData = transformFilterData(rows);

    return res.status(200).json({
      success: true,
      data: transformedData,
    });
  } catch (error) {
    console.error('Error in getGlobalFilters:', error.message);
    return res.status(400).json({
      success: false,
      message: error.message || 'Invalid request',
    });
  }
};

const transformFilterData = (data) => {

  const result = {
    inventoryOrganization: [],
    itemDepartment: [],
    warehouseName: [],
    itemCategory: [],
    itemCode: [],
    itemDescription: [],
  };

  const seen = {
    inventoryOrganization: new Set(),
    itemDepartment: new Set(),
    warehouseName: new Set(),
    itemCategory: new Set(),
    itemCode: new Set(),
    itemDescription: new Set(),
  };

  let keyCounters = {
    inventoryOrganization: 1,
    itemDepartment: 1,
    warehouseName: 1,
    itemCategory: 1,
    itemCode: 1,
    itemDescription: 1,
  };

  for (const item of data) {
    const { filterName, filterValue } = item;

    if (filterName in result) {
      if (filterValue && !seen[filterName].has(filterValue)) {
        seen[filterName].add(filterValue);
        result[filterName].push({
          key: keyCounters[filterName]++,
          label: filterValue
        });
      }
    }
  }
  return result;
};

module.exports = { getGlobalFilters };
