const { inventoryWarehouseQuery } = require('../../queryBuilder/ManagerInsights/inventoryWarehouseQuery');
const { mapInventoryWarehouse } = require("../../mappers/mapInventoryWarehouse")
const bigquery = require("../../connection/db.config")

const inventoryWarehouse = async (req, res) => {
  try {
     const filters = req.body;
    // Build BigQuery query using helper
    const data = await inventoryWarehouseQuery({ filters });
    // Run the BigQuery
    const [rows] = await bigquery.query({
      query: data.query
    });
    // Optional: transform rows
    //const transformedData = await transformFilterData(rows);
    const result = mapInventoryWarehouse(rows);
    return res.status(200).json({
      success: true,
      result: result,
    });
  } catch (error) {
    console.error('Error in Inventory Warehouse:', error.message);
    return res.status(400).json({
      success: false,
      message: error.message || 'Invalid request',
    });
  }
};

// const transformFilterData = (rows) => {
//   const result = {};

//   for (const row of rows) {
//     for (const key in row) {
//       const value = row[key]?.value ?? row[key];  // extract .value from BigQueryDate
//       if (!result[key]) {
//         result[key] = [];
//       }
//       result[key].push(value);
//     }
//   }

//   return result;
// }

;

// const getItemCodeFilters = async (req, res) => {

//   try {
//     const filters = req.body
//     const data = await getItemCodeFiltersQuery(filters)

//     console.log(data)
//     const [rows] = await bigquery.query({
//       query: data.query
//     });

//     // console.log(data.query)

//     // console.log(rows)
//     const transformedData = transformedItemCodeData(rows);

//     return res.status(200).json({//       success: true,
//       data: transformedData,
//     });


//   }
//   catch (error) {
//     console.error('Error in getItemCodeFilter:', error.message);
//     return res.status(400).json({
//       success: false,
//       message: error.message || 'Invalid request',
//     });
//   }

// }

module.exports = { inventoryWarehouse };