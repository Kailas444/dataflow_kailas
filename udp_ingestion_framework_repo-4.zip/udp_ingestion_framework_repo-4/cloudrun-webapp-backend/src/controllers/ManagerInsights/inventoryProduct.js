const { inventoryProductQuery, inventoryProductCount } = require("../../queryBuilder/ManagerInsights/inventoryProductQuery")
const bigquery = require("../../connection/db.config")


const inventoryProduct = async (req, res) => {
    try {
        const filters = req.body;

        const data = await inventoryProductQuery({ filters });
        const count = await inventoryProductCount({ filters });

        const [rowsResult, countResult] = await Promise.all([
            bigquery.query({ query: data.query }),
            bigquery.query({ query: count.query })
        ]);
        // BigQuery client returns an array: [rows]
        const [rows] = rowsResult;
        const [countData] = countResult;

        return res.status(200).json({
            success: true,
            rows,
            count: countData[0].totalCount
        });
    } catch (error) {
        console.error('Error in getGlobalFilters:', error.message);
        return res.status(400).json({
            success: false,
            message: error.message || 'Invalid request',
        });
    }
}

module.exports = inventoryProduct