const { alertDashboardQuery, categoryIdValues } = require('../../queryBuilder/alertCenter/alertDashboardQuery');
const bigquery = require("../../connection/db.config")
// const { mapAlertTable } = require("../../mappers/mapAlertTable")

const alertDashboard = async (req, res) => {
  try {
    const filters = req.body;
    // Build BigQuery query using helper
    const data = await alertDashboardQuery({ filters });

    // Run the BigQuery
    const [rows] = await bigquery.query({
      query: data.query
    });

    async function enrichRowsWithCategoryNames(rows) {
      const enrichedRows = await Promise.all(
        rows.map(async (row) => {
          // Fetch names for this row's category_ids
          const categoryNames = await categoryIdValues(row.itemCategory);

          const [category] = await bigquery.query({
            query: categoryNames.query
          });
          return {
            ...row,
            itemCode: row.itemCode.trim().split(",").map(e => e.trim()), // keep all existing row fields
            itemCategory: category.map(e => e.cs_item_category_desc), // append new field
          };
        })
      );

      return enrichedRows;
    }

    const result = await enrichRowsWithCategoryNames(rows);
    // return res.status(200).json({
    //   success: true,
    //   result: rows
    // })
    return res.status(200).json({
      success: true,
      result: result,
      count: result[0].total_records
    });
  } catch (error) {
    console.error('Error in alert dashboard', error.message);
    return res.status(400).json({
      success: false,
      message: error.message || 'Invalid request',
    });
  }
};

module.exports = { alertDashboard };