//const { } = require("../../mappers")
//const { } = require("../../queryBuilder")
const { inventoryAgingBucketQuery } = require("../../queryBuilder/InventoryAging/inventoryAgingBucketQuery")
const bigquery = require("../../connection/db.config")
const { mapAgingBucket } = require("../../mappers/mapAgingBucket")

const inventoryAgingBucket = async (req, res) => {
    try {
        const filters = req.body;

        const data = await inventoryAgingBucketQuery({ filters });

        const [rows] = await bigquery.query({
            query: data.query
        });

        const result = mapAgingBucket(rows)

        return res.status(200).json({
            success: true,
            result,
        });
    } catch (error) {
        console.error('Error in inventoryStatus:', error.message);
        return res.status(400).json({
            success: false,
            message: error.message || 'Invalid request',
        });
    }
}


module.exports = inventoryAgingBucket