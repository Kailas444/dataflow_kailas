//const { } = require("../../mappers")
const { stockDaysQuery } = require("../../queryBuilder/InventoryAging/stockDaysQuery")
const bigquery = require("../../connection/db.config");
const { mapAgingBucket } = require("../../mappers/mapAgingBucket")


const stockDays = async (req, res) => {
    try {
        const filters = req.body;

        const data = await stockDaysQuery({ filters });

        const [rows] = await bigquery.query({
            query: data.query
        });


        const result = mapAgingBucket(rows)
        const refinedResult = filters.agingBucket == "0-30 Days" ? result : result.shift()

        return res.status(200).json({
            success: true,
            result,
        });
    } catch (error) {
        console.error('Error in inventoryStatus:', error.message);
        return res.status(400).json({
            success: false,
            message: error.message || 'Invalid request',
        });
    }
}


module.exports = stockDays