//const { } = require("../../mappers")
const { replenishmentStatusDisplayQuery } = require("../../queryBuilder/InventoryAging/replenishmentStatusDisplayQuery")
const bigquery = require("../../connection/db.config")

const replenishmentStatusDisplay = async (req, res) => {
    try {
        const filters = req.body;

        const data = await replenishmentStatusDisplayQuery({ filters });

        const [rows] = await bigquery.query({
            query: data.query
        });

        return res.status(200).json({
            success: true,
            rows,
        });
    } catch (error) {
        console.error('Error in getGlobalFilters:', error.message);
        return res.status(400).json({
            success: false,
            message: error.message || 'Invalid request',
        });
    }
}


module.exports = replenishmentStatusDisplay