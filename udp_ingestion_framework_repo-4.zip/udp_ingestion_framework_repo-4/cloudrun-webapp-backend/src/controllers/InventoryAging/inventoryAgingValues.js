//const { } = require("../../mappers")
//const { } = require("../../queryBuilder")
const {
  inventoryAgingStatusQuery,
} = require("../../queryBuilder/InventoryAging/inventoryAgingValuesQuery");
const bigquery = require("../../connection/db.config");
const {
  mapInventoryAgingStatus,
} = require("../../mappers/mapInventoryAgingStatus");

const inventoryAgingValues = async (req, res) => {
  try {
    const filters = req.body;

    const data = await inventoryAgingStatusQuery({ filters });

    const [rows] = await bigquery.query({
      query: data.query,
    });

    const result = mapInventoryAgingStatus(rows);
    const order = ["Low Risk", "Moderate Risk", "High Risk", "Expired"];

    result.sort(
      (a, b) => order.indexOf(a.riskCategory) - order.indexOf(b.riskCategory)
    );

    return res.status(200).json({
      success: true,
      result,
    });
  } catch (error) {
    console.error("Error in inventoryStatus:", error.message);
    return res.status(400).json({
      success: false,
      message: error.message || "Invalid request",
    });
  }
};

module.exports = inventoryAgingValues;
