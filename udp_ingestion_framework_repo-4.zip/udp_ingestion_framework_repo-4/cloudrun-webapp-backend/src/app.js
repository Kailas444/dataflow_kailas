const managerInsights = require("./routes/managerInsights")
const inventoryAging = require("./routes/inventoryAging")
const alertCenter = require("./routes/alertCenter")
const express = require('express');
const cors = require('cors');
const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());


console.log("Registering managerInsights routes...");
app.use("/api/manager_insights", managerInsights)
app.use("/api/inventory_aging", inventoryAging)
app.use("/api/alert_center", alertCenter)





app.listen(PORT, () => {
  console.log('Server is up on port ' + PORT)
})
module.exports = app





// async function queryBigQuery() {
//   const query = `SELECT * FROM \`gc-proj-udp-dev-54a3.raw_layer.new_inventory_table_upd\` LIMIT 10`;

//   const [rows] = await bigquery.query({ query });

//   console.log("Query Results:");
//   rows.forEach(row => console.log(row));
// }

// queryBigQuery();