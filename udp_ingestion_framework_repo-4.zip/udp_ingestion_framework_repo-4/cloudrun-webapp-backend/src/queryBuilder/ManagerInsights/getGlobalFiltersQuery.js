const { fieldMap } = require("../../connection/constant");
const _ = require('lodash');
const { baseTable } = require("../../connection/constant");
// BigQuery table name
/**
 * Builds a dynamic SQL query based on filters provided.
 *
 * Handles 3 cases:
 * 1. Initial Load — return top 20 values for a filter
 * 2. Search — return matching values excluding initial 20
 * 3. Dependent Filters — return 20 values for all other filters based on selected values of current filter
 *
 * @param {Object} filters - The filter request from frontend
 * @param {string} filters.filterName - Current filter being queried
 * @param {Object} filters.selectedFilterValue - Object of selected filters { filterName: [values] }
 * @param {string} filters.searchTerm - Optional search string
 * @returns {Object} - { query: SQL string }
 */
const getGlobalFiltersQuery = async (filters) => {
  const { filterName, selectedFilterValue = {}, searchTerm = "" } = filters;

  if (!fieldMap[filterName]) {
    throw new Error(`Invalid filterName: ${filterName}`);
  }

  // Sanitize SQL values
  const sanitizeValue = (val) => {
    if (typeof val !== 'string') return '';
    return val.replace(/'/g, "\\'");
  };

  // Build WHERE clause from selected filters excluding a given filterName
  const buildWhereClause = (excludeKey = null) => {
    const conditions = Object.entries(selectedFilterValue)
      .filter(([key]) => key !== excludeKey && fieldMap[key])
      .flatMap(([key, values]) => {
        const dbField = fieldMap[key];
        if (Array.isArray(values) && values.length > 0 && !values.includes('ALL')) {
          const inClause = values.map(val => `'${sanitizeValue(val)}'`).join(', ');
          return [`${dbField} IN (${inClause})`];
        }
        return [];
      });

    return conditions.length > 0 ? `WHERE ${conditions.join(" AND ")}` : '';
  };

  // Initial Load — no searchTerm, no filters
  const isInitialLoad = _.isEmpty(searchTerm) && _.isEmpty(selectedFilterValue?.[filterName]);

  if (isInitialLoad) {
    const dbField = fieldMap[filterName];

    const query = `
      SELECT DISTINCT CAST(${dbField} AS STRING) AS filterValue, '${filterName}' AS filterName
      FROM ${baseTable}
      LIMIT 50
    `;

    return { query };
  }


  if (searchTerm && searchTerm.trim() !== "") {
    const sanitizedSearch = searchTerm.trim().replace(/'/g, "''"); // Basic SQL injection protection
    const dbField = fieldMap[filterName];

    const query = `
      SELECT DISTINCT CAST(${dbField} AS STRING) AS filterValue,
            '${filterName}' AS filterName
      FROM ${baseTable}
      WHERE LOWER(CAST(${dbField} AS STRING)) LIKE LOWER('%${sanitizedSearch}%')
      LIMIT 50
    `;

    return { query };
  }

  // // Search term provided
  // if (searchTerm && searchTerm.trim() !== "") {
  //   const sanitizedSearch = sanitizeValue(searchTerm.trim());
  //   const dbField = fieldMap[filterName];

  //   const dependentWhere = buildWhereClause(filterName);
  //   const searchConditions = [
  //     ...(
  //       dependentWhere
  //         ? [dependentWhere.replace(/^WHERE\s/, '')]
  //         : []
  //     ),
  //     `LOWER(CAST(${dbField} AS STRING)) LIKE LOWER('%${sanitizedSearch}%')`
  //   ];
  //   const searchWhereClause = `WHERE ${searchConditions.join(" AND ")}`;

  //   const query = `
  //     WITH
  //       search_values AS (
  //         SELECT DISTINCT CAST(${dbField} AS STRING) AS filterValue
  //         FROM ${baseTable}
  //         ${searchWhereClause}
  //         LIMIT 50
  //       ),
  //       final_values AS (
  //         SELECT filterValue FROM search_values
  //         EXCEPT DISTINCT
  //       )
  //     SELECT filterValue, '${filterName}' AS filterName,
  //     FROM final_values
  //     ORDER BY filterValue
  //     LIMIT 50
  //   `;

  //   console.log("qwe", query)

  //   return { query };
  // }

  // Dependent Filters — values selected for current filterName
const selectedValues = selectedFilterValue?.[filterName] || [];

if (
  Array.isArray(selectedValues) &&
  selectedValues.length > 0 &&
  !selectedValues.includes('ALL')
) {
  const dbField = fieldMap[filterName];

  const sanitizeValue = val => String(val).replace(/'/g, "''");

  const inClause = selectedValues.map(val => `'${sanitizeValue(val)}'`).join(', ');
  const whereClause = `WHERE ${dbField} IN (${inClause})`;

  const queries = Object.entries(fieldMap).map(([key, dependentField]) => {
    const shouldApplyFilter = key !== filterName;
    const clause = shouldApplyFilter ? whereClause : '';

    return `
      SELECT * FROM (
        SELECT DISTINCT '${key}' AS filterName, CAST(${dependentField} AS STRING) AS filterValue
        FROM ${baseTable}
        ${clause}
        LIMIT 50
      ) AS sub
    `.trim();
  });

  const combinedQuery = queries.join('\nUNION ALL\n');

  return { query: combinedQuery };
}

  // Fallback if nothing matches
  throw new Error("Invalid combination of searchTerm and selectedFilterValue.");
};

module.exports = { getGlobalFiltersQuery };
