

const kpiCustomizeDataQuery =  async (filters) => {
    const fieldMap = {
    inventoryOrganisationName: 'inventory_org_desc',
    warehouseName: 'whse_name',
    itemDepartment: 'gl_description',
    itemCategory: 'cs_item_category_desc',
    itemCode: 'prod_id',
    itemDescription: 'description',
  };

  const allowedFilters = Object.keys(fieldMap);

  // SELECT with aliases for frontend field names
  let query = `
    SELECT
    FROM \`gc-proj-udp-dev-54a3.raw_layer.new_inventory_table_upd\`
    WHERE 1=1
  `;

  const params = [];

  // Apply filters based on frontend keys
  for (const key of allowedFilters) {
    const column = fieldMap[key];
    const filterValue = filters[key];

    if (filterValue && filterValue.toUpperCase() !== 'ALL') {
      const values = filterValue.split(',').map(v => v.trim());
      const placeholders = values.map(() => '?').join(',');
      query += ` AND ${column} IN (${placeholders})`;
      params.push(...values);
    }
  }

  // Run BigQuery
  const [job] = await bigquery.createQueryJob({
    query,
    params,
    location: 'US',
  });

  const [rows] = await job.getQueryResults();
  return rows;
}


module.exports = kpiCustomizeDataQuery