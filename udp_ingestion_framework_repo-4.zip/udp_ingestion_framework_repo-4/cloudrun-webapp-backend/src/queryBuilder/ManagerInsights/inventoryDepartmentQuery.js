const { baseTable } = require("../../connection/constant");
const { fetchWhereClause } = require("../../utils/generalfunctions");

// Helper: Convert camelCase to snake_case
const camelToSnake = (str) => {
  return str.replace(/([a-z])([A-Z])/g, "$1_$2").toLowerCase();
}

const keyToColumnMap = {
  inventoryValue: 'inventory_value',
  inventoryQty: 'inventory_qty',
  WOH: 'WOH',
  outOfStock: 'OOS',
  countofSKU: 'SKU',
  excessInventorySKU: 'excess_inv_sku',
  excessInventoryQty: 'excess_inv_qty',
  upcExpProd: 'UPC_Exp_Prod',
  l14inventoryValue: 'l14_inventory_value',
  l14inventoryQty: 'l14_inventory_qty',
  l14WOH: 'l14_WOH',
  l14outOfStock: 'l14_OOS',
  l14countofSKU: 'l14_SKU',
  l14excessInventorySKU: 'l14_excess_inv_sku',
  l14excessInventoryQty: 'l14_excess_inv_qty',
  l14upcExpProd: 'l14_UPC_Exp_Prod',
  organizationCde: 'organization_cde',
  whseName: 'whse_name',
  whseId: 'whse_id'
};

async function inventoryDepartmentQuery({ filters }) {
  let { kpiFilter, selectedgraphValue } = filters;

  // Convert camelCase keys to snake_case column names
  kpiFilter = keyToColumnMap[kpiFilter] || camelToSnake(kpiFilter);

  const columnTypes = {
    organization_cde: 'string',
    whse_id: 'number',
    whse_name: 'string',
    // Add more columns and types as needed
  };

  const needsFilter = selectedgraphValue && selectedgraphValue.toUpperCase?.() !== 'ALL';
  const isNumeric = columnTypes[kpiFilter] === 'number';

  const filterCondition = needsFilter
    ? (isNumeric
        ? `AND ${kpiFilter} = ${selectedgraphValue}`
        : `AND ${kpiFilter} = ${selectedgraphValue}`)
    : '';


const query = `with L14_day as(
select dept_desc,avg(inventory_value) l14_inventory_value,
avg(inventory_qty) l14_inventory_qty,avg(WOH) l14_WOH,avg(SKU) l14_SKU,avg(OOS) l14_OOS, avg(excess_inv_sku) l14_excess_inv_sku,avg(excess_inv_qty) l14_excess_inv_qty,avg(UPC_Exp_Prod) l14_UPC_Exp_Prod from(
select inventory_date,dept_desc,sum(inventory_value) inventory_value,sum(inventory_qty) inventory_qty,
sum(inventory_qty)/(sum(max_total_shipped_qty)/13) WOH,count(distinct whse_item_id) SKU,
count(distinct(case when out_of_stock_prod='Y' then whse_item_id else null end))/count(distinct whse_item_id) *100 OOS,count(distinct case when  Inventory_Level="Excess Inventory" then whse_item_id end) excess_inv_sku,
sum(case when  Inventory_Level="Excess Inventory" then inventory_qty end) excess_inv_qty,count(UPC_Exp_Prod) UPC_Exp_Prod
FROM ${baseTable} 
where DateRange not in ('CD') and ${fetchWhereClause({ filters })} ${filterCondition}
group by 1,2
)
group by 1
),
 
 
CD as(
SELECT dept_desc,sum(inventory_value) inventory_value,sum(inventory_qty) inventory_qty,
sum(inventory_qty)/(sum(max_total_shipped_qty)/13) WOH,count(distinct whse_item_id),
count(distinct(case when out_of_stock_prod='Y' then whse_item_id else null end))/count(distinct whse_item_id) *100 OOS,count(whse_item_id) SKU,count(distinct case when  Inventory_Level="Excess Inventory" then whse_item_id end) excess_inv_sku,
sum(case when  Inventory_Level="Excess Inventory" then inventory_qty end) excess_inv_qty,count(UPC_Exp_Prod) UPC_Exp_Prod
FROM ${baseTable}
where DateRange in ('CD') and ${fetchWhereClause({ filters })} ${filterCondition}
group by 1
order by 1
)
 
 
SELECT
a.dept_desc,
inventory_value,
inventory_qty,
WOH,
OOS,
SKU,
excess_inv_sku,
excess_inv_qty,
UPC_Exp_Prod,
l14_inventory_value,
l14_inventory_qty,
l14_WOH,
l14_SKU,
l14_OOS,
l14_excess_inv_sku,
l14_excess_inv_qty,
  SAFE_DIVIDE(inventory_value - l14_inventory_value, NULLIF(l14_inventory_value, 0))*100  AS l14_inventory_value_chg,
   SAFE_DIVIDE(inventory_qty - l14_inventory_qty, NULLIF(l14_inventory_qty, 0))*100  AS l14_inventory_qty_chg,
      SAFE_DIVIDE(WOH - l14_WOH, NULLIF(l14_WOH, 0))*100  AS l14_WOH_chg,
      SAFE_DIVIDE(OOS - l14_OOS, NULLIF(l14_OOS, 0))*100  AS l14_OOS_chg,
      SAFE_DIVIDE(SKU - l14_SKU, NULLIF(l14_SKU, 0))*100  AS l14_SKU_chg,
  SAFE_DIVIDE(excess_inv_sku - l14_excess_inv_sku, NULLIF(l14_excess_inv_sku, 0))*100  AS l14_excess_inv_sku_chg,
    SAFE_DIVIDE(excess_inv_qty - l14_excess_inv_qty, NULLIF(l14_excess_inv_qty, 0))*100  AS l14_excess_inv_qty_chg,
    SAFE_DIVIDE(UPC_Exp_Prod - l14_UPC_Exp_Prod, NULLIF(l14_UPC_Exp_Prod, 0))*100  AS l14_excess_UPC_Exp_Prod,
from CD a
join L14_day b
on a.dept_desc=b.dept_desc
order by inventory_value desc`

  return { query };
}

module.exports = { inventoryDepartmentQuery };
