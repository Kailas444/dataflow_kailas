const { fetchWhereClause } = require("../../utils/generalfunctions")
const { baseTable } = require("../../connection/constant");
 
const camelToSnake = (str) => {
  return str.replace(/([a-z])([A-Z])/g, "$1_$2").toLowerCase();
}
 
const keyToColumnMap = {
  inventoryValue: 'inventory_value',
  inventoryQty: 'inventory_qty',
  WOH: 'WOH',
  outOfStock: 'OOS',
  countofSKU: 'SKU',
  excessInventorySKU: 'excess_inv_sku',
  excessInventoryQty: 'excess_inv_qty',
  upcExpProd: 'UPC_Exp_Prod',
  l14inventoryValue: 'l14_inventory_value',
  l14inventoryQty: 'l14_inventory_qty',
  l14WOH: 'l14_WOH',
  l14outOfStock: 'l14_OOS',
  l14countofSKU: 'l14_SKU',
  l14excessInventorySKU: 'l14_excess_inv_sku',
  l14excessInventoryQty: 'l14_excess_inv_qty',
  l14upcExpProd: 'l14_UPC_Exp_Prod',
  organizationCde: 'organization_cde',
  whseName: 'whse_name',
  whseId: 'whse_id'
};
 
const privateDistributionQuantityQuery = ({ filters }) => {
 
    let { kpiFilter, selectedgraphValue } = filters;
 
  // Convert camelCase keys to snake_case column names
  kpiFilter = keyToColumnMap[kpiFilter] || camelToSnake(kpiFilter);
 
  const columnTypes = {
    organization_cde: 'string',
    whse_id: 'number',
    whse_name: 'string',
    // Add more columns and types as needed
  };
 
  const needsFilter = selectedgraphValue && selectedgraphValue.toUpperCase?.() !== 'ALL';
  const isNumeric = columnTypes[kpiFilter] === 'number';
 
  const filterCondition = needsFilter
    ? (isNumeric
        ? `AND ${kpiFilter} = ${selectedgraphValue}`
        : `AND ${kpiFilter} = ${selectedgraphValue}`)
    : '';
 
    let query = `
    SELECT SUM(CASE WHEN Private_Label_Flag_Desc = 'National' THEN inventory_qty ELSE 0 END) / SUM(inventory_qty) AS national_share,
    SUM(CASE WHEN Private_Label_Flag_Desc = 'Private' THEN inventory_qty ELSE 0 END) / SUM(inventory_qty) AS private_share
    FROM ${baseTable}
    WHERE ${fetchWhereClause({ filters })} ${filterCondition}`
 
    console.log(query)
 
    return { query }
}
 
 
module.exports = { privateDistributionQuantityQuery }