const { fieldMap, baseTable } = require("../../connection/constant");
const { fetchWhereClause } = require("../../utils/generalfunctions");
 
// Utility: Convert camelCase to snake_case
const camelToSnake = (str) =>
  str.replace(/([a-z])([A-Z])/g, "$1_$2").toLowerCase();
 
// Map UI filter keys to DB column names
const keyToColumnMap = {
  inventoryValue: "inventory_value",
  inventoryQty: "inventory_qty",
  WOH: "WOH",
  outOfStock: "OOS",
  countofSKU: "SKU",
  excessInventorySKU: "excess_inv_sku",
  excessInventoryQty: "excess_inv_qty",
  upcExpProd: "UPC_Exp_Prod",
  l14inventoryValue: "l14_inventory_value",
  l14inventoryQty: "l14_inventory_qty",
  l14WOH: "l14_WOH",
  l14outOfStock: "l14_OOS",
  l14countofSKU: "l14_SKU",
  l14excessInventorySKU: "l14_excess_inv_sku",
  l14excessInventoryQty: "l14_excess_inv_qty",
  l14upcExpProd: "l14_UPC_Exp_Prod",
  organizationCde: "organization_cde",
  whseName: "whse_name",
  whseId: "whse_id"
};
 
const columnTypes = {
  organization_cde: "string",
  whse_id: "number",
  whse_name: "string",
  dept_desc: "string"
};
 
const inventoryCategoryQuery = async ({ filters }) => {
  let { kpiFilter, selectedgraphValue, selectedDeptValue } = filters;
 
  console.log("Incoming filters:", filters);
 
  // Convert camelCase key to actual SQL column
  const originalKpiFilter = kpiFilter;
  kpiFilter = kpiFilter ? keyToColumnMap[kpiFilter] || camelToSnake(kpiFilter) : "";
 
  console.log("Mapped KPI filter:", originalKpiFilter, "=>", kpiFilter);
 
  const filterConditions = [];
 
  // 1. KPI filter
  if (selectedgraphValue && kpiFilter) {
    const isNumber = columnTypes[kpiFilter] === "number";
    const value = isNumber ? selectedgraphValue : `'${selectedgraphValue}'`;
    filterConditions.push(`${kpiFilter} = ${value}`);
  }
 
  // 2. Department filter
  if (selectedDeptValue && selectedDeptValue.toUpperCase() !== "ALL") {
    const deptColumn = keyToColumnMap.selectedDeptValue || "dept_desc";
    filterConditions.push(`${deptColumn} = '${selectedDeptValue}'`);
  }
 
  // Final WHERE clause filter part
  const additionalFilters =
    filterConditions.length > 0 ? ` AND ${filterConditions.join(" AND ")}` : "";
 
  // ✅ Debug output
  console.log("Filter Conditions:", filterConditions);
  console.log("Final SQL Filter:", additionalFilters);
 
  // Build query
  const query = `
    WITH L14_day AS (
      SELECT
        cs_item_category_desc,
        AVG(inventory_value) l14_inventory_value,
        AVG(inventory_qty) l14_inventory_qty,
        AVG(WOH) l14_WOH,
        AVG(SKU) l14_SKU,
        AVG(OOS) l14_OOS,
        AVG(excess_inv_sku) l14_excess_inv_sku,
        AVG(excess_inv_qty) l14_excess_inv_qty,
        AVG(UPC_Exp_Prod) l14_UPC_Exp_Prod
      FROM (
        SELECT
          inventory_date,
          cs_item_category_desc,
          SUM(inventory_value) inventory_value,
          SUM(inventory_qty) inventory_qty,
          SUM(inventory_qty) / (SUM(max_total_shipped_qty) / 13) WOH,
          COUNT(DISTINCT whse_item_id) SKU,
          COUNT(DISTINCT CASE WHEN out_of_stock_prod = 'Y' THEN whse_item_id ELSE NULL END) / COUNT(DISTINCT whse_item_id) * 100 OOS,
          COUNT(DISTINCT CASE WHEN Inventory_Level = "Excess Inventory" THEN whse_item_id END) excess_inv_sku,
          SUM(CASE WHEN Inventory_Level = "Excess Inventory" THEN inventory_qty END) excess_inv_qty,
          COUNT(UPC_Exp_Prod) UPC_Exp_Prod
        FROM ${baseTable}
        WHERE ${fetchWhereClause({ filters })} ${additionalFilters} AND DateRange NOT IN ('CD')
        GROUP BY 1, 2
      )
      GROUP BY 1
    ),
 
    CD AS (
      SELECT
        cs_item_category_desc,
        SUM(inventory_value) inventory_value,
        SUM(inventory_qty) inventory_qty,
        SUM(inventory_qty) / (SUM(max_total_shipped_qty) / 13) WOH,
        COUNT(DISTINCT whse_item_id),
        COUNT(DISTINCT CASE WHEN out_of_stock_prod = 'Y' THEN whse_item_id ELSE NULL END) / COUNT(DISTINCT whse_item_id) * 100 OOS,
        COUNT(whse_item_id) SKU,
        COUNT(DISTINCT CASE WHEN Inventory_Level = "Excess Inventory" THEN whse_item_id END) excess_inv_sku,
        SUM(CASE WHEN Inventory_Level = "Excess Inventory" THEN inventory_qty END) excess_inv_qty,
        COUNT(UPC_Exp_Prod) UPC_Exp_Prod
      FROM ${baseTable}
      WHERE ${fetchWhereClause({ filters })} ${additionalFilters} AND DateRange IN ('CD')
      GROUP BY 1
      ORDER BY 1
    )
 
    SELECT
      a.cs_item_category_desc,
      inventory_value,
      inventory_qty,
      WOH,
      OOS,
      SKU,
      excess_inv_sku,
      excess_inv_qty,
      UPC_Exp_Prod,
      l14_inventory_value,
      l14_inventory_qty,
      l14_WOH,
      l14_SKU,
      l14_OOS,
      l14_excess_inv_sku,
      l14_excess_inv_qty,
      SAFE_DIVIDE(inventory_value - l14_inventory_value, NULLIF(l14_inventory_value, 0)) * 100 AS l14_inventory_value_chg,
      SAFE_DIVIDE(inventory_qty - l14_inventory_qty, NULLIF(l14_inventory_qty, 0)) * 100 AS l14_inventory_qty_chg,
      SAFE_DIVIDE(WOH - l14_WOH, NULLIF(l14_WOH, 0)) * 100 AS l14_WOH_chg,
      SAFE_DIVIDE(OOS - l14_OOS, NULLIF(l14_OOS, 0)) * 100 AS l14_OOS_chg,
      SAFE_DIVIDE(SKU - l14_SKU, NULLIF(l14_SKU, 0)) * 100 AS l14_SKU_chg,
      SAFE_DIVIDE(excess_inv_sku - l14_excess_inv_sku, NULLIF(l14_excess_inv_sku, 0)) * 100 AS l14_excess_inv_sku_chg,
      SAFE_DIVIDE(excess_inv_qty - l14_excess_inv_qty, NULLIF(l14_excess_inv_qty, 0)) * 100 AS l14_excess_inv_qty_chg,
      SAFE_DIVIDE(UPC_Exp_Prod - l14_UPC_Exp_Prod, NULLIF(l14_UPC_Exp_Prod, 0)) * 100 AS l14_excess_UPC_Exp_Prod
    FROM CD a
    JOIN L14_day b ON a.cs_item_category_desc = b.cs_item_category_desc
  `;
 
  // ✅ Log full query for debugging
  console.log("Generated Query:\n", query);
 
  return { query };
};
 
module.exports = { inventoryCategoryQuery };