const {
  fetchWhereClause,
  getTableColumn,
  orderByWithSQL
} = require("../../utils/generalfunctions");
const { get: _get } = require("lodash");
const { baseTable } = require("../../connection/constant");

const camelToSnake = (str) => {
  return str.replace(/([a-z])([A-Z])/g, "$1_$2").toLowerCase();
};

const keyToColumnMap = {
  inventoryValue: "inventory_value",
  inventoryQty: "inventory_qty",
  WOH: "WOH",
  outOfStock: "OOS",
  countofSKU: "SKU",
  excessInventorySKU: "excess_inv_sku",
  excessInventoryQty: "excess_inv_qty",
  upcExpProd: "UPC_Exp_Prod",
  l14inventoryValue: "l14_inventory_value",
  l14inventoryQty: "l14_inventory_qty",
  l14WOH: "l14_WOH",
  l14outOfStock: "l14_OOS",
  l14countofSKU: "l14_SKU",
  l14excessInventorySKU: "l14_excess_inv_sku",
  l14excessInventoryQty: "l14_excess_inv_qty",
  l14upcExpProd: "l14_UPC_Exp_Prod",
  organizationCde: "organization_cde",
  whseName: "whse_name",
  whseId: "whse_id",
};

const keyToColumnMapSort = {
  cs_item_category_desc: "cs_item_category_desc",
  inventory_item_status_cde: "inventory_item_status_cde",
  CD_inventory_value: "CD_inventory_value",
  LD_inventory_value: "LD_inventory_value",
  LD_inventory_value_chg: "LD_inventory_value_chg",
  L14D_inventory_value_chg: "L14D_inventory_value_chg",
  L14D_inventory_value: "L14D_inventory_value",
  CD_prod_qty: "CD_prod_qty",
  LD_prod_qty: "LD_prod_qty",
  LD_prod_qty_chg: "LD_prod_qty_chg",
  L14D_prod_qty_chg: "L14D_prod_qty_chg",
  L14D_prod_qty: "L14D_prod_qty",
  CD_WOH: "CD_WOH",
  LD_WOH: "LD_WOH",
  LD_WOH_chg: "LD_WOH_chg",
  L14D_WOH_chg: "L14D_WOH_chg",
  L14_days_WOH: "L14_days_WOH",
  CD_OOS_pct: "CD_OOS_pct",
  LD_OOS_pct: "LD_OOS_pct",
  LD_OOS_pct_chg: "LD_OOS_pct_chg",
  L14D_OOS_pct_chg: "L14D_OOS_pct_chg",
  L14D_OOS_PCT: "L14D_OOS_PCT",
  CD_sku: "CD_sku",
  LD_sku: "LD_sku",
  LD_sku_chg: "LD_sku_chg",
  L14D_sku_chg: "L14D_sku_chg",
  L14D_sku: "L14D_sku",
  CD_excess_sku: "CD_excess_sku",
  LD_excess_sku: "LD_excess_sku",
  LD_excess_sku_chg: "LD_excess_sku_chg",
  L14D_excess_sku_chg: "L14D_excess_sku_chg",
  L14_days_excess_sku: "L14_days_excess_sku",
  CD_excess_qty: "CD_excess_qty",
  LD_excess_qty: "LD_excess_qty",
  LD_excess_qty_chg: "LD_excess_qty_chg",
  L14D_excess_qty_chg: "L14D_excess_qty_chg",
  L14D_excess_qty: "L14D_excess_qty",
  CD_exp_prod: "CD_exp_prod",
  LD_exp_prod: "LD_exp_prod",
  LD_exp_prod_chg: "LD_exp_prod_chg",
  L14D_exp_prod_chg: "L14D_exp_prod_chg",
  L14D_exp_prod: "L14D_exp_prod",
  CD_age_of_inventory: "CD_age_of_inventory",
  LD_age_of_inventory: "LD_age_of_inventory",
  LD_age_of_inventory_chg: "LD_age_of_inventory_chg",
  L14D_age_of_inventory_chg: "L14D_age_of_inventory_chg",
  L14D_age_of_inventory: "L14D_age_of_inventory"
}

const inventoryProductQuery = async ({ filters }) => {
  const orderBy = orderByWithSQL({ keyToColumnMapSort, filters, sortKey: 'sorting', defaultOrder: `sort_order` });
  const offset =
    _get(filters, "offset") >= 0
      ? _get(filters, "offset")
      : _get(filters, "pageNo") && _get(filters, "limit")
        ? (_get(filters, "pageNo") - 1) * _get(filters, "limit")
        : 50;
  const limit = _get(filters, "limit") ? _get(filters, "limit") : 50;
  let {
    kpiFilter,
    selectedCategoryValue,
    selectedDeptValue,
    selectedGraphValue,
  } = filters;

  const defaultBuckets = ["0-30 Days", "31-60 Days", "61-90 Days", "90+ Days"];
  const mapNumericToBucket = (value) => {
    const num = parseInt(value);
    if (isNaN(num)) return null;

    if (num >= 0 && num <= 30) return "0-30 Days";
    if (num >= 31 && num <= 60) return "31-60 Days";
    if (num >= 61 && num <= 90) return "61-90 Days";
    if (num > 90) return "90+ Days";

    return null;
  };

  // Normalize agingBucket filter value
  let selectedBucket = filters.agingBucket;

  if (selectedBucket && !defaultBuckets.includes(selectedBucket)) {
    const mappedBucket = mapNumericToBucket(selectedBucket);
    if (mappedBucket) {
      selectedBucket = mappedBucket;
    } else {
      selectedBucket = null; // fallback if not matched
    }
  }

  // Convert camelCase keys to snake_case column names
  kpiFilter = keyToColumnMap[kpiFilter];

  const columnTypes = {
    organization_cde: "string",
    whse_id: "number",
    whse_name: "string",
    // Add more columns and types as needed
  };

  const needsFilter =
    selectedGraphValue && selectedGraphValue.toUpperCase?.() !== "ALL";
  const needsDepartmentFilter =
    selectedDeptValue && selectedDeptValue.toUpperCase?.() !== "ALL";
  const needsCategoryFilter =
    selectedCategoryValue && selectedCategoryValue.toUpperCase?.() !== "ALL";

  const isNumeric = columnTypes[kpiFilter] === "number";

  const filterCondition = needsFilter
    ? isNumeric
      ? `AND ${kpiFilter} = ${selectedGraphValue}`
      : `AND ${kpiFilter} = '${selectedGraphValue}'`
    : "";

  // console.log(filterCondition)

  const filterCondition1 = needsDepartmentFilter
    ? `AND dept_desc ='${selectedDeptValue}'`
    : "";

  const filterCondition2 = needsCategoryFilter
    ? `AND cs_item_category_desc ='${selectedCategoryValue}'`
    : "";

  let query = `
  WITH base AS (
  SELECT
    DateRange,
    inventory_date,
    ${getTableColumn(filters.granularity1)},
    ${getTableColumn(filters.granularity2)},
    SUM(inventory_value) AS inventory_value,
    SUM(inventory_qty) AS inventory_qty,
      avg(weighted_inventory_age) as age_of_inventory,
    SAFE_DIVIDE(SUM(inventory_qty), NULLIF(SUM(max_total_shipped_qty) / 13, 0)) AS days_WOH,
    COUNT(DISTINCT whse_item_id) AS total_sku,
    COUNT(DISTINCT CASE WHEN out_of_stock_prod = 'Y' THEN whse_item_id END) AS oos_sku,
    COUNT(whse_item_id) AS sku_count,
    COUNTIF(Inventory_Level = "Excess Inventory") AS excess_sku,
    SUM(CASE WHEN Inventory_Level = "Excess Inventory" THEN inventory_qty ELSE 0 END) AS excess_qty,
    COUNT(UPC_Exp_Prod) AS exp_prod
  FROM ${baseTable} WHERE ${fetchWhereClause({
    filters,
  })} ${filterCondition} ${filterCondition1} ${filterCondition2}
  ${selectedBucket ? ` AND aging_bucket='${selectedBucket}'` : ""} and
    whse_item_id in (select distinct(whse_item_id) from(
        SELECT
          whse_item_id,
          --SUM(Prod_Qty) AS Total_Qty,
          MAX(reorder_point) AS Max_Repln_Level,
          CASE
            WHEN SUM(inventory_qty) < MAX(reorder_point) THEN "Below Reorder point"
            ELSE "instock"
          END AS Replenishment_Status
        FROM ${baseTable}
        where daterange='CD'
        GROUP BY
          whse_item_id)
        ${filters.replenishmentStatus
      ? `WHERE Replenishment_Status="${filters.replenishmentStatus === "Instock"
        ? "instock"
        : "Below Reorder point"
      }"`
      : ""
    }
      )
  GROUP BY all
),
agg AS (
  SELECT 
  ${filters.granularity1 == "itemCode"
      ? "whse_item_id"
      : getTableColumn(filters.granularity1)
    },
  ${filters.granularity2 == "itemCode"
      ? "whse_item_id"
      : getTableColumn(filters.granularity2)
    },
    -- CD metrics
    SUM(CASE WHEN DateRange = 'CD' THEN inventory_value ELSE 0 END) AS CD_inventory_value,
    SUM(CASE WHEN DateRange = 'CD' THEN inventory_qty ELSE 0 END) AS CD_prod_qty,
    AVG(CASE WHEN DateRange = 'CD' THEN days_WOH END) AS CD_days_WOH,
    SAFE_DIVIDE(SUM(CASE WHEN DateRange = 'CD' THEN oos_sku END),
                NULLIF(SUM(CASE WHEN DateRange = 'CD' THEN total_sku END), 0)) * 100 AS CD_OOS_pct,
    SUM(CASE WHEN DateRange = 'CD' THEN sku_count ELSE 0 END) AS CD_sku,
    SUM(CASE WHEN DateRange = 'CD' THEN excess_sku ELSE 0 END) AS CD_excess_sku,
    SUM(CASE WHEN DateRange = 'CD' THEN excess_qty ELSE 0 END) AS CD_excess_qty,
    SUM(CASE WHEN DateRange = 'CD' THEN exp_prod ELSE 0 END) AS CD_exp_prod,
        AVG(CASE WHEN DateRange = 'CD' THEN age_of_inventory ELSE 0 END) AS CD_age_of_inventory,

    -- LD metrics
    SUM(CASE WHEN DateRange = 'LD' THEN inventory_value ELSE 0 END) AS LD_inventory_value,
    SUM(CASE WHEN DateRange = 'LD' THEN inventory_qty ELSE 0 END) AS LD_prod_qty,
    AVG(CASE WHEN DateRange = 'LD' THEN days_WOH END) AS LD_days_WOH,
    SAFE_DIVIDE(SUM(CASE WHEN DateRange = 'LD' THEN oos_sku END),
                NULLIF(SUM(CASE WHEN DateRange = 'LD' THEN total_sku END), 0)) * 100 AS LD_OOS_pct,
    SUM(CASE WHEN DateRange = 'LD' THEN sku_count ELSE 0 END) AS LD_sku,
    SUM(CASE WHEN DateRange = 'LD' THEN excess_sku ELSE 0 END) AS LD_excess_sku,
    SUM(CASE WHEN DateRange = 'LD' THEN excess_qty ELSE 0 END) AS LD_excess_qty,
    SUM(CASE WHEN DateRange = 'LD' THEN exp_prod ELSE 0 END) AS LD_exp_prod,
    AVG(CASE WHEN DateRange = 'LD' THEN age_of_inventory ELSE 0 END) AS LD_age_of_inventory,

    -- L14 (all except CD)
    AVG(CASE WHEN DateRange != 'CD' THEN inventory_value END) AS L14_days_inventory_value,
    AVG(CASE WHEN DateRange != 'CD' THEN inventory_qty END) AS L14_days_prod_qty,
    AVG(CASE WHEN DateRange != 'CD' THEN days_WOH END) AS L14_days_WOH,
    AVG(SAFE_DIVIDE(
      CASE WHEN DateRange != 'CD' THEN oos_sku END,
      CASE WHEN DateRange != 'CD' THEN NULLIF(total_sku, 0) END
)) * 100 AS L14_day_OOS_PCT,
   -- AVG(SAFE_DIVIDE(oos_sku, NULLIF(total_sku, 0))) * 100 AS L14_day_OOS_PCT,
    AVG(CASE WHEN DateRange != 'CD' THEN sku_count END) AS L14_days_sku,
    AVG(CASE WHEN DateRange != 'CD' THEN excess_sku END) AS L14_days_excess_sku,
    AVG(CASE WHEN DateRange != 'CD' THEN excess_qty END) AS L14_days_excess_qty,
    AVG(CASE WHEN DateRange != 'CD' THEN exp_prod END) AS L14_days_exp_prod,
     AVG(CASE WHEN DateRange != 'CD' THEN age_of_inventory END) AS L14_age_of_inventory
  FROM base
  group by all
),


final as(
SELECT
  -- Inventory value
${filters.granularity1 == "itemCode"
      ? "whse_item_id"
      : getTableColumn(filters.granularity1)
    },
  ${filters.granularity2 == "itemCode"
      ? "whse_item_id"
      : getTableColumn(filters.granularity2)
    },
  CD_inventory_value,
  LD_inventory_value,
  SAFE_DIVIDE(CD_inventory_value - LD_inventory_value, NULLIF(LD_inventory_value, 0)) * 100 AS LD_inventory_value_chg,
  SAFE_DIVIDE(CD_inventory_value - L14_days_inventory_value, NULLIF(L14_days_inventory_value, 0)) * 100 AS L14D_inventory_value_chg,
  L14_days_inventory_value as L14D_inventory_value,

  -- Inventory qty
  CD_prod_qty,
  LD_prod_qty,
  SAFE_DIVIDE(CD_prod_qty - LD_prod_qty, NULLIF(LD_prod_qty, 0)) * 100 AS LD_prod_qty_chg,
  SAFE_DIVIDE(CD_prod_qty - L14_days_prod_qty, NULLIF(L14_days_prod_qty, 0)) * 100 AS L14D_prod_qty_chg,
  L14_days_prod_qty as L14D_prod_qty,

  -- WOH
  CD_days_WOH as CD_WOH,
  LD_days_WOH as LD_WOH,
  SAFE_DIVIDE(CD_days_WOH - LD_days_WOH, NULLIF(LD_days_WOH, 0)) * 100 AS LD_WOH_chg,
  SAFE_DIVIDE(CD_days_WOH - L14_days_WOH, NULLIF(L14_days_WOH, 0)) * 100 AS L14D_WOH_chg,
  L14_days_WOH,

  -- OOS
  CD_OOS_pct,
  LD_OOS_pct,
  SAFE_DIVIDE(CD_OOS_pct - LD_OOS_pct, NULLIF(LD_OOS_pct, 0)) * 100 AS LD_OOS_pct_chg,
  SAFE_DIVIDE(CD_OOS_pct - L14_day_OOS_PCT, NULLIF(L14_day_OOS_PCT, 0)) * 100 AS L14D_OOS_pct_chg,
  L14_day_OOS_PCT as L14D_OOS_PCT,

  -- SKU
  CD_sku,
  LD_sku,
  SAFE_DIVIDE(CD_sku - LD_sku, NULLIF(LD_sku, 0)) * 100 AS LD_sku_chg,
  SAFE_DIVIDE(CD_sku - L14_days_sku, NULLIF(L14_days_sku, 0)) * 100 AS L14D_sku_chg,
  L14_days_sku as L14D_sku,

  -- Excess SKU
  CD_excess_sku,
  LD_excess_sku,
  SAFE_DIVIDE(CD_excess_sku - LD_excess_sku, NULLIF(LD_excess_sku, 0)) * 100 AS LD_excess_sku_chg,
  SAFE_DIVIDE(CD_excess_sku - L14_days_excess_sku, NULLIF(L14_days_excess_sku, 0)) * 100 AS L14D_excess_sku_chg,
  L14_days_excess_sku,

  -- Excess qty
  CD_excess_qty,
  LD_excess_qty,
  SAFE_DIVIDE(CD_excess_qty - LD_excess_qty, NULLIF(LD_excess_qty, 0)) * 100 AS LD_excess_qty_chg,
  SAFE_DIVIDE(CD_excess_qty - L14_days_excess_qty, NULLIF(L14_days_excess_qty, 0)) * 100 AS L14D_excess_qty_chg,
  L14_days_excess_qty as L14D_excess_qty,

  -- Expiring products
  CD_exp_prod,
  LD_exp_prod,
  SAFE_DIVIDE(CD_exp_prod - LD_exp_prod, NULLIF(LD_exp_prod, 0)) * 100 AS LD_exp_prod_chg,
  SAFE_DIVIDE(CD_exp_prod - L14_days_exp_prod, NULLIF(L14_days_exp_prod, 0)) * 100 AS L14D_exp_prod_chg,
  L14_days_exp_prod as L14D_exp_prod,

    CD_age_of_inventory,
  LD_age_of_inventory,
  SAFE_DIVIDE(CD_age_of_inventory - LD_age_of_inventory, NULLIF(LD_age_of_inventory, 0)) * 100 AS LD_age_of_inventory_chg,
  SAFE_DIVIDE(CD_age_of_inventory - L14_age_of_inventory, NULLIF(L14_age_of_inventory, 0)) * 100 AS L14D_age_of_inventory_chg,
    L14_age_of_inventory as L14D_age_of_inventory

FROM agg)

SELECT * FROM (
  SELECT 0 AS sort_order,
    'Grand Total' AS ${filters.granularity1 == "itemCode"
      ? "whse_item_id"
      : getTableColumn(filters.granularity1)
    },
    '' AS ${filters.granularity2 == "itemCode"
      ? "whse_item_id"
      : getTableColumn(filters.granularity2)
    },
    SUM(CD_inventory_value) AS CD_inventory_value,
    SUM(LD_inventory_value) AS LD_inventory_value,
    AVG(LD_inventory_value_chg) as LD_inventory_value_chg,
    AVG(L14D_inventory_value_chg) AS L14D_inventory_value_chg,
    SUM(L14D_inventory_value) AS L14D_inventory_value,

    SUM(CD_prod_qty) AS CD_prod_qty,
    SUM(LD_prod_qty) AS LD_prod_qty,
    AVG(LD_prod_qty_chg) AS LD_prod_qty_chg,
    AVG(L14D_prod_qty_chg) AS L14D_prod_qty_chg,
    SUM(L14D_prod_qty) AS L14D_prod_qty,

    AVG(CD_WOH) AS CD_WOH,
    AVG(LD_WOH) AS LD_WOH,
    AVG(LD_WOH_chg) AS LD_WOH_chg,
    AVG(L14D_WOH_chg) AS L14D_WOH_chg,
    AVG(L14_days_WOH) AS L14_days_WOH,

    AVG(CD_OOS_pct) AS CD_OOS_pct,
    AVG(LD_OOS_pct) AS LD_OOS_pct,
    AVG(LD_OOS_pct_chg) AS LD_OOS_pct_chg,
    AVG(L14D_OOS_pct_chg) AS L14D_OOS_pct_chg,
    AVG(L14D_OOS_PCT) AS L14D_OOS_PCT,

    SUM(CD_sku) AS CD_sku,
    SUM(LD_sku) AS LD_sku,
    AVG(LD_sku_chg) AS LD_sku_chg,
    AVG(L14D_sku_chg) AS L14D_sku_chg,
    SUM(L14D_sku) AS L14D_sku,

    SUM(CD_excess_sku) AS CD_excess_sku,
    SUM(LD_excess_sku) AS LD_excess_sku,
    AVG(LD_excess_sku_chg) AS LD_excess_sku_chg,
    AVG(L14D_excess_sku_chg) AS L14D_excess_sku_chg,
    SUM(L14_days_excess_sku) AS L14_days_excess_sku,

    SUM(CD_excess_qty) AS CD_excess_qty,
    SUM(LD_excess_qty) AS LD_excess_qty,
    AVG(LD_excess_qty_chg) AS LD_excess_qty_chg,
    AVG(L14D_excess_qty_chg) AS L14D_excess_qty_chg,
    SUM(L14D_excess_qty) AS L14D_excess_qty,

    SUM(CD_exp_prod) AS CD_exp_prod,
    SUM(LD_exp_prod) AS LD_exp_prod,
    AVG(LD_exp_prod_chg) AS LD_exp_prod_chg,
    AVG(L14D_exp_prod_chg) AS L14D_exp_prod_chg,
    SUM(L14D_exp_prod) AS L14D_exp_prod,

    AVG(CD_age_of_inventory) as CD_age_of_inventory,
  AVG(LD_age_of_inventory) as LD_age_of_inventory,
  AVG(LD_age_of_inventory_chg) as LD_age_of_inventory_chg,
  AVG(L14D_age_of_inventory_chg) as L14D_age_of_inventory_chg ,
 
  AVG(L14D_age_of_inventory) as  L14D_age_of_inventory

  FROM final
 UNION ALL
  SELECT 
  1 AS sort_order, * FROM final)
  ORDER BY ${orderBy}`;

  if (_get(filters, "pageNo")) {
    query = query.concat(` limit ${limit} OFFSET ${offset}`);
  }

  return { query };
};

const inventoryProductCount = async ({ filters }) => {
  let {
    kpiFilter,
    selectedCategoryValue,
    selectedDeptValue,
    selectedGraphValue,
  } = filters;

  // Convert camelCase keys to snake_case column names
  kpiFilter = keyToColumnMap[kpiFilter];
  const defaultBuckets = ["0-30 Days", "31-60 Days", "61-90 Days", "90+ Days"];

  const mapNumericToBucket = (value) => {
    const num = parseInt(value);
    if (isNaN(num)) return null;

    if (num >= 0 && num <= 30) return "0-30 Days";
    if (num >= 31 && num <= 60) return "31-60 Days";
    if (num >= 61 && num <= 90) return "61-90 Days";
    if (num > 90) return "90+ Days";

    return null;
  };

  // Normalize agingBucket filter value
  let selectedBucket = filters.agingBucket;

  if (selectedBucket && !defaultBuckets.includes(selectedBucket)) {
    const mappedBucket = mapNumericToBucket(selectedBucket);
    if (mappedBucket) {
      selectedBucket = mappedBucket;
    } else {
      selectedBucket = null; // fallback if not matched
    }
  }

  const columnTypes = {
    organization_cde: "string",
    whse_id: "number",
    whse_name: "string",
    // Add more columns and types as needed
  };

  const needsFilter =
    selectedGraphValue && selectedGraphValue.toUpperCase?.() !== "ALL";
  const needsDepartmentFilter =
    selectedDeptValue && selectedDeptValue.toUpperCase?.() !== "ALL";
  const needsCategoryFilter =
    selectedCategoryValue && selectedCategoryValue.toUpperCase?.() !== "ALL";

  const isNumeric = columnTypes[kpiFilter] === "number";

  const filterCondition = needsFilter
    ? isNumeric
      ? `AND ${kpiFilter} = ${selectedGraphValue}`
      : `AND ${kpiFilter} = '${selectedGraphValue}'`
    : "";

  // console.log(filterCondition)

  const filterCondition1 = needsDepartmentFilter
    ? `AND dept_desc ='${selectedDeptValue}'`
    : "";

  const filterCondition2 = needsCategoryFilter
    ? `AND cs_item_category_desc ='${selectedCategoryValue}'`
    : "";
  let query = `
SELECT count(*) as totalCount FROM(
WITH base AS (
  SELECT
    DateRange,
    inventory_date,
    ${getTableColumn(filters.granularity1)},
    ${getTableColumn(filters.granularity2)},
    SUM(inventory_value) AS inventory_value,
    SUM(inventory_qty) AS inventory_qty,
      avg(weighted_inventory_age) as age_of_inventory,
    SAFE_DIVIDE(SUM(inventory_qty), NULLIF(SUM(max_total_shipped_qty) / 13, 0)) AS days_WOH,
    COUNT(DISTINCT whse_item_id) AS total_sku,
    COUNT(DISTINCT CASE WHEN out_of_stock_prod = 'Y' THEN whse_item_id END) AS oos_sku,
    COUNT(whse_item_id) AS sku_count,
    COUNTIF(Inventory_Level = "Excess Inventory") AS excess_sku,
    SUM(CASE WHEN Inventory_Level = "Excess Inventory" THEN inventory_qty ELSE 0 END) AS excess_qty,
    COUNT(UPC_Exp_Prod) AS exp_prod
  FROM ${baseTable} WHERE ${fetchWhereClause({
    filters,
  })} ${filterCondition} ${filterCondition1} ${filterCondition2}
  ${selectedBucket ? ` AND aging_bucket='${selectedBucket}'` : ""} and
    whse_item_id in (select distinct(whse_item_id) from(
        SELECT
          whse_item_id,
          --SUM(Prod_Qty) AS Total_Qty,
          MAX(reorder_point) AS Max_Repln_Level,
          CASE
            WHEN SUM(inventory_qty) < MAX(reorder_point) THEN "Below Reorder point"
            ELSE "instock"
          END AS Replenishment_Status
        FROM ${baseTable}
        where daterange='CD'
        GROUP BY
          whse_item_id)
      ${filters.replenishmentStatus
      ? `WHERE Replenishment_Status="${filters.replenishmentStatus === "Instock"
        ? "instock"
        : "Below Reorder point"
      }"`
      : ""
    }
      )
  GROUP BY all
),
agg AS (
  SELECT 
  ${filters.granularity1 == "itemCode"
      ? "whse_item_id"
      : getTableColumn(filters.granularity1)
    },
  ${filters.granularity2 == "itemCode"
      ? "whse_item_id"
      : getTableColumn(filters.granularity2)
    },
    -- CD metrics
    SUM(CASE WHEN DateRange = 'CD' THEN inventory_value ELSE 0 END) AS CD_inventory_value,
    SUM(CASE WHEN DateRange = 'CD' THEN inventory_qty ELSE 0 END) AS CD_prod_qty,
    AVG(CASE WHEN DateRange = 'CD' THEN days_WOH END) AS CD_days_WOH,
    SAFE_DIVIDE(SUM(CASE WHEN DateRange = 'CD' THEN oos_sku END),
                NULLIF(SUM(CASE WHEN DateRange = 'CD' THEN total_sku END), 0)) * 100 AS CD_OOS_pct,
    SUM(CASE WHEN DateRange = 'CD' THEN sku_count ELSE 0 END) AS CD_sku,
    SUM(CASE WHEN DateRange = 'CD' THEN excess_sku ELSE 0 END) AS CD_excess_sku,
    SUM(CASE WHEN DateRange = 'CD' THEN excess_qty ELSE 0 END) AS CD_excess_qty,
    SUM(CASE WHEN DateRange = 'CD' THEN exp_prod ELSE 0 END) AS CD_exp_prod,
        AVG(CASE WHEN DateRange = 'CD' THEN age_of_inventory ELSE 0 END) AS CD_age_of_inventory,

    -- LD metrics
    SUM(CASE WHEN DateRange = 'LD' THEN inventory_value ELSE 0 END) AS LD_inventory_value,
    SUM(CASE WHEN DateRange = 'LD' THEN inventory_qty ELSE 0 END) AS LD_prod_qty,
    AVG(CASE WHEN DateRange = 'LD' THEN days_WOH END) AS LD_days_WOH,
    SAFE_DIVIDE(SUM(CASE WHEN DateRange = 'LD' THEN oos_sku END),
                NULLIF(SUM(CASE WHEN DateRange = 'LD' THEN total_sku END), 0)) * 100 AS LD_OOS_pct,
    SUM(CASE WHEN DateRange = 'LD' THEN sku_count ELSE 0 END) AS LD_sku,
    SUM(CASE WHEN DateRange = 'LD' THEN excess_sku ELSE 0 END) AS LD_excess_sku,
    SUM(CASE WHEN DateRange = 'LD' THEN excess_qty ELSE 0 END) AS LD_excess_qty,
    SUM(CASE WHEN DateRange = 'LD' THEN exp_prod ELSE 0 END) AS LD_exp_prod,
    AVG(CASE WHEN DateRange = 'LD' THEN age_of_inventory ELSE 0 END) AS LD_age_of_inventory,

    -- L14 (all except CD)
    AVG(CASE WHEN DateRange != 'CD' THEN inventory_value END) AS L14_days_inventory_value,
    AVG(CASE WHEN DateRange != 'CD' THEN inventory_qty END) AS L14_days_prod_qty,
    AVG(CASE WHEN DateRange != 'CD' THEN days_WOH END) AS L14_days_WOH,
    AVG(SAFE_DIVIDE(
      CASE WHEN DateRange != 'CD' THEN oos_sku END,
      CASE WHEN DateRange != 'CD' THEN NULLIF(total_sku, 0) END
)) * 100 AS L14_day_OOS_PCT,
   -- AVG(SAFE_DIVIDE(oos_sku, NULLIF(total_sku, 0))) * 100 AS L14_day_OOS_PCT,
    AVG(CASE WHEN DateRange != 'CD' THEN sku_count END) AS L14_days_sku,
    AVG(CASE WHEN DateRange != 'CD' THEN excess_sku END) AS L14_days_excess_sku,
    AVG(CASE WHEN DateRange != 'CD' THEN excess_qty END) AS L14_days_excess_qty,
    AVG(CASE WHEN DateRange != 'CD' THEN exp_prod END) AS L14_days_exp_prod,
     AVG(CASE WHEN DateRange != 'CD' THEN age_of_inventory END) AS L14_age_of_inventory
  FROM base
  group by all
),


final as(
SELECT
  -- Inventory value
${filters.granularity1 == "itemCode"
      ? "whse_item_id"
      : getTableColumn(filters.granularity1)
    },
  ${filters.granularity2 == "itemCode"
      ? "whse_item_id"
      : getTableColumn(filters.granularity2)
    },
  CD_inventory_value,
  LD_inventory_value,
  SAFE_DIVIDE(CD_inventory_value - LD_inventory_value, NULLIF(LD_inventory_value, 0)) * 100 AS LD_inventory_value_chg,
  SAFE_DIVIDE(CD_inventory_value - L14_days_inventory_value, NULLIF(L14_days_inventory_value, 0)) * 100 AS L14D_inventory_value_chg,
  L14_days_inventory_value as L14D_inventory_value,

  -- Inventory qty
  CD_prod_qty,
  LD_prod_qty,
  SAFE_DIVIDE(CD_prod_qty - LD_prod_qty, NULLIF(LD_prod_qty, 0)) * 100 AS LD_prod_qty_chg,
  SAFE_DIVIDE(CD_prod_qty - L14_days_prod_qty, NULLIF(L14_days_prod_qty, 0)) * 100 AS L14D_prod_qty_chg,
  L14_days_prod_qty as L14D_prod_qty,

  -- WOH
  CD_days_WOH as CD_WOH,
  LD_days_WOH as LD_WOH,
  SAFE_DIVIDE(CD_days_WOH - LD_days_WOH, NULLIF(LD_days_WOH, 0)) * 100 AS LD_WOH_chg,
  SAFE_DIVIDE(CD_days_WOH - L14_days_WOH, NULLIF(L14_days_WOH, 0)) * 100 AS L14D_WOH_chg,
  L14_days_WOH,

  -- OOS
  CD_OOS_pct,
  LD_OOS_pct,
  SAFE_DIVIDE(CD_OOS_pct - LD_OOS_pct, NULLIF(LD_OOS_pct, 0)) * 100 AS LD_OOS_pct_chg,
  SAFE_DIVIDE(CD_OOS_pct - L14_day_OOS_PCT, NULLIF(L14_day_OOS_PCT, 0)) * 100 AS L14D_OOS_pct_chg,
  L14_day_OOS_PCT as L14D_OOS_PCT,

  -- SKU
  CD_sku,
  LD_sku,
  SAFE_DIVIDE(CD_sku - LD_sku, NULLIF(LD_sku, 0)) * 100 AS LD_sku_chg,
  SAFE_DIVIDE(CD_sku - L14_days_sku, NULLIF(L14_days_sku, 0)) * 100 AS L14D_sku_chg,
  L14_days_sku as L14D_sku,

  -- Excess SKU
  CD_excess_sku,
  LD_excess_sku,
  SAFE_DIVIDE(CD_excess_sku - LD_excess_sku, NULLIF(LD_excess_sku, 0)) * 100 AS LD_excess_sku_chg,
  SAFE_DIVIDE(CD_excess_sku - L14_days_excess_sku, NULLIF(L14_days_excess_sku, 0)) * 100 AS L14D_excess_sku_chg,
  L14_days_excess_sku,

  -- Excess qty
  CD_excess_qty,
  LD_excess_qty,
  SAFE_DIVIDE(CD_excess_qty - LD_excess_qty, NULLIF(LD_excess_qty, 0)) * 100 AS LD_excess_qty_chg,
  SAFE_DIVIDE(CD_excess_qty - L14_days_excess_qty, NULLIF(L14_days_excess_qty, 0)) * 100 AS L14D_excess_qty_chg,
  L14_days_excess_qty as L14D_excess_qty,

  -- Expiring products
  CD_exp_prod,
  LD_exp_prod,
  SAFE_DIVIDE(CD_exp_prod - LD_exp_prod, NULLIF(LD_exp_prod, 0)) * 100 AS LD_exp_prod_chg,
  SAFE_DIVIDE(CD_exp_prod - L14_days_exp_prod, NULLIF(L14_days_exp_prod, 0)) * 100 AS L14D_exp_prod_chg,
  L14_days_exp_prod as L14D_exp_prod,

  CD_age_of_inventory,
  LD_age_of_inventory,
  SAFE_DIVIDE(CD_age_of_inventory - LD_age_of_inventory, NULLIF(LD_age_of_inventory, 0)) * 100 AS LD_age_of_inventory_chg,
  SAFE_DIVIDE(CD_age_of_inventory - L14_age_of_inventory, NULLIF(L14_age_of_inventory, 0)) * 100 AS L14D_age_of_inventory_chg,
    L14_age_of_inventory as L14D_age_of_inventory

FROM agg)

SELECT * FROM (
  SELECT 0 AS sort_order,
    'Grand Total' AS ${filters.granularity1 == "itemCode"
      ? "whse_item_id"
      : getTableColumn(filters.granularity1)
    },
    '' AS ${filters.granularity2 == "itemCode"
      ? "whse_item_id"
      : getTableColumn(filters.granularity2)
    },
    SUM(CD_inventory_value) AS CD_inventory_value,
    SUM(LD_inventory_value) AS LD_inventory_value,
    AVG(LD_inventory_value_chg) as LD_inventory_value_chg,
    AVG(L14D_inventory_value_chg) AS L14D_inventory_value_chg,
    SUM(L14D_inventory_value) AS L14D_inventory_value,

    SUM(CD_prod_qty) AS CD_prod_qty,
    SUM(LD_prod_qty) AS LD_prod_qty,
    AVG(LD_prod_qty_chg) AS LD_prod_qty_chg,
    AVG(L14D_prod_qty_chg) AS L14D_prod_qty_chg,
    SUM(L14D_prod_qty) AS L14D_prod_qty,

    AVG(CD_WOH) AS CD_WOH,
    AVG(LD_WOH) AS LD_WOH,
    AVG(LD_WOH_chg) AS LD_WOH_chg,
    AVG(L14D_WOH_chg) AS L14D_WOH_chg,
    AVG(L14_days_WOH) AS L14_days_WOH,

    AVG(CD_OOS_pct) AS CD_OOS_pct,
    AVG(LD_OOS_pct) AS LD_OOS_pct,
    AVG(LD_OOS_pct_chg) AS LD_OOS_pct_chg,
    AVG(L14D_OOS_pct_chg) AS L14D_OOS_pct_chg,
    AVG(L14D_OOS_PCT) AS L14D_OOS_PCT,

    SUM(CD_sku) AS CD_sku,
    SUM(LD_sku) AS LD_sku,
    AVG(LD_sku_chg) AS LD_sku_chg,
    AVG(L14D_sku_chg) AS L14D_sku_chg,
    SUM(L14D_sku) AS L14D_sku,

    SUM(CD_excess_sku) AS CD_excess_sku,
    SUM(LD_excess_sku) AS LD_excess_sku,
    AVG(LD_excess_sku_chg) AS LD_excess_sku_chg,
    AVG(L14D_excess_sku_chg) AS L14D_excess_sku_chg,
    SUM(L14_days_excess_sku) AS L14_days_excess_sku,

    SUM(CD_excess_qty) AS CD_excess_qty,
    SUM(LD_excess_qty) AS LD_excess_qty,
    AVG(LD_excess_qty_chg) AS LD_excess_qty_chg,
    AVG(L14D_excess_qty_chg) AS L14D_excess_qty_chg,
    SUM(L14D_excess_qty) AS L14D_excess_qty,

    SUM(CD_exp_prod) AS CD_exp_prod,
    SUM(LD_exp_prod) AS LD_exp_prod,
    AVG(LD_exp_prod_chg) AS LD_exp_prod_chg,
    AVG(L14D_exp_prod_chg) AS L14D_exp_prod_chg,
    SUM(L14D_exp_prod) AS L14D_exp_prod,

    AVG(CD_age_of_inventory) as CD_age_of_inventory,
  AVG(LD_age_of_inventory) as LD_age_of_inventory,
  AVG(LD_age_of_inventory_chg) as LD_age_of_inventory_chg,
  AVG(L14D_age_of_inventory_chg) as L14D_age_of_inventory_chg ,
 
  AVG(L14D_age_of_inventory) as  L14D_age_of_inventory

  FROM final
 UNION ALL
  SELECT 
  1 AS sort_order, * FROM final)
)`;

  return { query };
};

module.exports = { inventoryProductQuery, inventoryProductCount };
