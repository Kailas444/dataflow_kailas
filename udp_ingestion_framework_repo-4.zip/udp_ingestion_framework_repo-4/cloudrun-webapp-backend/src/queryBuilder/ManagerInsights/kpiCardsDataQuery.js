const { baseTable } = require("../../connection/constant");
const { fetchWhereClause } = require("../../utils/generalfunctions");

// 3. Main exported function
async function kpiCardsDataQuery(filters) {

  const query1 = `SELECT inventory_date,sum(inventory_value) inventory_value,sum(inventory_qty) inventory_qty,
sum(inventory_qty)/(sum(max_total_shipped_qty)/13) WOH,count(distinct whse_item_id),
count(distinct(case when out_of_stock_prod='Y' then whse_item_id else null end))/count(distinct whse_item_id) *100 OOS,count(whse_item_id) SKU,count(distinct case when  Inventory_Level="Excess Inventory" then whse_item_id end) excess_inv_sku,
sum(case when  Inventory_Level="Excess Inventory" then inventory_qty end) excess_inv_qty,count(UPC_Exp_Prod) UPC_Exp_Prod
FROM ${baseTable}
WHERE ${fetchWhereClause(filters)} AND DateRange in ('L_3_6D','LD','CD')
group by 1
order by 1`

const query2 = `WITH base AS (
  SELECT
    DateRange,
    inventory_date,
    SUM(inventory_value) AS inventory_value,
    SUM(inventory_qty) AS inventory_qty,
    SAFE_DIVIDE(SUM(inventory_qty), NULLIF(SUM(max_total_shipped_qty) / 13, 0)) AS days_WOH,
    COUNT(DISTINCT whse_item_id) AS total_sku,
    COUNT(DISTINCT CASE WHEN out_of_stock_prod = 'Y' THEN whse_item_id END) AS oos_sku,
    COUNT(whse_item_id) AS sku_count,
    COUNTIF(Inventory_Level = "Excess Inventory") AS excess_sku,
    SUM(CASE WHEN Inventory_Level = "Excess Inventory" THEN inventory_qty ELSE 0 END) AS excess_qty,
    COUNT(UPC_Exp_Prod) AS exp_prod
  FROM ${baseTable} WHERE ${fetchWhereClause(filters)}
  GROUP BY DateRange, inventory_date
),
agg AS (
  SELECT
    -- CD metrics
    SUM(CASE WHEN DateRange = 'CD' THEN inventory_value ELSE 0 END) AS CD_inventory_value,
    SUM(CASE WHEN DateRange = 'CD' THEN inventory_qty ELSE 0 END) AS CD_prod_qty,
    AVG(CASE WHEN DateRange = 'CD' THEN days_WOH END) AS CD_days_WOH,
    SAFE_DIVIDE(SUM(CASE WHEN DateRange = 'CD' THEN oos_sku END),
                NULLIF(SUM(CASE WHEN DateRange = 'CD' THEN total_sku END), 0)) * 100 AS CD_OOS_pct,
    SUM(CASE WHEN DateRange = 'CD' THEN sku_count ELSE 0 END) AS CD_sku,
    SUM(CASE WHEN DateRange = 'CD' THEN excess_sku ELSE 0 END) AS CD_excess_sku,
    SUM(CASE WHEN DateRange = 'CD' THEN excess_qty ELSE 0 END) AS CD_excess_qty,
    SUM(CASE WHEN DateRange = 'CD' THEN exp_prod ELSE 0 END) AS CD_exp_prod,

    -- LD metrics
    SUM(CASE WHEN DateRange = 'LD' THEN inventory_value ELSE 0 END) AS LD_inventory_value,
    SUM(CASE WHEN DateRange = 'LD' THEN inventory_qty ELSE 0 END) AS LD_prod_qty,
    AVG(CASE WHEN DateRange = 'LD' THEN days_WOH END) AS LD_days_WOH,
    SAFE_DIVIDE(SUM(CASE WHEN DateRange = 'LD' THEN oos_sku END),
                NULLIF(SUM(CASE WHEN DateRange = 'LD' THEN total_sku END), 0)) * 100 AS LD_OOS_pct,
    SUM(CASE WHEN DateRange = 'LD' THEN sku_count ELSE 0 END) AS LD_sku,
    SUM(CASE WHEN DateRange = 'LD' THEN excess_sku ELSE 0 END) AS LD_excess_sku,
    SUM(CASE WHEN DateRange = 'LD' THEN excess_qty ELSE 0 END) AS LD_excess_qty,
    SUM(CASE WHEN DateRange = 'LD' THEN exp_prod ELSE 0 END) AS LD_exp_prod,

    -- L14 (all except CD)
    AVG(CASE WHEN DateRange != 'CD' THEN inventory_value END) AS L14_days_inventory_value,
    AVG(CASE WHEN DateRange != 'CD' THEN inventory_qty END) AS L14_days_prod_qty,
    AVG(CASE WHEN DateRange != 'CD' THEN days_WOH END) AS L14_days_WOH,
    AVG(SAFE_DIVIDE(
      CASE WHEN DateRange != 'CD' THEN oos_sku END,
      CASE WHEN DateRange != 'CD' THEN NULLIF(total_sku, 0) END
)) * 100 AS L14_day_OOS_PCT,

   -- AVG(SAFE_DIVIDE(oos_sku, NULLIF(total_sku, 0))) * 100 AS L14_day_OOS_PCT,
    AVG(CASE WHEN DateRange != 'CD' THEN sku_count END) AS L14_days_sku,
    AVG(CASE WHEN DateRange != 'CD' THEN excess_sku END) AS L14_days_excess_sku,
    AVG(CASE WHEN DateRange != 'CD' THEN excess_qty END) AS L14_days_excess_qty,
    AVG(CASE WHEN DateRange != 'CD' THEN exp_prod END) AS L14_days_exp_prod
  FROM base
)

SELECT
  -- Inventory value
  CD_inventory_value,
  LD_inventory_value,
  SAFE_DIVIDE(CD_inventory_value - LD_inventory_value, NULLIF(LD_inventory_value, 0)) * 100 AS LD_inventory_value_chg,
  SAFE_DIVIDE(CD_inventory_value - L14_days_inventory_value, NULLIF(L14_days_inventory_value, 0)) * 100 AS L14_days_inventory_value_chg,
  L14_days_inventory_value,

  -- Inventory qty
  CD_prod_qty,
  LD_prod_qty,
  SAFE_DIVIDE(CD_prod_qty - LD_prod_qty, NULLIF(LD_prod_qty, 0)) * 100 AS LD_prod_qty_chg,
  SAFE_DIVIDE(CD_prod_qty - L14_days_prod_qty, NULLIF(L14_days_prod_qty, 0)) * 100 AS L14_days_prod_qty_chg,
  L14_days_prod_qty,

  -- WOH
  CD_days_WOH,
  LD_days_WOH,
  SAFE_DIVIDE(CD_days_WOH - LD_days_WOH, NULLIF(LD_days_WOH, 0)) * 100 AS LD_days_WOH_chg,
  SAFE_DIVIDE(CD_days_WOH - L14_days_WOH, NULLIF(L14_days_WOH, 0)) * 100 AS L14_days_WOH_chg,
  L14_days_WOH,

  -- OOS
  CD_OOS_pct,
  LD_OOS_pct,
  SAFE_DIVIDE(CD_OOS_pct - LD_OOS_pct, NULLIF(LD_OOS_pct, 0)) * 100 AS LD_OOS_pct_chg,
  SAFE_DIVIDE(CD_OOS_pct - L14_day_OOS_PCT, NULLIF(L14_day_OOS_PCT, 0)) * 100 AS L14_OOS_pct_chg,
  L14_day_OOS_PCT,

  -- SKU
  CD_sku,
  LD_sku,
  SAFE_DIVIDE(CD_sku - LD_sku, NULLIF(LD_sku, 0)) * 100 AS LD_sku_chg,
  SAFE_DIVIDE(CD_sku - L14_days_sku, NULLIF(L14_days_sku, 0)) * 100 AS L14_days_sku_chg,
  L14_days_sku,

  -- Excess SKU
  CD_excess_sku,
  LD_excess_sku,
  SAFE_DIVIDE(CD_excess_sku - LD_excess_sku, NULLIF(LD_excess_sku, 0)) * 100 AS LD_excess_sku_chg,
  SAFE_DIVIDE(CD_excess_sku - L14_days_excess_sku, NULLIF(L14_days_excess_sku, 0)) * 100 AS L14_days_excess_sku_chg,
  L14_days_excess_sku,

  -- Excess qty
  CD_excess_qty,
  LD_excess_qty,
  SAFE_DIVIDE(CD_excess_qty - LD_excess_qty, NULLIF(LD_excess_qty, 0)) * 100 AS LD_excess_qty_chg,
  SAFE_DIVIDE(CD_excess_qty - L14_days_excess_qty, NULLIF(L14_days_excess_qty, 0)) * 100 AS L14_days_excess_qty_chg,
  L14_days_excess_qty,

  -- Expiring products
  CD_exp_prod,
  LD_exp_prod,
  SAFE_DIVIDE(CD_exp_prod - LD_exp_prod, NULLIF(LD_exp_prod, 0)) * 100 AS LD_exp_prod_chg,
  SAFE_DIVIDE(CD_exp_prod - L14_days_exp_prod, NULLIF(L14_days_exp_prod, 0)) * 100 AS L14_days_exp_prod_chg,
  L14_days_exp_prod

FROM agg;`

    return { query1, query2 };

}

module.exports =  {kpiCardsDataQuery};
