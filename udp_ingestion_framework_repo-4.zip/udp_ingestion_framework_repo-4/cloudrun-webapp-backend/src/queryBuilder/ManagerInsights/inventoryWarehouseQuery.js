const { baseTable } = require("../../connection/constant");

const { fetchWhereClause } = require("../../utils/generalfunctions");

const metricOrderMap = {
  inventoryValue: 'inventory_value',
  inventoryQty: 'inventory_qty',
  WOH: 'WOH',
  outOfStock: 'OOS',
  countofSKU: 'SKU',
  excessInventorySKU: 'excess_inv_sku',
  excessInventoryQty: 'excess_inv_qty',
  organizationCde: 'organization_cde',
  whseName: 'whse_name',
  whseId: 'whse_id'
};

async function inventoryWarehouseQuery({ filters }) {

const orderByColumn = metricOrderMap[filters.kpiSelected];

const groupByxAxis = metricOrderMap[filters.xAxisSelected];

const query = `
WITH CD_value AS (
  SELECT 
    ${groupByxAxis},
    SUM(inventory_value) AS inventory_value,
    SUM(inventory_qty) AS inventory_qty,
    SAFE_DIVIDE(SUM(inventory_qty), (SUM(max_total_shipped_qty)/13)) AS WOH,
    COUNT(DISTINCT whse_item_id) AS SKU,
    COUNT(DISTINCT CASE WHEN out_of_stock_prod='Y' THEN whse_item_id ELSE NULL END) / COUNT(DISTINCT whse_item_id) * 100 AS OOS,
    COUNT(whse_item_id) AS SKU_total,
    COUNT(DISTINCT CASE WHEN Inventory_Level="Excess Inventory" THEN whse_item_id END) AS excess_inv_sku,
    SUM(CASE WHEN Inventory_Level="Excess Inventory" THEN inventory_qty END) AS excess_inv_qty,
    COUNT(UPC_Exp_Prod) AS UPC_Exp_Prod
  FROM ${baseTable}
  WHERE ${fetchWhereClause({ filters })} AND DateRange IN ('CD')
  GROUP BY 1
),

L14D_value AS (
  SELECT 
    ${groupByxAxis},
    AVG(inventory_value) AS l14_inventory_value,
    AVG(inventory_qty) AS l14_inventory_qty,
    AVG(WOH) AS l14_WOH,
    AVG(SKU) AS l14_SKU,
    AVG(OOS) AS l14_OOS,
    AVG(excess_inv_sku) AS l14_excess_inv_sku,
    AVG(excess_inv_qty) AS l14_excess_inv_qty,
    AVG(UPC_Exp_Prod) AS l14_UPC_Exp_Prod
  FROM (
    SELECT 
      inventory_date,
      ${groupByxAxis},
      SUM(inventory_value) AS inventory_value,
      SUM(inventory_qty) AS inventory_qty,
      SAFE_DIVIDE(SUM(inventory_qty), (SUM(max_total_shipped_qty)/13)) AS WOH,
      COUNT(DISTINCT whse_item_id) AS SKU,
      COUNT(DISTINCT CASE WHEN out_of_stock_prod='Y' THEN whse_item_id ELSE NULL END) / COUNT(DISTINCT whse_item_id) * 100 AS OOS,
      COUNT(DISTINCT CASE WHEN Inventory_Level="Excess Inventory" THEN whse_item_id END) AS excess_inv_sku,
      SUM(CASE WHEN Inventory_Level="Excess Inventory" THEN inventory_qty END) AS excess_inv_qty,
      COUNT(UPC_Exp_Prod) AS UPC_Exp_Prod
    FROM ${baseTable}
    WHERE ${fetchWhereClause({ filters })} AND DateRange NOT IN ('CD')
    GROUP BY 1,2
  )
  GROUP BY 1
)

SELECT 
  a.${groupByxAxis},
  a.inventory_value,
  a.inventory_qty,
  a.WOH,
  a.OOS,
  a.SKU,
  a.excess_inv_sku,
  a.excess_inv_qty,
  a.UPC_Exp_Prod,
  b.l14_inventory_value,
  b.l14_inventory_qty,
  b.l14_WOH,
  b.l14_SKU,
  b.l14_OOS,
  b.l14_excess_inv_sku,
  b.l14_excess_inv_qty,
  b.l14_UPC_Exp_Prod
FROM CD_value a
JOIN L14D_value b
 ON a.${groupByxAxis} = b.${groupByxAxis} 
  ORDER BY ${orderByColumn} DESC
`;

    return { query }
}

module.exports = { inventoryWarehouseQuery };
