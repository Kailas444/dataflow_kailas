//const { } = require("../../mappers")
//const { } = require("../../queryBuilder")
const { baseTable } = require("../../connection/constant");

const detailedAnalysisDataQuery = async (filters) => {
    const allowedFields = [
        'inventoryOrganisationName',
        'warehouseName',
        'itemDepartment',
        'itemCategory',
        'itemCode',
        'itemDescription',
        'measureName',
        'granularity-1',
        'granularity-2',
        'granularity-3'
    ];

    const field = filters.field?.trim();
    if (!field || !allowedFields.includes(field)) {
        throw new Error('Invalid or missing field parameter');
    }

    // Pagination params
    const page = parseInt(filters.page) || 1;
    const limit = parseInt(filters.limit) || 20;
    const offset = (page - 1) * limit;

    let query = `SELECT DISTINCT ${field} FROM \`your_dataset.your_table\``;
    const params = [];

    // Filtering logic
    const filterValue = filters[field]?.trim();
    if (filterValue && filterValue.toUpperCase() !== 'ALL') {
        const values = filterValue.split(',').map(v => v.trim());
        const placeholders = values.map(() => '?').join(',');
        query += ` WHERE ${field} IN (${placeholders})`;
        params.push(...values);
    }

    // Add pagination
    query += ` ORDER BY ${field} ASC LIMIT @limit OFFSET @offset`;
    params.push(limit, offset);

    // Build parameter types
    const queryParameters = [];

    // Positional params for WHERE clause
    if (filterValue && filterValue.toUpperCase() !== 'ALL') {
        const values = filterValue.split(',').map(v => v.trim());
        values.forEach(value => {
            queryParameters.push({
                parameterType: { type: 'STRING' },
                parameterValue: { value }
            });
        });
    }

    // Named params for limit and offset
    queryParameters.push({
        name: 'limit',
        parameterType: { type: 'INT64' },
        parameterValue: { value: limit }
    });

    queryParameters.push({
        name: 'offset',
        parameterType: { type: 'INT64' },
        parameterValue: { value: offset }
    });

    const [job] = await bigquery.createQueryJob({
        query,
        location: 'US',
        parameterMode: 'POSITIONAL',
        queryParameters
    });

    const [rows] = await job.getQueryResults();
    return rows;
}


module.exports = detailedAnalysisDataQuery