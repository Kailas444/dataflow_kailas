const { fetchWhereClause } = require("../../utils/generalfunctions");
const { baseTable } = require("../../connection/constant");

// Define default aging buckets
const defaultAgingBuckets = [
  "0-30 Days",
  "31-60 Days",
  "61-90 Days",
  "90+ Days",
];

// Generate SUMs for inventory_qty and inventory_value
function buildAgingBucketSums(buckets) {
  let qtySums = "";
  let valSums = "";

  buckets.forEach((bucket) => {
    qtySums += `SUM(CASE WHEN aging_bucket = '${bucket}' THEN inventory_qty ELSE 0 END) AS \`${bucket} Inv_qty\`,\n    `;
    valSums += `SUM(CASE WHEN aging_bucket = '${bucket}' THEN inventory_value ELSE 0 END) AS \`${bucket} Inv_value\`,\n    `;
  });

  return { qtySums, valSums };
}

// Generate % expressions for inventory_qty and inventory_value
function buildAgingBucketPercents(buckets, fieldType = "qty") {
  const suffix = fieldType === "qty" ? "Inv_qty" : "Inv_value";
  const percentSuffix = `${suffix}_%`;

  const totalExpr = buckets
    .map((bucket) => `COALESCE(\`${bucket} ${suffix}\`, 0)`)
    .join(" + ");

  return buckets
    .map((bucket) => {
      const current = `COALESCE(\`${bucket} ${suffix}\`, 0)`;
      return `SAFE_DIVIDE(${current}, NULLIF(${totalExpr}, 0)) * 100 AS \`${bucket} ${percentSuffix}\``;
    })
    .join(",\n  ");
}

// MAIN QUERY BUILDER
const inventoryAgingWarehouseQuery = async ({ filters }) => {
  const whereClause = fetchWhereClause({ filters });

  const defaultBuckets = ["0-30 Days", "31-60 Days", "61-90 Days", "90+ Days"];

  // Map numeric input (e.g. '33') to corresponding bucket string
  const mapNumericToBucket = (value) => {
    const num = parseInt(value);
    if (isNaN(num)) return null;

    if (num >= 0 && num <= 30) return "0-30 Days";
    if (num >= 31 && num <= 60) return "31-60 Days";
    if (num >= 61 && num <= 90) return "61-90 Days";
    if (num > 90) return "90+ Days";

    return null;
  };

  // Normalize agingBucket filter value
  let selectedBucket = filters.agingBucket;

  if (selectedBucket && !defaultBuckets.includes(selectedBucket)) {
    const mappedBucket = mapNumericToBucket(selectedBucket);
    if (mappedBucket) {
      selectedBucket = mappedBucket;
    } else {
      selectedBucket = null; // fallback if not matched
    }
  }

  const displayBuckets =
    selectedBucket === "ALL" || !selectedBucket
      ? defaultBuckets
      : [selectedBucket]; // Show only selected bucket

  // Always use all buckets for calculations
  const agingBuckets = defaultAgingBuckets;

  // Build SUMs
  const { qtySums, valSums } = buildAgingBucketSums(agingBuckets);

  // Build %s
  const qtyPercents = buildAgingBucketPercents(agingBuckets, "qty");
  const valPercents = buildAgingBucketPercents(agingBuckets, "value");

  // SELECT fields (filtered)
  const absQtyFields = displayBuckets
    .map((bucket) => `\`${bucket} Inv_qty\``)
    .join(",\n  ");
  const absValFields = displayBuckets
    .map((bucket) => `\`${bucket} Inv_value\``)
    .join(",\n  ");
  const percQtyFields = displayBuckets
    .map((bucket) => `\`${bucket} Inv_qty_%\``)
    .join(",\n  ");
  const percValFields = displayBuckets
    .map((bucket) => `\`${bucket} Inv_value_%\``)
    .join(",\n  ");

  const query = `
WITH aggregated AS (
  SELECT
    whse_name,
    ${qtySums}
    ${valSums}
  FROM ${baseTable}
  WHERE Daterange = 'CD' AND ${whereClause}
  and
    whse_item_id in (select distinct(whse_item_id) from(
        SELECT
          whse_item_id,
          --SUM(Prod_Qty) AS Total_Qty,
          MAX(reorder_point) AS Max_Repln_Level,
          CASE
            WHEN SUM(inventory_qty) < MAX(reorder_point) THEN "Below Reorder point"
            ELSE "instock"
          END AS Replenishment_Status
        FROM ${baseTable}
        where daterange='CD'
        GROUP BY
          whse_item_id)
       ${
         filters.replenishmentStatus
           ? `WHERE Replenishment_Status="${
               filters.replenishmentStatus === "Instock"
                 ? "instock"
                 : "Below Reorder point"
             }"`
           : ""
       }
        )
  GROUP BY whse_name
),
 
final AS (
  SELECT
    *,
    ${qtyPercents},
    ${valPercents}
  FROM aggregated
)
 
SELECT
  whse_name,
  ${absQtyFields},
  ${absValFields},
  ${percQtyFields},
  ${percValFields}
FROM final
ORDER BY whse_name;
`;

  return { query };
};

module.exports = {
  inventoryAgingWarehouseQuery,
};
