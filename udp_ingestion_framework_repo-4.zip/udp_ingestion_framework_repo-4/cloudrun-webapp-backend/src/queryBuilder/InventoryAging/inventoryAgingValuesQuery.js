//const { } = require("../../mappers")
//const { } = require("../../queryBuilder")

const { fetchWhereClause } = require("../../utils/generalfunctions");
const { baseTable } = require("../../connection/constant");

const inventoryAgingStatusQuery = async ({ filters }) => {
  const defaultBuckets = ["0-30 Days", "31-60 Days", "61-90 Days", "90+ Days"];

  // Map numeric input (e.g. '33') to corresponding bucket string
  const mapNumericToBucket = (value) => {
    const num = parseInt(value);
    if (isNaN(num)) return null;

    if (num >= 0 && num <= 30) return "0-30 Days";
    if (num >= 31 && num <= 60) return "31-60 Days";
    if (num >= 61 && num <= 90) return "61-90 Days";
    if (num > 90) return "90+ Days";

    return null;
  };

  // Normalize agingBucket filter value
  let selectedBucket = filters.agingBucket;

  if (selectedBucket && !defaultBuckets.includes(selectedBucket)) {
    const mappedBucket = mapNumericToBucket(selectedBucket);
    if (mappedBucket) {
      selectedBucket = mappedBucket;
    } else {
      selectedBucket = null; // fallback if not matched
    }
  }

  const displayBuckets =
    selectedBucket === "ALL" || !selectedBucket
      ? defaultBuckets
      : [selectedBucket]; // Show only selected bucket
  let query = `SELECT 
    risk_category,
  count(distinct(whse_item_id)) AS Inv_qty,
  SUM(inventory_value) AS Inv_value,

FROM ${baseTable}
where daterange='CD' AND ${fetchWhereClause({ filters })}${
    selectedBucket ? ` AND aging_bucket='${selectedBucket}'` : ""
  }
  and
    whse_item_id in (select distinct(whse_item_id) from(
        SELECT
          whse_item_id,
          --SUM(Prod_Qty) AS Total_Qty,
          MAX(reorder_point) AS Max_Repln_Level,
          CASE
            WHEN SUM(inventory_qty) < MAX(reorder_point) THEN "Below Reorder point"
            ELSE "instock"
          END AS Replenishment_Status
        FROM ${baseTable}
        where daterange='CD'
        GROUP BY
          whse_item_id)
     ${
       filters.replenishmentStatus
         ? `WHERE Replenishment_Status="${
             filters.replenishmentStatus === "Instock"
               ? "instock"
               : "Below Reorder point"
           }"`
         : ""
     }
    )
GROUP BY all`;
  return { query };
};

module.exports = { inventoryAgingStatusQuery };
