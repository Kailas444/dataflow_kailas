const { fetchWhereClause } = require("../../utils/generalfunctions");
const { baseTable } = require("../../connection/constant");

const inventoryAgingBucketQuery = async ({ filters }) => {
  const whereClause = fetchWhereClause({ filters });

  const defaultBuckets = ['0-30 Days', '31-60 Days', '61-90 Days', '90+ Days'];

  // Map numeric input (e.g. '33') to corresponding bucket string
  const mapNumericToBucket = (value) => {
    const num = parseInt(value);
    if (isNaN(num)) return null;

    if (num >= 0 && num <= 30) return '0-30 Days';
    if (num >= 31 && num <= 60) return '31-60 Days';
    if (num >= 61 && num <= 90) return '61-90 Days';
    if (num > 90) return '90+ Days';

    return null;
  };

  // Normalize agingBucket filter value
  let selectedBucket = filters.agingBucket;

  if (selectedBucket && !defaultBuckets.includes(selectedBucket)) {
    const mappedBucket = mapNumericToBucket(selectedBucket);
    if (mappedBucket) {
      selectedBucket = mappedBucket;
    } else {
      selectedBucket = null; // fallback if not matched
    }
  }

  const displayBuckets = selectedBucket === 'ALL' || !selectedBucket
    ? defaultBuckets
    : [selectedBucket]; // Show only selected bucket

  const bucketFilter = displayBuckets.map(bucket => `'${bucket}'`).join(',');

  const query = `WITH base AS (
    SELECT aging_bucket AS AgingBucket,
      SUM(CASE WHEN DateRange = 'CD' THEN inventory_qty ELSE 0 END) AS Inv_qty_CD,
      SUM(CASE WHEN DateRange = 'CD' THEN inventory_value ELSE 0 END) AS Inv_value_CD
    FROM ${baseTable}
    WHERE ${whereClause} ${selectedBucket ? ` AND aging_bucket='${selectedBucket}'` : ''} and
    whse_item_id in (select distinct(whse_item_id) from(
        SELECT
          whse_item_id,
          --SUM(Prod_Qty) AS Total_Qty,
          MAX(reorder_point) AS Max_Repln_Level,
          CASE
            WHEN SUM(inventory_qty) < MAX(reorder_point) THEN "Below Reorder point"
            ELSE "instock"
          END AS Replenishment_Status
        FROM ${baseTable}
        where daterange='CD'
        GROUP BY
          whse_item_id)
       ${
         filters.replenishmentStatus
           ? `WHERE Replenishment_Status="${
               filters.replenishmentStatus === "Instock"
                 ? "instock"
                 : "Below Reorder point"
             }"`
           : ""
       }
      )
    GROUP BY AgingBucket
    ORDER BY AgingBucket
  ),

  aging AS (
    SELECT aging_bucket AS AgingBucket,
      SAFE_DIVIDE(
        SUM(CASE WHEN DateRange = 'CD' THEN inventory_qty END),
        SUM(SUM(CASE WHEN DateRange = 'CD' THEN inventory_qty END)) OVER()
      ) * 100 AS Pct_Inv_qty_CD,
      SAFE_DIVIDE(
        SUM(CASE WHEN DateRange = 'CD' THEN inventory_value END),
        SUM(SUM(CASE WHEN DateRange = 'CD' THEN inventory_value END)) OVER()
      ) * 100 AS Pct_Inv_value_CD,
      SAFE_DIVIDE(
        SUM(CASE WHEN DateRange != 'CD' THEN inventory_qty END),
        SUM(SUM(CASE WHEN DateRange != 'CD' THEN inventory_qty END)) OVER()
      ) * 100 AS Pct_Inv_qty_L14_Day,
      SAFE_DIVIDE(
        SUM(CASE WHEN DateRange != 'CD' THEN inventory_value END),
        SUM(SUM(CASE WHEN DateRange != 'CD' THEN inventory_value END)) OVER()
      ) * 100 AS Pct_Inv_value_L14_Day
    FROM ${baseTable}
    GROUP BY AgingBucket
    ORDER BY AgingBucket
  )

  SELECT a.*, b.* EXCEPT(AgingBucket) 
  FROM base b
  JOIN aging a ON a.AgingBucket = b.AgingBucket ORDER BY a.AgingBucket ASC`;

  return { query };
};

module.exports = {
  inventoryAgingBucketQuery
};
