//const { } = require("../../mappers")
//const { } = require("../../queryBuilder")
 
const { fetchWhereClause } = require("../../utils/generalfunctions");
const { baseTable } = require("../../connection/constant");
 
const stockDaysQuery = async ({ filters }) => {
  const defaultBuckets = ["0-30 Days", "31-60 Days", "61-90 Days", "90+ Days"];
 
  let query = `WITH base AS (
  SELECT
    CAST(FLOOR(CAST(weighted_inventory_age AS FLOAT64)) AS INT64) AS age_i,  -- floored age
    inventory_qty
  FROM ${baseTable}
  WHERE Daterange = 'CD' and ${fetchWhereClause({ filters })} ${
    filters.agingBucket && defaultBuckets.includes(filters.agingBucket)
      ? ` AND aging_bucket='${filters.agingBucket}'`
      : ""
  } and
    whse_item_id in (select distinct(whse_item_id) from(
        SELECT
          whse_item_id,
          --SUM(Prod_Qty) AS Total_Qty,
          MAX(reorder_point) AS Max_Repln_Level,
          CASE
            WHEN SUM(inventory_qty) < MAX(reorder_point) THEN "Below Reorder point"
            ELSE "instock"
          END AS Replenishment_Status
        FROM ${baseTable}
        where daterange='CD'
        GROUP BY
          whse_item_id)
        ${
          filters.replenishmentStatus
            ? `WHERE Replenishment_Status="${
                filters.replenishmentStatus === "Instock"
                  ? "instock"
                  : "Below Reorder point"
              }"`
            : ""
        }
        )
    AND weighted_inventory_age IS NOT NULL
    AND weighted_inventory_age >= 0
),
bucketed AS (
  SELECT
    CASE
      WHEN age_i > 180 THEN '180+'
      WHEN age_i <= 6 THEN '0-6'
      ELSE FORMAT(
        '%d-%d',
        CAST(FLOOR((age_i - 7) / 6) * 6 + 7 AS INT64),
        CAST(LEAST(FLOOR((age_i - 7) / 6) * 6 + 7 + 5, 180) AS INT64)
      )
    END AS weighted_inventory_age,
    CASE
      WHEN age_i > 180 THEN 9999
      WHEN age_i <= 6 THEN 0
      ELSE CAST(FLOOR((age_i - 7) / 6) * 6 + 7 AS INT64)
    END AS bucket_sort_key,
    inventory_qty
  FROM base
)
SELECT
  weighted_inventory_age,
  SUM(inventory_qty) AS inventory_qty
FROM bucketed
GROUP BY weighted_inventory_age, bucket_sort_key
ORDER BY bucket_sort_key`;
 
  console.log(query);
 
  return { query };
};
 
module.exports = { stockDaysQuery };