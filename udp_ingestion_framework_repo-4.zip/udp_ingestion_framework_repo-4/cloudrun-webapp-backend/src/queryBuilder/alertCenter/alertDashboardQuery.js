const { fetchWhereClause } = require("../../utils/generalfunctions");
const { get: _get } = require("lodash")
const { alertCenterTable, latestTable, oldTable, baseTable } = require("../../connection/constant");

const alertDashboardQuery = async ({ filters }) => {
  const offset = _get(filters, 'offset') >= 0 ? _get(filters, 'offset') : (_get(filters, 'pageNo') && _get(filters, 'limit')) ? (_get(filters, 'pageNo') - 1) * _get(filters, 'limit') : 50;
  const limit = _get(filters, 'limit') ? _get(filters, 'limit') : 50;
  let query = `WITH cfg AS (
  SELECT
    COALESCE(MAX(IF(rule_key='EXPIRY_WITHIN_DAYS',       threshold_value, NULL)), 60.0)    AS expiry_within_days,
    COALESCE(MAX(IF(rule_key='NEAR_EXPIRY_PCT',          threshold_value, NULL)), 20.0)    AS near_expiry_pct,
    COALESCE(MAX(IF(rule_key='DAYS_IN_STOCK_GT_DAYS',    threshold_value, NULL)), 100.0)   AS dis_gt_days,
    COALESCE(MAX(IF(rule_key='WEIGHTED_AGE_GT_DAYS',     threshold_value, NULL)), 120.0)   AS weighted_age_days,
    COALESCE(MAX(IF(rule_key='NO_SALE_STALE_DAYS',       threshold_value, NULL)), 30.0)    AS no_sale_days,
    COALESCE(MAX(IF(rule_key='HIGH_VALUE_USD',           threshold_value, NULL)), 25000.0) AS high_value_usd,
    COALESCE(MAX(IF(rule_key='MIN_NO_SALES_SKU_PCT',      threshold_value, NULL)),  5.0)    AS min_no_sales_sku_pct,

    COALESCE(MAX(IF(rule_key='MIN_EXCESS_INV2_SKU_PCT', threshold_value, NULL)), 5.0)  AS min_excess_inv2_sku_pct,
COALESCE(MAX(IF(rule_key='MIN_LOW_INV2_SKU_PCT',   threshold_value, NULL)), 10.0) AS min_low_inv2_sku_pct,
    

    -- NEW: alert gating minimums (override via rule_config if you add these keys)
    COALESCE(MAX(IF(rule_key='MIN_DIS_SKU_PCT',              threshold_value, NULL)), 10.0)   AS min_dis_sku_pct,
    COALESCE(MAX(IF(rule_key='MIN_WAGE_SKU_PCT',             threshold_value, NULL)), 10.0)   AS min_wage_sku_pct,
    COALESCE(MAX(IF(rule_key='MIN_REPL_PCT',                 threshold_value, NULL)), 10.0)   AS min_repl_pct,
    COALESCE(MAX(IF(rule_key='MIN_NEAR_EXP_VALUE_PCT',       threshold_value, NULL)), 5.0)    AS min_near_exp_value_pct,
    COALESCE(MAX(IF(rule_key='MIN_NEAR_EXP_VALUE_USD',       threshold_value, NULL)), 500000) AS min_near_exp_value_usd,
    COALESCE(MAX(IF(rule_key='MIN_NEAR_EXP_SKU_PCT',         threshold_value, NULL)), 4.0)    AS min_near_exp_sku_pct,
    COALESCE(MAX(IF(rule_key='MIN_NEAR_EXP_SKU_CNT',         threshold_value, NULL)), 15.0)   AS min_near_exp_sku_cnt
  FROM ${alertCenterTable} 
),

inv AS (
  SELECT
    whse_id,
    whse_name,
    CAST(item_category_id AS STRING)              AS category_id,
    cs_item_category_desc                         AS category_name,
    UPPER(TRIM(inventory_level_2)) AS inventory_level_2_norm,

    whse_item_id,
    CAST(inventory_value AS FLOAT64)              AS inventory_value,
    CAST(COALESCE(inventory_qty,0) AS FLOAT64)    AS qty,
    CAST(COALESCE(reorder_point,0) AS FLOAT64)    AS rop,
    CAST(COALESCE(weighted_inventory_age,0) AS FLOAT64)          AS days_in_stock,
    CAST(COALESCE(weighted_UPC_Exp_Prod, NULL) AS FLOAT64)       AS exp_days,
    CAST(COALESCE(weighted_percentage_shelf_life_remain, NULL) AS FLOAT64) AS shelf_life_pct,
    UPPER(COALESCE(sales_flag,''))              AS sales_flag,
    CAST(COALESCE(weighted_inventory_age, NULL) AS FLOAT64)      AS weighted_age,
    UPPER(COALESCE(Inventory_Level,''))           AS inventory_level,
    CAST(COALESCE(max_total_shipped_qty,0) AS FLOAT64) AS max_total_shipped_qty,
    UPPER(COALESCE(out_of_stock_prod,'N'))        AS oos_flag,
    master_item_description
  FROM ${baseTable}
  

  WHERE risk_category != 'Expired'and daterange='CD' AND ${fetchWhereClause({ filters })}
    AND CONCAT(whse_name, master_item_description) NOT IN (
      SELECT CONCAT(whse_name, master_item_description)
      FROM (
        SELECT whse_name, master_item_description, COUNT(DISTINCT whse_item_id) AS dcnt
        FROM ${baseTable}
        GROUP BY whse_name, master_item_description
        HAVING dcnt > 1
      ))
    AND whse_name NOT IN (
      SELECT DISTINCT whse_name
      FROM (
        SELECT whse_name, COUNT(DISTINCT whse_id) AS c
        FROM ${baseTable}
        GROUP BY 1 HAVING c > 1
      )
    )
),

drivers AS (
  SELECT
    i.*,
    c.*,
    (i.days_in_stock > c.dis_gt_days) AS dis_over_thr,
    (i.sales_flag            = 'N')   AS no_sales,
     (i.inventory_level_2_norm = 'EXCESS INVENTORY') AS excess_inv2_flag,
    (i.inventory_level_2_norm = 'LOW INVENTORY')    AS low_inv2_flag,

    -- NEAR-EXPIRY: life% only (≤ near_expiry_pct)
    (i.shelf_life_pct IS NOT NULL AND i.shelf_life_pct <= c.near_expiry_pct) AS near_expiry,
    (i.weighted_age IS NOT NULL AND i.weighted_age > c.weighted_age_days) AS w_age_over_thr
  FROM inv i
  CROSS JOIN cfg c
),

agg_whse AS (
  SELECT
    whse_id,
    whse_name,
    COUNT(DISTINCT whse_item_id) AS total_skus,
    SUM(inventory_value)       AS total_value,
    

    -- weighted inventory age > threshold
    COUNT(DISTINCT IF(dis_over_thr, whse_item_id, NULL)) AS dis_skus,
    SAFE_DIVIDE(COUNT(DISTINCT IF(dis_over_thr, whse_item_id, NULL)),
                COUNT(DISTINCT whse_item_id)) * 100.0 AS dis_pct,
    SUM(IF(dis_over_thr, inventory_value, 0.0)) AS dis_value,
    ARRAY_AGG(DISTINCT IF(dis_over_thr, CAST(whse_item_id AS STRING), NULL) IGNORE NULLS LIMIT 10000) AS dis_products,
    ARRAY_AGG(DISTINCT IF(dis_over_thr, category_id, NULL) IGNORE NULLS LIMIT 10000) AS dis_categories,

    -- Near expiry (life% only)
    SUM(IF(near_expiry, inventory_value, 0.0)) AS near_expiry_value,
    SAFE_DIVIDE(SUM(IF(near_expiry, inventory_value, 0.0)),
                NULLIF(SUM(inventory_value),0.0)) * 100.0 AS near_expiry_value_pct,
    COUNT(DISTINCT IF(near_expiry, whse_item_id, NULL)) AS near_expiry_skus,
    SAFE_DIVIDE(COUNT(DISTINCT IF(near_expiry, whse_item_id, NULL)),
                COUNT(DISTINCT whse_item_id)) * 100.0 AS near_expiry_skus_pct,
    ARRAY_AGG(DISTINCT IF(near_expiry, CAST(whse_item_id AS STRING), NULL) IGNORE NULLS LIMIT 10000) AS near_expiry_products,
    ARRAY_AGG(DISTINCT IF(near_expiry, category_id, NULL) IGNORE NULLS LIMIT 10000) AS near_expiry_categories,


     -- ===== No sales
    COUNT(DISTINCT IF(no_sales, whse_item_id, NULL))                                            AS no_sales_skus,
    SUM(IF(no_sales, inventory_value, 0.0)) AS no_sales_inventory_value,
    SAFE_DIVIDE(COUNT(DISTINCT IF(no_sales, whse_item_id, NULL)), COUNT(DISTINCT whse_item_id)) * 100.0      AS no_sales_skus_pct,
    ARRAY_AGG(DISTINCT IF(no_sales, CAST(whse_item_id AS STRING), NULL) IGNORE NULLS LIMIT 10000)          AS no_sales_products,


    -- ===== Excess Inventory (Inventory Level 2)
COUNT(DISTINCT IF(excess_inv2_flag, whse_item_id, NULL)) AS excess_inv2_skus,
SAFE_DIVIDE(COUNT(DISTINCT IF(excess_inv2_flag, whse_item_id, NULL)),
            COUNT(DISTINCT whse_item_id)) * 100.0        AS excess_inv2_skus_pct,
SUM(IF(excess_inv2_flag, inventory_value, 0.0))        AS excess_inv2_value,
ARRAY_AGG(DISTINCT IF(excess_inv2_flag, CAST(whse_item_id AS STRING), NULL)
          IGNORE NULLS LIMIT 10000)                    AS excess_inv2_products,
ARRAY_AGG(DISTINCT IF(excess_inv2_flag, category_id, NULL)
          IGNORE NULLS LIMIT 10000)                    AS excess_inv2_categories,

-- ===== Low Inventory (Inventory Level 2) → stockout risk
COUNT(DISTINCT IF(low_inv2_flag, whse_item_id, NULL))    AS low_inv2_skus,
SAFE_DIVIDE(COUNT(DISTINCT IF(low_inv2_flag, whse_item_id, NULL)),
            COUNT(DISTINCT whse_item_id)) * 100.0        AS low_inv2_skus_pct,
SUM(IF(low_inv2_flag, inventory_value, 0.0))           AS low_inv2_value,
ARRAY_AGG(DISTINCT IF(low_inv2_flag, CAST(whse_item_id AS STRING), NULL)
          IGNORE NULLS LIMIT 10000)                    AS low_inv2_products,
ARRAY_AGG(DISTINCT IF(low_inv2_flag, category_id, NULL)
          IGNORE NULLS LIMIT 10000)                    AS low_inv2_categories,



    -- Weighted age > threshold
    COUNT(DISTINCT IF(w_age_over_thr, whse_item_id, NULL)) AS w_age_skus,
    SAFE_DIVIDE(COUNT(DISTINCT IF(w_age_over_thr, whse_item_id, NULL)),
                COUNT(DISTINCT whse_item_id)) * 100.0 AS w_age_pct,
    ARRAY_AGG(DISTINCT IF(w_age_over_thr, CAST(whse_item_id AS STRING), NULL) IGNORE NULLS LIMIT 10000) AS w_age_products,
    ARRAY_AGG(DISTINCT IF(w_age_over_thr, category_id, NULL) IGNORE NULLS LIMIT 10000) AS w_age_categories,

    ANY_VALUE(dis_gt_days)       AS dis_gt_days,
    ANY_VALUE(near_expiry_pct)   AS near_expiry_pct,
    ANY_VALUE(weighted_age_days) AS weighted_age_days
  FROM drivers
  GROUP BY whse_id, whse_name
),



alerts AS (

  -- High Days in Stock (gate on SKU%)
  SELECT
    CONCAT('A', RIGHT(FORMAT('%08x', ABS(FARM_FINGERPRINT(CONCAT(CAST(a.whse_id AS STRING),'|','DIS_WHS')))), 8)) AS alert_id,
    'Aging Risk' AS alert_category,
    a.whse_name AS warehouse_name,
    FORMAT('%.1f%% of Products have weighted inventory age > %d days, worth %s in %s Warehouse',
           a.dis_pct, CAST(a.dis_gt_days AS INT64), FORMAT("$%'d", CAST(ROUND( a.dis_value) AS INT64)), a.whse_name) AS summary,
    CASE WHEN a.dis_pct >= 25 THEN 'High'
         WHEN a.dis_pct >= 15 THEN 'Medium'
         ELSE 'Low' END AS severity,
    a.dis_value AS impact_value,    -- << sum(inventory_value) of affected SKUs
    'Hold PO / Plan Promotion / DC Transfer' AS suggested_action,
    a.dis_products   AS product_ids_arr,
    a.dis_categories AS category_ids_arr
  FROM agg_whse a
  CROSS JOIN cfg c
  WHERE a.dis_pct >= c.min_dis_sku_pct

UNION ALL
-- OVERSTOCK RISK (Inventory Level 2 = 'Excess Inventory') – QC-style
SELECT
  CONCAT('A', RIGHT(FORMAT('%08x', ABS(FARM_FINGERPRINT(
    CONCAT(CAST(a.whse_id AS STRING),'|','OVERSTOCK_L2_WHS')
  ))), 8)) AS alert_id,
  'Overstock Risk' AS alert_category,
  a.whse_name AS warehouse_name,
  FORMAT('%.2f%% of Products (%s) are flagged as Excess Inventory, valued (%s) in %s Warehouse',
         a.excess_inv2_skus_pct, FORMAT("%'d",cast(a.excess_inv2_skus as int64)),
          FORMAT("$%'d", CAST(ROUND( a.excess_inv2_value) AS INT64)), a.whse_name) AS summary,
  CASE
    WHEN a.excess_inv2_skus_pct >= 25 THEN 'High'
    WHEN a.excess_inv2_skus_pct >= 15 THEN 'Medium'
    ELSE 'Low'
  END AS severity,
  a.excess_inv2_value AS impact_value,
  'Hold PO / Plan Markdown/Promotion' AS suggested_action,
  a.excess_inv2_products   AS product_ids_arr,
  a.excess_inv2_categories AS category_ids_arr
FROM agg_whse a
CROSS JOIN cfg c
WHERE a.excess_inv2_skus > 0
  AND a.excess_inv2_skus_pct >= c.min_excess_inv2_sku_pct
 

UNION ALL


-- NEW: Near Expiry SKUs (≤ 10% shelf life remaining)
SELECT
  CONCAT('A', RIGHT(FORMAT('%08x', ABS(FARM_FINGERPRINT(
    CONCAT(CAST(a.whse_id AS STRING),'|','NEAR_EXPIRY_SKU_WHS')
  ))), 8)) AS alert_id,
  'Near Expiry' AS alert_category,
  a.whse_name AS warehouse_name,
  FORMAT('%.2f%% of Products have ≤ %.0f%% shelf life remaining in %s Warehouse',
         a.near_expiry_skus_pct, a.near_expiry_pct, a.whse_name) AS summary,
  CASE
    WHEN a.near_expiry_skus_pct >= 20 THEN 'High'
    WHEN a.near_expiry_skus_pct >= 10 THEN 'Medium'
    ELSE 'Low'
  END AS severity,
  near_expiry_value AS impact_value,
  --CAST(a.near_expiry_skus AS FLOAT64) AS impact_value,     -- SKU count as impact
  'Plan Markdown/Promotions / Relocate to high demand locations / Deplete First' AS suggested_action,
  a.near_expiry_products   AS product_ids_arr,
  a.near_expiry_categories AS category_ids_arr
FROM agg_whse a
WHERE a.near_expiry_skus > 0 and near_expiry_skus_pct>5

UNION ALL
-- No-Sales SKUs (from sales_flag = 'N')
SELECT
  CONCAT('A', RIGHT(FORMAT('%08x', ABS(FARM_FINGERPRINT(CONCAT(CAST(a.whse_id AS STRING),'|','NO_SALES_WHS')))), 8)) AS alert_id,
  'No-Sales SKUs' AS alert_category,
  a.whse_name AS warehouse_name,
  FORMAT('%.2f%% of products showed no sales for the last 13 weeks in %s Warehouse',
         a.no_sales_skus_pct, a.whse_name) AS summary,
  CASE WHEN a.no_sales_skus_pct >= 20 THEN 'High'
       WHEN a.no_sales_skus_pct >= 10 THEN 'Medium'
       ELSE 'Low' END AS severity,
  CAST(a.no_sales_inventory_value AS FLOAT64) AS impact_value,
  'DC Transfer / Hold PO / Plan Markdown' AS suggested_action,
  a.no_sales_products AS product_ids_arr,
  a.dis_categories    AS category_ids_arr
FROM agg_whse a
CROSS JOIN cfg c
WHERE a.no_sales_skus_pct >= c.min_no_sales_sku_pct

group by all
),
 

final_alerts AS (
  SELECT
    alert_id, alert_category, warehouse_name, summary, severity, impact_value, suggested_action,
    row_number() over(partition by alert_category order by impact_value desc) as rnk,
    COALESCE((SELECT STRING_AGG(pid, ', ' ORDER BY pid) FROM UNNEST(product_ids_arr) pid), '')  AS whse_item_ids,
    COALESCE((SELECT STRING_AGG(cid, ', ' ORDER BY cid) FROM UNNEST(category_ids_arr) cid), '') AS category_ids
  FROM alerts
)

SELECT
  alert_id, alert_category, warehouse_name as warehouseName, summary, severity, 
  --FORMAT(""$%,.2f"", impact_value) AS impact_value
  COUNT(*) OVER() AS total_records,
  FORMAT("$%'d", CAST(ROUND(impact_value) AS INT64)) AS impact_value,
  suggested_action, whse_item_ids as itemCode, category_ids as itemCategory
FROM final_alerts
where rnk<3
order by severity,impact_value 
`

  if (_get(filters, 'pageNo')) {
    query = query.concat(` LIMIT ${limit} OFFSET ${offset}`)
  }
  return { query };
};

const categoryIdValues = async (category_ids) => {
  let query = `select distinct item_category_id, cs_item_category_desc from ${baseTable}
  where item_category_id IN (${category_ids.split(",").map((e) => `"${e.trim()}"`).join(",")})`
  return { query }
}

module.exports = {
  alertDashboardQuery,
  categoryIdValues
};