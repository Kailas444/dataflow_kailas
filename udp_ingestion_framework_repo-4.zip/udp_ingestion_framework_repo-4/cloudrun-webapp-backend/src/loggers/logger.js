
const { createLogger, format, transports, error } = require('winston');
const { combine, timestamp, printf } = format;

const myFormat = printf((error) => {
    return `${error.timestamp} ${error.level}:${error.message.error}`
})


const logger = createLogger({
    level: 'error',
    format: combine(
        timestamp(),
        myFormat
    ),
    transports: [new transports.File({ filename: "error.log", level: "error" })],
})



module.exports = {
    logger
}