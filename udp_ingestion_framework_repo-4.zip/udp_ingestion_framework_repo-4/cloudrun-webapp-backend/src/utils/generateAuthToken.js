const axios = require("axios")
require("dotenv").config();

const generateEmbedToken = async (auth_token, payload) => {
    try {
        const config = {
            headers: { Authorization: `Bearer ${auth_token}`, 'Content-Type': "application/json" }
        };
        console.log("check 11", config)
        const body = {
            "datasets": [{ "id": payload.datasets }],
            "reports": [{ "id": payload.reportId }],
            // "identities": [
            //     {
            //         "username": "aman.yadav@unilever.com",
            //         "roles": [
            //             "Admin"
            //         ],
            //         "datasets": [
            //             payload.datasets
            //         ]
            //     }
            // ],
        };
        console.log("check 12", body)
        const { data } = await axios.post(
            'https://api.powerbi.com/v1.0/myorg/GenerateToken',
            body,
            config
        );
        console.log(data)
        return data.token;
    } catch (error) {
        return { status: false, error: "generateEmbedToken" + error.toString() };
    }
};
const generateAuthToken = async (payload) => {
    try {
        const CLIENT_ID = process.env.CLIENT_ID;
        const CLIENT_SECRET = process.env.CLIENT_SECRET;
        const TENANT_ID = process.env.TENANT_ID;
        const config = { headers: { "Content-Type": "application/x-www-form-urlencoded" } };
        const params = new URLSearchParams();
        params.append("grant_type", "client_credentials");
        params.append("client_id", CLIENT_ID);
        params.append("client_secret", CLIENT_SECRET);
        params.append("scope", process.env.scope);
        //params.append("resource", "https://graph.microsoft.com/.default");
        params.append("redirect_uri", process.env.redirect_url)
        console.log("check 1", params)
        const { data } = await axios.post(
            `https://login.microsoftonline.com/${TENANT_ID}/oauth2/v2.0/token`,
            params,
            config
        );
        console.log("Access token", data);
        let AUTH_TOKEN = data?.access_token;
        console.log(AUTH_TOKEN)
        return await generateEmbedToken(AUTH_TOKEN, payload);
    } catch (error) {
        return { status: false, error: "generateAuthToken :" + error.toString() };
    }
};

module.exports = { generateAuthToken }