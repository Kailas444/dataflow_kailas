//import db from "../connection/db.connect";
const { get: _get } = require("lodash")

function fetchWhereClause({ filters }) {
  let query = ''
  if (filters.inventoryOrganisationName) {
    query = query.concat(`${filters.inventoryOrganisationName === "ALL"
      ? "organization_name IN (organization_name)"
      : `organization_name IN (${filters.inventoryOrganisationName.map(id => `'${id}'`).join(',')})`}`)
  }

  if (filters.warehouseName) {
    query = query.concat(`${filters.warehouseName === "ALL"
      ? "AND whse_name IN (whse_name)"
      : `AND whse_name IN (${filters.warehouseName.map(id => `'${id}'`).join(',')})`}`)
  }

  if (filters.itemDepartment) {
    query = query.concat(`${filters.itemDepartment === "ALL"
      ? "AND dept_desc IN (dept_desc)"
      : `AND dept_desc IN (${filters.itemDepartment.map(id => `'${id}'`).join(',')})`}`)
  }

  if (filters.itemCategory) {
    query = query.concat(`${filters.itemCategory === "ALL"
      ? "AND cs_item_category_desc IN (cs_item_category_desc)"
      : `AND cs_item_category_desc IN (${filters.itemCategory.map(id => `'${id}'`).join(',')})`}`)
  }

  if (filters.itemCode) {
    let intArray = filters.itemCode != "ALL" ? filters.itemCode.map(Number) : []
    query = query.concat(`${filters.itemCode === "ALL"
      ? "AND whse_item_id IN (whse_item_id)"
      : `AND whse_item_id IN (${intArray.map(id => `${id}`).join(',')})`}`)
  }

  if (filters.itemDescription) {
    query = query.concat(`${filters.itemDescription === "ALL"
      ? "AND master_item_description IN (master_item_description)"
      : `AND master_item_description IN (${filters.itemDescription.map(id => `'${id}'`).join(',')})`}`)
  }
  if (filters.riskCategory) {
    query = query.concat(` AND risk_category='${filters.riskCategory}'`)
  }
  // // if (filters.size) {
  // //   if (filters.size == "Inventory Value") {
  // //     query = query.concat(`AND `)
  // //   }
  // //   if (filters.size == "Inventory Qty") {
  // //     query = query.concat(`AND `)
  // //   }
  // //   if (filters.size == "Weeks on Hand") {
  // //     query = query.concat(`AND `)
  // //   }
  // //   if (filters.size == "Near Expiry") {
  // //     query = query.concat(`AND `)
  // //   }
  // //   if (filters.size == "Out of Stock") {
  // //     query = query.concat(`AND `)
  // //   }
  // }

  return query
}


// function fetchWhereClause({ filters }) {
//   console.log(filters)
//   let query = ''
//   console.log(query)
//   if (filters.inventoryOrganisationName) {
//     query = query.concat(`inventory_org_desc IN (${filters.inventoryOrganisationName.map(id => `'${id}'`).join(',')})`)
//   }

//   if (filters.warehouseName) {
//     query = query.concat(`AND whse_name IN (${filters.warehouseName.map(id => `'${id}'`).join(',')})`)
//   }

//   if (filters.itemDepartment) {
//     query = query.concat(`AND gl_description IN (${filters.itemDepartment.map(id => `'${id}'`).join(',')})`)
//   }

//   if (filters.itemCategory) {
//     query = query.concat(`AND cs_item_category_desc IN (${filters.itemCategory.map(id => `'${id}'`).join(',')})`)
//   }


//   if (filters.itemCode) {
//     query = query.concat(`AND prod_id IN (${filters.itemCode.map(id => `'${id}'`).join(',')})`)
//   }

//   if (filters.itemDescription) {
//     query = query.concat(`AND description IN (${filters.itemDescription.map(id => `'${id}'`).join(',')})`)
//   }

//   return query
// }



function getTableColumn(granularity) {
  const params = {
    warehouseName: 'whse_name',
    itemCategory: 'cs_item_category_desc',
    itemStatusCode: 'inventory_item_status_cde',
    privateDistribution: 'Private_Label_Flag_desc',
    ssic: 'ssic_num',
    itemCode: 'CAST(whse_item_id as string) as whse_item_id',
    itemDescription: 'master_item_description',
    itemDepartment: 'dept_desc',
    vendorName: 'vendor_name'

  }
  return params[granularity] || null;
}

const orderTypeAlias = {
  desc: 'DESC',
  asc: 'ASC',
}

const getOrder = (orderByDef) => _get(orderTypeAlias, String(_get(orderByDef, 'orderType')).toLowerCase(), 'ASC');

const getColumn = (orderByDef, keyToColumnMapSort) => _get(keyToColumnMapSort, _get(orderByDef, 'orderBy'));

function orderByWithSQL({ keyToColumnMapSort = {}, filters = {}, sortKey = '', defaultOrder = '' }) {
  const sortColumnsArr = Array.from(_get(filters, sortKey, []));
  if (sortColumnsArr && sortColumnsArr.length > 0) {
    const orderBy = sortColumnsArr.map(orderByDef => `${getColumn(orderByDef, keyToColumnMapSort)} ${getOrder(orderByDef)}`);
    if (orderBy.length > 0) {
      return orderBy.join(', ');
    }
  }
  return defaultOrder;
};

module.exports = {
  // findCategoryById,
  fetchWhereClause,
  getTableColumn,
  orderByWithSQL
  // createUrl
}