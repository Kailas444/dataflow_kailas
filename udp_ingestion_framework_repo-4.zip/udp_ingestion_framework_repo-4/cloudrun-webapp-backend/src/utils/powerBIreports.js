const powerBI = {
    development: {
        // samplePowerBIReport: {
        //     groupId: "9cecc4ec-57b8-4bb0-b885-33fd60946dbf",
        //     reportId: "aeeccda2-cbe0-4f36-b5db-969a92b90199",
        //     datasets: "0da3349b-78a2-4410-9545-5065c157a502",
        //     get embedURL() {
        //         return `https://app.powerbi.com/reportEmbed?reportId=${this.reportId}&groupId=${this.groupId}&w=2&config=eyJjbHVzdGVyVXJsIjoiaHR0cHM6Ly9XQUJJLVNPVVRILUVBU1QtQVNJQS1yZWRpcmVjdC5hbmFseXNpcy53aW5kb3dzLm5ldCIsImVtYmVkRmVhdHVyZXMiOnsidXNhZ2VNZXRyaWNzVk5leHQiOnRydWV9fQ%3d%3d`;
        //     },
        // },
        samplePowerBIReport: {
            groupId: "a49b8db3-c45e-4ccf-8d14-5b179e42dc36",
            reportId: "d50c84a0-e8f8-4215-afdf-a183623bbe30",
            datasets: "4d723ce7-f0d5-4959-bf03-2049a9c3636c",
            get embedURL() {
                return `https://app.powerbi.com/reportEmbed?reportId=d50c84a0-e8f8-4215-afdf-a183623bbe30&groupId=a49b8db3-c45e-4ccf-8d14-5b179e42dc36&w=2&config=eyJjbHVzdGVyVXJsIjoiaHR0cHM6Ly9XQUJJLU5PUlRILUVVUk9QRS1yZWRpcmVjdC5hbmFseXNpcy53aW5kb3dzLm5ldCIsImVtYmVkRmVhdHVyZXMiOnsidXNhZ2VNZXRyaWNzVk5leHQiOnRydWV9fQ%3d%3d`;
            },
        },
        wasteCadDoData: {
            groupId: "9cecc4ec-57b8-4bb0-b885-33fd60946dbf",
            reportId: "d03e19cc-386f-4013-91c1-8681acc87fea",
            datasets: "100b29ba-b4f4-441e-990c-e5de5ed948b0",
            get embedURL() {
                return `https://app.powerbi.com/reportEmbed?reportId=${this.reportId}&groupId=${this.groupId}&w=2&config=eyJjbHVzdGVyVXJsIjoiaHR0cHM6Ly9XQUJJLVNPVVRILUVBU1QtQVNJQS1yZWRpcmVjdC5hbmFseXNpcy53aW5kb3dzLm5ldCIsImVtYmVkRmVhdHVyZXMiOnsidXNhZ2VNZXRyaWNzVk5leHQiOnRydWV9fQ%3d%3d`;
            },
        },

    }
}

module.exports = { powerBI }