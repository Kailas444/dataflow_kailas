const fieldMap = {
  inventoryOrganization: 'organization_name',
  warehouseName: 'whse_name',
  itemDepartment: 'dept_desc',
  itemCategory: 'cs_item_category_desc',
  itemCode: 'whse_item_id',
  itemDescription: 'master_item_description',
};

const baseTable = '`gc-proj-udp-dev-54a3.warehouse_gold.inventory_item_daily`';

const latestTable = '`gc-proj-udp-dev-54a3.raw_layer.vw_inventory_latest`'

const alertCenterTable = '`gc-proj-udp-dev-54a3.raw_layer.rule_config`';

const oldTable = '`gc-proj-udp-dev-54a3.raw_layer.inventory_item_daily`';

module.exports = {
  fieldMap,
  baseTable,
  latestTable,
  alertCenterTable,
  oldTable
};