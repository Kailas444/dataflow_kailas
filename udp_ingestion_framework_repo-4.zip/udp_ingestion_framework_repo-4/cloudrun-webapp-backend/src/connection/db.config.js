const { BigQuery } = require('@google-cloud/bigquery');

const bigquery = new BigQuery({
  projectId: 'gc-proj-udp-dev-54a3', // Your actual project ID   // Path to service account key
});


module.exports = bigquery