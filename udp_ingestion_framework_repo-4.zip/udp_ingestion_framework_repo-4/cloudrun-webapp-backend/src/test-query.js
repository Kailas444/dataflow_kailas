const { BigQuery } = require('@google-cloud/bigquery');

// ✅ Create a client instance
const bigquery = new BigQuery({
  projectId: 'test-gcp-connection-with-node', // Your actual project ID
  keyFilename: './gcp-service.json',      // Path to service account key
});

const datasetId = 'my_dataset'; // Your dataset name

async function checkConnectionAndDataset() {
  try {
    // ✅ Access dataset from the client instance
    const dataset = bigquery.dataset(datasetId);
    const [exists] = await dataset.exists();

    if (exists) {
      console.log(`✅ Connected. Dataset "${datasetId}" exists.`);
      return datasetId;
    } else {
      console.error(`❌ Dataset "${datasetId}" does not exist.`);
      return null;
    }
  } catch (error) {
    console.error('❌ Connection failed:', error.message);
    return null;
  }
}

checkConnectionAndDataset();