const filterData = [{
  "prod_id": "96578",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Mc Slow Roasted Pot Roast Bowl",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "543927",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Tal Glto Lyrs Choc Chry Chsck",
  "cs_item_category_desc": "Ice Cream Otheric"
}, {
  "prod_id": "394117",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "I/O-Kim Bk Snt Tr Sgr Cki 10ct",
  "cs_item_category_desc": "Cookiesthawpkgbky"
}, {
  "prod_id": "40021825",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Sport Gold 100 Box 01017",
  "cs_item_category_desc": "Cigs 100s And Nonfilter Kingstob"
}, {
  "prod_id": "281180",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Bnqt Orig Fried Chicken 4c",
  "cs_item_category_desc": "Chickenfr"
}, {
  "prod_id": "164821",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Focaccia Dough",
  "cs_item_category_desc": "Frozen Breadsbky"
}, {
  "prod_id": "183069",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Olson Angel Food Loaf",
  "cs_item_category_desc": "Frozen Cakecupckchsecakebky"
}, {
  "prod_id": "407322",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Gg Bby Brssl Sprts Btr Sce Bxd",
  "cs_item_category_desc": "Vegetablesfr"
}, {
  "prod_id": "533951",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Oi Golden Crinkle Cuts",
  "cs_item_category_desc": "Potatoespierogiesfr"
}, {
  "prod_id": "532469",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Tot Party Pza Trpl Proni",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "292241",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Mc Bwl 4chs Rav Garden Tom",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "40021889",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Winston White 100\u0027s Box Lip",
  "cs_item_category_desc": "Cigs 100s And Nonfilter Kingstob"
}, {
  "prod_id": "301925",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Grtn Brd Fsh Fil 10ct",
  "cs_item_category_desc": "Fishseafoodfr"
}, {
  "prod_id": "303672",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Tj Farms Hash Browns Shrd Pot",
  "cs_item_category_desc": "Potatoespierogiesfr"
}, {
  "prod_id": "291456",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "El Mont Ckn \u0026 Chez Flr Taquito",
  "cs_item_category_desc": "Pkg Heatservemt"
}, {
  "prod_id": "499217",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Crvn Flv Onion Rings",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "482642",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Simplot Potato Wedges",
  "cs_item_category_desc": "Pkg Heatservemt"
}, {
  "prod_id": "117232",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "I/O-Gnla Egg Hot Dog Buns",
  "cs_item_category_desc": "Frozen Buns  Rollsbky"
}, {
  "prod_id": "287863",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Ff Crispy Strips",
  "cs_item_category_desc": "Poultry  Frozenmt"
}, {
  "prod_id": "297351",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Bnqt Classic Meatloaf",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "377291",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Jlb Chocolate Creme Pie Ss 8\"",
  "cs_item_category_desc": "Frozen Piesbky"
}, {
  "prod_id": "366262",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Bnqt Mgabwl Dynmt Pnn W Mtbl",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "241998",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Hsf Hf Cold Cut Cmbo Sand",
  "cs_item_category_desc": "Frozen Meatsmt"
}, {
  "prod_id": "464758",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Ff Ckn Corn Dg Jmb Hny 72 4oz",
  "cs_item_category_desc": "Frozen Meatsmt"
}, {
  "prod_id": "277101",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Ft 9\"Choc Lovers Chscke",
  "cs_item_category_desc": "Frozen Cakecupckchsecakebky"
}, {
  "prod_id": "54700",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Cafvly Mini Gs Mint Cpcks",
  "cs_item_category_desc": "Frozen Cakecupckchsecakebky"
}, {
  "prod_id": "95498",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Crzy Czne Gen Tsos Chkcn",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "274329",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Rch P Vrty Dbl Layer 8\"",
  "cs_item_category_desc": "Frozen Cakecupckchsecakebky"
}, {
  "prod_id": "306857",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Stfr Prty Sz Lasgna W/Mt",
  "cs_item_category_desc": "Entreesfamily Sizefr"
}, {
  "prod_id": "322258",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "B Yet Fz Brocoli Florets Steam",
  "cs_item_category_desc": "Vegetablespriv Labfr"
}, {
  "prod_id": "160014",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Crvn Flv Ic Sw Mntcc 12ct",
  "cs_item_category_desc": "Ice Cream Noveltiesmulti Pkic"
}, {
  "prod_id": "307800",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Jo Taquitos Ckn Chs Lg 15ct",
  "cs_item_category_desc": "Sandwichburritostrombolifr"
}, {
  "prod_id": "44057993",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Camel Mntl $1",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "531442",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Hsts Snoballs Ss 2ct",
  "cs_item_category_desc": "Cakescheesecakesfr"
}, {
  "prod_id": "274157",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Kh Hmbrgr Buns 8ct",
  "cs_item_category_desc": "Frozen Buns  Rollsbky"
}, {
  "prod_id": "326039",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "B Yet Btrmilk Waffles 24ct",
  "cs_item_category_desc": "Breakfast Itemsfr"
}, {
  "prod_id": "232746",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Kh 4ct Orig Rolls",
  "cs_item_category_desc": "Frozen Buns  Rollsbky"
}, {
  "prod_id": "299709",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Msf Sausage Patties",
  "cs_item_category_desc": "Meatless Meat Productsfr"
}, {
  "prod_id": "329424",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Tal Roman Rasp Sorbetto",
  "cs_item_category_desc": "Ice Cream Dairy Freeic"
}, {
  "prod_id": "371945",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Be Sf Sweet Peas",
  "cs_item_category_desc": "Vegetablesfr"
}, {
  "prod_id": "470348",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Wld Mk Ult Pza 4chs Spsz",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "320449",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Stfr Roast Turkey",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "40005622",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Capri Magenta Box",
  "cs_item_category_desc": "Cigs 100s And Nonfilter Kingstob"
}, {
  "prod_id": "426934",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Dgn Chs Stf 3meat Pza 6\"",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "533945",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Sara Oven Fresh Cherry Pie 9\"",
  "cs_item_category_desc": "Piesfr"
}, {
  "prod_id": "414974",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "2bite Mini Cpcke Choc 12ct",
  "cs_item_category_desc": "Cookiesthawpkgbky"
}, {
  "prod_id": "149801",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Hills Mild Ital Ssg Link",
  "cs_item_category_desc": "Smoked Sausagemt"
}, {
  "prod_id": "145140",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Mrkt Snd Mg Wht Trky Chs Sw",
  "cs_item_category_desc": "Frozen Sandwiches  Mt"
}, {
  "prod_id": "304646",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Pills Tstr Strdl Strwbry 6ct",
  "cs_item_category_desc": "Breakfast Itemsfr"
}, {
  "prod_id": "210733",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Random Weight - Frozen - Seafood",
  "description": "Smoked Turkey Wings Tp",
  "cs_item_category_desc": "Turkeys  Frozenmt"
}, {
  "prod_id": "333878",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "I/O-Bryr Oreo\u0027s Cke\u0026Crm",
  "cs_item_category_desc": "Ice Cream Multi Servebulkic"
}, {
  "prod_id": "287229",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Tllmk Ice Cream Strawberry",
  "cs_item_category_desc": "Ice Cream Multi Servebulkic"
}, {
  "prod_id": "334500",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Otsh Fruit Bars Mango 6 Count",
  "cs_item_category_desc": "Ice Cream Noveltiesmulti Pkic"
}, {
  "prod_id": "585883",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Random Weight - Frozen - Seafood",
  "description": "Wvm Beef Neck Bones Cut",
  "cs_item_category_desc": "Beef Offalmt"
}, {
  "prod_id": "538227",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Richs Pershing Donut",
  "cs_item_category_desc": "Frozen Donutsmuffinsbky"
}, {
  "prod_id": "352295",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Crvn Flv Ic Cp Vp 12ct",
  "cs_item_category_desc": "Ice Cream Noveltiesmulti Pkic"
}, {
  "prod_id": "40083030",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Pp$.89-Blk\u0026Mld Royales",
  "cs_item_category_desc": "Cigar Productstob"
}, {
  "prod_id": "365278",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Nwmn Thin Crust Four Cheese",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "194118",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Lfthse Sb Shrtck Frst Cki",
  "cs_item_category_desc": "Frozen Cookie Batterbky"
}, {
  "prod_id": "507221",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Crvn Flv Ny Chsck Strwb Swirl",
  "cs_item_category_desc": "Cakescheesecakesfr"
}, {
  "prod_id": "51363",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "El Mont Beef Enchilada Meal",
  "cs_item_category_desc": "Frozen Meatsmt"
}, {
  "prod_id": "35803",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Aktchn Bowls 3chs \u0026 Kle Bake",
  "cs_item_category_desc": "Vegetarianvegan Foodfr"
}, {
  "prod_id": "289180",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "El Mont Tqts Bf Chs 21ct",
  "cs_item_category_desc": "Pkg Heatservemt"
}, {
  "prod_id": "295590",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Dgn Chsc Peprn 12in",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "40005818",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Va Slim M Gold Pck 12",
  "cs_item_category_desc": "Cigs 100s And Nonfilter Kingstob"
}, {
  "prod_id": "318657",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Smkr Uncrst Sw Pb Hny 4ct",
  "cs_item_category_desc": "Sandwichburritostrombolifr"
}, {
  "prod_id": "64881",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Cmpvrde Srbt Crm Cmbo Acai Yog",
  "cs_item_category_desc": "Fruitsmoothie Mixfr"
}, {
  "prod_id": "40005807",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Marl A Bp Special Bl Red Bx",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "315692",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Stfr Fsf Gr Ma Chix Veg Bake",
  "cs_item_category_desc": "Entreesfamily Sizefr"
}, {
  "prod_id": "464092",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Pills Wfl Cca Puffs 8ct",
  "cs_item_category_desc": "Breakfast Itemsfr"
}, {
  "prod_id": "538001",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Labrea T\u0026B Dnr Rolls",
  "cs_item_category_desc": "Frozen Buns  Rollsbky"
}, {
  "prod_id": "292743",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Tal Glto Layers Snkrdl Cki",
  "cs_item_category_desc": "Ice Cream Otheric"
}, {
  "prod_id": "230186",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Random Weight - Frozen",
  "description": "I/O-Db L Or Bnls Prm Rib Of Bf",
  "cs_item_category_desc": "Frozen Meatsmt"
}, {
  "prod_id": "296599",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Hsts Twinkies Ss 2ct",
  "cs_item_category_desc": "Cakescheesecakesfr"
}, {
  "prod_id": "40008532",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Winston Mnthl Box 100\u0027s $1.00",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "302723",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Jo Chicken Chimichangas",
  "cs_item_category_desc": "Sandwichburritostrombolifr"
}, {
  "prod_id": "222209",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Tys Grlld Chickn Strips",
  "cs_item_category_desc": "Frozen Chickenmt"
}, {
  "prod_id": "316586",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Msf Veg Bfst Bcn Strips",
  "cs_item_category_desc": "Meatless Meat Productsfr"
}, {
  "prod_id": "377216",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "I/O-Jlb Pmkn Nsa Pie Bkd 8\"",
  "cs_item_category_desc": "Frozen Piesbky"
}, {
  "prod_id": "40023582",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Marl Men Ice Box",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "44062465",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Lcky Strk Activate Green Bx",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "536506",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "2bite Orng Crnbry Scns Sq Tb",
  "cs_item_category_desc": "Frozen Pastrybky"
}, {
  "prod_id": "598039",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Random Weight - Frozen - Seafood",
  "description": "Wvm Crn L Tr Smkd Prk Hck Tp",
  "cs_item_category_desc": "Frozen Meatsmt"
}, {
  "prod_id": "538244",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Rich Cookies N Crm Pwp Bttrcrm",
  "cs_item_category_desc": "Toppingsicingbky"
}, {
  "prod_id": "44063032",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Blk\u0026Mld Wn 5pk$4.45",
  "cs_item_category_desc": "Cigar Productstob"
}, {
  "prod_id": "225688",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Pills Tstr Strdl Chry",
  "cs_item_category_desc": "Breakfast Itemsfr"
}, {
  "prod_id": "443442",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Tys Fc Buff Ckn Chse Crispito",
  "cs_item_category_desc": "Frozen Meatsmt"
}, {
  "prod_id": "40005613",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Pl Ml Pallsav Blu 85 Box 01440",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "534697",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Fast Fxn Chicken Strips",
  "cs_item_category_desc": "Frozen Chickenmt"
}, {
  "prod_id": "336906",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Lactaid Ic Mnt Chchp",
  "cs_item_category_desc": "Ice Cream Otheric"
}, {
  "prod_id": "420740",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Krft M\u0026C Dlx M\u0026C Chdr",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "216687",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Stonefire Stnfr Orig Nn Rnd",
  "cs_item_category_desc": "Frozen Breadsbky"
}, {
  "prod_id": "242149",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "I/O-Hsf Hf Itl Cmbo Sand",
  "cs_item_category_desc": "Frozen Meatsmt"
}, {
  "prod_id": "85881",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Bnqt Mega Meal Salsbry Stk",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "99671",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Cmf Tapatio Beef Tamales",
  "cs_item_category_desc": "Sandwichburritostrombolifr"
}, {
  "prod_id": "40005809",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "B\u0026H 100 Nm Bx Fil",
  "cs_item_category_desc": "Cigs 100s And Nonfilter Kingstob"
}, {
  "prod_id": "57433",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Cafvly Mini Gs Lmn Cpcks",
  "cs_item_category_desc": "Frozen Cakecupckchsecakebky"
}, {
  "prod_id": "484765",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Simplot Orig Ct Br Batr Skn On",
  "cs_item_category_desc": "Pkg Heatservemt"
}, {
  "prod_id": "316856",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Random Weight - Frozen - Seafood",
  "description": "Mvm Chicken Feet",
  "cs_item_category_desc": "Poultry  Frozenmt"
}, {
  "prod_id": "319576",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "B Yet 5 Chs Texas Toast",
  "cs_item_category_desc": "Breadrollsmuffinsfr"
}, {
  "prod_id": "538165",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Jwa Ui Choc Cke Layer 8\"",
  "cs_item_category_desc": "Frozen Cakecupckchsecakebky"
}, {
  "prod_id": "302477",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Bnqt Classic Swedish Meatballs",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "177206",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Be Sf Edamme In The Pod",
  "cs_item_category_desc": "Vegetablesfr"
}, {
  "prod_id": "289925",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Tllmk Ice Cream Chocolate",
  "cs_item_category_desc": "Ice Cream Multi Servebulkic"
}, {
  "prod_id": "286102",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Jvl Orig Brkft Link",
  "cs_item_category_desc": "Pork Sausage  Frozenmt"
}, {
  "prod_id": "128026",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Ff Honey Bbq Wings",
  "cs_item_category_desc": "Frozen Meatsmt"
}, {
  "prod_id": "320387",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Oi Extra Crispy Tator Tot",
  "cs_item_category_desc": "Potatoespierogiesfr"
}, {
  "prod_id": "40005817",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Va Slim Gold 120 Nm Bx Fil",
  "cs_item_category_desc": "Cigs 100s And Nonfilter Kingstob"
}, {
  "prod_id": "232579",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Eggo Buttermilk Pancakes",
  "cs_item_category_desc": "Breakfast Itemsfr"
}, {
  "prod_id": "40011026",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Grizzly Wtrgrn Pouch",
  "cs_item_category_desc": "Chewing Tobacco  Snufftob"
}, {
  "prod_id": "532453",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Fatboy Ic Sw Mntcc 6ct",
  "cs_item_category_desc": "Ice Cream Noveltiesmulti Pkic"
}, {
  "prod_id": "40005804",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Marl A Silvr 100 Bx Fl04780",
  "cs_item_category_desc": "Cigs 100s And Nonfilter Kingstob"
}, {
  "prod_id": "40005808",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Marl A Bp Spec Bl100\u0027s Red",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "297808",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "B Yet Frz Bry Medley Sup",
  "cs_item_category_desc": "Fruitsmoothie Mixfr"
}, {
  "prod_id": "528175",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Mc Lattice Apple Pie",
  "cs_item_category_desc": "Piesfr"
}, {
  "prod_id": "164774",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Crvn Flv Ic Brs Tfe Crnch 12ct",
  "cs_item_category_desc": "Ice Cream Noveltiesmulti Pkic"
}, {
  "prod_id": "61520",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Old Orch Lemonade",
  "cs_item_category_desc": "Juicedrinkslushsnow Conefr"
}, {
  "prod_id": "407117",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Gg Swt Peas Btr Sce Boxed",
  "cs_item_category_desc": "Vegetablesfr"
}, {
  "prod_id": "329235",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "H Dazs Ice Cream Chocolate",
  "cs_item_category_desc": "Ice Cream Single Servepintsic"
}, {
  "prod_id": "169081",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Raos Chkn Parmsn Multi Srv",
  "cs_item_category_desc": "Entreesfamily Sizefr"
}, {
  "prod_id": "271746",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Rich Longjohn Dnut Prefri",
  "cs_item_category_desc": "Frozen Donutsmuffinsbky"
}, {
  "prod_id": "286704",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen - Seafood",
  "description": "Pilgrims Frz Fryr Lg Qrtrs",
  "cs_item_category_desc": "Frozen Chickenmt"
}, {
  "prod_id": "278179",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Lbrea French Lf Par Bk",
  "cs_item_category_desc": "Frozen Breadsbky"
}, {
  "prod_id": "317852",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Tgif Mozz Stix",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "44059135",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Crowns Red Box",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "267054",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Crvn Flv Ic Bars Van 12ct",
  "cs_item_category_desc": "Ice Cream Noveltiesmulti Pkic"
}, {
  "prod_id": "293996",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Dole Wildly Nutritious Mxd Bry",
  "cs_item_category_desc": "Fruitsmoothie Mixfr"
}, {
  "prod_id": "317865",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Bgl Bt Cheese Pepperoni",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "320436",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Stfr Swedish Meatballs",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "40011028",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Levi Grt Chewing Tob",
  "cs_item_category_desc": "Chewing Tobacco  Snufftob"
}, {
  "prod_id": "309419",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Aktchn Vegetable Lasgana",
  "cs_item_category_desc": "Vegetarianvegan Foodfr"
}, {
  "prod_id": "536572",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Lfthse Pmkn Snkrdl",
  "cs_item_category_desc": "Cookiesthawpkgbky"
}, {
  "prod_id": "500335",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "B\u0026J Top Pboverthetop",
  "cs_item_category_desc": "Ice Cream Single Servepintsic"
}, {
  "prod_id": "293682",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Be Voila Alfredo Chicken",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "55879",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Cafvly Mini Gs Advntrfls Cpck",
  "cs_item_category_desc": "Frozen Cakecupckchsecakebky"
}, {
  "prod_id": "391579",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Tal Layer Mint Fudge Cookie",
  "cs_item_category_desc": "Ice Cream Otheric"
}, {
  "prod_id": "152682",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "I/O-Golden Dinner Roll",
  "cs_item_category_desc": "Frozen Breadsbky"
}, {
  "prod_id": "319547",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Stfr Home Salisbury Stk",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "199512",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Mcc Anchor Cc Popper",
  "cs_item_category_desc": "Frozen Meatsmt"
}, {
  "prod_id": "304402",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Hc Cfe Stm Swt \u0026 Sr Ckn",
  "cs_item_category_desc": "Entrees Low Calhealthyfr"
}, {
  "prod_id": "320462",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Stfr Spaghetti With Meat Sauce",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "40104642",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Salem Box Kings",
  "cs_item_category_desc": "Cigs 100s And Nonfilter Kingstob"
}, {
  "prod_id": "126439",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Gldcrsp Gc Ched Potato Bites",
  "cs_item_category_desc": "Frozen Meatsmt"
}, {
  "prod_id": "535258",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Bibigo Stmd Dmplngs Prk Veg",
  "cs_item_category_desc": "Frozen Meatsmt"
}, {
  "prod_id": "417029",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Oep Tco Bites Beef \u0026 Chs 20ct",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "540768",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Blu Bny Prem Ic Vb",
  "cs_item_category_desc": "Ice Cream Multi Servebulkic"
}, {
  "prod_id": "285381",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Dlmx Taquitos Beef 20 Count",
  "cs_item_category_desc": "Frozen Meatsmt"
}, {
  "prod_id": "291057",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Mc Cntry Frd Chck",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "420778",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "B Yet Frozen Blueberries",
  "cs_item_category_desc": "Fruitsmoothie Mixfr"
}, {
  "prod_id": "40001855",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Camel Kg Box Lip",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "352153",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Crvn Flv Mini Ic Sw Van 16ct",
  "cs_item_category_desc": "Ice Cream Noveltiesmulti Pkic"
}, {
  "prod_id": "300128",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Jo Beef \u0026 Chs Chimichangas",
  "cs_item_category_desc": "Sandwichburritostrombolifr"
}, {
  "prod_id": "538254",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Richs 7\" German Choc Cake",
  "cs_item_category_desc": "Frozen Cakecupckchsecakebky"
}, {
  "prod_id": "319115",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "B Yet Orange Jce Regular",
  "cs_item_category_desc": "Juicedrinkspriv Labfr"
}, {
  "prod_id": "317294",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Coolwhip Xcrmy Whp Topping",
  "cs_item_category_desc": "Toppingsfr"
}, {
  "prod_id": "44065307",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Kool Box $1",
  "cs_item_category_desc": "Cigs 100s And Nonfilter Kingstob"
}, {
  "prod_id": "214522",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "I/O-Bkrboy Sgr Cke Dnut Hl",
  "cs_item_category_desc": "Frozen Donutsmuffinsbky"
}, {
  "prod_id": "287296",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Random Weight - Frozen - Seafood",
  "description": "Pork Backribs Frozen",
  "cs_item_category_desc": "Cs Fresh Porkmt"
}, {
  "prod_id": "538373",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "8\" Ff Carrot Rnd Ck",
  "cs_item_category_desc": "Frozen Cakecupckchsecakebky"
}, {
  "prod_id": "336305",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Bryr Ic Hm Van",
  "cs_item_category_desc": "Ice Cream Multi Servebulkic"
}, {
  "prod_id": "83758",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Dgn Crsnt Crust Pza Proni",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "450605",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Dlly Country Fried Steak",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "133662",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Random Weight - Frozen - Seafood",
  "description": "Best Y 9.5% Abf Trky 18-20",
  "cs_item_category_desc": "Turkeys  Frozenmt"
}, {
  "prod_id": "44070179",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Blk\u0026Mld Jazz Wt 25c",
  "cs_item_category_desc": "Cigar Productstob"
}, {
  "prod_id": "292249",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Pop Fd Bars Spdmn 6ct",
  "cs_item_category_desc": "Ice Cream Noveltiesmulti Pkic"
}, {
  "prod_id": "455936",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Jdean Maple Griddle Cake",
  "cs_item_category_desc": "Pkg Heatservemt"
}, {
  "prod_id": "40005433",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Newport Kings Sp",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "319791",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Jo Taquitos Beef 20 Count",
  "cs_item_category_desc": "Sandwichburritostrombolifr"
}, {
  "prod_id": "40005443",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "I/O-Newport Plat 100\u0027s Blu Bx",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "225716",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Tys Uc Tmpra Ckn Breast Nggt",
  "cs_item_category_desc": "Further Prepared Chickenmt"
}, {
  "prod_id": "316753",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Pf Cheese Texas Toast",
  "cs_item_category_desc": "Breadrollsmuffinsfr"
}, {
  "prod_id": "301393",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Chkr\u0026Rly Famous Seasoned Fries",
  "cs_item_category_desc": "Potatoespierogiesfr"
}, {
  "prod_id": "40001853",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Doral Gold 100 Bx Mn13130",
  "cs_item_category_desc": "Cigs 100s And Nonfilter Kingstob"
}, {
  "prod_id": "329419",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Mgnm Dbl Crml Ic Bar 3c",
  "cs_item_category_desc": "Ice Cream Noveltiesmulti Pkic"
}, {
  "prod_id": "543254",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Blu Bny Sft Ic Choc",
  "cs_item_category_desc": "Ice Cream Multi Servebulkic"
}, {
  "prod_id": "538203",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Rch P Cnn Stnl Cnn Rl Dgh",
  "cs_item_category_desc": "Frozen Buns  Rollsbky"
}, {
  "prod_id": "598642",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Tcf Ctn Cndy Bby Got Cke Rr Ss",
  "cs_item_category_desc": "Frozen Cakecupckchsecakebky"
}, {
  "prod_id": "40084187",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Newport 100 Box $1.00 1pk 6m",
  "cs_item_category_desc": "Cigs 100s And Nonfilter Kingstob"
}, {
  "prod_id": "450344",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Random Weight - Frozen - Seafood",
  "description": "Beef Oxtail Frozen",
  "cs_item_category_desc": "Frozen Meatsmt"
}, {
  "prod_id": "183874",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Jdean Roll Hut-Julian",
  "cs_item_category_desc": "Pork Sausage  Frozenmt"
}, {
  "prod_id": "313098",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Lc Edf Lasag W/Mt Sauce",
  "cs_item_category_desc": "Entrees Low Calhealthyfr"
}, {
  "prod_id": "306009",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Be Steamfresh Broccoli Florets",
  "cs_item_category_desc": "Vegetablesfr"
}, {
  "prod_id": "40016325",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Blk\u0026Mld Org Wt 5pk 00125",
  "cs_item_category_desc": "Cigar Productstob"
}, {
  "prod_id": "44060723",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Grizzly Wntrgrn $.25",
  "cs_item_category_desc": "Chewing Tobacco  Snufftob"
}, {
  "prod_id": "40005835",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Marl C Black Mn 100 Bx09646",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "448927",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Random Weight - Frozen - Seafood",
  "description": "Beef Kidney Prepacked",
  "cs_item_category_desc": "Beef Offalmt"
}, {
  "prod_id": "331060",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Its It Mint Ic Sandwich",
  "cs_item_category_desc": "Ice Cream Noveltiesmulti Pkic"
}, {
  "prod_id": "306751",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Tot Party Pizza Combination",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "44070188",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Blk\u0026Mld Wn Plstc Tp 5 Fr 4",
  "cs_item_category_desc": "Cigar Productstob"
}, {
  "prod_id": "140455",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Crvn Flv Ic Sw Cki\u0026Crm 12ct",
  "cs_item_category_desc": "Ice Cream Noveltiesmulti Pkic"
}, {
  "prod_id": "7791",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Fatboy Ic Sw Cki N Crm 6ct",
  "cs_item_category_desc": "Ice Cream Noveltiesmulti Pkic"
}, {
  "prod_id": "318319",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Ed Gourmet Chocolate Creme Pie",
  "cs_item_category_desc": "Piesfr"
}, {
  "prod_id": "40025653",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "I/O-Itg Tax Only",
  "cs_item_category_desc": "Cigs 100s And Nonfilter Kingstob"
}, {
  "prod_id": "40001861",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Doral Gold 85 Bx",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "316313",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Hnz Dvr Chkn Crd Blue Mac\u0026Chs",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "537994",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Rch P Ylw Cke Sq W Van Icing",
  "cs_item_category_desc": "Frozen Cakecupckchsecakebky"
}, {
  "prod_id": "319827",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Alexia Waffle Fries Sea Salt",
  "cs_item_category_desc": "Potatoespierogiesfr"
}, {
  "prod_id": "537756",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Pills Plc Bk Twrl Dgh Cnn",
  "cs_item_category_desc": "Frozen Pastrybky"
}, {
  "prod_id": "308364",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Mc Dd Pastry Pie Shells 2ct",
  "cs_item_category_desc": "Pastrydoughshellsfr"
}, {
  "prod_id": "86465",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Dgn Crsnt Crust Pza 3meat",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "289335",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "El Mont Spcy Bn Chs Chmchng",
  "cs_item_category_desc": "Pkg Heatservemt"
}, {
  "prod_id": "326210",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Alexia Crispy Onion Ring Salt",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "318018",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Coolwhip Light Topping",
  "cs_item_category_desc": "Toppingsfr"
}, {
  "prod_id": "193658",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Invasn Iqf Veg Fried Rce",
  "cs_item_category_desc": "Frozen Meatsmt"
}, {
  "prod_id": "236515",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Clyde Glazed French Fritter",
  "cs_item_category_desc": "Frozen Pastrybky"
}, {
  "prod_id": "291513",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Jdean Ham Brkfst Bowl",
  "cs_item_category_desc": "Pkg Heatservemt"
}, {
  "prod_id": "187716",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Labrea T\u0026B Seeded Sr Dgh Rl",
  "cs_item_category_desc": "Frozen Buns  Rollsbky"
}, {
  "prod_id": "276936",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Kh Bttr Svry Rl 12ct",
  "cs_item_category_desc": "Frozen Buns  Rollsbky"
}, {
  "prod_id": "44061710",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Winston Rd Bx 100$50",
  "cs_item_category_desc": "Cigs 100s And Nonfilter Kingstob"
}, {
  "prod_id": "40005441",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "I/O-Newport Men Slct Clsc 100",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "319599",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Stfr Rb Fst Lasagna W/Meat",
  "cs_item_category_desc": "Entreesfamily Sizefr"
}, {
  "prod_id": "394043",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "I/O-Kim Bk Winter Blu/Wht Ckie",
  "cs_item_category_desc": "Cookiesthawpkgbky"
}, {
  "prod_id": "529270",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "H Dazs Vcrmlpizel Bar 3ct",
  "cs_item_category_desc": "Ice Cream Noveltiesmulti Pkic"
}, {
  "prod_id": "40023912",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Blk\u0026Mld Wn 25ct 1 For $0.89",
  "cs_item_category_desc": "Cigar Productstob"
}, {
  "prod_id": "328451",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Dryr Grand Ic Vb",
  "cs_item_category_desc": "Ice Cream Multi Servebulkic"
}, {
  "prod_id": "304847",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Bnqt Spaghetti \u0026 Meatballs",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "540784",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Blu Bny Ic Chry Pickin\u0027 Choc",
  "cs_item_category_desc": "Ice Cream Multi Servebulkic"
}, {
  "prod_id": "284225",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Lfthse Otml Rsn",
  "cs_item_category_desc": "Cookiesthawpkgbky"
}, {
  "prod_id": "185431",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Invasn Crispy Honey Chicken",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "284497",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Mc Mtlf Grvy Dnr",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "40005813",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "B\u0026H Dlx 100 Nm Bx Fil",
  "cs_item_category_desc": "Cigs 100s And Nonfilter Kingstob"
}, {
  "prod_id": "296342",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Gii Super Crispy Tots",
  "cs_item_category_desc": "Potatoespierogiesfr"
}, {
  "prod_id": "537838",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Rch P Choc Curl 1/4 Sht Cke",
  "cs_item_category_desc": "Frozen Cakecupckchsecakebky"
}, {
  "prod_id": "316996",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "J\u0026J Sp Sft Pretzels Orig 6ct",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "40013275",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Nas Full-Bodied Blue Force Out",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "322327",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Dole Fd Whp Frtcp Pine 4ct",
  "cs_item_category_desc": "Ice Cream Noveltiesmulti Pkic"
}, {
  "prod_id": "206681",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Grtn Fish Portions",
  "cs_item_category_desc": "Fishseafoodfr"
}, {
  "prod_id": "297050",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Bynd Mt Pb Ground Beef Brck",
  "cs_item_category_desc": "Meatless Frozen Meatmt"
}, {
  "prod_id": "291732",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Be Voila Garlic Shrimp",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "303781",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Tinas Chimichanga Family Pack",
  "cs_item_category_desc": "Sandwichburritostrombolifr"
}, {
  "prod_id": "217138",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Pot Pie Top Crust",
  "cs_item_category_desc": "Frozen Piesbky"
}, {
  "prod_id": "294665",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Bnqt Sausage \u0026 Gravy Deep Dish",
  "cs_item_category_desc": "Breakfast Itemsfr"
}, {
  "prod_id": "540730",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "B\u0026J Nd Ic P.B. \u0026 Cki",
  "cs_item_category_desc": "Ice Cream Dairy Freeic"
}, {
  "prod_id": "326711",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Dstk Ic Cones Cki Dip Vrty 8ct",
  "cs_item_category_desc": "Ice Cream Noveltiesmulti Pkic"
}, {
  "prod_id": "301827",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Msf Chik Patties Original",
  "cs_item_category_desc": "Meatless Meat Productsfr"
}, {
  "prod_id": "329364",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "H Dazs Caramel Cone",
  "cs_item_category_desc": "Ice Cream Single Servepintsic"
}, {
  "prod_id": "322933",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "B Yet Death By Choc Ice Cream",
  "cs_item_category_desc": "Ice Cream Multi Servebulkic"
}, {
  "prod_id": "404988",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Halo Mixin Ic Swtcrm Cb",
  "cs_item_category_desc": "Ice Cream Single Servepintsic"
}, {
  "prod_id": "40005435",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Newport Box 100 01510",
  "cs_item_category_desc": "Cigs 100s And Nonfilter Kingstob"
}, {
  "prod_id": "531563",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Tot Pza Rolls Chs 100c",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "391960",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Bert Ckn Florentine \u0026 Farfalle",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "8224",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Blu Bny Twst Choc Van Cns 4ct",
  "cs_item_category_desc": "Ice Cream Noveltiesmulti Pkic"
}, {
  "prod_id": "328191",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Eggo Mini Wfl Cin Tst Fampk 24",
  "cs_item_category_desc": "Breakfast Itemsfr"
}, {
  "prod_id": "415144",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Cafvly Mfns Grmt Bb 4ct",
  "cs_item_category_desc": "Frozen Donutsmuffinsbky"
}, {
  "prod_id": "451148",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "B Yet Frz Strwb \u0026 Ban",
  "cs_item_category_desc": "Fruitsmoothie Mixfr"
}, {
  "prod_id": "154781",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Jwa 8\" Red Velvet Cake",
  "cs_item_category_desc": "Frozen Cakecupckchsecakebky"
}, {
  "prod_id": "534707",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Fast Fxn Breast Nugget",
  "cs_item_category_desc": "Frozen Chickenmt"
}, {
  "prod_id": "536164",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Pf 5 Cheese Texas Toast",
  "cs_item_category_desc": "Breadrollsmuffinsfr"
}, {
  "prod_id": "543281",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Blu Bny Twst Choc Pb Cns 4ct",
  "cs_item_category_desc": "Ice Cream Noveltiesmulti Pkic"
}, {
  "prod_id": "537656",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Rhodes Cinn Rolls",
  "cs_item_category_desc": "Breadrollsmuffinsfr"
}, {
  "prod_id": "311741",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Bnqt Ckn Fried Ckn Meal",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "94081",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Mc Roast Beef",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "581939",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Cmpvrde Sorbet Bars Ccnt 6ct",
  "cs_item_category_desc": "Fruitsmoothie Mixfr"
}, {
  "prod_id": "429365",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Random Weight - Frozen - Seafood",
  "description": "I/O-Nrbst Frz 24 +",
  "cs_item_category_desc": "Turkeys  Frozenmt"
}, {
  "prod_id": "330804",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Lactaid Ic Chocolate",
  "cs_item_category_desc": "Ice Cream Otheric"
}, {
  "prod_id": "537284",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Rch P Rtf Bb Cke Dnut",
  "cs_item_category_desc": "Frozen Donutsmuffinsbky"
}, {
  "prod_id": "415039",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Ft Variety Sampler Cheesecake",
  "cs_item_category_desc": "Frozen Cakecupckchsecakebky"
}, {
  "prod_id": "400942",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Ff Corn Dogs",
  "cs_item_category_desc": "Frozen Meatsmt"
}, {
  "prod_id": "40019886",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Top Cig Papers 51001",
  "cs_item_category_desc": "Cigarette Paperstob"
}, {
  "prod_id": "316787",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "B Yet Buttermilk Waffles",
  "cs_item_category_desc": "Breakfast Itemsfr"
}, {
  "prod_id": "40013276",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Nas Mellow Gold Force Out",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "488019",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Shp-Jj\u0027s Fll Ftr Ps Asst",
  "cs_item_category_desc": "Piesfr"
}, {
  "prod_id": "211484",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Random Weight - Frozen - Seafood",
  "description": "Smoked Turkey Tails Tp",
  "cs_item_category_desc": "Smoked Turkeypartsmt"
}, {
  "prod_id": "241337",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Kh Sldr Bns Pre Slc Orig 9pk",
  "cs_item_category_desc": "Frozen Breadsbky"
}, {
  "prod_id": "287348",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Tllmk Ic Or Dkchry",
  "cs_item_category_desc": "Ice Cream Multi Servebulkic"
}, {
  "prod_id": "292677",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Jdean Trk Ssgegg Wtchcroi4ct",
  "cs_item_category_desc": "Pkg Heatservemt"
}, {
  "prod_id": "44072660",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Pl Ml Select Blue Box",
  "cs_item_category_desc": "Cigs 100s And Nonfilter Kingstob"
}, {
  "prod_id": "317888",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Stfr Tuna Noodle Casserole",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "153664",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "I/O-Mint Chip Bettrcrm",
  "cs_item_category_desc": "Toppingsicingbky"
}, {
  "prod_id": "280758",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Rch P 6ct Choc Iced Dnut",
  "cs_item_category_desc": "Frozen Donutsmuffinsbky"
}, {
  "prod_id": "533988",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Pf Puff Pastry Shells",
  "cs_item_category_desc": "Pastrydoughshellsfr"
}, {
  "prod_id": "60357",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Hsts Bby Bndts Lmn Drzzl 8ct",
  "cs_item_category_desc": "Cakescheesecakesfr"
}, {
  "prod_id": "68946",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Cmpvrde Srbt Cmbo Acai Mngo",
  "cs_item_category_desc": "Fruitsmoothie Mixfr"
}, {
  "prod_id": "160418",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Tuscan Bread",
  "cs_item_category_desc": "Frozen Breadsbky"
}, {
  "prod_id": "322332",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Dole Fd Whp Frtcp Strwb 4ct",
  "cs_item_category_desc": "Ice Cream Noveltiesmulti Pkic"
}, {
  "prod_id": "448527",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Bryr Ic Pstch Alm",
  "cs_item_category_desc": "Ice Cream Multi Servebulkic"
}, {
  "prod_id": "337315",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Tal Gelato Belgian Chocolate",
  "cs_item_category_desc": "Ice Cream Otheric"
}, {
  "prod_id": "206662",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Sara Cherry Ch Cke",
  "cs_item_category_desc": "Cakescheesecakesfr"
}, {
  "prod_id": "40030162",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Nas Mlw Men Hp Grn 6m",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "297369",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Grtn Beer Bat Flt",
  "cs_item_category_desc": "Fishfrozenmt"
}, {
  "prod_id": "315614",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Stfr Ckn Broc Psta Bk Famsz",
  "cs_item_category_desc": "Entreesfamily Sizefr"
}, {
  "prod_id": "144424",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Ts Lt Ic Fdg Swirl Pail",
  "cs_item_category_desc": "Ice Cream Multi Servebulkic"
}, {
  "prod_id": "266457",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Jacks Pepprn Pizza Sticks 4ct",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "40005439",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "I/O-Newport Non Mngld Kg01597",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "311632",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Aktchn Pesto Tortellini Bwl",
  "cs_item_category_desc": "Vegetarianvegan Foodfr"
}, {
  "prod_id": "313053",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Tgif Mozzarella Stick",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "55921",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Pills Buttermilk Biscuit",
  "cs_item_category_desc": "Frozen Buns  Rollsbky"
}, {
  "prod_id": "148906",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Oatmeal Rsn Cookie",
  "cs_item_category_desc": "Cookiesthawpkgbky"
}, {
  "prod_id": "40029943",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Montego Red Kngs Bx",
  "cs_item_category_desc": "Cigs 100s And Nonfilter Kingstob"
}, {
  "prod_id": "263341",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Mrs Redd Raw Pie Shell 6\"",
  "cs_item_category_desc": "Frozen Piesbky"
}, {
  "prod_id": "293715",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Frsch Boc Pza Proni",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "538168",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "2bite Lemon Poppyseed Scones",
  "cs_item_category_desc": "Frozen Pastrybky"
}, {
  "prod_id": "313020",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Hc Smp Unwrpd Brto Bwl",
  "cs_item_category_desc": "Entrees Low Calhealthyfr"
}, {
  "prod_id": "180242",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Jdean Spec Sge Rec Rll-Julian",
  "cs_item_category_desc": "Pork Sausage  Frozenmt"
}, {
  "prod_id": "311974",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Aktchn Cntry Cheddar Bowl",
  "cs_item_category_desc": "Vegetarianvegan Foodfr"
}, {
  "prod_id": "490656",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "S Bcn Spcy Prk Ssg Brck 16 Oz",
  "cs_item_category_desc": "Smoked Sausagemt"
}, {
  "prod_id": "264657",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "B Yet Chpd Collard Greens Frz",
  "cs_item_category_desc": "Vegetablespriv Labfr"
}, {
  "prod_id": "295683",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Gg Spiral Veg Zucchini",
  "cs_item_category_desc": "Vegetarianvegan Foodfr"
}, {
  "prod_id": "535391",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Jdean Ht S Slsa Vrd Bfst Bwl",
  "cs_item_category_desc": "Frozen Meatsmt"
}, {
  "prod_id": "563892",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Tot Pza Rolls Spcy Proni 50ct",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "338398",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Hmx Ic Bars Mini Vp 12ct",
  "cs_item_category_desc": "Ice Cream Noveltiesmulti Pkic"
}, {
  "prod_id": "398413",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Stfr Sides Grnbn Csrl",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "294850",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Rd Brn Clsc Crust Pza Proni",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "538177",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Lfthse Hldy Cki Snwbll Mltwy",
  "cs_item_category_desc": "Cookiesthawpkgbky"
}, {
  "prod_id": "286963",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Bnqt Bns Maple Links",
  "cs_item_category_desc": "Pork Sausage  Frozenmt"
}, {
  "prod_id": "537746",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "2bite Blueberry Scones",
  "cs_item_category_desc": "Frozen Pastrybky"
}, {
  "prod_id": "303782",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Ht Pkt B\u0026B Buff Ckn 2pk",
  "cs_item_category_desc": "Sandwichburritostrombolifr"
}, {
  "prod_id": "326573",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "B Yet Multigrain Waffles",
  "cs_item_category_desc": "Breakfast Itemsfr"
}, {
  "prod_id": "21744",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Jj\u0027s Apple Pie",
  "cs_item_category_desc": "Piesfr"
}, {
  "prod_id": "323472",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Ktkt Ic Cones Vp 8ct",
  "cs_item_category_desc": "Ice Cream Noveltiesmulti Pkic"
}, {
  "prod_id": "289933",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Jdean Bisc Roll-Ups Sec 8ct",
  "cs_item_category_desc": "Pkg Heatservemt"
}, {
  "prod_id": "273035",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Tllmk Ic Choc Hzlnt",
  "cs_item_category_desc": "Ice Cream Multi Servebulkic"
}, {
  "prod_id": "147067",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Hsts Twinkies Banana 10 Count",
  "cs_item_category_desc": "Cakescheesecakesfr"
}, {
  "prod_id": "323451",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Old Orch 100% Jce Conc Apl",
  "cs_item_category_desc": "Juicedrinkslushsnow Conefr"
}, {
  "prod_id": "322591",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "B Yet Maple Walnut Ice Cream",
  "cs_item_category_desc": "Ice Cream Multi Servebulkic"
}, {
  "prod_id": "178202",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Cafvly Bundt Lmn Cke",
  "cs_item_category_desc": "Frozen Cakecupckchsecakebky"
}, {
  "prod_id": "199901",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Clyde Glazed Plain Cake Donuts",
  "cs_item_category_desc": "Frozen Donutsmuffinsbky"
}, {
  "prod_id": "326135",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Klndk Heath Bar",
  "cs_item_category_desc": "Ice Cream Noveltiesmulti Pkic"
}, {
  "prod_id": "40005816",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Va Slim Gld 100mn Bxf07346",
  "cs_item_category_desc": "Cigs 100s And Nonfilter Kingstob"
}, {
  "prod_id": "190291",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Kcmnd Fc Meatloaf W Glaze",
  "cs_item_category_desc": "Frozen Breadsbky"
}, {
  "prod_id": "316741",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Oi Tater Tots",
  "cs_item_category_desc": "Potatoespierogiesfr"
}, {
  "prod_id": "40011027",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Grizzly Snuff",
  "cs_item_category_desc": "Chewing Tobacco  Snufftob"
}, {
  "prod_id": "500975",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Jvl Vt Maple Brkft",
  "cs_item_category_desc": "Pork Sausage  Frozenmt"
}, {
  "prod_id": "291043",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Tllmk Ic Marionberry Pie",
  "cs_item_category_desc": "Ice Cream Multi Servebulkic"
}, {
  "prod_id": "318199",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Smkr Uncrst Sw Choc Hzlnt 4ct",
  "cs_item_category_desc": "Sandwichburritostrombolifr"
}, {
  "prod_id": "592603",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Heartland Entrees Pot Pie Flng",
  "cs_item_category_desc": "Frozen Meatsmt"
}, {
  "prod_id": "40001845",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Camel Crush 85 Bx Mn12207",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "281820",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "I/O-Ttp Swt Potato Pie Bkd 8\"",
  "cs_item_category_desc": "Frozen Piesbky"
}, {
  "prod_id": "40013082",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "I/O-Durango Chew Tobacco00809",
  "cs_item_category_desc": "Chewing Tobacco  Snufftob"
}, {
  "prod_id": "329103",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "B\u0026J Ice Cream Vanilla",
  "cs_item_category_desc": "Ice Cream Single Servepintsic"
}, {
  "prod_id": "390325",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Yummy Dino Nae Wg Ckn Nggt",
  "cs_item_category_desc": "Frozen Meatsmt"
}, {
  "prod_id": "302767",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Tai Pei General Tso\u0027s Spcy Ckn",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "210715",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Random Weight - Frozen - Seafood",
  "description": "Smoked Turkey Neck Tp",
  "cs_item_category_desc": "Turkeys  Frozenmt"
}, {
  "prod_id": "326145",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Hm Selects Clsc Fried Ckn",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "321297",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Hm Pubfav Beer Batr Ckn",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "458886",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Otsh Frt Bars Crmy Ccnt 6ct",
  "cs_item_category_desc": "Ice Cream Noveltiesmulti Pkic"
}, {
  "prod_id": "634892",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Random Weight - Frozen - Seafood",
  "description": "73% Fine Ground Beef",
  "cs_item_category_desc": "Frozen Meatsmt"
}, {
  "prod_id": "336154",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "B\u0026J Non Dry Ic Choc Fdg Brwni",
  "cs_item_category_desc": "Ice Cream Dairy Freeic"
}, {
  "prod_id": "316514",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Pills Pie Crusts Dd 2ct",
  "cs_item_category_desc": "Pastrydoughshellsfr"
}, {
  "prod_id": "282019",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "El Mont Tco Ssn Bf Chs 18ct",
  "cs_item_category_desc": "Pkg Heatservemt"
}, {
  "prod_id": "40005788",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Marl Red Lbl 100bx Fl03690",
  "cs_item_category_desc": "Cigs 100s And Nonfilter Kingstob"
}, {
  "prod_id": "278079",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Lbrea French Bguette Par Bk",
  "cs_item_category_desc": "Frozen Breadsbky"
}, {
  "prod_id": "316233",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Ht Pkt Crsnt Pkt Proni Pza",
  "cs_item_category_desc": "Sandwichburritostrombolifr"
}, {
  "prod_id": "303140",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Tai Pei Sweet \u0026 Sour Chicken",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "544132",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Dgn Rsgcrst Pza 3meat",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "294523",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Hsts Frst Mini Donut",
  "cs_item_category_desc": "Cakescheesecakesfr"
}, {
  "prod_id": "44062466",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Lcky Strk Gold Box",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "597875",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Random Weight - Frozen - Seafood",
  "description": "Wvm Crn L Tr Smkd Prk Shnk Tp",
  "cs_item_category_desc": "Frozen Meatsmt"
}, {
  "prod_id": "470622",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Wld Mk Ult Pza Cmbo Spsz",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "327383",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "B\u0026J Choc Chip Cookie Dough",
  "cs_item_category_desc": "Ice Cream Single Servepintsic"
}, {
  "prod_id": "588532",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Random Weight - Frozen - Seafood",
  "description": "Wvm Beef Scoaded Tripe Diced",
  "cs_item_category_desc": "Beef Offalmt"
}, {
  "prod_id": "40005822",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Va Slim 100 Mn Bx Fl07746",
  "cs_item_category_desc": "Cigs 100s And Nonfilter Kingstob"
}, {
  "prod_id": "40001880",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Camel Gold Box",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "537711",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Deli Exp Market Italian Wrap",
  "cs_item_category_desc": "Frozen Meatsmt"
}, {
  "prod_id": "285743",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Lfthse Ylw Fsc 10ct",
  "cs_item_category_desc": "Frozen Cookie Batterbky"
}, {
  "prod_id": "538053",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Rch P Dl Ccnt Wht Cke W Whp Cn",
  "cs_item_category_desc": "Frozen Cakecupckchsecakebky"
}, {
  "prod_id": "40021894",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Kool Blue 100 Bx Men",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "300903",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Tai Pei Shrimp Fried Rice",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "327381",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "H Dazs Ice Cream Rocky Road",
  "cs_item_category_desc": "Ice Cream Single Servepintsic"
}, {
  "prod_id": "449090",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Random Weight - Frozen - Seafood",
  "description": "Beef Heart Prepacked",
  "cs_item_category_desc": "Frozen Meatsmt"
}, {
  "prod_id": "44062141",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Marl Blk Sp Bl Bx $1",
  "cs_item_category_desc": "Cigs 100s And Nonfilter Kingstob"
}, {
  "prod_id": "537986",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "I/O-Rch P Strwbry Bettercrm",
  "cs_item_category_desc": "Toppingsicingbky"
}, {
  "prod_id": "446693",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Hsts Cupcakes Strawberry",
  "cs_item_category_desc": "Cakescheesecakesfr"
}, {
  "prod_id": "377190",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Jlb Lemon Meringue Pie Ss 8\"",
  "cs_item_category_desc": "Frozen Piesbky"
}, {
  "prod_id": "598650",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Tcf 24/7 Bby Got Bundt Rr Ss",
  "cs_item_category_desc": "Frozen Cakecupckchsecakebky"
}, {
  "prod_id": "40018117",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Cpnhgn Lng Cut Snuff",
  "cs_item_category_desc": "Chewing Tobacco  Snufftob"
}, {
  "prod_id": "544061",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Dgn Rising Crust Pizza Supreme",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "90266",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Crvn Flv Ic Treats Vp 32ct",
  "cs_item_category_desc": "Ice Cream Noveltiesmulti Pkic"
}, {
  "prod_id": "318943",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "B Yet Ornge Jce Cntry Styl/Wic",
  "cs_item_category_desc": "Juicedrinkspriv Labfr"
}, {
  "prod_id": "335073",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "H Dazs Ic Pine Ccnt",
  "cs_item_category_desc": "Ice Cream Single Servepintsic"
}, {
  "prod_id": "62991",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Old Orch Berry Blend Juice",
  "cs_item_category_desc": "Juicedrinkslushsnow Conefr"
}, {
  "prod_id": "315918",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "B Yet Oj Calc Fortified",
  "cs_item_category_desc": "Juicedrinkspriv Labfr"
}, {
  "prod_id": "305749",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Invasn Vegetable Fried Rice",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "40016335",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Blk\u0026Mld Wine Wt 25ct",
  "cs_item_category_desc": "Cigar Productstob"
}, {
  "prod_id": "429921",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Hnz Dvr Bwl Spcy Prk M C",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "40028747",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Lcky Strk Mnthl 100 Box",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "18425",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Csm Blueberry Mini Muffins",
  "cs_item_category_desc": "Frozen Donutsmuffinsbky"
}, {
  "prod_id": "313404",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Kd Csne Chicken Nugget",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "325698",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Tgif Crm Chse Stuffed Jalapeno",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "187737",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "I/O-Labrea T B Rsmry Fccc Rl",
  "cs_item_category_desc": "Frozen Buns  Rollsbky"
}, {
  "prod_id": "40030163",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Nas Mlw Org Hp Gold 6m",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "327391",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Bryr Natural Vanilla Ic",
  "cs_item_category_desc": "Ice Cream Multi Servebulkic"
}, {
  "prod_id": "44071329",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Salem Silver Box 100\u0027s",
  "cs_item_category_desc": "Cigs 100s And Nonfilter Kingstob"
}, {
  "prod_id": "544053",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Dgn Rsgcrst Pza Haw",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "150877",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Hills Maple Pork Link Sausage",
  "cs_item_category_desc": "Smoked Sausagemt"
}, {
  "prod_id": "144290",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Ts Ic Choc Lt Pail",
  "cs_item_category_desc": "Ice Cream Multi Servebulkic"
}, {
  "prod_id": "537704",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Deli Exp Ranch Ckn Sld Sw",
  "cs_item_category_desc": "Frozen Delidl"
}, {
  "prod_id": "302922",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Msf Chik\u0027n Nuggets",
  "cs_item_category_desc": "Meatless Meat Productsfr"
}, {
  "prod_id": "327756",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "B\u0026J Ic Van Crml Fdg",
  "cs_item_category_desc": "Ice Cream Single Servepintsic"
}, {
  "prod_id": "327409",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "B\u0026J Peanut Butter Cup",
  "cs_item_category_desc": "Ice Cream Single Servepintsic"
}, {
  "prod_id": "294072",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Rmp Ss Chry Cobbler",
  "cs_item_category_desc": "Frozen Piesbky"
}, {
  "prod_id": "40001856",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Camel Blue 85 Box 30594",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "317429",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Ht Pkt Crsnt Pkt Ham\u0026 Cheddar",
  "cs_item_category_desc": "Sandwichburritostrombolifr"
}, {
  "prod_id": "302244",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Lfthse Spng Grn Fsc Try 18ct",
  "cs_item_category_desc": "Cookiesthawpkgbky"
}, {
  "prod_id": "561520",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Jo Dblstf Tqts Ckn Chs 10ct",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "391839",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Bert Shrimp Scampi Linguine",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "325910",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Aktchn Macaroni \u0026 Cheese",
  "cs_item_category_desc": "Vegetarianvegan Foodfr"
}, {
  "prod_id": "538403",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Rich Eclair Shells 878",
  "cs_item_category_desc": "Frozen Pastrybky"
}, {
  "prod_id": "40022923",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "I/O-Pl Ml Red Box $.50/1 Pk",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "67057",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "I/O-Carlfrm Ground Pork",
  "cs_item_category_desc": "Frozen Meatsmt"
}, {
  "prod_id": "44062469",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Lcky Strk Menth Silver Box",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "51935",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "El Mont Ckn Quasadilla Meal",
  "cs_item_category_desc": "Frozen Meatsmt"
}, {
  "prod_id": "511311",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Bnqt Chsy Patty Meal",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "40005821",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Va Slim 100 Bx Fil 07726",
  "cs_item_category_desc": "Cigs 100s And Nonfilter Kingstob"
}, {
  "prod_id": "317889",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Ht Pkt 4 Cheese",
  "cs_item_category_desc": "Sandwichburritostrombolifr"
}, {
  "prod_id": "27276",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Jvl Ital Ssg Ground Mild",
  "cs_item_category_desc": "Pork Sausage  Frozenmt"
}, {
  "prod_id": "525242",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Tal Srbtt Brs Smr Strwb 6ct",
  "cs_item_category_desc": "Ice Cream Noveltiesmulti Pkic"
}, {
  "prod_id": "354552",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Random Weight - Frozen - Seafood",
  "description": "S Cntr Ct Bn Hm Stks Nat Jc",
  "cs_item_category_desc": "Frozen Meatsmt"
}, {
  "prod_id": "295587",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Hnz Dvr Wht Chdr Bcn Mac \u0026 Chs",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "40005609",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Pl Ml Orange Ksb Fsc",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "291840",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Hsts Pwd Sgr Mn Dnt Bg Fzn",
  "cs_item_category_desc": "Frozen Cakecupckchsecakebky"
}, {
  "prod_id": "242769",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Prm Prtn Prtn Pancakes 12ct",
  "cs_item_category_desc": "Breakfast Itemsfr"
}, {
  "prod_id": "86165",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Hc Cafe Stmr Asian Pine Ckn",
  "cs_item_category_desc": "Entrees Low Calhealthyfr"
}, {
  "prod_id": "311802",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "B Yet Fz Mx Veg Steamable",
  "cs_item_category_desc": "Vegetablespriv Labfr"
}, {
  "prod_id": "446592",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Lfthse Fsc Hpy Bday Cke 10ct",
  "cs_item_category_desc": "Frozen Cookie Batterbky"
}, {
  "prod_id": "40001867",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Camel Wides 85 Box 32966",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "289446",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Jdean Ht N Srv Link Rg Vp",
  "cs_item_category_desc": "Pork Sausage  Frozenmt"
}, {
  "prod_id": "61308",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Ff Mini Chkn Corn Dogs/84 Ct",
  "cs_item_category_desc": "Frozen Chickenmt"
}, {
  "prod_id": "313212",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "B Yet Mixed Vegetables",
  "cs_item_category_desc": "Vegetablespriv Labfr"
}, {
  "prod_id": "59924",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Ff Gf Corn Dogs 12ct",
  "cs_item_category_desc": "Pkg Heatservemt"
}, {
  "prod_id": "533857",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Stfr Pty Sz Veg Lasg Cpk",
  "cs_item_category_desc": "Entreesfamily Sizefr"
}, {
  "prod_id": "428417",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Crvn Flv Pza Rsgcrst Proni",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "416938",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Tot Bfst Snk Bts Bcn Chs 40ct",
  "cs_item_category_desc": "Breakfast Itemsfr"
}, {
  "prod_id": "149322",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Labrea T B Frnch Bgtt Twn Pk",
  "cs_item_category_desc": "Frozen Breadsbky"
}, {
  "prod_id": "40021887",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Winston Gold 100 Box Lip",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "151350",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Apple Fritter Pf",
  "cs_item_category_desc": "Frozen Pastrybky"
}, {
  "prod_id": "305558",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Tot Party Pizza Triple Meat",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "597875",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Random Weight - Frozen - Seafood",
  "description": "Wvm Crn L Tr Smkd Prk Shnk Tp",
  "cs_item_category_desc": "Pork Offalmt"
}, {
  "prod_id": "528179",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Mc Thaw \u0026 Enjoy Key Lime Pie",
  "cs_item_category_desc": "Piesfr"
}, {
  "prod_id": "142825",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Hsts Twinkies 10 Count",
  "cs_item_category_desc": "Cakescheesecakesfr"
}, {
  "prod_id": "184173",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Invasn 60009 Pork Pot Stickers",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "200558",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Jvl Cheddar Bratwurst",
  "cs_item_category_desc": "Pork Sausage  Frozenmt"
}, {
  "prod_id": "314594",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Stfr Rb Fsr Chicken Alfredo",
  "cs_item_category_desc": "Entreesfamily Sizefr"
}, {
  "prod_id": "535182",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Mc Pot Pie Cheesy Ckn Bcn Ls",
  "cs_item_category_desc": "Pot Piesfr"
}, {
  "prod_id": "367361",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Msf Veggie Corn Dogs 4 Count",
  "cs_item_category_desc": "Meatless Meat Productsfr"
}, {
  "prod_id": "302458",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Bnqt Classics Bckyd Bbq Meal",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "296310",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Hsts Ho Ho Mp 10 Ct",
  "cs_item_category_desc": "Cakescheesecakesfr"
}, {
  "prod_id": "632561",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Jennie 95% All Nat Wht Burg",
  "cs_item_category_desc": "Frozen Meatsmt"
}, {
  "prod_id": "40027419",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Dosal Tax Only",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "531571",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Tot Pza Rolls Trpl Meat 100c",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "32640",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Hsts Twinkies Fampk 16ct",
  "cs_item_category_desc": "Breakfast Itemsfr"
}, {
  "prod_id": "311804",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "B Yet Cut Corn Frz",
  "cs_item_category_desc": "Vegetablespriv Labfr"
}, {
  "prod_id": "537732",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Rch P Dl Cki Crm Cke W Whp Cng",
  "cs_item_category_desc": "Frozen Cakecupckchsecakebky"
}, {
  "prod_id": "21851",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Jj\u0027s Lemon Pie",
  "cs_item_category_desc": "Piesfr"
}, {
  "prod_id": "165796",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Hills Hot Ital Ssg Brck",
  "cs_item_category_desc": "Frozen Meatsmt"
}, {
  "prod_id": "536424",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Richs Full Sheet White Cake",
  "cs_item_category_desc": "Frozen Cakecupckchsecakebky"
}, {
  "prod_id": "193518",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Invasn Veg Lo Mein Ndl Kit",
  "cs_item_category_desc": "Frozen Meatsmt"
}, {
  "prod_id": "536490",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Lbrea Rsmry Olive Lf Par Bk",
  "cs_item_category_desc": "Frozen Breadsbky"
}, {
  "prod_id": "333111",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Fatboy Vanilla Sanwich 12pk",
  "cs_item_category_desc": "Ice Cream Noveltiesmulti Pkic"
}, {
  "prod_id": "297376",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Hm Selects Mex Fiesta",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "295586",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Flavrpac Whole Kernel Corn",
  "cs_item_category_desc": "Vegetablesfr"
}, {
  "prod_id": "44071267",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Blk\u0026Mld Wine Wood Tip",
  "cs_item_category_desc": "Cigar Productstob"
}, {
  "prod_id": "44058561",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Grizzly Lc Strt $.50",
  "cs_item_category_desc": "Chewing Tobacco  Snufftob"
}, {
  "prod_id": "309950",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Ed Gourmet Cki\u0026Crm Pie",
  "cs_item_category_desc": "Piesfr"
}, {
  "prod_id": "292216",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Random Weight - Frozen - Seafood",
  "description": "I/O-Norbst 8-10 Hens Frz",
  "cs_item_category_desc": "Turkeys  Frozenmt"
}, {
  "prod_id": "564987",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Dlmx Taquitos Ckn \u0026 Chs 16ct",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "431894",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "I/O-Ed Gourmet Turtle Crm Pie",
  "cs_item_category_desc": "Piesfr"
}, {
  "prod_id": "309674",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "B Yet French Cut Beans Frz",
  "cs_item_category_desc": "Vegetablespriv Labfr"
}, {
  "prod_id": "168038",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Raos Boc Pza 5chs",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "295813",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Mrs Smiths Pumpkin Pie",
  "cs_item_category_desc": "Piesfr"
}, {
  "prod_id": "319751",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Pf Garlic Bread",
  "cs_item_category_desc": "Breadrollsmuffinsfr"
}, {
  "prod_id": "223039",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Mc Beef Pot Pie",
  "cs_item_category_desc": "Pot Piesfr"
}, {
  "prod_id": "295158",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Dole Sliced Peaches",
  "cs_item_category_desc": "Fruitsmoothie Mixfr"
}, {
  "prod_id": "598039",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Random Weight - Frozen - Seafood",
  "description": "Wvm Crn L Tr Smkd Prk Hck Tp",
  "cs_item_category_desc": "Pork Offalmt"
}, {
  "prod_id": "298684",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Mc Pumpkin Pie",
  "cs_item_category_desc": "Piesfr"
}, {
  "prod_id": "342390",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Bfflo Ht Spcy Wngs Flly Ckd",
  "cs_item_category_desc": "Frozen Chickenmt"
}, {
  "prod_id": "308853",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Eggo Strawberry Waffle",
  "cs_item_category_desc": "Breakfast Itemsfr"
}, {
  "prod_id": "305683",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Eggo Blueberry Waffles",
  "cs_item_category_desc": "Breakfast Itemsfr"
}, {
  "prod_id": "40024656",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "305\u0027s 100 Blue Box",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "193086",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Invasn Orange Chicken",
  "cs_item_category_desc": "Frozen Meatsmt"
}, {
  "prod_id": "538317",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Rch P Ylw Cke Sq W Choc Icing",
  "cs_item_category_desc": "Frozen Cakecupckchsecakebky"
}, {
  "prod_id": "317063",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Coolwhip Whp Topping Orig",
  "cs_item_category_desc": "Toppingsfr"
}, {
  "prod_id": "165086",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Hills Chli Smkd Pprk Lnk Ssg",
  "cs_item_category_desc": "Frozen Meatsmt"
}, {
  "prod_id": "312515",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Mm White Lemonade",
  "cs_item_category_desc": "Juicedrinkslushsnow Conefr"
}, {
  "prod_id": "335584",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Bryr Ic Reese\u0027s Pbc",
  "cs_item_category_desc": "Ice Cream Multi Servebulkic"
}, {
  "prod_id": "83295",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Random Weight - Frozen - Seafood",
  "description": "Pork Neckbones",
  "cs_item_category_desc": "Pork Offalmt"
}, {
  "prod_id": "597873",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Random Weight - Frozen - Seafood",
  "description": "Wvm Beef Feet Diced",
  "cs_item_category_desc": "Beef Offalmt"
}, {
  "prod_id": "518766",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Random Weight - Frozen - Seafood",
  "description": "Btrbl Yng Trky 14-16",
  "cs_item_category_desc": "Turkeys  Frozenmt"
}, {
  "prod_id": "191067",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Rmp 8\" Ss Apl Lattice Bxd Pies",
  "cs_item_category_desc": "Frozen Piesbky"
}, {
  "prod_id": "51769",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Lc Fav Ckn Fettuccini",
  "cs_item_category_desc": "Entrees Low Calhealthyfr"
}, {
  "prod_id": "44060678",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "I/O-Backwoods Grape Cigars",
  "cs_item_category_desc": "Cigar Productstob"
}, {
  "prod_id": "544015",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Dgn Rsgcrst Pza 4chs",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "285531",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "I/O-Lfthse Pat Star Sgr Cki",
  "cs_item_category_desc": "Frozen Cookie Batterbky"
}, {
  "prod_id": "535241",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Bnqt Bs Hot Spicy",
  "cs_item_category_desc": "Frozen Chickenmt"
}, {
  "prod_id": "315056",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "B Yet Apple Jce/Wic",
  "cs_item_category_desc": "Juicedrinkspriv Labfr"
}, {
  "prod_id": "369823",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Random Weight - Frozen - Seafood",
  "description": "Frozen Cab Bnls Strips",
  "cs_item_category_desc": "Frozen Meatsmt"
}, {
  "prod_id": "40001874",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Camel Blue 99 Box 33965",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "128410",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Mcc Frsh Styl Pbfry 3 8 Skn On",
  "cs_item_category_desc": "Frozen Meatsmt"
}, {
  "prod_id": "284864",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Jvl Beer\u0027n Bratwurst",
  "cs_item_category_desc": "Pork Sausage  Frozenmt"
}, {
  "prod_id": "486421",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Jj\u0027s Raspberry Pie",
  "cs_item_category_desc": "Piesfr"
}, {
  "prod_id": "241846",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "I/O-Hsf Hf Fc Hm Chs Clb Snd",
  "cs_item_category_desc": "Frozen Meatsmt"
}, {
  "prod_id": "528180",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Mc Peanut Btr Crm Pie",
  "cs_item_category_desc": "Piesfr"
}, {
  "prod_id": "391847",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Pfc Chicken Fried Rice",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "316972",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Bgl Bt Pza Snk 3chs 9ct",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "319497",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Stfr Fettucini Alfredo",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "44059138",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Crowns Gold Box 100s",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "277943",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "I/O-Cafvly Chry Turnover 4ct",
  "cs_item_category_desc": "Frozen Pastrybky"
}, {
  "prod_id": "432247",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "B Yet Frozen Berry Medley",
  "cs_item_category_desc": "Fruitsmoothie Mixfr"
}, {
  "prod_id": "287818",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Jdean Ssge/Egg/Chs Bsct 4c",
  "cs_item_category_desc": "Pkg Heatservemt"
}, {
  "prod_id": "40005786",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Marl B 100 Men Bx Fil 03646",
  "cs_item_category_desc": "Cigs 100s And Nonfilter Kingstob"
}, {
  "prod_id": "40005611",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Pl Ml Pallsav Red 85 Box 01438",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "284939",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Jdean Bfst Bwl Ssg \u0026 Grvy",
  "cs_item_category_desc": "Pkg Heatservemt"
}, {
  "prod_id": "40005829",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Marl Spblnd Black 100\u0027s Bx",
  "cs_item_category_desc": "Cigs 100s And Nonfilter Kingstob"
}, {
  "prod_id": "426197",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Lc Pepperoni Pizza",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "97309",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Cmf Tpt Brrts Bf Bn Chs",
  "cs_item_category_desc": "Sandwichburritostrombolifr"
}, {
  "prod_id": "309966",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "B Yet Fz Corn Steamable",
  "cs_item_category_desc": "Vegetablespriv Labfr"
}, {
  "prod_id": "313147",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Stfr Meat Lovers Lasagn",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "447699",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "B Yet Frz Strwb Ban Sup",
  "cs_item_category_desc": "Fruitsmoothie Mixfr"
}, {
  "prod_id": "528186",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Be Sf Lgrn Wht Rce W Mxv",
  "cs_item_category_desc": "Vegetablesfr"
}, {
  "prod_id": "321419",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Aktchn Bean And Cheese Burrito",
  "cs_item_category_desc": "Vegetarianvegan Foodfr"
}, {
  "prod_id": "341321",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Jvl Italian Sausage Ground Hot",
  "cs_item_category_desc": "Frozen Meatsmt"
}, {
  "prod_id": "44059137",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Crowns Gold Box",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "40001211",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Eve Amethyst 120s Bx",
  "cs_item_category_desc": "Cigs 100s And Nonfilter Kingstob"
}, {
  "prod_id": "292507",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Frsch Nrc Pza Sprm",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "40001870",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Doral Red 85 Box 32969",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "533986",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Be Sf Mixed Vegetables",
  "cs_item_category_desc": "Vegetablesfr"
}, {
  "prod_id": "314962",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "B Yet Crinkle Cut Carro",
  "cs_item_category_desc": "Vegetablespriv Labfr"
}, {
  "prod_id": "356094",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "I/O-Ed Gourmet Chc Snd Pie 2pk",
  "cs_item_category_desc": "Piesfr"
}, {
  "prod_id": "295175",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Aktchn Gf Nchld Rstd Pbln",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "40083643",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Blk\u0026Mld Jazz Plst .89",
  "cs_item_category_desc": "Cigar Productstob"
}, {
  "prod_id": "295639",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Flavrpac Petite Peas",
  "cs_item_category_desc": "Vegetablesfr"
}, {
  "prod_id": "195331",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Ft Ny Style Plain Chsck 6\u0027",
  "cs_item_category_desc": "Frozen Cakecupckchsecakebky"
}, {
  "prod_id": "536152",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Stfr Creamed Chipped Beef",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "316764",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Oi Mini Tater Tots",
  "cs_item_category_desc": "Potatoespierogiesfr"
}, {
  "prod_id": "544149",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Dgn Rsgcrst Pza Ssg Proni",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "40005849",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Marl C Nxt 31776",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "540805",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Tllmk Ice Cream Caramel Swirl",
  "cs_item_category_desc": "Ice Cream Multi Servebulkic"
}, {
  "prod_id": "481770",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Hills Pork Link Sausage Bulk",
  "cs_item_category_desc": "Frozen Meatsmt"
}, {
  "prod_id": "592602",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Crnflk Brd Rtc Jmb Ckn Tndr",
  "cs_item_category_desc": "Frozen Meatsmt"
}, {
  "prod_id": "241799",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Tys Fun Ckn Nugget",
  "cs_item_category_desc": "Tyson Chickenmt"
}, {
  "prod_id": "329896",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "I/O-Hmebke Plld Prk W Bbq Sce",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "40025404",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "I/O-Cpnhgn Lc Spr $0.50 Off",
  "cs_item_category_desc": "Chewing Tobacco  Snufftob"
}, {
  "prod_id": "40005618",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "I/O-Bglr Cigpaper 115c82003",
  "cs_item_category_desc": "Cigarette Paperstob"
}, {
  "prod_id": "537335",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Aln Full Sht Uniced Choc Ck",
  "cs_item_category_desc": "Frozen Cakecupckchsecakebky"
}, {
  "prod_id": "147110",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Hsts Ding Dongs Ss 2ct",
  "cs_item_category_desc": "Frozen Pastrybky"
}, {
  "prod_id": "560845",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Ll Potstickers Spicy Chicken",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "311819",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "B Yet Fz Peas \u0026 Diced Carrots",
  "cs_item_category_desc": "Vegetablespriv Labfr"
}, {
  "prod_id": "537144",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Richs 1/2sht Crt Lyr Ck",
  "cs_item_category_desc": "Frozen Cakecupckchsecakebky"
}, {
  "prod_id": "306814",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Tot Party Pizza Triple Cheese",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "540749",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Klndk Ic Cns Rees Choc Pb 8ct",
  "cs_item_category_desc": "Ice Cream Noveltiesmulti Pkic"
}, {
  "prod_id": "426529",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Crvn Flv Pza Rsgcrst Sprm",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "40001223",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Pyramid Red 100 Box 40830",
  "cs_item_category_desc": "Cigs 100s And Nonfilter Kingstob"
}, {
  "prod_id": "327198",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Crvn Flv Fudge Bars 12 Count",
  "cs_item_category_desc": "Ice Cream Noveltiesmulti Pkic"
}, {
  "prod_id": "326168",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Mm Limeade",
  "cs_item_category_desc": "Juicedrinkslushsnow Conefr"
}, {
  "prod_id": "315553",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Mc Turkey Pot Pie",
  "cs_item_category_desc": "Pot Piesfr"
}, {
  "prod_id": "64887",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "B Yet Potatoe W On \u0026 Peppers",
  "cs_item_category_desc": "Potatoespriv Labfr"
}, {
  "prod_id": "536147",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Stfr Esy Expres Chse Lasagne",
  "cs_item_category_desc": "Entreesfamily Sizefr"
}, {
  "prod_id": "319766",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Sara Classic Cheesecake",
  "cs_item_category_desc": "Cakescheesecakesfr"
}, {
  "prod_id": "483323",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Random Weight - Frozen - Seafood",
  "description": "Beef Back Ribs Frozen",
  "cs_item_category_desc": "Frozen Meatsmt"
}, {
  "prod_id": "293685",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Be Steamfresh Cut Green Beans",
  "cs_item_category_desc": "Vegetablesfr"
}, {
  "prod_id": "295849",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Bnqt Mac \u0026 Cheese",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "291727",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Tllmk Ice Cream Mudslide",
  "cs_item_category_desc": "Ice Cream Multi Servebulkic"
}, {
  "prod_id": "44071330",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Kool Box 100\u0027s",
  "cs_item_category_desc": "Cigs 100s And Nonfilter Kingstob"
}, {
  "prod_id": "289646",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Mc Beef Pot Pie",
  "cs_item_category_desc": "Pot Piesfr"
}, {
  "prod_id": "291760",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "I/O-Jvl Chd Ch Br Lnks Lt",
  "cs_item_category_desc": "Pork Sausage  Frozenmt"
}, {
  "prod_id": "449131",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Bryr Cs Ic Choc Pb",
  "cs_item_category_desc": "Ice Cream Multi Servebulkic"
}, {
  "prod_id": "354308",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Eggo Gng Lge Wfl Cc 4ct",
  "cs_item_category_desc": "Breakfast Itemsfr"
}, {
  "prod_id": "295523",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Bryr Ic Sb Shrtck",
  "cs_item_category_desc": "Ice Cream Multi Servebulkic"
}, {
  "prod_id": "295662",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Flavrpac Chw Mn Veg Str Fry",
  "cs_item_category_desc": "Vegetablesfr"
}, {
  "prod_id": "317162",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Pills Gr Bisc Btrmlk 12ct",
  "cs_item_category_desc": "Breadrollsmuffinsfr"
}, {
  "prod_id": "583176",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Scow Ic Sw Van Gone Wild 4ct",
  "cs_item_category_desc": "Ice Cream Noveltiesmulti Pkic"
}, {
  "prod_id": "44071331",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Salem Box 100\u0027s",
  "cs_item_category_desc": "Cigs 100s And Nonfilter Kingstob"
}, {
  "prod_id": "447236",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "B Yet Frz Dk Swt Chry",
  "cs_item_category_desc": "Fruitsmoothie Mixfr"
}, {
  "prod_id": "318206",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Pf Three Layer Cake Coconut",
  "cs_item_category_desc": "Cakescheesecakesfr"
}, {
  "prod_id": "325589",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "B Yet French Vanilla Ice Cream",
  "cs_item_category_desc": "Ice Cream Multi Servebulkic"
}, {
  "prod_id": "537219",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Orng Bk Prsgrd Apl Strdl Bts",
  "cs_item_category_desc": "Frozen Danishbky"
}, {
  "prod_id": "325322",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Hm Boneless Fried Chicken",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "172928",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Hsts Chocolate Baby Bundts",
  "cs_item_category_desc": "Cakescheesecakesfr"
}, {
  "prod_id": "304007",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Bnqt Chicken Breast Nuggets",
  "cs_item_category_desc": "Chickenfr"
}, {
  "prod_id": "543337",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Red Robin Crispy Onion Rings",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "310693",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Sara All Btr Lb Cke Famsz",
  "cs_item_category_desc": "Cakescheesecakesfr"
}, {
  "prod_id": "490552",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "S Bcn Spcy Prk Ssg Brck 16 Oz",
  "cs_item_category_desc": "Smoked Sausagemt"
}, {
  "prod_id": "537812",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Orng Bk Prsgrd Apl Trnvr",
  "cs_item_category_desc": "Frozen Pastrybky"
}, {
  "prod_id": "427071",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "B Yet Straight Cut Potatoes",
  "cs_item_category_desc": "Potatoespriv Labfr"
}, {
  "prod_id": "301243",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Hc Cafe Steamers Beef Teriyaki",
  "cs_item_category_desc": "Entrees Low Calhealthyfr"
}, {
  "prod_id": "292394",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Tllmk Ic Malted Moo Shk",
  "cs_item_category_desc": "Ice Cream Multi Servebulkic"
}, {
  "prod_id": "65897",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Cmpvrde Jumbo Strawberries",
  "cs_item_category_desc": "Fruitsmoothie Mixfr"
}, {
  "prod_id": "536114",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Jdean Ssg \u0026 3chs Egg Bites",
  "cs_item_category_desc": "Pkg Heatservemt"
}, {
  "prod_id": "133341",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Tot Pza Rolls Cmbo 15ct",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "317732",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Smkr Uncrst Pb Strwb 15pk",
  "cs_item_category_desc": "Sandwichburritostrombolifr"
}, {
  "prod_id": "122459",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Random Weight - Frozen - Seafood",
  "description": "Btrbl Lil Tky",
  "cs_item_category_desc": "Turkeys  Frozenmt"
}, {
  "prod_id": "51410",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Smkr Uncrst Pb Strwb Jam 10ct",
  "cs_item_category_desc": "Sandwichburritostrombolifr"
}, {
  "prod_id": "334465",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Lactaid Ic Vanilla",
  "cs_item_category_desc": "Ice Cream Otheric"
}, {
  "prod_id": "40005806",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Marl B Silvr 100 M Bx F04856",
  "cs_item_category_desc": "Cigs 100s And Nonfilter Kingstob"
}, {
  "prod_id": "326173",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "B Yet Strawberry Ice Cream",
  "cs_item_category_desc": "Ice Cream Multi Servebulkic"
}, {
  "prod_id": "40005795",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Marl B Gold Kgf Mn Bx 04010",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "40000760",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "305\u0027s Silver 100 Box",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "225295",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Tys Signature Buff Wings",
  "cs_item_category_desc": "Further Prepared Chickenmt"
}, {
  "prod_id": "304409",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Tinas Bf \u0026 Bn Family Pack",
  "cs_item_category_desc": "Sandwichburritostrombolifr"
}, {
  "prod_id": "40013279",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Nas Smth Orng 857010",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "536159",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Lc Santa Fe Rice Bean",
  "cs_item_category_desc": "Entrees Low Calhealthyfr"
}, {
  "prod_id": "40001217",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Eagle 20 Red 100 Bx 28830",
  "cs_item_category_desc": "Cigs 100s And Nonfilter Kingstob"
}, {
  "prod_id": "490454",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Smfld Fc Sausage Patty Bulk",
  "cs_item_category_desc": "Pork Sausage  Frozenmt"
}, {
  "prod_id": "70389",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Random Weight - Frozen - Seafood",
  "description": "Aa Can Tri Tips Frz",
  "cs_item_category_desc": "Frozen Meatsmt"
}, {
  "prod_id": "223256",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Jvl Ital Ssg Ground Swt",
  "cs_item_category_desc": "Pork Sausage  Frozenmt"
}, {
  "prod_id": "40005847",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "I/O-L\u0026M Turkish Blnd Box31396",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "538385",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Ice Cream Cake.Butterfinger 8\"",
  "cs_item_category_desc": "Frozen Cakecupckchsecakebky"
}, {
  "prod_id": "301471",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Mc Cntry Frd Pk Ch",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "144559",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Deli Exp Pancake Sw Sec",
  "cs_item_category_desc": "Frozen Sandwiches  Mt"
}, {
  "prod_id": "303808",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Lc Prtn Kick Vt Wht Chdr M C",
  "cs_item_category_desc": "Entrees Low Calhealthyfr"
}, {
  "prod_id": "604078",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Curlys Shredded Beef Brisket",
  "cs_item_category_desc": "Frozen Meatsmt"
}, {
  "prod_id": "326217",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "B Yet Neopolitan Ice Cream",
  "cs_item_category_desc": "Ice Cream Multi Servebulkic"
}, {
  "prod_id": "40005834",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Marl A 72 Bx Fil 09630",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "537135",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Lfthse Fsc Blu 10ct",
  "cs_item_category_desc": "Cookiesthawpkgbky"
}, {
  "prod_id": "40017372",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Dm Presdnt 3640-262",
  "cs_item_category_desc": "Cigar Productstob"
}, {
  "prod_id": "153508",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Telera Roll Dough",
  "cs_item_category_desc": "Frozen Breadsbky"
}, {
  "prod_id": "178303",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Labrea T\u0026B Ciabatta Rl",
  "cs_item_category_desc": "Frozen Buns  Rollsbky"
}, {
  "prod_id": "291470",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Rd Brn Dp Dsh Pep Prsnl Pza",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "480744",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen - Seafood",
  "description": "Shrimp Meat",
  "cs_item_category_desc": "Frozen Shrimpmt"
}, {
  "prod_id": "316295",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Ht Pkt Sausage Egg \u0026 Cheese",
  "cs_item_category_desc": "Sandwichburritostrombolifr"
}, {
  "prod_id": "417026",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Tot Bfst Snk Bts Ssg Chs 40ct",
  "cs_item_category_desc": "Breakfast Itemsfr"
}, {
  "prod_id": "291426",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Random Weight - Frozen - Seafood",
  "description": "I/O-Norbest Trky Tom Frz 16-18",
  "cs_item_category_desc": "Turkeys  Frozenmt"
}, {
  "prod_id": "40016326",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Blk\u0026Mld Wine Wt 5pk 00129",
  "cs_item_category_desc": "Cigar Productstob"
}, {
  "prod_id": "40018124",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Skoal Long Cut Straight",
  "cs_item_category_desc": "Chewing Tobacco  Snufftob"
}, {
  "prod_id": "597867",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Random Weight - Frozen - Seafood",
  "description": "Wvm Beef Soup Bones",
  "cs_item_category_desc": "Beef Offalmt"
}, {
  "prod_id": "379176",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Oreo Ic Sw Mint 4ct",
  "cs_item_category_desc": "Ice Cream Noveltiesmulti Pkic"
}, {
  "prod_id": "66577",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Gg Creamed Spinach Sauced",
  "cs_item_category_desc": "Vegetablesfr"
}, {
  "prod_id": "456601",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Oreo Ice Cream Mint",
  "cs_item_category_desc": "Ice Cream Multi Servebulkic"
}, {
  "prod_id": "315429",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Stfr Meatloaf Family Size",
  "cs_item_category_desc": "Entreesfamily Sizefr"
}, {
  "prod_id": "214814",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "I/O-Bkrboy Cin Sgr Cke Dnut Hl",
  "cs_item_category_desc": "Frozen Donutsmuffinsbky"
}, {
  "prod_id": "290077",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Random Weight - Frozen - Seafood",
  "description": "I/O-Nb Frozen Hen 10/12lb",
  "cs_item_category_desc": "Turkeys  Frozenmt"
}, {
  "prod_id": "231850",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Stfr Stfd Pepp Ss",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "597879",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Random Weight - Frozen - Seafood",
  "description": "Wvm Beef Pipe Bone Bulk",
  "cs_item_category_desc": "Beef Offalmt"
}, {
  "prod_id": "537691",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "2bite Crml Toffee Scones",
  "cs_item_category_desc": "Frozen Pastrybky"
}, {
  "prod_id": "40021885",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Winston Red 100 Bx Lip",
  "cs_item_category_desc": "Cigs 100s And Nonfilter Kingstob"
}, {
  "prod_id": "415205",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "I/O-Rch P Cki Dgh Cndy Cc",
  "cs_item_category_desc": "Frozen Cookie Batterbky"
}, {
  "prod_id": "452546",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen - Seafood",
  "description": "B Yet 71/90 Ck Shrmp Tail On",
  "cs_item_category_desc": "Frozen Shrimpmt"
}, {
  "prod_id": "40104641",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Salem Gold Box Kings",
  "cs_item_category_desc": "Cigs 100s And Nonfilter Kingstob"
}, {
  "prod_id": "97526",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Cmf Tpt Brrts Chrz Egg",
  "cs_item_category_desc": "Sandwichburritostrombolifr"
}, {
  "prod_id": "545009",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Pills Sthrn Styl Biscuits",
  "cs_item_category_desc": "Breadrollsmuffinsfr"
}, {
  "prod_id": "538411",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Deli Exp Smoked Trky \u0026 Ched Sw",
  "cs_item_category_desc": "Frozen Delidl"
}, {
  "prod_id": "369262",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "B\u0026J Ic Ch Crml Ckdgh",
  "cs_item_category_desc": "Ice Cream Single Servepintsic"
}, {
  "prod_id": "21346",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Jj\u0027s Cherry Pie",
  "cs_item_category_desc": "Piesfr"
}, {
  "prod_id": "324004",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Crzy Czne Chckn Ptstckrs",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "298681",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Grtn Crsp Batr Fish Flt",
  "cs_item_category_desc": "Fishseafoodfr"
}, {
  "prod_id": "291590",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Dole All Natural Blueberries",
  "cs_item_category_desc": "Fruitsmoothie Mixfr"
}, {
  "prod_id": "464889",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Ff Chli Lvr Dg Jmb W Bgs 36 4z",
  "cs_item_category_desc": "Frozen Meatsmt"
}, {
  "prod_id": "318235",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Stfr Mac \u0026 Bf W/Toms",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "504675",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Random Weight - Frozen - Seafood",
  "description": "Frozen Ck Exports Cab",
  "cs_item_category_desc": "Frozen Meatsmt"
}, {
  "prod_id": "279302",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Kh Swt Rlls 12ct",
  "cs_item_category_desc": "Frozen Buns  Rollsbky"
}, {
  "prod_id": "40001854",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Camel Reg Nft Lip",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "193291",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Tatrkeg Cheese Bomb",
  "cs_item_category_desc": "Frozen Meatsmt"
}, {
  "prod_id": "538494",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Bnqt Bns Country Links",
  "cs_item_category_desc": "Frozen Meatsmt"
}, {
  "prod_id": "286128",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Bnqt Bns Original Patty",
  "cs_item_category_desc": "Pork Sausage  Frozenmt"
}, {
  "prod_id": "20072",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Msf Veggie Griller Crumbles",
  "cs_item_category_desc": "Vegetarianvegan Foodfr"
}, {
  "prod_id": "232391",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Ff Chicken Patties",
  "cs_item_category_desc": "Frozen Chickenmt"
}, {
  "prod_id": "306933",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Eggo Chocolate Chip Waffles",
  "cs_item_category_desc": "Breakfast Itemsfr"
}, {
  "prod_id": "85967",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Crvn Flv Icpp Rwb 20ct",
  "cs_item_category_desc": "Ice Cream Noveltiesmulti Pkic"
}, {
  "prod_id": "538110",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "C-2bite Choc Cpcke 12pk",
  "cs_item_category_desc": "Frozen Cakecupckchsecakebky"
}, {
  "prod_id": "84908",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Mc Shrimp Fajita",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "313322",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Tj Farms Select Shoestrings",
  "cs_item_category_desc": "Potatoespierogiesfr"
}, {
  "prod_id": "483116",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Simplot Smp Rte Crml Styl On",
  "cs_item_category_desc": "Pkg Heatservemt"
}, {
  "prod_id": "119319",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Jlb Prebaked Pecan Pie 8\"",
  "cs_item_category_desc": "Frozen Piesbky"
}, {
  "prod_id": "335083",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Gdhmr Fd Bars Sb Shrtck 6ct",
  "cs_item_category_desc": "Ice Cream Noveltiesmulti Pkic"
}, {
  "prod_id": "44062467",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Lcky Strk Menth Box",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "303081",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Pfc Pork Korean Noodle Bowl",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "122496",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Random Weight - Frozen - Seafood",
  "description": "Whle Fryer Frz",
  "cs_item_category_desc": "Frozen Chickenmt"
}, {
  "prod_id": "304438",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Mc Coconut Cream Pie",
  "cs_item_category_desc": "Piesfr"
}, {
  "prod_id": "317919",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Whtcst Chsbrgr Sldrs 6ct",
  "cs_item_category_desc": "Sandwichburritostrombolifr"
}, {
  "prod_id": "322750",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Hm Boneless Pork Rib Patties",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "298742",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Bnqt Classic Turkey Meal",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "325426",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "B Yet Choc Chip Ckie Dough Ic",
  "cs_item_category_desc": "Ice Cream Multi Servebulkic"
}, {
  "prod_id": "321402",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "B Yet Mntcc Ic",
  "cs_item_category_desc": "Ice Cream Multi Servebulkic"
}, {
  "prod_id": "290944",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Mc 4 Chs Lasagna",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "537333",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "I/O-Kim Bk Oreo Mini Cpcke 12c",
  "cs_item_category_desc": "Frozen Cakecupckchsecakebky"
}, {
  "prod_id": "370415",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "H Dazs Ic Brs Dlc De Lch 3ct",
  "cs_item_category_desc": "Ice Cream Noveltiesmulti Pkic"
}, {
  "prod_id": "293691",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "B Yet Fz Grape Juice 100%",
  "cs_item_category_desc": "Juicedrinkspriv Labfr"
}, {
  "prod_id": "298393",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Flavrpac Mixed Vegetables",
  "cs_item_category_desc": "Vegetablesfr"
}, {
  "prod_id": "49596",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "El Mont Sgntr Ldd Nch Chm",
  "cs_item_category_desc": "Pkg Heatservemt"
}, {
  "prod_id": "352996",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Kronos White Pita Bread",
  "cs_item_category_desc": "Frozen Breadsbky"
}, {
  "prod_id": "149002",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Prfct Fnsh Btrcrm",
  "cs_item_category_desc": "Toppingsicingbky"
}, {
  "prod_id": "290675",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Ff Buffl Brst Bites",
  "cs_item_category_desc": "Poultry  Frozenmt"
}, {
  "prod_id": "543331",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Blu Bny Ic Dbl Strwb",
  "cs_item_category_desc": "Ice Cream Multi Servebulkic"
}, {
  "prod_id": "296437",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Bnqt Ckn Nggt W M\u0026C",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "291357",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Rd Brn Clsc Crust Pza Spec Dlx",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "10660",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Msf Buf Chik Patties",
  "cs_item_category_desc": "Meatless Meat Productsfr"
}, {
  "prod_id": "31843",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Btrfng Ice Cream Bar 6 Count",
  "cs_item_category_desc": "Ice Cream Noveltiesmulti Pkic"
}, {
  "prod_id": "296286",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "B\u0026J Ic Sundae Chocolatta Chsck",
  "cs_item_category_desc": "Ice Cream Single Servepintsic"
}, {
  "prod_id": "634892",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Random Weight - Frozen - Seafood",
  "description": "73% Fine Ground Beef",
  "cs_item_category_desc": "Cs Ground Beefmt"
}, {
  "prod_id": "40000759",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "305\u0027s Full Flavor 100 Bx",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "319046",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Stfr Meatloaf",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "40001871",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Doral Gold 100 Box",
  "cs_item_category_desc": "Cigs 100s And Nonfilter Kingstob"
}, {
  "prod_id": "40021888",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Winston White 85 Bx Lip",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "292246",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Tllmk Ic Wc Rasp",
  "cs_item_category_desc": "Ice Cream Multi Servebulkic"
}, {
  "prod_id": "159544",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Choc Brwn Iced Fud",
  "cs_item_category_desc": "Frozen Browniessquaresbky"
}, {
  "prod_id": "531446",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Flavrpac Stew Vegetables",
  "cs_item_category_desc": "Vegetablesfr"
}, {
  "prod_id": "40021827",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Sport Menth 100 Box 01020",
  "cs_item_category_desc": "Cigs 100s And Nonfilter Kingstob"
}, {
  "prod_id": "52537",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "El Mont Nacho Cheese Taquito",
  "cs_item_category_desc": "Frozen Meatsmt"
}, {
  "prod_id": "300041",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Hsts Chocolate Cupck 8pk",
  "cs_item_category_desc": "Cakescheesecakesfr"
}, {
  "prod_id": "308788",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Invasn Chicken Fried Rice",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "249390",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Prm Prtn Prtn Wfl 10ct",
  "cs_item_category_desc": "Breakfast Itemsfr"
}, {
  "prod_id": "427039",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Bnqt Brn/Serv Bf Lnk11502",
  "cs_item_category_desc": "Pork Sausage  Frozenmt"
}, {
  "prod_id": "315892",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "B Yet Limeade",
  "cs_item_category_desc": "Juicedrinkspriv Labfr"
}, {
  "prod_id": "40003831",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Misty Grn 120 Bx Men",
  "cs_item_category_desc": "Cigs 100s And Nonfilter Kingstob"
}, {
  "prod_id": "302470",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Stfr Meat Lovers Lasagna",
  "cs_item_category_desc": "Entreesfamily Sizefr"
}, {
  "prod_id": "538510",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "El Mont Grn Chli Brrts 02309",
  "cs_item_category_desc": "Frozen Meatsmt"
}, {
  "prod_id": "302711",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Pfc Dan Dan Noodles Bwl W Pork",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "391939",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Bert Chicken Carbonara",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "326194",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Hm Pub Fav Chopped Beef Steak",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "415319",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "I/O-Rch P Cki Dgh Otml Rsn",
  "cs_item_category_desc": "Frozen Cookie Batterbky"
}, {
  "prod_id": "291215",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "B Yet Frz Bb Sup",
  "cs_item_category_desc": "Fruitsmoothie Mixfr"
}, {
  "prod_id": "324041",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "B\u0026J Chunky Monkey",
  "cs_item_category_desc": "Ice Cream Single Servepintsic"
}, {
  "prod_id": "40028401",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Lcky Strk Red Box",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "324483",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Aktchn Broccoli Pot Pie",
  "cs_item_category_desc": "Vegetarianvegan Foodfr"
}, {
  "prod_id": "588180",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Random Weight - Frozen - Seafood",
  "description": "Wvm Beef Honeycomb Tripe Diced",
  "cs_item_category_desc": "Frozen Meatsmt"
}, {
  "prod_id": "182843",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Invasn 29955 Ckn Fried Rce",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "40075651",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Nas Sky",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "44059166",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Marl Blk Gld Bx",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "371965",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "J\u0026J Sp Sft Prtzl Bts Jal Chdr",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "40011032",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Grizzly L/C Straight01886",
  "cs_item_category_desc": "Chewing Tobacco  Snufftob"
}, {
  "prod_id": "40005814",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "B\u0026H Dlx 100 Mn Bx Fl07306",
  "cs_item_category_desc": "Cigs 100s And Nonfilter Kingstob"
}, {
  "prod_id": "326062",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Dstk Ic Cones Van 8ct",
  "cs_item_category_desc": "Ice Cream Noveltiesmulti Pkic"
}, {
  "prod_id": "244177",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Tgif Chicken Wings Honey Bbq",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "214604",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Ed Gourmet Org Cheesecake",
  "cs_item_category_desc": "Piesfr"
}, {
  "prod_id": "165313",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Gnla Golden Dinner Roll Dough",
  "cs_item_category_desc": "Frozen Buns  Rollsbky"
}, {
  "prod_id": "390684",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "I/O-B\u0026J Nd Ic Cc Cki Dgh",
  "cs_item_category_desc": "Ice Cream Dairy Freeic"
}, {
  "prod_id": "368970",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Sdlcs Nd Vb Cnutmlk",
  "cs_item_category_desc": "Ice Cream Dairy Freeic"
}, {
  "prod_id": "30096",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "100 Grand Ic Bar 6ct",
  "cs_item_category_desc": "Ice Cream Noveltiesmulti Pkic"
}, {
  "prod_id": "314874",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "B Yet White Lemonade",
  "cs_item_category_desc": "Juicedrinkspriv Labfr"
}, {
  "prod_id": "184574",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Cafvly Trpl Choc Bundt Cke",
  "cs_item_category_desc": "Frozen Cakecupckchsecakebky"
}, {
  "prod_id": "544525",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "I/O-Dgn Cltc Pza Marg",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "296142",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Mich Salisbury Steak",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "40005438",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Newport Non Menthol 100 Bx",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "312411",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Mm Calcium Orange Juice",
  "cs_item_category_desc": "Juicedrinkslushsnow Conefr"
}, {
  "prod_id": "278790",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Mc Rtb Streusel Pie Strwb Rhub",
  "cs_item_category_desc": "Piesfr"
}, {
  "prod_id": "441781",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "C\u0026W Petite White Corn",
  "cs_item_category_desc": "Vegetablesfr"
}, {
  "prod_id": "315032",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "B Yet Vegetable Stir Fry",
  "cs_item_category_desc": "Vegetablespriv Labfr"
}, {
  "prod_id": "390094",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Blu Bny Mswrl Ic Cone Choc 8ct",
  "cs_item_category_desc": "Ice Cream Noveltiesmulti Pkic"
}, {
  "prod_id": "81816",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Crvn Flv Rnbw Pops Ocg 20ct",
  "cs_item_category_desc": "Ice Cream Noveltiesmulti Pkic"
}, {
  "prod_id": "294127",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Crvn Flv Pza Rsgcrst 3meat",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "289884",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Tllmk Ic Udderly Choc",
  "cs_item_category_desc": "Ice Cream Multi Servebulkic"
}, {
  "prod_id": "139940",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Pfc Chicken Dumplings",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "285286",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Tllmk Ic Cfe Alm Fdg",
  "cs_item_category_desc": "Ice Cream Multi Servebulkic"
}, {
  "prod_id": "390980",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Hc Cafe Stmr Ckn Pesto",
  "cs_item_category_desc": "Entrees Low Calhealthyfr"
}, {
  "prod_id": "150539",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Hills Mild Ital Ssg Brck",
  "cs_item_category_desc": "Smoked Sausagemt"
}, {
  "prod_id": "167384",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Choc Chip Cookie",
  "cs_item_category_desc": "Cookiesthawpkgbky"
}, {
  "prod_id": "40005798",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Marl Southern Cut Bx04246",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "325760",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "B Yet Rocky Road Ice Cream",
  "cs_item_category_desc": "Ice Cream Multi Servebulkic"
}, {
  "prod_id": "376630",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Atc Glcr Ice Cubes 7lb",
  "cs_item_category_desc": "Ice Cubesfr"
}, {
  "prod_id": "325805",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Smkr Uncrst Pb Strwb 4pk",
  "cs_item_category_desc": "Sandwichburritostrombolifr"
}, {
  "prod_id": "561518",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Jo Dblstf Tqts Bf Crn 12ct",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "160344",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "I/O-Rr Choc Pat Mini Cpcke",
  "cs_item_category_desc": "Frozen Cakecupckchsecakebky"
}, {
  "prod_id": "291668",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Jdean Hbrn Mt Lvr Chdr Moz",
  "cs_item_category_desc": "Pkg Heatservemt"
}, {
  "prod_id": "534364",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Zat Blackened Chicken Alfredo",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "85480",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Csm Cin Bttr Lf Cke 3/4",
  "cs_item_category_desc": "Frozen Cakecupckchsecakebky"
}, {
  "prod_id": "538210",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Rch P Rtf Pf Rnd Dnut Shl Rasp",
  "cs_item_category_desc": "Frozen Donutsmuffinsbky"
}, {
  "prod_id": "449824",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Random Weight - Frozen - Seafood",
  "description": "Beef Tripas Prepacked",
  "cs_item_category_desc": "Beef Offalmt"
}, {
  "prod_id": "528790",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Msf Grillers Prime Veg Burg",
  "cs_item_category_desc": "Meatless Frozen Meatmt"
}, {
  "prod_id": "415028",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Jsknr Hvnly Chs Strp Dnsh",
  "cs_item_category_desc": "Frozen Danishbky"
}, {
  "prod_id": "328796",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "B\u0026J Nd Chry Garcia",
  "cs_item_category_desc": "Ice Cream Dairy Freeic"
}, {
  "prod_id": "161642",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Egg Onion Roll",
  "cs_item_category_desc": "Frozen Breadsbky"
}, {
  "prod_id": "316079",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Stfr Chkn Enchiladas",
  "cs_item_category_desc": "Entreesfamily Sizefr"
}, {
  "prod_id": "177361",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Cafvly Grmt Lmn Poppy Mfn 4ct",
  "cs_item_category_desc": "Frozen Donutsmuffinsbky"
}, {
  "prod_id": "291914",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Tonys Pizzaria Style Pepperoni",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "304455",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Be Sf Broc Caul Crrt",
  "cs_item_category_desc": "Vegetablesfr"
}, {
  "prod_id": "327510",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Pop Sf Icpp Ocg 18ct",
  "cs_item_category_desc": "Ice Cream Noveltiesmulti Pkic"
}, {
  "prod_id": "415080",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Brill Marble Lf Cke 3/4",
  "cs_item_category_desc": "Frozen Cakecupckchsecakebky"
}, {
  "prod_id": "351967",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Crvn Flv Ic Cones Vp 8ct",
  "cs_item_category_desc": "Ice Cream Noveltiesmulti Pkic"
}, {
  "prod_id": "313479",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Eggo Homestyle Waffles",
  "cs_item_category_desc": "Breakfast Itemsfr"
}, {
  "prod_id": "295242",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Rmp Ss Peach Cobbler",
  "cs_item_category_desc": "Frozen Piesbky"
}, {
  "prod_id": "317301",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Stfr Mac/Cheese-Family Sz",
  "cs_item_category_desc": "Entreesfamily Sizefr"
}, {
  "prod_id": "40028609",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Lcky Strk Red 100 Box",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "40021829",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Sport Men Gld 100 Bx20006",
  "cs_item_category_desc": "Cigs 100s And Nonfilter Kingstob"
}, {
  "prod_id": "241412",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Tys Ckn Buff Strip",
  "cs_item_category_desc": "Tyson Chickenmt"
}, {
  "prod_id": "302094",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Tot Pizza Roll Trp Pep 50c",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "240276",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Hm Chicken Parmesan",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "288772",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Bynd Mt Burg Pty Plnt Base",
  "cs_item_category_desc": "Meatless Frozen Meatmt"
}, {
  "prod_id": "168931",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Gnla Petite Kaiser Roll Dough",
  "cs_item_category_desc": "Frozen Breadsbky"
}, {
  "prod_id": "83983",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Csm Lmnade Lf Cke 3/4",
  "cs_item_category_desc": "Frozen Cakecupckchsecakebky"
}, {
  "prod_id": "413922",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Kh Prtzl Bites Orig Swt Tub",
  "cs_item_category_desc": "Frozen Breadsbky"
}, {
  "prod_id": "167714",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Shell Lemon Filled",
  "cs_item_category_desc": "Toppingsicingbky"
}, {
  "prod_id": "40005843",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "L\u0026M Blue Nm Kg Bx",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "316039",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Oi Golden Twirls",
  "cs_item_category_desc": "Potatoespierogiesfr"
}, {
  "prod_id": "309788",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Eggo Bb Wfl Fampk",
  "cs_item_category_desc": "Breakfast Itemsfr"
}, {
  "prod_id": "312814",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Oi Golden Fries",
  "cs_item_category_desc": "Potatoespierogiesfr"
}, {
  "prod_id": "168895",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Raos Meat Lasagna",
  "cs_item_category_desc": "Dinnersentreesfr"
}, {
  "prod_id": "301586",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Tot Pza Rolls Trpl Meat 50ct",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "483150",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Simplot Rte Rstd Ppprs On Blnd",
  "cs_item_category_desc": "Pkg Heatservemt"
}, {
  "prod_id": "535334",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "Bibigo Mini Wonton Ckn Veg",
  "cs_item_category_desc": "Frozen Meatsmt"
}, {
  "prod_id": "415090",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Bakery - Frozen",
  "description": "Brill Ban Nut Lf Cke Slcd",
  "cs_item_category_desc": "Frozen Cakecupckchsecakebky"
}, {
  "prod_id": "40019777",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Nas Sky $1 Off Vap",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "40005787",
  "inventory_org_desc": "C\u0026S Gs Rr Repack - Cigarette",
  "whse_name": "North Houston, Tx (Repack )",
  "gl_description": "Tobacco",
  "description": "Marl A Red Label Kg Bx03680",
  "cs_item_category_desc": "Cigs Reg Filters And Filter Kingstob"
}, {
  "prod_id": "322149",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Mm Oj Country Style",
  "cs_item_category_desc": "Juicedrinkslushsnow Conefr"
}, {
  "prod_id": "317395",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Nyb Texas Toast Garlic",
  "cs_item_category_desc": "Breadrollsmuffinsfr"
}, {
  "prod_id": "144534",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Ts Lt Ic Van Pail",
  "cs_item_category_desc": "Ice Cream Multi Servebulkic"
}, {
  "prod_id": "334638",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Ice Cream",
  "description": "Snkr Ic Bar",
  "cs_item_category_desc": "Ice Cream Noveltiesmulti Pkic"
}, {
  "prod_id": "317380",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Frozen",
  "description": "Plt$30-Tot Pza 50ct 5 Vrty",
  "cs_item_category_desc": "Pizzasnacksonion Ringsfr"
}, {
  "prod_id": "400801",
  "inventory_org_desc": "C\u0026S Pnw Freezer",
  "whse_name": "Milwaukie, Or (Fdc)",
  "gl_description": "Meats - Net Weight - Frozen",
  "description": "I/O-Ff Buff Ckn Strips",
  "cs_item_category_desc": "Frozen Chickenmt"
}]


module.exports = filterData