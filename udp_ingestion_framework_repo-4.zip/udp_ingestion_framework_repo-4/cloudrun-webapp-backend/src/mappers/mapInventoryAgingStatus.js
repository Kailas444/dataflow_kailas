const { get: _get, map: _map } = require('lodash')

const mapInventoryAgingStatus = (rows) => {

    const inventoryAgingStatus = _map(rows, r => ({
        riskCategory: _get(r, 'risk_category'),
        inventoryQty: _get(r, 'Inv_qty'),
        inventoryValue: _get(r, 'Inv_value')
    }))

    return inventoryAgingStatus
}


module.exports = { mapInventoryAgingStatus }