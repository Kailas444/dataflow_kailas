const { get: _get, map: _map } = require('lodash')

const mapAgingBucket = (rows) => {

    return rows.map(row => {
        const newRow = {};
        for (const key in row) {
            if (row.hasOwnProperty(key)) {
                const camelKey = key.replace(/^_+/, '').replace(/_+([a-zA-Z])/g, (_, char) => char.toUpperCase()).replace(/^[A-Z]/, char => char.toLowerCase()); // Make first letter lowercase
                newRow[camelKey] = row[key];
            }
        }
        return newRow;
    });
}



module.exports = { mapAgingBucket }