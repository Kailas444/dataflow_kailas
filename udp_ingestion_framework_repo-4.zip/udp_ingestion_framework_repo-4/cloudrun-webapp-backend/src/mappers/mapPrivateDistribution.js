const { get: _get, map: _map } = require('lodash')

const mapPrivateDistribution = (rows) => {

    const privateDistributionQuantity = _map(rows, r => ({
        Private: _get(r, 'private_share') * 100,
        National: _get(r, 'national_share') * 100
    }))

    return privateDistributionQuantity
}



module.exports = { mapPrivateDistribution }