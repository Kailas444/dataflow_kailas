const { get: _get, map: _map } = require('lodash');
 
// ✅ Better camelCase converter
const toCamelCase = (str) => {
  return str
    .toLowerCase()
    .replace(/[_\s]+(.)?/g, (_, ch) => (ch ? ch.toUpperCase() : ''));
};
 
const mapInventoryDepartment = (rows) => {
  const inventoryDepartment = _map(rows, r => {
    // Explicit mappings for known fields
    const mapped = {
      inventoryDescription: _get(r, 'dept_desc'),
      inventoryValue: _get(r, 'inventory_value'),
      inventoryQty: _get(r, 'inventory_qty'),
      WOH: _get(r, 'WOH'),
      outOfStock: _get(r, 'OOS'),
      countofSKU: _get(r, 'SKU'),
      excessInventorySKU: _get(r, 'excess_inv_sku'),
      excessInventoryQty: _get(r, 'excess_inv_qty'),
      upcExpProd: _get(r, 'UPC_Exp_Prod'),
 
      l14inventoryValue: _get(r, 'l14_inventory_value'),
      l14inventoryQty: _get(r, 'l14_inventory_qty'),
      l14WOH: _get(r, 'l14_WOH'),
      l14outOfStock: _get(r, 'l14_OOS'),
      l14countofSKU: _get(r, 'l14_SKU'),
      l14excessInventorySKU: _get(r, 'l14_excess_inv_sku'),
      l14excessInventoryQty: _get(r, 'l14_excess_inv_qty'),
      l14upcExpProd: _get(r, 'l14_UPC_Exp_Prod'),
 
      l14inventoryValueChg: _get(r, 'l14_inventory_value_chg'),
      l14inventoryQtyChg: _get(r, 'l14_inventory_qty_chg'),
      l14WOHChg: _get(r, 'l14_WOH_chg'),
      l14outOfStockChg: _get(r, 'l14_OOS_chg'),
      l14countofSKUChg: _get(r, 'l14_SKU_chg'),
      l14excessInventorySKUChg: _get(r, 'l14_excess_inv_sku_chg'),
      l14excessInventoryQtyChg: _get(r, 'l14_excess_inv_qty_chg'),
      l14upcExpProdChg: _get(r, 'l14_UPC_Exp_Prod_chg'),
    };
 
    const mappedFields = new Set([
      'dept_desc',
      'inventory_value',
      'inventory_qty',
      'WOH',
      'OOS',
      'SKU',
      'excess_inv_sku',
      'excess_inv_qty',
      'UPC_Exp_Prod',
      'l14_inventory_value',
      'l14_inventory_qty',
      'l14_WOH',
      'l14_SKU',
      'l14_excess_inv_sku',
      'l14_excess_inv_qty',
      'l14_UPC_Exp_Prod',
       
      'l14_inventory_value_chg',
      'l14_inventory_qty_chg',
      'l14_WOH_chg',
      'l14_OOS_chg',
      'l14_SKU_chg',
      'l14_excess_inv_sku_chg',
      'l14_excess_inv_qty_chg',
      'l14_UPC_Exp_Prod_chg'
    ]);
 
    // ✅ Convert unmapped keys to camelCase
    for (const key in r) {
      if (!mappedFields.has(key)) {
        const camelKey = toCamelCase(key);
        mapped[camelKey] = r[key]?.value ?? r[key];
      }
    }
 
    return mapped;
  });
 
  return inventoryDepartment;
};
 
module.exports = { mapInventoryDepartment };