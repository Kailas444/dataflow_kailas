const { get: _get, map: _map } = require('lodash');

// ✅ Better camelCase converter
const toCamelCase = (str) => {
  return str
    .toLowerCase()
    .replace(/[_\s]+(.)?/g, (_, ch) => (ch ? ch.toUpperCase() : ''));
};

const mapInventoryDepartment = (rows) => {
  const inventoryDepartment = _map(rows, r => {
    // Explicit mappings for known fields
    const mapped = {
      inventoryDescription: _get(r, 'dept_desc'),
      inventoryValue: _get(r, 'inventory_value'),
      inventoryQty: _get(r, 'inventory_qty'),
      WOH: _get(r, 'WOH'),
      outOfStock: _get(r, 'OOS'),
      countofSKU: _get(r, 'SKU'),
      excessInventorySKU: _get(r, 'excess_inv_sku'),
      excessInventoryQty: _get(r, 'excess_inv_qty')
    };

    const mappedFields = new Set([
      'dept_desc',
      'inventory_value',
      'inventory_qty',
      'WOH',
      'OOS',
      'SKU',
      'excess_inv_sku',
      'excess_inv_qty'
    ]);

    // ✅ Convert unmapped keys to camelCase
    for (const key in r) {
      if (!mappedFields.has(key)) {
        const camelKey = toCamelCase(key);
        mapped[camelKey] = r[key]?.value ?? r[key];
      }
    }

    return mapped;
  });

  return inventoryDepartment;
};

module.exports = { mapInventoryDepartment };
