#!/bin/bash
set -e  # Exit on first error
