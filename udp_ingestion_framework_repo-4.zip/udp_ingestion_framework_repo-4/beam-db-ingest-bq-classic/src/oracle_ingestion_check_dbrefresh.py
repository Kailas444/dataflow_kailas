
"""
File Name: oracle_ingestion_check_dbrefresh.py

Description: 
This script is used for checking if the db refresh has happened before we load data from Oracle database
Classes:
    - PartitionQueriesGenerator: A class representing a DoFn for generating distinct partition values.
    - FetchDataFromOracle: A class representing a DoFn for fetching data from Oracle and writing to BigQuery.
    - OracleInputOptions: A class representing the pipeline options for Oracle input.
    - OracleConnectionPool: A class which will create connection pool.
Functions:
    - run_pipeline: Runs the Apache Beam pipeline for checking db refresh.

Created By: krishnar
Revision History:
    | Date       | Author    | Changes Made
    | 2024-12-02 | sbhavana  | Initial Code Checkin
"""
import apache_beam as beam
import sys
import argparse
import traceback
from ast import literal_eval

from apache_beam.options.pipeline_options import PipelineOptions
from oracle_helper_classes.transforms.config_parser_DoFn import ConfigParserDoFn
from oracle_helper_classes.transforms.check_db_refresh_DoFn import CheckDBRefreshDoFn
from oracle_helper_classes.pipeline_helper.oracle_connection_pool import OracleConnectionPool
from oracle_helper_classes.pipeline_helper.oracle_input_options import OracleInputOptions


import logging
from typing import Dict
logger = logging.getLogger(__name__)


def run_pipeline() -> None:
    """
    Run the Beam pipeline for Oracle data ingestion.
    Args:
        beam_args(list): List of command-line arguments for the Beam pipeline.
    Returns:
        None: This method does not return anything.
    """
    # Parse command-line arguments
    parser = argparse.ArgumentParser()

    _, beam_args = parser.parse_known_args()

    # Beam pipeline options
    pipeline_options = PipelineOptions(
        beam_args, 
        save_main_session=True,
        use_public_ips=False,
        autoscaling_algorithm='THROUGHPUT_BASED'
    )
    try:
        oracle_options = pipeline_options.view_as(OracleInputOptions)
        with beam.Pipeline(options=pipeline_options) as p:
                logging.info("===Apache Beam Run with pipeline options started===")

                # Step 1: Read and parse the configuration file
                config_file = (
                    p
                    | "Create config path" >> beam.Create([oracle_options.config_file_path])
                )

                config_parser = (
                    config_file
                    | "create config parser" >> beam.ParDo(ConfigParserDoFn(oracle_options.secret_project_id,oracle_options.dcname))
                )

                # Step 2: Check Db Refresh
                (
                    config_parser
                    | "Check DB Refresh" >> beam.ParDo(CheckDBRefreshDoFn(oracle_options.base_query))
                )                
           
        OracleConnectionPool.close_pool()
        logging.info("===Apache Beam Run completed successfully===")
    except Exception as exp:
        logging.error(f"Error occured in Apache Beam Run {exp}")
        logging.error("===ERROR: Apache Beam Run Failed===")
        logging.error(traceback.format_exc())

if __name__ == '__main__':
    # Run the pipeline with the provided arguments
    run_pipeline()
