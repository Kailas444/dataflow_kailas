
"""
File Name: oracle_ingestion_gcs.py

Description: 
This script is used for ingesting data from Oracle database into Parquet files using Apache Beam.
Classes:
    - PartitionQueriesGenerator: A class representing a DoFn for generating distinct partition values.
    - FetchDataFromOracle: A class representing a DoFn for fetching data from Oracle and writing to BigQuery.
    - OracleInputOptions: A class representing the pipeline options for Oracle input.
    - OracleConnectionPool: A class which will create connection pool.
Functions:
    - run_pipeline: Runs the Apache Beam pipeline for ingesting data from Oracle to Parquet.

Created By: krishnar
Revision History:
    | Date       | Author    | Changes Made
    | 2024-08-16 | krishnar  | Initial Framework
"""
import apache_beam as beam
import sys
import argparse
import traceback
from ast import literal_eval
from apache_beam.pvalue import AsSingleton
from apache_beam.options.pipeline_options import PipelineOptions
from apache_beam.io.textio import WriteToText
from oracle_helper_classes.transforms.config_parser_DoFn import ConfigParserDoFn
from oracle_helper_classes.transforms.partition_queries_generator_DoFn import PartitionQueriesGeneratorDoFn
from oracle_helper_classes.transforms.fetch_data_from_oracle_DoFn import FetchDataFromOracleDoFn
from oracle_helper_classes.pipeline_helper.oracle_connection_pool import OracleConnectionPool
from oracle_helper_classes.pipeline_helper.oracle_input_options import OracleInputOptions


import logging
from typing import Dict
logger = logging.getLogger(__name__)


def run_pipeline() -> None:
    """
    Run the Beam pipeline for Oracle data ingestion.
    Args:
        beam_args(list): List of command-line arguments for the Beam pipeline.
    Returns:
        None: This method does not return anything.
    """
    # Parse command-line arguments
    parser = argparse.ArgumentParser()

    _, beam_args = parser.parse_known_args()

    # Beam pipeline options
    pipeline_options = PipelineOptions(
        beam_args, 
        save_main_session=True,
        use_public_ips=False,
        autoscaling_algorithm='THROUGHPUT_BASED'
    )
    try:
        oracle_options = pipeline_options.view_as(OracleInputOptions)
        with beam.Pipeline(options=pipeline_options) as p:
                logging.info("===Apache Beam Run with pipeline options started===")

                # Step 1: Read and parse the configuration file
                config_file = (
                    p
                    | "Create config path" >> beam.Create([oracle_options.config_file_path])
                )

                config_parser = (
                    config_file
                    | "create config parser" >> beam.ParDo(ConfigParserDoFn(oracle_options.secret_project_id, oracle_options.dcname))
                )

                # Step 2: Get partition values based on the base query
                query = (
                    config_parser
                    | "Getting partition values" >> beam.ParDo(PartitionQueriesGeneratorDoFn(oracle_options.base_query, oracle_options.nbatches))
                )
                
                # Step 3: Fetch data from Oracle based on the generated query
                data = (
                    query
                    | "Fetching data from Oracle" >> beam.ParDo(FetchDataFromOracleDoFn(), element=AsSingleton(config_parser))
                )

                file_path_prefix = oracle_options.file_path_prefix
                data | 'Write to CSV' >> WriteToText(
                        file_path_prefix,
                        file_name_suffix='.csv.gz',
                        compression_type='gzip',
                        append_trailing_newlines=True,
                        skip_if_empty=True
                )
                
           
        OracleConnectionPool.close_pool()
        logging.info("===Apache Beam Run completed successfully===")
    except Exception as exp:
        logging.error(f"Error occured in Apache Beam Run {exp}")
        logging.error("===ERROR: Apache Beam Run Failed===")
        logging.error(traceback.format_exc())

if __name__ == '__main__':
    # Run the pipeline with the provided arguments
    run_pipeline()
