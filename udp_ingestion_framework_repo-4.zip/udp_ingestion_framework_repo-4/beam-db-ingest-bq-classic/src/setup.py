from setuptools import setup, find_packages

# with open('requirements.txt') as f:
#     required_packages = f.read().splitlines()

required_packages = [
    'oracledb==3.1.0',
    'google-cloud-storage==3.1.0',
    'google-cloud-secret-manager==2.23.3'
]    

setup(
    name='cs_db_ingestion',
    version='0.0.1',
    description='C&S - UDP - DB Ingestion Framework',
    install_requires=required_packages,
    packages=find_packages(),
    include_package_data=True,
    package_data={"cs_helper_class": ["*.yaml"]},
    author="sprithiv",
    author_email="sprithiv@cswg.com",
    maintainer="sprithiv",
    maintainer_email="sprithiv@cswg.com"
)
