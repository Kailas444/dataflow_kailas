
"""
File Name: oracle_ingestion_bq.py

Description: 
This script is used for ingesting data from Oracle database into Parquet files using Apache Beam.
Created By: krishnar
Revision History:
    | Date       | Author    | Changes Made
    | 2024-08-16 | krishnar  | Initial Framework
"""
import os
import apache_beam as beam
import argparse
import traceback
from apache_beam.pvalue import AsSingleton
from apache_beam.options.pipeline_options import PipelineOptions
from apache_beam.options.pipeline_options import GoogleCloudOptions
from apache_beam.io.gcp.bigquery import WriteToBigQuery
import sys
sys.path.append(".")
from oracle_helper_classes.transforms.config_parser_DoFn import ConfigParserDoFn
from oracle_helper_classes.transforms.partition_queries_generator_DoFn import PartitionQueriesGeneratorDoFn
from oracle_helper_classes.transforms.fetch_data_from_oracle_DoFn import FetchDataFromOracleDoFn
from oracle_helper_classes.pipeline_helper.oracle_connection_pool import OracleConnectionPool
from oracle_helper_classes.pipeline_helper.oracle_input_options import OracleInputOptions

import logging
logger = logging.getLogger(__name__)

def run_pipeline() -> None:
    """
    Run the Beam pipeline for Oracle data ingestion.
    Args:
        beam_args(list): List of command-line arguments for the Beam pipeline.
    Returns:
        None: This method does not return anything.
    """
    # Parse command-line arguments
    parser = argparse.ArgumentParser()
    _, beam_args = parser.parse_known_args()
    # Beam pipeline options
    pipeline_options = PipelineOptions(
        beam_args, 
        save_main_session=True,
        use_public_ips=False,
        num_workers=1,
        max_num_workers=4,
        machine_type='n2-standard-4',
        autoscaling_algorithm='THROUGHPUT_BASED'
    )

    try:
        #Ingestion Parameters 
        oracle_options = pipeline_options.view_as(OracleInputOptions)
        # Google Paramaters
        google_options = pipeline_options.view_as(GoogleCloudOptions)

        with beam.Pipeline(options=pipeline_options) as p:
            logging.info("===Apache Beam Run with pipeline options started===")

            # Step 1: Read and parse the configuration file
            config_file = (
                p
                | "Create config path" >> beam.Create([oracle_options.config_file_path])
            )

            config_parser = (
                config_file
                | "create config parser" >> beam.ParDo(ConfigParserDoFn(google_options.project))
            )

            # Extract target_table_name from config_parser
            def get_table_name(element):
                """Extracts the table name from the configuration."""
                logging.info(f"(table_name,{element['bq_table_name']})")
                return ("table_name", element['bq_table_name'])

            bq_table_name = (
                config_parser
                | "Get BQ Table Name" >> beam.Map(get_table_name)
            )

            bq_table_dict = beam.pvalue.AsDict(bq_table_name)             

            # Step 2: Get partition values based on the base query
            query = (
                config_parser
                | "Getting partition values" >> beam.ParDo(PartitionQueriesGeneratorDoFn(oracle_options.query_filter))
            )

            # Step 3: Fetch data from Oracle based on the generated query
            data = (
                query
                | "Fetching data from Oracle" >> beam.ParDo(FetchDataFromOracleDoFn(), element=AsSingleton(config_parser))
            )

            # table_name = oracle_options.target_table_name
            
            data | 'Write to BigQuery' >> WriteToBigQuery(
            table=lambda element, table_dict: table_dict['table_name'],
            table_side_inputs=(bq_table_dict,),
            create_disposition='CREATE_NEVER',
            write_disposition='WRITE_APPEND'
            )         

        OracleConnectionPool.close_pool()
        logging.info("===Apache Beam Run completed successfully===")


    except Exception as exp:
        logging.error(f"Error occured in Apache Beam Run {exp}")
        logging.error("===ERROR: Apache Beam Run Failed===")
        logging.error(traceback.format_exc())

if __name__ == '__main__':
    # Run the pipeline with the provided arguments
    run_pipeline()
