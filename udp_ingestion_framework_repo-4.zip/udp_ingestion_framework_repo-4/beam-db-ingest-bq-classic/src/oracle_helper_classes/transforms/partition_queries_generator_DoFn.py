"""
File Name: partition_queries_generator_DoFn.py
Description: This file contains the PartitionQueriesGeneratorDoFn helper class,
            which will create queries based on the partition field and batch field.
Created By: krishnar
Revision History:
    | Date       | Author    | Changes Made
    | 2024-08-16 | krishnar  | Initial Framework
"""
from typing import Any
import apache_beam as beam
from oracle_helper_classes.pipeline_helper.oracle_connection_pool import OracleConnectionPool
import logging
import re
logger = logging.getLogger(__name__)


class PartitionQueriesGeneratorDoFn(beam.DoFn):
    """
    A Beam DoFn class gets distinct partition value and batches the data to generate queries.
      Methods:
        process(element): Processes each element and generates final queries.
        get_final_query(element, partition_value): Generates the final query based on the element and partition value.
        finish_bundle(): Closes the connection pool.
    """
    def __init__(self,query_filter):
        self.query_filter = query_filter
        self.base_query = None
        self.query_template = None
        self.source_table = None
        self.partition_column = None
        self.nbatches= None
        pass


    def check_count(self, connection, element):
        """
        This function will check the table having data for the given query or not.
        If table doesnt have the data it will throw error
        Args:
            connection (obj): oracle connection
            query (str): base query to fetch data
            element (dict): The element containing the necessary parameters for the query execution.
        """
        try:
            query = f"select count(*) from {element['source_table_name']}"    
            where_clause = re.search(r'WHERE\s+(.+)', self.base_query, re.IGNORECASE)
            condition = None
            
            if where_clause:
                condition = f" where {where_clause.group(1)}  "
                

            if self.query_filter:
                condition = f"{condition} AND {self.query_filter} " if condition else f" where {self.query_filter} "

            query = f"""{query} {condition}""" if condition else query
            logger.info("Query to check the record count in the source table: %s", query)
            with connection.cursor() as cursor:
                cursor.execute(query)
                count = cursor.fetchall()[0][0]
                logger.info("Record count in the source for given query is %s", str(count))
            if count>0:
                return True
            return False
        except Exception as exp:
            logger.error("An unexpected error occurred: %s", str(exp))
            raise
            

    def process(self, element: dict) -> Any:
        """
        Generate queries based on partition column and batches
        Args:
            element (dict): The element to be processed.
        Yields:
            str: The final query generated for each batch.
        """
        try:
            self.query_filter = self.query_filter.get()
            self.base_query = element['query']
            self.source_table = element['source_table_name']   
            self.partition_column = element['partition_column']  
            self.nbatches = int(element['n_batches']) if int(element['n_batches']) >= 0 else 0
            
            connection = OracleConnectionPool.acquire_connection(element)
            if self.check_count(connection, element):
                # Only process if check_count returns True
                distinct_values = self._get_distinct_values(connection, element)
                for value in distinct_values:
                    query = self.get_final_query(element, value)
                    inter = 'AND' if "where" in query.lower() else 'WHERE'

                    if self.query_filter:
                        query = f"{query} {inter} {self.query_filter}"
                        inter = 'AND'
                    
                    if self.nbatches is not None:
                       logger.info(f"Number of bactches from the pipeline options is being used") 
                    if self.nbatches <=0:
                        logger.info(f"Number of batches is 0, so skipping the further steps. "
                        f"Query passed to fetch data from Oracle: {query}")
                        yield query
                    for batch in range(self.nbatches):
                        final_query = f"{query} {inter} MOD(ORA_HASH({element['batch_columns']}),{self.nbatches}) = {batch}"
                        logger.info(f"Query passed to fetch data from oracle {final_query}")
                        yield final_query
            else:
                # Log if no data found and skip further processing
                logger.info("No data present in the source table for the given query %s", self.base_query)

        except Exception as exp:
            logger.error("Error occrued while executing the process operation %s", str(exp))
            raise exp
        finally:
            OracleConnectionPool.release_connection(connection)

    def _get_distinct_values(self, connection, element):
        """Get distinct partition values based on the partition column."""
        if self.partition_column:
            self.query_template = f"SELECT DISTINCT {self.partition_column} FROM {self.source_table}"
            logger.info("partition query template is %s", self.query_template)
            with connection.cursor() as cursor:
                cursor.execute(self.query_template)
                distinct_values = cursor.fetchall()
                logger.info(f"Distinct partition for the table:{self.source_table} and partiton column:{self.partition_column} are {distinct_values}")
                return distinct_values
        return ['no_partition']

        
    def get_final_query(self, element: dict, partition_value: list) -> str:
        """
        Generates the final query based on the given element and partition value.
        Args:
        - element(dict): A dictionary containing information about the partition column and filter.
        - partition_value(list): A list of partition values.
        Returns:
        - str: The final query string.
        """

        try:
            conditions = []
            
            if element['partition_column']:
                inter = 'AND' if "where" in self.base_query.lower() else 'WHERE'
                if not element['partition_filter']:
                    raise ValueError("Partition filter is required when a partition column is provided.")
                for column, value, filter_condition in zip(self.partition_column.split(','),
                                                            partition_value,
                                                            element['partition_filter']):

                    partition_condition = filter_condition.format(partition_value=value)
                    conditions.append(f"{column} = {partition_condition}")
                where_clause = " AND ".join(conditions)
                query = f"{self.base_query} {inter} {where_clause}"
            else:
                query = f"{self.base_query}"
            return query
        except Exception as exp:
            logger.error("Error occrued while executing the get_final_query operation %s", str(exp))
            raise exp

