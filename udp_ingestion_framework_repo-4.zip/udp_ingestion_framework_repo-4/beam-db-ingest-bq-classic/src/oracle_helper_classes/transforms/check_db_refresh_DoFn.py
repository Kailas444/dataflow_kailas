"""
File Name: partition_queries_generator_DoFn.py
Description: This file contains the PartitionQueriesGeneratorDoFn helper class,
            which will create queries based on the partition field and batch field.
Created By: krishnar
Revision History:
    | Date       | Author    | Changes Made
    | 2024-08-16 | krishnar  | Initial Framework
"""
from typing import Any
import apache_beam as beam
import logging
from oracle_helper_classes.pipeline_helper.oracle_connection_pool import OracleConnectionPool
logger = logging.getLogger(__name__)


class CheckDBRefreshDoFn(beam.DoFn):
    """
    A Beam DoFn class to check if the db has refreshed.
      
    """
    def __init__(self, base_query):
        self.base_query = base_query

    def check_db_refresh(self, connection, element):
        """
        This function will check the table having data for the given query or not.
        If table doesnt have the data it will throw error
        Args:
            connection (obj): oracle connection
            query (str): base query to fetch data
            element (dict): The element containing the necessary parameters for the query execution.
        """
        try:

            logger.info("Query to check the db refresh: %s", self.base_query.get())
            with connection.cursor() as cursor:
                cursor.execute(self.base_query.get())
                result = cursor.fetchall()[0]
                max_timestamp = result[0]
                datetime_now = result[1]
                time_difference = result[2]
                logger.info(f"The time difference between last_update_date: {max_timestamp} and current_time:{datetime_now} is {time_difference} minutes")
            if time_difference >= 30:
                return False
            return True
        except Exception as exp:
            logger.error("An unexpected error occurred: %s", str(exp))
            raise
            

    def process(self, element: dict) -> Any:
        """
        Generate queries based on partition column and batches
        Args:
            element (dict): The element to be processed.
        Yields:
            str: The final query generated for each batch.
        """
        try:
            connection = OracleConnectionPool.acquire_connection(element)
            if self.check_db_refresh(connection, element):
               logger.info("The data has refershed in stand by DB in the last 30 minutes")
            else:
                # Log if no data found and skip further processing
                logger.error("The data has not refreshed in the stand by DB in last 30 minutes")
                raise SystemExit()
        except Exception as exp:
            logger.error("Error occrued while executing the process operation %s", str(exp))
            raise exp
        finally:
            OracleConnectionPool.release_connection(connection)

    