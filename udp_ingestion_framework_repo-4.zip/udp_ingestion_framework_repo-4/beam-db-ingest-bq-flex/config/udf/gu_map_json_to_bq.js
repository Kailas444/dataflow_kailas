function process(inJson) {
    // Parse the input JSON string
    var obj = JSON.parse(inJson);

    // Initialize the output object for BigQuery
    var output = {};

    // Direct mapping/extraction
    output.trans_date = obj.column_0
    output.trans_time = obj.column_1
    output.terminal_code = obj.column_2
    output.cashier_code = obj.column_3
    output.sequence = obj.column_4
    output.key_function = obj.column_5
    output.key_function_id = obj.column_6
    output.department_code = obj.column_7
    output.price_multiple = obj.column_8
    output.price = obj.column_9
    output.quantity = obj.column_10
    output.weight = obj.column_11
    output.ext_sales = obj.column_12
    output.tendered_amount = obj.column_13
    output.receipt_flags = obj.column_14
    output.account = obj.column_15
    output.category = obj.column_16
    output.sub_category = obj.column_17
    output.sub_department = obj.column_18
    output.price_type = obj.column_19
    output.fs_discount = obj.column_20
    output.premium = obj.column_21
    output.frequent_shopper_id = obj.column_22
    output.sales_total = obj.column_23
    output.tax_total = obj.column_24
    output.transaction_total = obj.column_25
    output.total_discounts = obj.column_26
    output.total_points = obj.column_27
    output.cash_back = obj.column_28
    output.transaction_code = obj.column_29
    output.cost = obj.column_30
    output.customer_id = obj.column_31
    output.store_number = obj.column_32
    output.alternate_id = obj.column_33
    output.loyalty_points = obj.column_34
    output.extra_filler = obj.column_35
    output.source_file = obj.source_file
    output.sourcefile_ts = obj.timestamp
    output.file_record_count = String(obj.File_record_count)
    output.filesize_bytes = String(obj.FileSize_bytes)

    // Return the transformed object as a JSON string
    return JSON.stringify(output);
}