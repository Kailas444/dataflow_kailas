"""
File Name: oracle_input_options.py
Description: This file contains the OracleInputOptions helper class.
Created By: sprithiv
Revision History:
    | Date       | Author    | Changes Made
    | 2025-06-16 | sprithiv  | Initial Framework
"""

from apache_beam.options.pipeline_options import PipelineOptions
import logging

logger = logging.getLogger(__name__)

class OracleInputOptions(PipelineOptions):
    """
    A helper class for parsing the oracle pipeline options passed in the parameter
    """

    @classmethod
    def _add_argparse_args(cls, parser: object) -> None:
        """
        Add argparse arguments for Oracle input options.
        Args:
            parser(object): The argparse parser object.
        Returns:
            None: This method does not return anything.
        """ 
        try:      
            parser.add_value_provider_argument("--config_file_path",
                                                help="GCS Location where the config file is placed")
            parser.add_value_provider_argument("--query_filter",
                                                help="Query Filter to fetch the data from Database")
        except Exception as exp:
            logger.error("Error occrued while executing the _add_argparse_args operation %s", str(exp))
            raise exp

