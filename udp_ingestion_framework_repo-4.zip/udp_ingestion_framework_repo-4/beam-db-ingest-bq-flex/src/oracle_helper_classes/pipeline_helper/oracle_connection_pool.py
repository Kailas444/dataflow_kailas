"""
File Name: oracle_connection_pool.py
Description: This file contains the OracleConnectionPool helper class.
Created By: krishnar
Revision History:
    | Date       | Author    | Changes Made
    | 2024-08-16 | krishnar  | Initial Framework
"""

import oracledb
import logging
logger = logging.getLogger(__name__)

class OracleConnectionPool:
    """
    A helper class for creating Oracle connection pool, connection
    """
    _instance = None

    def __init__(self):
        if OracleConnectionPool._instance is not None:
            raise TypeError("This class is a singleton. Use get_pool() to get the instance.")
    
    @classmethod
    def get_pool(cls: object, element: dict) -> object:  
        """
        Process the given element to create an Oracle connection pool.
        Args:
             element (dict): A dictionary containing the following keys:
                - 'username' (str): The username for the Oracle connection.
                - 'password' (str): The password for the Oracle connection.
                - 'url' (str): The URL for the Oracle connection.
                - 'min_pool_size' (int): The minimum size of the connection pool.
                - 'max_pool_size' (int): The maximum size of the connection pool.
                - 'increment' (int): The increment size of the connection pool.
        Returns:
            pool: The Oracle connection pool.
        """
        try:
            if cls._instance is None:
                mode = element.get('thick_mode',False)

                if mode:
                    oracledb.init_oracle_client()
                    logger.info("Enabled Thick Mode")
                else:
                    logger.info("Enabled Thin Mode")
                                    
                cls._instance = oracledb.create_pool(user = element['username'],
                                        password=element['password'],
                                        dsn=element['url'],
                                        min = element['min_pool_size'],
                                        max = element['max_pool_size'],
                                        increment = element['increment']
                                        )
                logger.info("Connection pool was requested and created")
            else:
                logger.info("Using existing connection pool")
            return cls._instance
        except Exception as exp:
            logger.error("Error occrued while executing the get_pool operation %s", str(exp))
            raise exp

    @classmethod
    def acquire_connection(cls: object,config_dict: dict) -> object:
        """
        Acquires a connection from the connection pool.
        Args:
            config_dict(dict): A dictionary containing the configuration details.
        Returns:
            object: The acquired connection from the pool.
        """
        try:
            pool = cls.get_pool(config_dict)
            connection = pool.acquire()
            logger.info("Connection acquired from the pool")
            return connection
        except Exception as exp:
            logger.error("Error occrued while executing the get_pool operation %s", str(exp))
            raise exp
            

    @classmethod
    def release_connection(cls: object, connection: object) -> None:
        """
        Releases a connection back to the connection pool.
        Args:
            connection(object): The connection object to be released.
        Returns:
            None: This method does not return anything.
        """
        try:
            pool = cls._instance
            if pool:
                pool.release(connection)
                logger.info("Connection released back to the pool")
        except Exception as exp:
            logger.error("Error occrued while executing the release_connection operation %s", str(exp))
            raise exp
        

    @classmethod
    def close_pool(cls: object) -> None:
        """
        Closes the connection pool.
        Args:
            cls(object): The class object.
        Returns:
            None: This method does not return anything.
        """
        try:
            if cls._instance:
                cls._instance.close()
                logger.info("Connection pool closed")
                cls._instance = None
        except Exception as exp:
            logger.error("Error occrued while executing the close_pool operation %s", str(exp))
            raise exp
        