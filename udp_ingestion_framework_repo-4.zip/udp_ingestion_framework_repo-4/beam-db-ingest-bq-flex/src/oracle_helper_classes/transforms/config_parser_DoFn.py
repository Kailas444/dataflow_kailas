"""
File Name: config_parser_DoFn.py
Description: This file contains the ConfigParserDoFn helper class.
Created By: sprithiv
Revision History:
    | Date       | Author    | Changes Made
    | 2025-06-16 | sprithiv  | Initial Framework
"""
import yaml
import json
import os
import importlib
import re
from typing import Any, Dict
from apache_beam import DoFn
from google.cloud import secretmanager
from google.cloud import storage
import logging

logger = logging.getLogger(__name__)

class ConfigParserDoFn(DoFn):
    """
    A class that parses configuration data and retrieves Oracle parameters.
    Methods:
        get_oracle_parameter(config_dict: dict) -> dict:
        validate_json_data_types(json_data: Dict[str, Any]) -> bool:
        download_config_data_from_gcs(config_file_path: str) -> dict:
        get_config_data(config_file_path: str) -> dict:
        process(config_file_path: Any):
    """
    def __init__(self, project_id):
        self.project_id = project_id
        
    def get_oracle_parameter(self, config_dict:dict) -> dict:
        """
        Retrieves the Oracle parameters from the secret manager and parses the config to update the config_dict.
        Args:
            config_dict (dict): The dictionary containing the configuration parameters and secret parameters.
        Returns:
            dict: The updated config_dict with the Oracle parameters.
        """
        try:
            client = secretmanager.SecretManagerServiceClient()
            secret_project_id = config_dict.get("projec_id",self.project_id) 
            secret_path = f"projects/{secret_project_id}/secrets/{config_dict['secret_name']}/versions/latest"
            logger.info(f"Secret path is generated{secret_path}")    

            response = client.access_secret_version(name=secret_path)
            secret = response.payload.data.decode('UTF-8')
            logger.info("Secret is retrived from secret manager")

            secret_dict = json.loads(secret)
            url = f"{secret_dict['host']}:{secret_dict['port']}/{secret_dict['service']}"

            logger.info("credentials formed")

            return {
                'username': secret_dict['username'],
                'password': secret_dict['password'],
                'url':url                
            }
        except Exception as exp:
            logger.error("Error occrued while executing the get_oracle_parameter operation %s", str(exp))
            raise exp

    def validate_json_data_types(self, json_data: Dict[str, Any]) -> bool:
        """
        Validate the data types of specific keys in the JSON data.

        Args:
            json_data (dict): The JSON data to validate.

        Returns:
            bool: True if all validations pass, False otherwise.
        """
        try:
            expected_types = {
                'array_size': int,
                'max_pool_size': int,
                'source_table_name': str,
                'db_secret': dict,
                'batch_columns': str,
                'n_batches': int
            }
            # checking if partition column is in configuration parameter
            # and validating its type
            if json_data['partition_column']:
                if not isinstance(json_data['partition_column'], str):
                    logger.error("Validation failed: Key '%s' should be of type comma seperated columns in a string, but got '%s'",
                                    'partition_column',
                                     type(json_data['partition_column']).__name__)
                    return False
                if not isinstance(json_data['partition_filter'], list):
                    logger.error("Validation failed: Key '%s' should be of type list, but got '%s'",
                                    'partition_filter',
                                     type(json_data['partition_filter']).__name__)
                    return False

            for key, expected_type in expected_types.items():
                if key in json_data:
                    if not isinstance(json_data[key], expected_type):
                        logger.error("Validation failed: Key '%s' should be of type '%s', but got '%s'",
                                    key, expected_type.__name__, type(json_data[key]).__name__)
                        return False
                else:
                    logger.error("Validation failed: Key '%s' is missing from the JSON data.", key)
                    return False


            return True
        except Exception as exp:
            logger.error("Error occrued while executing the validate_json_data_types operation %s", str(exp))
            raise exp



    def download_config_data_from_gcs(self, config_file_path: str) -> dict:
        """
        Downloads the configuration data from Google Cloud Storage and returns it as a dictionary.
        Args: config_file_path (str): The path to the configuration file in Google Cloud Storage.
        Returns: dict: The configuration data as a dictionary.
        Raises: FileNotFoundError: If the specified file path does not exist.
        """
        try:
            # Create a client to interact with GCP Cloud Storage
            client = storage.Client()

            # Get the bucket and blob names from the config_file_path
            bucket_name = config_file_path.split("/")[2]
            blob_name = "/".join(config_file_path.split("/")[3:])

            # Get the blob object
            bucket = client.get_bucket(bucket_name)
            blob = bucket.blob(blob_name)

            if blob.exists():
                # Download the file as a string
                config_yaml_str = blob.download_as_text()

                # Parse the YAML string into a dictionary
                config_data_dict = yaml.safe_load(config_yaml_str)
            else:
                raise FileNotFoundError(f"The specified file path({config_file_path}) does not exist.")

            return config_data_dict

        except Exception as exp:
            logger.error("Error occrued while executing the download_config_data_from_gcs operation %s", str(exp))
            raise exp

    def get_config_data(self, config_file_path: str) -> dict:
        """
        Retrieves the configuration data from the specified file path.
        Args: config_file_path (str): The path to the configuration file.
        Returns: dict: The configuration data as a dictionary.
        Raises: FileNotFoundError: If the specified file path does not exist.
        """
        try:
            config_data_dict = None
            if str(config_file_path).startswith("gs"):
                config_data_dict = self.download_config_data_from_gcs(config_file_path)
            else:
                if os.path.exists(str(config_file_path)):
                    # Read the YAML file from local file system
                    with open(str(config_file_path), "r") as file:
                        config_data_dict = yaml.safe_load(file)
                else:
                    raise FileNotFoundError(f"The specified file path({config_file_path}) does not exist.")
            logger.info("Config File read Successfully")
            return config_data_dict

        except Exception as exp:
            logger.error("Error occrued while executing the get_config_data operation %s", str(exp))
            raise exp

    def process(self, config_file_path: Any):
        """
        Process the configuration dictionary and yield tagged outputs based on the input and output values.
        Args: config_dict (dict): The configuration dictionary containing input and output values.
        Yields: pvalue.TaggedOutput: Tagged outputs based on the input and output values.
        """
        try:
            passed_config_file_path = config_file_path.get()
            # self.project_id = self.project_id.get()
            if passed_config_file_path:
                config_dict = self.get_config_data(passed_config_file_path)
                logger.info(f"config dict is generated {config_dict}")    
                if config_dict["input"].upper() == "ORACLE":
                    if not self.validate_json_data_types(config_dict):
                        raise ValueError("Validation failed: Some of the keys are not present or incorrect in config_dict.")
                    config_dict.update(self.get_oracle_parameter(config_dict['db_secret']))

                
                if config_dict["input"].upper() == "MSSQL":
                    if not self.validate_json_data_types(config_dict):
                        raise ValueError("Validation failed: Some of the keys are not present or incorrect in config_dict.")
                    # config_dict = self.get_oracle_parameter(config_dict)                

                yield config_dict
                
                    
        except Exception as exp:
            logger.error("Error occrued while executing the process operation %s", str(exp))
            raise exp
            