"""
File Name: fetch_data_from_oracle_DoFn.py
Description: This file contains the FetchDataFromOracleDoFn helper class,
            which fetches data from Oracle database.
Created By: sprithiv
Revision History:
    | Date       | Author    | Changes Made
    | 2025-06-16 | sprithiv  | Initial Framework
"""
import apache_beam as beam
import oracledb
from oracle_helper_classes.pipeline_helper.oracle_connection_pool import OracleConnectionPool
from datetime import datetime
import logging
logger = logging.getLogger(__name__)

class FetchDataFromOracleDoFn(beam.DoFn):
    """
    A Beam DoFn class that fetches data from Oracle database and writes it to BigQuery.
    Methods:
        process(query, element): Fetches data from Oracle database and yields 
        it as dictionaries or string based on sink type
    """

    def __init__(self):
        self.partition_column = None
        self.source_table_name = None
        
    def process(self, query: str, element: dict):
        """
        Executes the given query using the provided element and returns the result as a generator of dictionaries.
        Args:
            query (str): The SQL query to be executed.
            element (dict): The element containing the necessary parameters for the query execution.
        Yields:
            dict: A dictionary representing each row of the query result, with column names as keys and row values as values.
        """
        # Function to covert all values to string
        def output_type_handler(cursor: object, metadata):
            return cursor.var(oracledb.DB_TYPE_VARCHAR, arraysize=cursor.arraysize,encoding_errors="ignore")
        
        try:
            connection = OracleConnectionPool.acquire_connection(element)
            
            with connection.cursor() as cursor:
                start_time = datetime.now()
                logger.info(f"Cursor opeend for query: {query} at {start_time}")
                cursor.arraysize = element['array_size']
                cursor.prefetchrows = element['prefetch_rows']
                cursor.outputtypehandler = output_type_handler
                try:
                    cursor.execute(query)
                    columns = [col[0].lower() for col in cursor.description]
                    if element['sink_type'] == 'BQ' or element['sink_type'] == 'GCS':
                        nullmarker = element.get('nullmarker')
                        if nullmarker is not None:
                            for row in cursor:
                                yield {col: (None if val == nullmarker else str(val)) for col, val in zip(columns, row)}
                        else:
                            for row in cursor:    
                                yield dict(zip(columns, row))
                    else:
                        delimiter = element.get('delimiter', '|')
                        quotechar = element.get('quotechar', '')
                        nullmarker = element.get('nullmarker', '^')
                        logger.info(f"delimiter:'{delimiter}' quotechar:'{quotechar}' nullmarker:{nullmarker}")
                        for row in cursor:
                            row_str = delimiter.join(f'{quotechar}{str(value) if value is not None else nullmarker}{quotechar}' for value in row)
                            yield row_str
                except Exception as exp:
                    logger.error(f"Error during query execution in cusrsor: {exp}")
                    raise
        except Exception as exp:
            logger.error("Error occrued while executing the process operation while fetching data from oracle %s",
                          str(exp))
            raise exp
        
        finally:
            end_time = datetime.now()
            logger.info(f"End time for processing query: {end_time}")
            logger.info(f"Total time taken to process the query: {end_time-start_time}")
            logger.info(f"completed query is {query}")
            OracleConnectionPool.release_connection(connection)