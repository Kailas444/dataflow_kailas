#!/bin/bash
set -e  # Exit on first error

# --- Get script directory so paths work regardless of where script is run from ---
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC_DIR="$(cd "${SCRIPT_DIR}/../src" && pwd)"

# Read environment argument
ENV="$1"

if [[ -z "$ENV" ]]; then
  echo "ERROR: No environment specified. Usage: $0 <dev|prod>"
  exit 1
fi

# Set project & job file based on environment
if [[ "$ENV" == "prod" ]]; then
  PROJECT="gc-proj-udp-dev-54a3"
  BUCKET="gc-us-gcs-udp-prd"
elif [[ "$ENV" == "dev" ]]; then
  PROJECT="gc-proj-udp-dev-54a3"
  BUCKET="gc-us-gcs-udp-dev"
else
  echo "ERROR: Invalid environment '$ENV'. Use 'dev' or 'prod'."
  exit 1
fi

REGION="us-east4"
REPO="udp-cswg-dckr-artreg"
IMAGE_NAME="beam-db-ingest-bq"
TEMPLATE_NAME="beam_db_ingest_bq_flex_template.json"
METADATA="beam_db_ingest_bq_flex_metadata.json"

echo "Using project: $PROJECT"
echo "Source directory: $SRC_DIR"
echo "Script directory: $SCRIPT_DIR"
echo "Using Region: $REGION"
echo "Using Repo: $REPO"
echo "Image Name: $IMAGE_NAME"
echo "Bucket Name: $BUCKET"
echo "Template File Name: $TEMPLATE_NAME"
echo "Metadata File Name: $METADATA"

read -p "Press Enter to continue or Ctrl+C to cancel..."

echo "Building local Image"
docker build --progress=plain -f "${SRC_DIR}/Dockerfile" -t ${IMAGE_NAME} "${SRC_DIR}"

echo "Tagging Image"
docker tag ${IMAGE_NAME} ${REGION}-docker.pkg.dev/${PROJECT}/${REPO}/${IMAGE_NAME}

echo "Pushing Image to Repo"
docker push ${REGION}-docker.pkg.dev/${PROJECT}/${REPO}/${IMAGE_NAME}

read -p "Press Enter to Create Flex Template or Ctrl+C to cancel..."
echo "Creating Flex Template"
gcloud dataflow flex-template build gs://${BUCKET}/dataflow/flex/template/${TEMPLATE_NAME} \
--image ${REGION}-docker.pkg.dev/${PROJECT}/${REPO}/${IMAGE_NAME} \
--sdk-language PYTHON \
--metadata-file ../metadata/${METADATA} \
--project ${PROJECT}

echo "Deployment complete."
